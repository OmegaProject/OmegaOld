/**
 * File: InfoManager.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef InfoManager_h
#define InfoManager_h

#include "DSPEElements.h"
#include <time.h>

/* Collected info ids */
typedef enum infoID {
	infoIDCount
} infoID;

#ifdef __cplusplus
extern "C" {
#endif

/**
 * InfoManager_writeInfo function
 */
void infoManager_writeInfo(const DSPEElement *element, const char *info, ...);

/**
 * InfoManager_logInfo function
 */
void infoManager_logInfo(const DSPEElement *element, const char *info, ...);

/**
 * InfoManager_collectAndWriteInfo function
 */
void infoManager_collectAndWriteInfo(const DSPEElement *element, const infoID id, const unsigned int increment);

/**
 * InfoManager_collectAndLogInfo function
 */
void infoManager_collectAndLogInfo(const DSPEElement *element, const infoID id, const unsigned int increment);

/**
 * InfoSupport_getCollectedInfoString function
 */
const char* infoSupport_getCollectedInfoString(const infoID id);

/**
 * InfoSupport_getCurrentTime function
 */
clock_t infoSupport_getCurrentTime();

/**
 * InfoSupport_getMilliseconds function
 */
double infoSupport_getMilliseconds(clock_t ticks);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
