/**
 * File: ThreadManager.h
 *
 * @author Loris
 * @created Thu May 26 10:23:46 CEST 2011
 */
#ifndef ThreadManager_h
#define ThreadManager_h

#include "DSPEElements.h"

#define MIN_NUM_THREADS 1#define MAX_NUM_THREADS 1
#define THREAD_ROUTINE_LPART void*
#define THREAD_ROUTINE_ARGS void *args
#define THREAD_ROUTINE_RETURN return NULL;
#define CREATE_THREAD_ROUTINE void* (*threadRoutine) (void*)

#ifdef __cplusplus
extern "C" {
#endif

/**
 * ThreadManager_createThread function
 * Create and start a thread
 */
void* threadManager_createThread(const DSPEElement *element, CREATE_THREAD_ROUTINE, THREAD_ROUTINE_ARGS);

/**
 * ThreadManager_waitThread function
 * The calling thread is suspended until the thread passed as
 * argument is terminated.
 */
void threadManager_waitThread(const DSPEElement *element, void *thread);

/**
 * ThreadManager_destroyThread function
 */
void threadManager_destroyThread(const DSPEElement *element, void *thread);

/**
 * ThreadManager_createMutex function
 */
void* threadManager_createMutex(const DSPEElement *element);

/**
 * ThreadManager_lockMutex function
 */
void threadManager_lockMutex(const DSPEElement *element, void *mutex);

/**
 * ThreadManager_tryLockMutex function
 */
int threadManager_tryLockMutex(const DSPEElement *element, void *mutex);

/**
 * ThreadManager_unlockMutex function
 */
void threadManager_unlockMutex(const DSPEElement *element, void *mutex);

/**
 * ThreadManager_deleteMutex function
 */
void threadManager_deleteMutex(const DSPEElement *element, void *mutex);

void* threadManager_createSpin(const DSPEElement *element);

void threadManager_lockSpin(const DSPEElement *element, void *spin);

int threadManager_tryLockSpin(const DSPEElement *element, void *spin);

void threadManager_unlockSpin(const DSPEElement *element, void *spin);

void threadManager_deleteSpin(const DSPEElement *element, void *spin);

/**
 * ThreadManager_createCondition function
 * Create and initialise condition variable
 */
void* threadManager_createCondition(const DSPEElement *element);

/**
 * ThreadManager_waitCondition function
 */
void threadManager_waitCondition(const DSPEElement *element, void *condition, void *mutex);

void threadManager_wakeCondition(const DSPEElement *element, void *condition);

/**
 * threadManager_wakeAllCondition function
 */
void threadManager_wakeAllCondition(const DSPEElement *element, void *condition);

/**
 * ThreadManager_destroyCondition function
 */
void threadManager_destroyCondition(const DSPEElement *element, void *condition);

/**
 * ThreadManager_delay function
 * The calling thread is suspended for seconds (argument 'sec')
 * and nano seconds (argument 'nsec').
 */
void threadManager_delay(const DSPEElement *element, long int sec, long int nsec);

/**
 * ThreadManager_getOwnerIndex function
 */
int threadManager_getOwnerIndex(const DSPEOwner *owner);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
