/**
 * File: StringManager.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef StringManager_h
#define StringManager_h

#ifdef __cplusplus
extern "C" {
#endif

/**
 * StringSupport_copy function
 */
char* stringSupport_copy(char *destination, const char *source);

/**
 * StringSupport_nCopy function
 */
char* stringSupport_nCopy(char *destination, const char *source, size_t numChars);

/**
 * StringSupport_compare function
 */
int stringSupport_compare(const char *first, const char *second);

/**
 * StringSupport_nCompare function
 */
int stringSupport_nCompare(const char *first, const char *second, size_t numChars);

/**
 * StringSupport_compareNoCase function
 */
int stringSupport_compareNoCase(const char *first, const char *second);

/**
 * StringSupport_nCompareNoCase function
 */
int stringSupport_nCompareNoCase(const char *first, const char *second, size_t numChars);

/**
 * StringSupport_length function
 */
unsigned int stringSupport_length(const char *string);

/**
 * StringSupport_generateID function
 */
char* stringSupport_generateID(const char *prefix, const char *unitName);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
