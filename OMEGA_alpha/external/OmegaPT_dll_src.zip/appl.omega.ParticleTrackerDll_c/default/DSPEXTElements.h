/**
 * File: DSPEXTElements.h
 *
 * @author Loris
 * @created Thu May 26 10:23:46 CEST 2011
 */
#ifndef DSPEXTElements_h
#define DSPEXTElements_h

#include "DSPEElements.h"

#ifdef __cplusplus
extern "C" {
#endif

// DSPE XT

#define NON_EXCLUSIVE_QUEUE 0
#define EXCLUSIVE_QUEUE 1

typedef struct DSPEComposite DSPEComposite;

typedef struct DSPEWrapImplementation DSPEWrapImplementation;

typedef struct DSPEWrapBlockOptimization DSPEWrapBlockOptimization;

// EVENTS SUPPORT

typedef struct DSPEScheduler DSPEScheduler;

typedef struct DSPEEventsComposite DSPEEventsComposite;

typedef struct DSPEStateImplementation DSPEStateImplementation;

typedef struct DSPEStateBlockOptimization DSPEStateBlockOptimization;

// OP SUPPORT

typedef struct DSPEOp DSPEOp;

typedef struct DSPEOpInQueue DSPEOpInQueue;

typedef struct DSPEOpOutQueue DSPEOpOutQueue;

// COPROC SUPPORT

typedef struct DSPECoprocEvent DSPECoprocEvent;

typedef struct DSPECoprocUnit DSPECoprocUnit;

typedef struct DSPECoprocScheduler DSPECoprocScheduler;

typedef struct DSPECoprocImplementation DSPECoprocImplementation;

typedef struct DSPECoprocBlockOptimization DSPECoprocBlockOptimization;

// EXTERNAL EVENTS SUPPORT
typedef struct DSPEExternalEvent DSPEExternalEvent;

typedef struct DSPEExternalEventsQueue DSPEExternalEventsQueue;

// DSPE XT

struct DSPEComposite {
	DSPEUnit unit;
	OWNER_EXT;
};

struct DSPEWrapImplementation {
	DSPEUnitBehaviour unitBehaviour;
};

struct DSPEWrapBlockOptimization {
	DSPEWrapImplementation wrapImplementation;
};

// EVENTS SUPPORT

struct DSPEScheduler {
	DSPEStructure structure;

	DSPEExternalEventsQueue* (*getExternalEventsPool) (const DSPEScheduler *scheduler);
	DSPEExternalEventsQueue* (*getExternalEventsQueue) (const DSPEScheduler *scheduler);
};

struct DSPEEventsComposite {
	DSPEEventsUnit eventsUnit;
};

struct DSPEStateImplementation {
	DSPEUnitBehaviour unitBehaviour;
};

struct DSPEStateBlockOptimization {
	DSPEStateImplementation stateImplementation;
};

// OP SUPPORT

struct DSPEOp {
	DSPEElement element;
	
	void (*execute) (DSPEOp *op);
};

struct DSPEOpInQueue {
	DSPEElement element;

	void (*reset) (DSPEOpInQueue *queue);
	void (*dispose) (DSPEOpInQueue *queue);
};

struct DSPEOpOutQueue {
	DSPEElement element;
		
	void (*reset) (DSPEOpOutQueue *outQueue);
	void (*dispose) (DSPEOpOutQueue *outQueue);
};

// COPROC SUPPORT

struct DSPECoprocEvent {	
	DSPEEvent event;
	DSPEOp *op;
};

struct DSPECoprocUnit {
	DSPEQueueUnit queueUnit;

	DSPEOpInQueue* (*getCoprocQueue) (DSPECoprocUnit *unit);
	void (*initOp) (DSPECoprocUnit *unit, DSPEOp *op);
	void (*queueCoprocEvent) (DSPECoprocUnit *unit, DSPECoprocEvent *event);
	DSPECoprocEvent* (*getCoprocEvent) (DSPECoprocUnit *unit);
	void (*consumeCoprocEvent) (DSPECoprocUnit *unit);
};

struct DSPECoprocScheduler {
	DSPEScheduler scheduler;

	DSPEOpOutQueue* (*getOutQueue) (const DSPECoprocScheduler *scheduler);
};

struct DSPECoprocImplementation {
	DSPEUnitBehaviour unitBehaviour;
};

struct DSPECoprocBlockOptimization {
	DSPECoprocImplementation coprocImplementation;
};

// EXTERNAL EVENTS SUPPORT

struct DSPEExternalEvent {
	int id;
	
	DSPEExternalEvent *next;
};

struct DSPEExternalEventsQueue {
	DSPEElement element;

	// REMARK: Lock used for all variables that follow
	void *lock;
	
	DSPEExternalEvent *head;
	DSPEExternalEvent *tail;
	unsigned int numElements;
};

// INITIALIZATION FUNCTIONS

static INLINE void initDSPECoprocUnit(DSPECoprocUnit *unit) {
	initDSPEQueueUnit((DSPEQueueUnit*) unit);
	unit->getCoprocQueue = NULL;
	unit->initOp = NULL;
	unit->queueCoprocEvent = NULL;
	unit->getCoprocEvent = NULL;
	unit->consumeCoprocEvent = NULL;
}

static INLINE void initDSPECoprocScheduler(DSPECoprocScheduler *scheduler) {
	scheduler->getOutQueue = NULL;
}

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
