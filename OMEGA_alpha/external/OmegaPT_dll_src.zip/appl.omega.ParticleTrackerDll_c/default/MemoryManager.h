/**
 * File: MemoryManager.h
 *
 * @author Loris
 * @created Thu May 26 10:23:46 CEST 2011
 */
#ifndef MemoryManager_h
#define MemoryManager_h

#include "DSPEXTElements.h"
#include "MemoryGround.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * MemorySupport_getMemoryUsage function
 */
size_t memorySupport_getMemoryUsage();

/**
 * MemorySupport_allocate function
 */
void* memorySupport_allocate(size_t size);

/**
 * MemorySupport_allocateAndInit function
 */
void* memorySupport_allocateAndInit(size_t blockSize, size_t size);

/**
 * MemorySupport_realloc function
 */
void* memorySupport_realloc(void *pointer, size_t newSize);

/**
 * MemorySupport_dispose function
 */
void memorySupport_dispose(void *pointer);

/**
 * MemorySupport_copyBlock function
 */
void memorySupport_copyBlock(void *destination, const void *source, size_t size);

/**
 * MemorySupport_resetBlock function
 */
void memorySupport_resetBlock(void *destination, size_t size);

/**
 * MemoryManager_allocate function
 */
void* memoryManager_allocate(const DSPEElement *element, size_t size);

/**
 * MemoryManager_allocateAndInit function
 */
void* memoryManager_allocateAndInit(const DSPEElement *element, size_t blockSize, size_t size);

/**
 * MemorySupport_allocateAligned function
 */
void* memorySupport_allocateAligned(size_t size, size_t offset);

/**
 * MemorySupport_disposeAligned function
 */
void memorySupport_disposeAligned(void *pointer);

/**
 * MemoryManager_allocateAligned function
 */
void* memoryManager_allocateAligned(const DSPEElement *element, size_t size, size_t offset);

/**
 * MemorySupport_allocateHost function
 */
void* memorySupport_allocateHost(size_t size);

/**
 * MemorySupport_allocateHostAndInit function
 */
void* memorySupport_allocateHostAndInit(size_t blockSize, size_t size);

/**
 * MemorySupport_disposeHost function
 */
void memorySupport_disposeHost(void *pointer);

/**
 * MemorySupport_copyBlockHost function
 */
void memorySupport_copyBlockHost(void *destination, const void *source, size_t size);

/**
 * MemoryManager_allocateHost function
 */
void* memoryManager_allocateHost(const DSPEElement *element, size_t size);

/**
 * MemoryManager_allocateHostAndInit function
 */
void* memoryManager_allocateHostAndInit(const DSPEElement *element, size_t blockSize, size_t size);

/**
 * PoolHandler initialization function
 */
void memoryManager_initPoolHandler(DSPEOwner *ownerExt);

/**
 * PoolHandler get function
 */
static INLINE DSPEPoolHandler* memoryManager_getPoolHandler(const DSPEOwner *owner) {
	return NULL;
}

/**
 * PoolHandler reset function
 */
void memoryManager_resetPoolHandler(DSPEHandler *handler);

/**
 * PoolHandler prealloc function
 */
void memoryManager_preAllocPoolHandler(DSPEElement *element, unsigned int size);

/**
 * PoolHandler dispose function
 */
void memoryManager_disposePoolHandler(DSPEHandler *handler);

/**
 * MemoryManager_addBaseEventPool function 
 */
void memoryManager_addPool(DSPEPoolHandler *handler, DSPEBaseEventsPool *pool);

/**
 * MemoryManager_getBaseEventPool function 
 */
DSPEBaseEventsPool* memoryManager_getPool(DSPEPoolHandler *handler, void *gateDefID);

/**
 * MemoryManager_addGroupEventPool function
 */
void memoryManager_addGroupPool(DSPEPoolHandler *handler, DSPEGroupEventsPool *pool);

/**
 * MemoryManager_getGroupEventPool function
 */
DSPEGroupEventsPool* memoryManager_getGroupPool(DSPEPoolHandler *handler, void *gateDefID, size_t groupSize);

/**
 * MemoryManager_addBaseEventPool function 
 */
void memoryManager_addPoolBlock(DSPEPoolHandler *handler, DSPEBlockEventsPool *pool);

/**
 * MemoryManager_getBaseEventPool function 
 */
DSPEBlockEventsPool* memoryManager_getPoolBlock(DSPEPoolHandler *handler, void *gateDefID, size_t size);

/**
 * MemoryManager_addBaseEventPool function 
 */
void memoryManager_addGroupPoolBlock(DSPEPoolHandler *handler, DSPEGroupBlockEventsPool *pool);

/**
 * MemoryManager_getBaseEventPool function 
 */
DSPEGroupBlockEventsPool* memoryManager_getGroupPoolBlock(DSPEPoolHandler *handler, void *gateDefID, size_t groupSize, size_t blockSize);

/**
 * MemoryManager_initCoprocEventPool function
 */
DSPECoprocEventsPool* memoryManager_initCoprocPool(DSPECoprocScheduler *scheduler);

/******************************************************************************
 * EXTERNAL EVENTS SUPPORT
 ******************************************************************************/

/**
 * MemoryManager_initExternalEventsQueue function
 */
DSPEExternalEventsQueue* memoryManager_initExternalEventsQueue(const DSPEScheduler *scheduler);

/**
 * MemoryManager_disposeExternalEventsQueue function
 */
void memoryManager_disposeExternalEventsQueue(const DSPEScheduler *scheduler, DSPEExternalEventsQueue *queue);

/**
 * MemoryManager_resetExternalEventsQueue function
 */
void memoryManager_resetExternalEventsQueue(const DSPEScheduler *scheduler);

/**
 * MemoryManager_addExternalEventToQueue function
 */
void memoryManager_addExternalEventToQueue(const DSPEScheduler *scheduler, int id);

/**
 * MemoryManager_getExternalEventFromQueue function
 */
DSPEExternalEvent* memoryManager_getExternalEventFromQueue(const DSPEScheduler *scheduler);

/**
 * MemoryManager_addExternalEventToPool function
 */
void memoryManager_addExternalEventToPool(const DSPEScheduler *scheduler, DSPEExternalEvent *evt);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
