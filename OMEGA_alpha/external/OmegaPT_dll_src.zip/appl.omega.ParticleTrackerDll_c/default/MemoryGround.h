/**
 * File: MemoryGround.h
 *
 * @author Loris
 * @created Thu May 26 10:23:46 CEST 2011
 */
#ifndef MemoryGround_h
#define MemoryGround_h

#include "DSPEXTElements.h"

/* Coproc EventPool Support */
typedef struct DSPECoprocEventsPool DSPECoprocEventsPool;

struct DSPECoprocEventsPool {
	DSPEEventsPool event;

	size_t eventsNumElements;
	DSPECoprocEvent *eventsHead;
	DSPECoprocEvent *eventsTail;
};

/* Coproc EventPool init Support */

static INLINE void initDSPECoprocEventsPool(DSPECoprocEventsPool *pool) {
	initDSPEEventsPool((DSPEEventsPool*) pool);
	pool->eventsNumElements = 0;
	pool->eventsHead = NULL;
	pool->eventsTail = NULL;
}

/* DSPEHandler ID for eventPool handler */
#define POOL_HANDLER_TYPE 0

/* Base EventPool Support */
typedef struct DSPEPoolHandler DSPEPoolHandler;

struct DSPEPoolHandler {
	DSPEHandler handler;

	
	/* EventGate pools */
	size_t poolsNumElements;
	DSPEEventsPool *poolsHead;
	DSPEEventsPool *poolsTail;
	/* CoprocEvents Pool */
	DSPECoprocEventsPool *coprocEventsPool;
};
/* BasePool initFunctions */
static INLINE void initDSPEPoolHandler(DSPEPoolHandler *handler, const DSPEElement *container) {
	initDSPEHandler((DSPEHandler*) handler, container);

	/* EventGate pools */
	handler->poolsNumElements = 0;
	handler->poolsHead = NULL;
	handler->poolsTail = NULL;
	/* CoprocEvents Pool */
	handler->coprocEventsPool = NULL;
}
typedef struct DSPEBaseEventsPool DSPEBaseEventsPool;

typedef struct DSPEGroupEventsPool DSPEGroupEventsPool;


struct DSPEBaseEventsPool {
	DSPEEventsPool event;
};

struct DSPEGroupEventsPool {
	DSPEEventsPool event;

	size_t groupSize;
	
	size_t groupsNumElements;
	DSPEGroupEventsPool *groupsHead;
	DSPEGroupEventsPool *groupsTail;
}; 
static INLINE void initDSPEBaseEventsPool(DSPEBaseEventsPool *pool) {
	initDSPEEventsPool((DSPEEventsPool*) pool);
}

static INLINE void initDSPEGroupEventsPool(DSPEGroupEventsPool *pool) {
	initDSPEEventsPool((DSPEEventsPool*) pool);
	pool->groupSize = 0;
	pool->groupsNumElements = 0;
	pool->groupsHead = NULL;
	pool->groupsTail = NULL;
}
/* Block EventPool Support */
typedef struct DSPEBlockEventsPool DSPEBlockEventsPool;

typedef struct DSPEGroupBlockEventsPool DSPEGroupBlockEventsPool;

struct DSPEBlockEventsPool {
	DSPEEventsPool event;

	size_t size;
	
	size_t blocksNumElements;
	DSPEBlockEventsPool *blocksHead;
	DSPEBlockEventsPool *blocksTail;
};

struct DSPEGroupBlockEventsPool {
	DSPEBlockEventsPool event;

	size_t groupSize;
	
	size_t blocksNumElements;
	DSPEGroupBlockEventsPool *blocksHead;
	DSPEGroupBlockEventsPool *blocksTail;
	
	size_t groupsNumElements;
	DSPEGroupBlockEventsPool *groupsHead;
	DSPEGroupBlockEventsPool *groupsTail;
};
/* Block EventPool init Support */

static INLINE void initDSPEBlockEventsPool(DSPEBlockEventsPool *pool) {
	initDSPEEventsPool((DSPEEventsPool*) pool);
	pool->size = 0;
	pool->blocksNumElements = 0;
	pool->blocksHead = NULL;
	pool->blocksTail = NULL;
}

static INLINE void initDSPEGroupBlockEventsPool(DSPEGroupBlockEventsPool *pool) {
	initDSPEBlockEventsPool((DSPEBlockEventsPool*) pool);
	pool->groupSize = 0;
	pool->blocksNumElements = 0;
	pool->blocksHead = NULL;
	pool->blocksTail = NULL;
	pool->groupsNumElements = 0;
	pool->groupsHead = NULL;
	pool->groupsTail = NULL;
}
#endif
