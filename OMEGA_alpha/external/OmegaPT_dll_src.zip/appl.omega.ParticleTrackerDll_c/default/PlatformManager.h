/**
 * File: PlatformManager.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef PlatformManager_h
#define PlatformManager_h

#include <stddef.h>

#define WINDOWS 1
#define GC_WIN 1

#define INLINE inline
#endif
