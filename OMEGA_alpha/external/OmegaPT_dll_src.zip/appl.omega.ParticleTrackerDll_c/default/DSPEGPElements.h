/**
 * File: DSPEGPElements.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef DSPEGPElements_h
#define DSPEGPElements_h

#include "DSPEXTElements.h"

#ifdef __cplusplus
extern "C" {
#endif

#define CAST_TO_GP_COPROC_OP(coprocOp) ((DSPEGPCoprocOpExt*) ((DSPECoprocOp*) (coprocOp))->opExt)
#define CAST_TO_COPROC_OP(gpCoprocOp) ((DSPECoprocOp*) ((DSPEGPCoprocOpExt*) (gpCoprocOp))->root)

typedef struct DSPEGPImplementation DSPEGPImplementation;

typedef struct DSPEGPBlockOptimization DSPEGPBlockOptimization;

typedef struct DSPEGPCoprocOpExt DSPEGPCoprocOpExt;

struct DSPEGPImplementation {
	DSPEUnitBehaviour unitBehaviour;
};

struct DSPEGPBlockOptimization {
	DSPEGPImplementation gpImplementation;
};

struct DSPEGPCoprocOpExt {
	DSPEExtension extension;

	unsigned int streamEnded;
	void (*steal) (DSPEOp* op);
};

// REMARK: Declaring a static inline function imposes inclusion of MemoryManager (that cannot
// be included). Defines are resolved by the preprocessor and callers already include all
// needed files.
#define initDSPEGPCoprocOpExt(element, coprocOp) {\
	DSPEGPCoprocOpExt *gpCoprocOpExt = (DSPEGPCoprocOpExt*) memoryManager_allocate(element, sizeof(DSPEGPCoprocOpExt));\
	initDSPEExtension((DSPEExtension*) gpCoprocOpExt, (DSPEElement*) (coprocOp));\
	gpCoprocOpExt->streamEnded = 0;\
	gpCoprocOpExt->steal = NULL;\
	GET_COPROC_OP_EXT(coprocOp) = (DSPEExtension*) gpCoprocOpExt;\
}

#define disposeDSPEGPCoprocOpExt(coprocOp) {\
	memorySupport_dispose(GET_COPROC_OP_EXT(coprocOp));\
}

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
