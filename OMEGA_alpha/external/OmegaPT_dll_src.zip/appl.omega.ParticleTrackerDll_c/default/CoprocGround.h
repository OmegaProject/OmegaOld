/**
 * File: CoprocGround.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef CoprocGround_h
#define CoprocGround_h

#include "DSPEXTElements.h"

typedef struct DSPECoprocOp DSPECoprocOp;
typedef struct DSPEProfileCoprocOp DSPEProfileCoprocOp;

struct DSPECoprocOp {
	DSPEOp op;

	DSPECoprocOp *next;
};

struct DSPEProfileCoprocOp {
	DSPECoprocOp op;

	DSPEProfileNode **profileQueue;
	int unitProfileID;
};

static INLINE void initDSPECoprocOp(DSPEElement *element, DSPECoprocOp *coprocOp) {

}

static INLINE void disposeDSPECoprocOp(DSPECoprocOp *coprocOp) {

}

#endif
