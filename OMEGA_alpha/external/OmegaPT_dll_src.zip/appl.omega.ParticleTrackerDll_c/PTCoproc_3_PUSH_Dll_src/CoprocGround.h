/**
 * File: CoprocGround.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef CoprocGround_h
#define CoprocGround_h

#include "DSPEXTElements.h"

#define HAS_COPROC_OP_EXT(coprocOp) ((DSPECoprocOp*) (coprocOp))->opExt != NULL
#define GET_COPROC_OP_EXT(coprocOp) (((DSPECoprocOp*) (coprocOp))->opExt)


typedef struct DSPECoprocOp DSPECoprocOp;
typedef struct DSPEProfileCoprocOp DSPEProfileCoprocOp;

struct DSPECoprocOp {
	DSPEOp op;
	DSPEExtension *opExt;

	DSPECoprocOp *next;
};

struct DSPEProfileCoprocOp {
	DSPECoprocOp op;

	DSPEProfileNode **profileQueue;
	int unitProfileID;
};


// REMARK: Declaring a static inline function imposes inclusion of MemoryManager (that cannot
// be included). Defines are resolved by the preprocessor and callers already include all
// needed files.
#define initDSPECoprocOp(element, coprocOp) {\
	(coprocOp)->opExt = NULL;\
}

#define disposeDSPECoprocOp(coprocOp) {\
}

#endif
