/**
 * File: PlatformManager.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef PlatformManager_h
#define PlatformManager_h

#include <stddef.h>

#define WINDOWS 1
#define VC_WIN 1

#define INLINE __inline

#ifndef _LDSUPPORT
#define _LDSUPPORT
#endif

/* String compare no case defines */
#define stringCompareNoCase(first, second) _stricmp(first, second)
#define stringNCompareNoCase(first, second, numChars) _strnicmp(first, second, numChars)

/* String to number conversion defines */
#define strToLongLong(str, ptr) _strtoi64(str, ptr, 10)
#define strToULongLong(str, ptr) _strtoui64(str, ptr, 10)
#define strToLongDouble(res, str, ptr) errno = _atoldbl(&(res), (char*) str)

/* Thread delay define */
#define threadDelay(time) pthread_delay_np(&time)
/* Thread num processors */
#define threadNumProcessors() return (unsigned int) pthread_num_processors_np()
#endif
