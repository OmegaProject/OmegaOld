/**
 * File: MemoryManager.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef MemoryManager_h
#define MemoryManager_h

#include "DSPEElements.h"
#include "MemoryGround.h"

/* MemoryManager Handler defines */
#define MAX_NUM_HANDLERS 4
#define HANDLER_INDEX_EVENTPOOL 0
#define HANDLER_INDEX_COPROC 1
#define HANDLER_INDEX_THREAD 2
#define HANDLER_INDEX_BENCHMARK 3

#ifdef __cplusplus
extern "C" {
#endif

/**
 * MemorySupport_allocate function
 */
void* memorySupport_allocate(size_t size);

/**
 * MemorySupport_allocateAndInit function
 */
void* memorySupport_allocateAndInit(size_t blockSize, size_t size);

/**
 * MemorySupport_realloc function
 */
void* memorySupport_realloc(void *pointer, size_t newSize);

/**
 * MemorySupport_dispose function
 */
void memorySupport_dispose(void *pointer);

/**
 * MemorySupport_copyBlock function
 */
void memorySupport_copyBlock(void *destination, const void *source, size_t size);

/**
 * MemorySupport_resetBlock function
 */
void memorySupport_resetBlock(void *destination, size_t size);

/**
 * MemoryManager_allocate function
 */
void* memoryManager_allocate(const DSPEElement *element, size_t size);

/**
 * MemoryManager_allocateAndInit function
 */
void* memoryManager_allocateAndInit(const DSPEElement *element, size_t blockSize, size_t size);

/**
 * MemoryManager_allocateHandlerPool function
 */
void memoryManager_allocateHandlerPool(const DSPEElement *element, DSPEOwner *ownerExt);

/**
 * MemoryManager_resetHandlerPool function
 */
void memoryManager_resetHandlerPool(const DSPEElement *element, DSPEOwner *ownerExt);

/**
 * MemoryManager_disposeHandlerPool function
 */
void memoryManager_disposeHandlerPool(const DSPEElement *element, DSPEOwner *ownerExt);

/* PoolHandlers functions */

/**
 * PoolHandler reset function
 */
void memoryManager_resetPoolHandler(DSPEHandler *handler);

/**
 * PoolHandler dispose function
 */
void memoryManager_disposePoolHandler(DSPEHandler *handler);

/**
 * PoolHandler initialization function
 */
void memoryManager_initPoolHandler(DSPEOwner *ownerExt);

/**
 * PoolHandler get function
 */
static INLINE DSPEPoolHandler* memoryManager_getPoolHandler(const DSPEOwner *owner) {
	return (DSPEPoolHandler*) owner->handlers[HANDLER_INDEX_EVENTPOOL];
}

/**
 * PoolHandler prealloc function
 */
void memoryManager_preAllocPoolHandler(DSPEElement *element, unsigned int size);

/**
 * MemoryManager_addBaseEventPool function 
 */
void memoryManager_addPool(DSPEPoolHandler *handler, DSPEBaseEventsPool *pool);

/**
 * MemoryManager_getBaseEventPool function 
 */
DSPEBaseEventsPool* memoryManager_getPool(DSPEPoolHandler *handler, void *gateDefID);

/**
 * MemoryManager_addGroupEventPool function
 */
void memoryManager_addGroupPool(DSPEPoolHandler *handler, DSPEGroupEventsPool *pool);

/**
 * MemoryManager_getGroupEventPool function
 */
DSPEGroupEventsPool* memoryManager_getGroupPool(DSPEPoolHandler *handler, void *gateDefID, size_t groupSize);

/**
 * MemoryManager_initCoprocEventPool function
 */
DSPECoprocEventsPool* memoryManager_initCoprocPool(DSPECoprocScheduler *scheduler);

/******************************************************************************
 * EXTERNAL EVENTS SUPPORT
 ******************************************************************************/

/**
 * MemoryManager_initExternalEventsQueue function
 */
DSPEExternalEventsQueue* memoryManager_initExternalEventsQueue(const DSPEScheduler *scheduler);

/**
 * MemoryManager_disposeExternalEventsQueue function
 */
void memoryManager_disposeExternalEventsQueue(const DSPEScheduler *scheduler, DSPEExternalEventsQueue *queue);

/**
 * MemoryManager_resetExternalEventsQueue function
 */
void memoryManager_resetExternalEventsQueue(const DSPEScheduler *scheduler);

/**
 * MemoryManager_addExternalEventToQueue function
 */
void memoryManager_addExternalEventToQueue(const DSPEScheduler *scheduler, int id);

/**
 * MemoryManager_getExternalEventFromQueue function
 */
DSPEExternalEvent* memoryManager_getExternalEventFromQueue(const DSPEScheduler *scheduler);

/**
 * MemoryManager_addExternalEventToPool function
 */
void memoryManager_addExternalEventToPool(const DSPEScheduler *scheduler, DSPEExternalEvent *evt);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
