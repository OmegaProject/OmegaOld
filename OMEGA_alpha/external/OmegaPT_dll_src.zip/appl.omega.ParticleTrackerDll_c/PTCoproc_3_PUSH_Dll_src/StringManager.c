/**
 * File: StringManager.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "StringManager.h"

#include "RunnerGround.h"

#include <stdlib.h>
#include <string.h>

/**
 * StringSupport_copy function
 */
char* stringSupport_copy(char *destination, const char *source) {
	return strcpy(destination, source);
}

/**
 * StringSupport_nCopy function
 */
char* stringSupport_nCopy(char *destination, const char *source, size_t numChars) {
	return strncpy(destination, source, numChars);
}

/**
 * StringSupport_compare function
 */
int stringSupport_compare(const char *first, const char *second) {
	return strcmp(first, second);
}

/**
 * StringSupport_nCompare function
 */
int stringSupport_nCompare(const char *first, const char *second, size_t numChars) {
	return strncmp(first, second, numChars);
}

/**
 * StringSupport_compareNoCase function
 */
int stringSupport_compareNoCase(const char *first, const char *second) {
	return stringCompareNoCase(first, second);
}

/**
 * StringSupport_nCompareNoCase function
 */
int stringSupport_nCompareNoCase(const char *first, const char *second, size_t numChars) {
	return stringNCompareNoCase(first, second, numChars);
}

/**
 * StringSupport_length function
 */
size_t stringSupport_length(const char *string) {
	return strlen(string);
}

/**
 * StringSupport_generateID function
 */
char* stringSupport_generateID(const char *prefix, const char *unitName) {
	register size_t prefixL = (prefix == 0) ? 0 : strlen(prefix);
	char *tmp;
	if (prefixL > 0) {
		// size: 1 for '_' + 1 for '\0' + prefixLenght + unitNameLenght
		tmp = (char*) allocateMemory(NULL, (2 + prefixL + strlen(unitName)) * sizeof(char));
		tmp[0] = '\0';
		tmp = strcat(tmp, prefix);
		tmp = strcat(tmp, "_");
		return strcat(tmp, unitName);
	} else {
		// size: 1 for '\0' + unitNameLenght
		tmp = (char*) allocateMemory(NULL, (1 + strlen(unitName)) * sizeof(char));
		tmp[0] = '\0';
		return strcat(tmp, unitName);
	}
}

