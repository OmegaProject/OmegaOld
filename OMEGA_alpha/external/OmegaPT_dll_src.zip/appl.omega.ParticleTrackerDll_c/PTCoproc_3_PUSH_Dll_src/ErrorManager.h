/**
 * File: ErrorManager.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef ErrorManager_h
#define ErrorManager_h

#include "DSPEElements.h"

#define ERROR_MAX_SIZE 10

#ifdef __cplusplus
extern "C" {
#endif

/**
 * ErrorManager_initialize function
 */
void errorManager_initialize(const DSPEElement *element);

/**
 * ErrorManager_dispose function
 */
void errorManager_dispose(const DSPEElement *element);

/**
 * ErrorManager_appendError function
 * Error is added to errorQueue and an error message is displayed.
 */
void errorManager_appendError(const DSPEElement *element, const char *errorMsg, ...);

/**
 * ErrorManager_appendStandardError function
 * Error is added to errorQueue and an error message is displayed.
 */
void errorManager_appendStandardError(const DSPEElement *element, int errorCode);

/**
 * ErrorManager_collectError function.
 * Error is added to errorQueue but no error message is displayed.
 */
void errorManager_collectError(const DSPEElement *element, const char *errorMsg, ...);

/**
 * ErrorManager_collectStandardError function
 * Error is added to errorQueue but no error message is displayed.
 */
void errorManager_collectStandardError(const DSPEElement *element, int errorCode);

/**
 * ErrorManager_clearErrors function
 */
void errorManager_clearErrors(const DSPEElement *element);

/**
 * ErrorManager_hasErrorOccurred function
 */
int errorManager_hasErrorOccurred(const DSPEElement *element);

/**
 * ErrorManager_showErrors function
 */
void errorManager_showErrors(const DSPEElement *element, const char *message);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
