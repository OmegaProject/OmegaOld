/**
 * File: CriticalSection.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef CriticalSection_h
#define CriticalSection_h

#include "RunnerGround.h"

#ifdef __cplusplus
extern "C" {
#endif

void initializeCurAndLastValues(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context);

void disposeCurAndLastValues(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context);


infoSwap* initializeInfoSwap(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context);

engineSwap* initializeEngineSwap(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context);

void disposeSwapAreas(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context);

void updateEnginePendingChanges(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context);

void updateEngineChanges(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context);

void updateEngineState(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context);

void updateEngineStateFeedback(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context);

void updateInfo(const DSPEElement *element);

void initializeChangeFlags(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
