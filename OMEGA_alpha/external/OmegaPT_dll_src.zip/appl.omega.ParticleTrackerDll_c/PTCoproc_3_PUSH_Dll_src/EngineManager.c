/**
 * File: EngineManager.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "EngineManager.h"

#include "ThreadManager.h"
#include "CoprocManager.h"

#include "CriticalSection.h"
#include "RunnerGround.h"

#define stoppedState 0
#define stoppingState 1
#define executingState 2
#define exitState 3
#define runningState 100
#define pausedState 101
#define suspendedState 102
#define skippingState 103

/**
 * GetCurrentEngineSwap function.
 */
static INLINE engineSwap* getCurrentEngineSwap(const DSPEElement *element, int isFeedback) {
	engineSwap *current;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (isFeedback) {
		threadManager_lockSpin(element, context->engineFeedbackSwapLock);
		current = context->engineFeedbackSwapEngine;
		threadManager_unlockSpin(element, context->engineFeedbackSwapLock);
	} else {
		threadManager_lockSpin(element, context->engineSwapLock);
		current = context->engineSwapGui;
		threadManager_unlockSpin(element, context->engineSwapLock);
	}

	threadManager_lockSpin(element, current->changesLock);
	current->addingChanges = 1;
	threadManager_unlockSpin(element, current->changesLock);

	return current;
}

/**
 * AddEngineChange function.
 */
static INLINE void addEngineChange(const DSPEElement *element, long int skipCycles) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;
	engineSwap *current;
	int isFeedbackChangeAvailable = 0;

	threadManager_lockSpin(element, context->engineFeedbackSwapLock);
	isFeedbackChangeAvailable = context->isEngineFeedbackChanged;
	threadManager_unlockSpin(element, context->engineFeedbackSwapLock);
	if (isFeedbackChangeAvailable)
		// Priority is given to processing thread engine state changes (feedback changes).
		// Ignore all non feedback changes if a feedback change is already available.
		return;

	current = getCurrentEngineSwap(element, 0);

	current->mainState = context->mainState_curValue;
	current->subState = context->subState_curValue;
	current->skipCycles = skipCycles;

	threadManager_lockSpin(element, current->changesLock);
	current->addingChanges = 0;
	threadManager_unlockSpin(element, current->changesLock);

	/* Demands update engine state */
	threadManager_lockSpin(element, context->engineSwapLock);
	context->isEngineChanged = 1;
	threadManager_unlockSpin(element, context->engineSwapLock);
}

/**
 * AddEngineFeedbackChange function.
 */
static INLINE void addEngineFeedbackChange(const DSPEElement *element) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;
	engineSwap *current = getCurrentEngineSwap(element, 1);

	current->mainState = context->mainState_lastValue;
	current->subState = context->subState_lastValue;

	threadManager_lockSpin(element, current->changesLock);
	current->addingChanges = 0;
	threadManager_unlockSpin(element, current->changesLock);

	/* Demands update engine state */
	threadManager_lockSpin(element, context->engineSwapLock);
	if (context->isEngineChanged)
		// Priority is given to processing thread engine state changes (feedback changes).
		context->isEngineChanged = 0;
	threadManager_unlockSpin(element, context->engineSwapLock);
	threadManager_lockSpin(element, context->engineFeedbackSwapLock);
	context->isEngineFeedbackChanged = 1;
	threadManager_unlockSpin(element, context->engineFeedbackSwapLock);
}

/**
 * IsLockFree function.
 */
static INLINE int isLockFree(const DSPEElement *element) {
	return element->owner == CAST_TO_OWNER(element->application);
}

/**
 * GetMainStatePtr function.
 */
static INLINE int* getMainStatePtr(const DSPEElement *element) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (isLockFree(element))
		return &context->mainState_lastValue;
	else
		return &context->mainState_curValue;
}

/**
 * GetSubStatePtr function.
 */
static INLINE int* getSubStatePtr(const DSPEElement *element) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (isLockFree(element))
		return &context->subState_lastValue;
	else
		return &context->subState_curValue;
}

/**
 * EngineManager_initialize function
 */
void engineManager_initialize(const DSPEElement *element) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	context->mainState_curValue = stoppedState;
	context->mainState_lastValue = stoppedState;
	context->subState_curValue = -1;
	context->subState_lastValue = -1;

	context->engineManagerLock = threadManager_createSpin(element);
}

/**
 * EngineManager_dispose function
 */
void engineManager_dispose(const DSPEElement *element) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	threadManager_deleteSpin(element, context->engineManagerLock);
}

/**
 * EngineManager_isExecuting function
 */
int engineManager_isExecuting(const DSPEElement *element) {
	int isExecuting = 0;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (isLockFree(element))
		isExecuting = context->mainState_lastValue == executingState;
	else {
		threadManager_lockSpin(element, context->engineManagerLock);
		isExecuting = context->mainState_curValue == executingState;
		threadManager_unlockSpin(element, context->engineManagerLock);
	}
	return isExecuting;
}

/**
 * EngineManager_isStopping function
 */
int engineManager_isStopping(const DSPEElement *element) {
	int isStopping = 0;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (isLockFree(element))
		isStopping = context->mainState_lastValue == stoppingState;
	else {
		threadManager_lockSpin(element, context->engineManagerLock);
		isStopping = context->mainState_curValue == stoppingState;
		threadManager_unlockSpin(element, context->engineManagerLock);
	}
	return isStopping;
}

/**
 * EngineManager_isStopped function
 */
int engineManager_isStopped(const DSPEElement *element) {
	int isStopped = 0;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (isLockFree(element))
		isStopped = context->mainState_lastValue == stoppedState || context->mainState_lastValue == exitState;
	else {
		threadManager_lockSpin(element, context->engineManagerLock);
		isStopped = context->mainState_curValue == stoppedState || context->mainState_curValue == exitState;
		threadManager_unlockSpin(element, context->engineManagerLock);
	}
	return isStopped;
}

/**
 * EngineManager_isRunning function
 */
int engineManager_isRunning(const DSPEElement *element) {
	int isRunning = 0;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (isLockFree(element))
		isRunning = context->mainState_lastValue == executingState && context->subState_lastValue == runningState;
	else {
		threadManager_lockSpin(element, context->engineManagerLock);
		isRunning = context->mainState_curValue == executingState && context->subState_curValue == runningState;
		threadManager_unlockSpin(element, context->engineManagerLock);
	}
	return isRunning;
}

/**
 * EngineManager_isPaused function
 */
int engineManager_isPaused(const DSPEElement *element) {
	int isPaused = 0;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (isLockFree(element))
		isPaused = context->mainState_lastValue == executingState && context->subState_lastValue == pausedState;
	else {
		threadManager_lockSpin(element, context->engineManagerLock);
		isPaused = context->mainState_curValue == executingState && context->subState_curValue == pausedState;
		threadManager_unlockSpin(element, context->engineManagerLock);
	}
	return isPaused;
}

/**
 * EngineManager_isSkipping function
 */
int engineManager_isSkipping(const DSPEElement *element) {
	int isSkipping = 0;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (isLockFree(element))
		isSkipping = context->mainState_lastValue == executingState && context->subState_lastValue == skippingState;
	else {
		threadManager_lockSpin(element, context->engineManagerLock);
		isSkipping = context->mainState_curValue == executingState && context->subState_curValue == skippingState;
		threadManager_unlockSpin(element, context->engineManagerLock);
	}
	return isSkipping;
}

/**
 * EngineManager_isExiting function
 */
int engineManager_isExiting(const DSPEElement *element) {
	int isExiting = 0;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (isLockFree(element))
		isExiting = context->mainState_lastValue == exitState;
	else {
		threadManager_lockSpin(element, context->engineManagerLock);
		isExiting = context->mainState_curValue == exitState;
		threadManager_unlockSpin(element, context->engineManagerLock);
	}
	return isExiting;
}

/**
 * EngineManager_isSuspended function
 */
int engineManager_isSuspended(const DSPEElement *element) {
	int isSuspended = 0;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (isLockFree(element))
		isSuspended = context->mainState_lastValue == executingState && context->subState_lastValue == suspendedState;
	else {
		threadManager_lockSpin(element, context->engineManagerLock);
		isSuspended = context->mainState_curValue == executingState && context->subState_curValue == suspendedState;
		threadManager_unlockSpin(element, context->engineManagerLock);
	}
	return isSuspended;
}

/**
 * EngineManager_run function
 */
void engineManager_run(const DSPEElement *element) {
	int *mainState = getMainStatePtr(element);
	int *subState = getSubStatePtr(element);
	int lockFree = isLockFree(element);
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (!lockFree)
		threadManager_lockSpin(element, context->engineManagerLock);

	if (*mainState == executingState && *subState == runningState) {
		if (!lockFree)
			threadManager_unlockSpin(element, context->engineManagerLock);
		return;
	}

	if (*mainState == stoppedState || *mainState == stoppingState) {
		*mainState = executingState;
		*subState = runningState;
		if (lockFree)
			addEngineFeedbackChange(element);
		else {
			addEngineChange(element, 0);
			threadManager_unlockSpin(element, context->engineManagerLock);
		}
		threadManager_lockMutex(element, context->startCondMutex);
		threadManager_wakeCondition(element, context->startCondition);
		threadManager_unlockMutex(element, context->startCondMutex);
	} else if (*mainState == executingState) {
		if (*subState == pausedState) {
			*subState = runningState;
			if (lockFree)
				addEngineFeedbackChange(element);
			else {
				addEngineChange(element, 0);
				threadManager_unlockSpin(element, context->engineManagerLock);
			}
			threadManager_lockMutex(element, context->pauseCondMutex);
			threadManager_wakeCondition(element, context->pauseCondition);
			threadManager_unlockMutex(element, context->pauseCondMutex);
		} else if (*subState == suspendedState) {
			*subState = runningState;
			if (lockFree)
				addEngineFeedbackChange(element);
			else {
				addEngineChange(element, 0);
				threadManager_unlockSpin(element, context->engineManagerLock);
			}
			threadManager_lockMutex(element, context->suspendCondMutex);
			threadManager_wakeCondition(element, context->suspendCondition);
			threadManager_unlockMutex(element, context->suspendCondMutex);
		} else if (*subState == skippingState) {
			*subState = runningState;
			if (lockFree) {
				context->skipCycles = 0;
				addEngineFeedbackChange(element);
			} else {
				addEngineChange(element, 0);
				threadManager_unlockSpin(element, context->engineManagerLock);
			}
		} else {
			if (!lockFree)
				threadManager_unlockSpin(element, context->engineManagerLock);
		}
	} else {
		if (!lockFree)
			threadManager_unlockSpin(element, context->engineManagerLock);
	}
}

/**
 * EngineManager_stop function
 */
void engineManager_stop(const DSPEElement *element) {
	int *mainState = getMainStatePtr(element);
	int *subState = getSubStatePtr(element);
	int lockFree = isLockFree(element);
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (!lockFree)
		threadManager_lockSpin(element, context->engineManagerLock);

	if (*mainState == stoppedState) {
		if (!lockFree)
			threadManager_unlockSpin(element, context->engineManagerLock);
		return;
	}

	/* Reset both pause and suspend conditions in order to exit the main loop */
	if (*mainState == executingState) {
		*mainState = stoppingState;
		if (*subState == pausedState) {
			*subState = -1;
			if (lockFree)
				addEngineFeedbackChange(element);
			else {
				addEngineChange(element, 0);
				threadManager_unlockSpin(element, context->engineManagerLock);
			}
			threadManager_lockMutex(element, context->pauseCondMutex);
			threadManager_wakeCondition(element, context->pauseCondition);
			threadManager_unlockMutex(element, context->pauseCondMutex);
		} else if (*subState == suspendedState) {
			*subState = -1;
			if (lockFree)
				addEngineFeedbackChange(element);
			else {
				addEngineChange(element, 0);
				threadManager_unlockSpin(element, context->engineManagerLock);
			}
			threadManager_lockMutex(element, context->suspendCondMutex);
			threadManager_wakeCondition(element, context->suspendCondition);
			threadManager_unlockMutex(element, context->suspendCondMutex);
		} else {
			if (*subState == skippingState && lockFree)
				context->skipCycles = 0;
			*subState = -1;
			if (lockFree)
				addEngineFeedbackChange(element);
			else {
				addEngineChange(element, 0);
				threadManager_unlockSpin(element, context->engineManagerLock);
			}
		}
	} else if (*mainState == stoppingState && isLockFree(element)) {
		// Only the processing thread can change from stopping to stopped state
		*mainState = stoppedState;
		addEngineFeedbackChange(element);
	} else {
		if (!lockFree)
			threadManager_unlockSpin(element, context->engineManagerLock);
	}
}

/**
 * Pause function
 * Usually called by the main thread when the user calls the
 * command pause
 */
void engineManager_pause(const DSPEElement *element) {
	int *mainState = getMainStatePtr(element);
	int *subState = getSubStatePtr(element);
	int lockFree = isLockFree(element);
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (!lockFree)
		threadManager_lockSpin(element, context->engineManagerLock);

	if (*mainState == executingState && *subState == pausedState) {
		if (!lockFree)
			threadManager_unlockSpin(element, context->engineManagerLock);
		return;
	}

	/* Enter the pause status if not already stopped */
	if (*mainState == executingState) {
		if (*subState == suspendedState) {
			*subState = pausedState;
			if (lockFree)
				addEngineFeedbackChange(element);
			else {
				addEngineChange(element, 0);
				threadManager_unlockSpin(element, context->engineManagerLock);
			}
			threadManager_lockMutex(element, context->suspendCondMutex);
			threadManager_wakeCondition(element, context->suspendCondition);
			threadManager_unlockMutex(element, context->suspendCondMutex);
		} else {
			*subState = pausedState;
			if (lockFree)
				addEngineFeedbackChange(element);
			else {
				addEngineChange(element, 0);
				threadManager_unlockSpin(element, context->engineManagerLock);
			}
		}
	} else {
		if (!lockFree)
			threadManager_unlockSpin(element, context->engineManagerLock);
	}
}

/**
 * EngineManager_skip function
 */
void engineManager_skip(const DSPEElement *element, long int cycles) {
	int *mainState = getMainStatePtr(element);
	int *subState = getSubStatePtr(element);
	int lockFree = isLockFree(element);
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (!lockFree)
		threadManager_lockSpin(element, context->engineManagerLock);
	else
		context->skipCycles = cycles;

	if (*mainState == stoppedState || *mainState == stoppingState) {
		*mainState = executingState;
		*subState = skippingState;
		if (lockFree)
			addEngineFeedbackChange(element);
		else {
			addEngineChange(element, cycles);
			threadManager_unlockSpin(element, context->engineManagerLock);
		}
		threadManager_lockMutex(element, context->startCondMutex);
		threadManager_wakeCondition(element, context->startCondition);
		threadManager_unlockMutex(element, context->startCondMutex);
	} else if (*mainState == executingState) {
		if (*subState == runningState) {
			*subState = skippingState;
			if (lockFree)
				addEngineFeedbackChange(element);
			else {
				addEngineChange(element, cycles);
				threadManager_unlockSpin(element, context->engineManagerLock);
			}
		} else if (*subState == pausedState) {
			*subState = skippingState;
			if (lockFree)
				addEngineFeedbackChange(element);
			else {
				addEngineChange(element, cycles);
				threadManager_unlockSpin(element, context->engineManagerLock);
			}
			threadManager_lockMutex(element, context->pauseCondMutex);
			threadManager_wakeCondition(element, context->pauseCondition);
			threadManager_unlockMutex(element, context->pauseCondMutex);
		} else if (*subState == suspendedState) {
			*subState = skippingState;
			if (lockFree)
				addEngineFeedbackChange(element);
			else {
				addEngineChange(element, cycles);
				threadManager_unlockSpin(element, context->engineManagerLock);
			}
			threadManager_lockMutex(element, context->suspendCondMutex);
			threadManager_wakeCondition(element, context->suspendCondition);
			threadManager_unlockMutex(element, context->suspendCondMutex);
		} else {
			if (!lockFree)
				threadManager_unlockSpin(element, context->engineManagerLock);
		}
	} else {
		if (!lockFree)
			threadManager_unlockSpin(element, context->engineManagerLock);
	}
}

/**
 * EngineManager_quit function
 */
void engineManager_quit(const DSPEElement *element) {
	int *mainState = getMainStatePtr(element);
	int *subState = getSubStatePtr(element);
	int lockFree = isLockFree(element);
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (!lockFree)
		threadManager_lockSpin(element, context->engineManagerLock);

	if (*mainState == exitState) {
		if (!lockFree)
			threadManager_unlockSpin(element, context->engineManagerLock);
		return;
	}

	if (*mainState == stoppedState || *mainState == stoppingState) {
		*mainState = exitState;
		if (lockFree)
			addEngineFeedbackChange(element);
		else {
			addEngineChange(element, 0);
			threadManager_unlockSpin(element, context->engineManagerLock);
		}
		threadManager_lockMutex(element, context->startCondMutex);
		threadManager_wakeCondition(element, context->startCondition);
		threadManager_unlockMutex(element, context->startCondMutex);
	} else if (*mainState == executingState) {
		*mainState = exitState;
		if (*subState == runningState) {
			*subState = -1;
			if (lockFree)
				addEngineFeedbackChange(element);
			else {
				addEngineChange(element, 0);
				threadManager_unlockSpin(element, context->engineManagerLock);
				threadManager_lockMutex(element, context->endRunCondMutex);
				threadManager_waitCondition(element, context->endRunCondition, context->endRunCondMutex);
				threadManager_unlockMutex(element, context->endRunCondMutex);
			}
		} else if (*subState == pausedState) {
			*subState = -1;
			if (lockFree)
				addEngineFeedbackChange(element);
			else {
				addEngineChange(element, 0);
				threadManager_unlockSpin(element, context->engineManagerLock);
			}
			threadManager_lockMutex(element, context->pauseCondMutex);
			threadManager_wakeCondition(element, context->pauseCondition);
			threadManager_unlockMutex(element, context->pauseCondMutex);
		} else if (*subState == suspendedState) {
			*subState = -1;
			if (lockFree)
				addEngineFeedbackChange(element);
			else {
				addEngineChange(element, 0);
				threadManager_unlockSpin(element, context->engineManagerLock);
			}
			threadManager_lockMutex(element, context->suspendCondMutex);
			threadManager_wakeCondition(element, context->suspendCondition);
			threadManager_unlockMutex(element, context->suspendCondMutex);
		} else if (*subState == skippingState) {
			*subState = -1;
			if (lockFree) {
				context->skipCycles = 0;
				addEngineFeedbackChange(element);
			} else {
				addEngineChange(element, 0);
				threadManager_unlockSpin(element, context->engineManagerLock);
				threadManager_lockMutex(element, context->endRunCondMutex);
				threadManager_waitCondition(element, context->endRunCondition, context->endRunCondMutex);
				threadManager_unlockMutex(element, context->endRunCondMutex);
			}
		} else {
			if (!lockFree)
				threadManager_unlockSpin(element, context->engineManagerLock);
		}
	} else {
		if (!lockFree)
			threadManager_unlockSpin(element, context->engineManagerLock);
	}
}

/**
 * Suspend function
 * Usually called by the processing application thread.
 * (e.g. a player unit implementation when the data buffers
 * are full).
 * NB: the thread will suspend at the end of the process phase
 */
void engineManager_suspend(const DSPEElement *element) {
	int *mainState = getMainStatePtr(element);
	int *subState = getSubStatePtr(element);
	int lockFree = isLockFree(element);
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (!lockFree)
		threadManager_lockSpin(element, context->engineManagerLock);

	if (*mainState == executingState && *subState == suspendedState) {
		if (!lockFree)
			threadManager_unlockSpin(element, context->engineManagerLock);
		return;
	}

	/* Enter the suspended status if not already stopped */
	if (*mainState == executingState) {
		if (*subState == pausedState) {
			*subState = suspendedState;
			if (lockFree)
				addEngineFeedbackChange(element);
			else {
				addEngineChange(element, 0);
				threadManager_unlockSpin(element, context->engineManagerLock);
			}
			threadManager_lockMutex(element, context->pauseCondMutex);
			threadManager_wakeCondition(element, context->pauseCondition);
			threadManager_unlockMutex(element, context->pauseCondMutex);
		} else {
			*subState = suspendedState;
			if (lockFree)
				addEngineFeedbackChange(element);
			else {
				addEngineChange(element, 0);
				threadManager_unlockSpin(element, context->engineManagerLock);
			}
		}
	} else {
		if (!lockFree)
			threadManager_unlockSpin(element, context->engineManagerLock);
	}
}

/**
 * Freeze function
 * This can be called from the processing application thread
 * only, because the calling thread is immediately
 * suspended !!!
 * (e.g. a player unit implementation when the
 * data buffers are full).application It returns the
 * info if the processing application thread has been stopped
 */
int engineManager_freeze(const DSPEElement *element) {
	int localStopped;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (!isLockFree(element))
		// Ignored because this function can only be called from the processing
		// thread since calling thread is immediately suspended
		return engineManager_isStopped(element) || engineManager_isStopping(element);

	/* Enter the suspended status and suspend itself if not already stopped */
	localStopped = context->mainState_lastValue == stoppedState;
	if (context->mainState_lastValue == executingState) {
		if (context->subState_lastValue == pausedState) {
			context->subState_lastValue = suspendedState;
			addEngineFeedbackChange(element);
			threadManager_lockMutex(element, context->pauseCondMutex);
			threadManager_wakeCondition(element, context->pauseCondition);
			threadManager_unlockMutex(element, context->pauseCondMutex);
		} else {
			context->subState_lastValue = suspendedState;
			addEngineFeedbackChange(element);
		}
		threadManager_lockMutex(element, context->suspendCondMutex);
		threadManager_waitCondition(element, context->suspendCondition, context->suspendCondMutex);
		threadManager_unlockMutex(element, context->suspendCondMutex);
	}

	return localStopped;
}

/**
 * Resume function
 * Usually called by a third thread
 * (e.g. a player when the data buffers aren't full any longer)
 */
void engineManager_resume(const DSPEElement *element) {
	int *mainState = getMainStatePtr(element);
	int *subState = getSubStatePtr(element);
	int lockFree = isLockFree(element);
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (!lockFree)
		threadManager_lockSpin(element, context->engineManagerLock);

	/* Reset the suspend condition only */
	if (*mainState == executingState && *subState == suspendedState) {
		*subState = runningState;
		if (lockFree)
			addEngineFeedbackChange(element);
		else {
			addEngineChange(element, 0);
			threadManager_unlockSpin(element, context->engineManagerLock);
		}
		threadManager_lockMutex(element, context->suspendCondMutex);
		threadManager_wakeCondition(element, context->suspendCondition);
		threadManager_unlockMutex(element, context->suspendCondMutex);
	} else {
		if (!lockFree)
			threadManager_unlockSpin(element, context->engineManagerLock);
	}
}

/**
 * EngineManager_performIdleTime function
 */
void engineManager_performIdleTime(const DSPEElement *element) {
	/* Forward request to do coprocContribution */
	coprocManager_coprocContribution(element);
}

/**
 * EngineManager_forceCriticalSection function.
 * Returns engineManager stopped state.
 */
int engineManager_forceCriticalSection(const DSPEElement *element) {

	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	updateEnginePendingChanges(context);
	// TODO L'update dello stato dell'engine dovrebbe essere fatto anch'esso con
	// il rate / timer del force critical section e non a ogni chiamata!!
	updateEngineChanges(context);

	if (--context->forceCriticalRateCounter != 0 && engineManager_isRunning(element))
		return engineManager_isStopped(element) || engineManager_isStopping(element);

	if (engineManager_isSkipping(element) && --context->skipCycles == 0)
		engineManager_pause(element);

	/* Wait condition if paused or suspended */
	while (engineManager_isPaused(element) || engineManager_isSuspended(element)) {
		if (engineManager_isPaused(element)) {
			if (context->skipCycles) context->skipCycles = 0;
			threadManager_lockMutex(element, context->pauseCondMutex);
			threadManager_waitCondition(element, context->pauseCondition, context->pauseCondMutex);
			threadManager_unlockMutex(element, context->pauseCondMutex);
		} else if (engineManager_isSuspended(element)) {
			threadManager_lockMutex(element, context->suspendCondMutex);
			threadManager_waitCondition(element, context->suspendCondition, context->suspendCondMutex);
			threadManager_unlockMutex(element, context->suspendCondMutex);
		}
		updateEngineState(context);
	}

	context->forceCriticalRateCounter = PARTICLETRACKERDLLPTCOPROC_3_PUSH_DLL_APPLICATION_UPDATERATE;

	return engineManager_isStopped(element) || engineManager_isStopping(element);
}

