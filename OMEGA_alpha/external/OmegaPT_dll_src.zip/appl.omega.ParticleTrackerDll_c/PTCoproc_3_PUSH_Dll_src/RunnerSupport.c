/**
 * File: RunnerSupport.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "PlatformManager.h"
#include "ErrorManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "ThreadManager.h"
#include "EngineManager.h"
#include "ProfileManager.h"
#include "CoprocManager.h"
#include "InfoManager.h"

#include "RunnerSupport.h"
#include "CriticalSection.h"
#include "TextualRepresentation.h"

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <limits.h>

/**
 * InitializeRunner function.
 */
ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib* initializeRunner() {
	int i;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context;

	/* Context allocation */
	errno = 0;
	context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) memorySupport_allocate(sizeof(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib));
	if (errno) {
		printf("EXIT - Error during application allocation");
		return NULL;
	}
	initDSPEApplication((DSPEApplication*) context);
	
	context->quitOnStop = 0;

	context->runnerDelegate = (DSPERunnerDelegate*) memoryManager_allocate((DSPEElement*) context, sizeof(DSPERunnerDelegate));
	initDSPERunnerDelegate(context->runnerDelegate, (DSPEApplication*) context);

	/* Log file init */
	context->logFile = NULL;

	/* Error manager initialization */
	errorManager_initialize((DSPEElement*) context->runnerDelegate);

	/* Info manager initialization */
	infoManager_initialize((DSPEElement*) context->runnerDelegate);

	/* Engine manager initialization */
	engineManager_initialize((DSPEElement*) context->runnerDelegate);

	/* Profile manager initialization */
	profileManager_initialize((DSPEElement*) context->runnerDelegate);

	/* Open log file */
	openLogFile(context, 1);

	/* Initialize change flags */
	initializeChangeFlags(context);

	/* SpinLocks and conditions initialization */
	initializeLocksAndConditions(context);

	/* Info swap areas initialization */
	context->infoSwapGui = (infoSwap**) memoryManager_allocate((DSPEElement*) context->runnerDelegate, MAX_NUM_THREADS * sizeof(infoSwap*));
	context->infoSwapEngine = (infoSwap**) memoryManager_allocate((DSPEElement*) context->runnerDelegate, MAX_NUM_THREADS * sizeof(infoSwap*));

	for (i = 0; i < MAX_NUM_THREADS; i++) {
		context->infoSwapGui[i] = NULL;
		context->infoSwapEngine[i] = NULL;
	}

	threadManager_initThreadHandler(CAST_TO_OWNER(context->runnerDelegate));
	
	/* GUI thread swap areas */
	infoManager_initInfoSwap((DSPEElement*) context->runnerDelegate, threadManager_getOwnerIndex(CAST_TO_OWNER(context->runnerDelegate)));
	/* Engine swap areas initialization */
	context->engineSwapGui = initializeEngineSwap(context);
	context->engineSwapEngine = initializeEngineSwap(context);

	/* Engine feedback swap areas initialization */
	context->engineFeedbackSwapGui = initializeEngineSwap(context);
	context->engineFeedbackSwapEngine = initializeEngineSwap(context);

	/* UpdateDisplay thread initialization */
	initializeUpdateDisplayThread(context);

	/* Initialize gui current values and engine last values */
	initializeCurAndLastValues(context);

	/* Context initialization */
	// FIXME startup called by activator thread
	// ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_startup((ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application*) context);
	((DSPEApplication*) context)->startup = ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_runnerStartup;
	((DSPEApplication*) context)->shutdown = ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_shutdown;

	/* Set preProcess and postProcess DSPEComponent's pointer to functions */
	((DSPEComponent*) context)->preprocess = ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_preProcess;
	((DSPEComponent*) context)->postprocess = ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_postProcess;

	/* Startup synchonization */
	// REMARK handleOptions may override input parameters by setting applications input gates, which are allocated 
	// and initialized during application_startup. Therefore we have to wait until activator thread has successful
	// completed application_startup call.
	threadManager_lockMutex((DSPEElement*) context, context->activatorConditionMutex);

	context->activatorDone = 0;
	/* EngineThread initialization */
	initializeEngineThread(context);

	/* Avoid spurious wakeups */
	while (context->activatorDone == 0) {
		threadManager_waitCondition((DSPEElement*) context, context->activatorCondition, context->activatorConditionMutex);
	}
	
	threadManager_unlockMutex((DSPEElement*) context, context->activatorConditionMutex);

	/* Show errors occurred during application startup */
	if (errorManager_hasErrorOccurred((DSPEElement*) context->runnerDelegate))
		errorManager_showErrors((DSPEElement*) context->runnerDelegate, "Errors during application startup.");
	/* From now on all error messages are immediately displayed on the screen */
	context->alwaysCollectErrors = 0;

	return context;
}

/**
 * DestroyRunner function.
 */
void destroyRunner(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	/* Show errors occurred during application shutdown */
	if (errorManager_hasErrorOccurred((DSPEElement*) context->runnerDelegate))
		errorManager_showErrors((DSPEElement*) context->runnerDelegate, "Errors during application shutdown.");
	/* From now on, errors are only collected */
	context->alwaysCollectErrors = 1;

	/* Waits for end of engineThread */
	waitEngineThreadEnd(context);

	/* Waits for end of updateDisplay thread */
	waitUpdateDisplayThreadEnd(context);

	/* Dispose infoswap */
	infoManager_disposeInfoSwap((DSPEElement*) context, threadManager_getOwnerIndex(CAST_TO_OWNER(context->runnerDelegate)));

	/* Swap areas dispose */
	disposeSwapAreas(context);

	/* Dispose handler pool */
	memoryManager_disposeHandlerPool((DSPEElement*) context, CAST_TO_OWNER(context->runnerDelegate));
	/* Profile manager dispose */
	profileManager_dispose((DSPEElement*) context->runnerDelegate);

	/* Engine manager dispose */
	engineManager_dispose((DSPEElement*) context->runnerDelegate);

	/* Dispose gui current values and engine last values */
	disposeCurAndLastValues(context);

	/* SpinLocks and conditions dispose */
	disposeLocksAndConditions(context);

	/* Info manager dispose */
	infoManager_dispose((DSPEElement*) context->runnerDelegate);

	/* Error manager dispose */
	errorManager_dispose((DSPEElement*) context->runnerDelegate);

	/* Close log file */
	closeLogFile(context);

	memorySupport_dispose((DSPEElement*) context->runnerDelegate);

	/* Context dispose */
	memorySupport_dispose(context);

}

/**
 * InitializeLocksAndConditions function.
 */
void initializeLocksAndConditions(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	DSPEElement *element = (DSPEElement*) context->runnerDelegate;

	/* Swap area spinLocks initialization */
	context->infoSwapLock = threadManager_createSpin(element);
	context->engineSwapLock = threadManager_createSpin(element);
	context->engineFeedbackSwapLock = threadManager_createSpin(element);

	/* Mutex initialization */
	context->engineMutex = threadManager_createMutex(element);
	context->pauseCondMutex = threadManager_createMutex(element);
	context->suspendCondMutex = threadManager_createMutex(element);
	context->startCondMutex = threadManager_createMutex(element);
	context->endRunCondMutex = threadManager_createMutex(element);
	context->activatorConditionMutex = threadManager_createMutex(element);

	/* Condition variables initialization */
	context->pauseCondition = threadManager_createCondition(element);
	context->suspendCondition = threadManager_createCondition(element);
	context->startCondition = threadManager_createCondition(element);
	context->endRunCondition = threadManager_createCondition(element);
	context->activatorCondition = threadManager_createCondition(element);
	}

/**
 * DisposeLocksAndConditions function.
 */
void disposeLocksAndConditions(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	DSPEElement *element = (DSPEElement*) context->runnerDelegate;

	/* Swap area spinLocks destroy */
	threadManager_deleteSpin(element, context->infoSwapLock);
	threadManager_deleteSpin(element, context->engineSwapLock);
	threadManager_deleteSpin(element, context->engineFeedbackSwapLock);

	/* Mutex destroy */
	threadManager_deleteMutex(element, context->engineMutex);
	threadManager_deleteMutex(element, context->pauseCondMutex);
	threadManager_deleteMutex(element, context->suspendCondMutex);
	threadManager_deleteMutex(element, context->startCondMutex);
	threadManager_deleteMutex(element, context->endRunCondMutex);
	threadManager_deleteMutex(element, context->activatorConditionMutex);

	/* Condition variables destroy */
	threadManager_destroyCondition(element, context->pauseCondition);
	threadManager_destroyCondition(element, context->suspendCondition);
	threadManager_destroyCondition(element, context->startCondition);
	threadManager_destroyCondition(element, context->endRunCondition);
	threadManager_destroyCondition(element, context->activatorCondition);
}

/**
 * ResetInputParameters function.
 * Updates application parameter input values by copying
 * current last values to application parameter inputs.
 */
static INLINE void resetInputParameters(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *application = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application*) context;
	/* Reset application parameter inputs. */
	if (*application->paramIn_Radius != *context->paramIn_Radius_curValue) {
		ParticleTrackerDllIntGate_StandardGate_set((DSPEElement*) context, application->paramIn_Radius, context->paramIn_Radius_curValue);
	}
	if (*application->paramIn_Cutoff != *context->paramIn_Cutoff_curValue) {
		ParticleTrackerDllRealGate_CustomGate_set((DSPEElement*) context, application->paramIn_Cutoff, context->paramIn_Cutoff_curValue);
	}
	if (*application->paramIn_Percentile != *context->paramIn_Percentile_curValue) {
		ParticleTrackerDllRealGate_CustomGate_set((DSPEElement*) context, application->paramIn_Percentile, context->paramIn_Percentile_curValue);
	}
	if (*application->paramIn_Displacement != *context->paramIn_Displacement_curValue) {
		ParticleTrackerDllRealGate_CustomGate_set((DSPEElement*) context, application->paramIn_Displacement, context->paramIn_Displacement_curValue);
	}
	if (*application->paramIn_Linkrange != *context->paramIn_Linkrange_curValue) {
		ParticleTrackerDllIntGate_StandardGate_set((DSPEElement*) context, application->paramIn_Linkrange, context->paramIn_Linkrange_curValue);
	}
	if (*application->paramIn_ImgsNum != *context->paramIn_ImgsNum_curValue) {
		ParticleTrackerDllIntGate_StandardGate_set((DSPEElement*) context, application->paramIn_ImgsNum, context->paramIn_ImgsNum_curValue);
	}
	if (*application->paramIn_ImgWidth != *context->paramIn_ImgWidth_curValue) {
		ParticleTrackerDllIntGate_StandardGate_set((DSPEElement*) context, application->paramIn_ImgWidth, context->paramIn_ImgWidth_curValue);
	}
	if (*application->paramIn_ImgHeight != *context->paramIn_ImgHeight_curValue) {
		ParticleTrackerDllIntGate_StandardGate_set((DSPEElement*) context, application->paramIn_ImgHeight, context->paramIn_ImgHeight_curValue);
	}
	if (*application->paramIn_ImgMin != *context->paramIn_ImgMin_curValue) {
		ParticleTrackerDllRealGate_CustomGate_set((DSPEElement*) context, application->paramIn_ImgMin, context->paramIn_ImgMin_curValue);
	}
	if (*application->paramIn_ImgMax != *context->paramIn_ImgMax_curValue) {
		ParticleTrackerDllRealGate_CustomGate_set((DSPEElement*) context, application->paramIn_ImgMax, context->paramIn_ImgMax_curValue);
	}
}

/**
 * SetPreProcessInputParameters function
 */
static INLINE void setPreProcessInputParameters(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *application = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application*) context;

	/* Update preProcess input parameter curValues */
	if (*context->paramIn_Radius_curValue != *application->paramIn_Radius) {
		*context->paramIn_Radius_curValue = *application->paramIn_Radius;
	}
	if (*context->paramIn_Cutoff_curValue != *application->paramIn_Cutoff) {
		*context->paramIn_Cutoff_curValue = *application->paramIn_Cutoff;
	}
	if (*context->paramIn_Percentile_curValue != *application->paramIn_Percentile) {
		*context->paramIn_Percentile_curValue = *application->paramIn_Percentile;
	}
	if (*context->paramIn_Displacement_curValue != *application->paramIn_Displacement) {
		*context->paramIn_Displacement_curValue = *application->paramIn_Displacement;
	}
	if (*context->paramIn_Linkrange_curValue != *application->paramIn_Linkrange) {
		*context->paramIn_Linkrange_curValue = *application->paramIn_Linkrange;
	}
	if (*context->paramIn_ImgsNum_curValue != *application->paramIn_ImgsNum) {
		*context->paramIn_ImgsNum_curValue = *application->paramIn_ImgsNum;
	}
	if (*context->paramIn_ImgWidth_curValue != *application->paramIn_ImgWidth) {
		*context->paramIn_ImgWidth_curValue = *application->paramIn_ImgWidth;
	}
	if (*context->paramIn_ImgHeight_curValue != *application->paramIn_ImgHeight) {
		*context->paramIn_ImgHeight_curValue = *application->paramIn_ImgHeight;
	}
	if (*context->paramIn_ImgMin_curValue != *application->paramIn_ImgMin) {
		*context->paramIn_ImgMin_curValue = *application->paramIn_ImgMin;
	}
	if (*context->paramIn_ImgMax_curValue != *application->paramIn_ImgMax) {
		*context->paramIn_ImgMax_curValue = *application->paramIn_ImgMax;
	}
}

/**
 * SetProcessOutputParameters function
 */
static INLINE void setProcessOutputParameters(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *application = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application*) context;

	/* Update process output parameter curValues */
	if (*application->paramOut_DataReader_status != NULL) {
		if (*context->paramOut_DataReader_status_curValue == NULL || stringSupport_compare(*context->paramOut_DataReader_status_curValue, *application->paramOut_DataReader_status) != 0) {
			*context->paramOut_DataReader_status_curValue = *context->paramOut_DataReader_status_curValueAnchor;
			stringSupport_copy(*context->paramOut_DataReader_status_curValue, *application->paramOut_DataReader_status);
		}
	} else {
		if (*context->paramOut_DataReader_status_curValue != NULL) {
			*context->paramOut_DataReader_status_curValue = NULL;
		}
	}
	if (*application->paramOut_Convolve_status != NULL) {
		if (*context->paramOut_Convolve_status_curValue == NULL || stringSupport_compare(*context->paramOut_Convolve_status_curValue, *application->paramOut_Convolve_status) != 0) {
			*context->paramOut_Convolve_status_curValue = *context->paramOut_Convolve_status_curValueAnchor;
			stringSupport_copy(*context->paramOut_Convolve_status_curValue, *application->paramOut_Convolve_status);
		}
	} else {
		if (*context->paramOut_Convolve_status_curValue != NULL) {
			*context->paramOut_Convolve_status_curValue = NULL;
		}
	}
	if (*application->paramOut_Dilate_status != NULL) {
		if (*context->paramOut_Dilate_status_curValue == NULL || stringSupport_compare(*context->paramOut_Dilate_status_curValue, *application->paramOut_Dilate_status) != 0) {
			*context->paramOut_Dilate_status_curValue = *context->paramOut_Dilate_status_curValueAnchor;
			stringSupport_copy(*context->paramOut_Dilate_status_curValue, *application->paramOut_Dilate_status);
		}
	} else {
		if (*context->paramOut_Dilate_status_curValue != NULL) {
			*context->paramOut_Dilate_status_curValue = NULL;
		}
	}
	if (*application->paramOut_FindThreshold_status != NULL) {
		if (*context->paramOut_FindThreshold_status_curValue == NULL || stringSupport_compare(*context->paramOut_FindThreshold_status_curValue, *application->paramOut_FindThreshold_status) != 0) {
			*context->paramOut_FindThreshold_status_curValue = *context->paramOut_FindThreshold_status_curValueAnchor;
			stringSupport_copy(*context->paramOut_FindThreshold_status_curValue, *application->paramOut_FindThreshold_status);
		}
	} else {
		if (*context->paramOut_FindThreshold_status_curValue != NULL) {
			*context->paramOut_FindThreshold_status_curValue = NULL;
		}
	}
	if (*application->paramOut_FindParticles_status != NULL) {
		if (*context->paramOut_FindParticles_status_curValue == NULL || stringSupport_compare(*context->paramOut_FindParticles_status_curValue, *application->paramOut_FindParticles_status) != 0) {
			*context->paramOut_FindParticles_status_curValue = *context->paramOut_FindParticles_status_curValueAnchor;
			stringSupport_copy(*context->paramOut_FindParticles_status_curValue, *application->paramOut_FindParticles_status);
		}
	} else {
		if (*context->paramOut_FindParticles_status_curValue != NULL) {
			*context->paramOut_FindParticles_status_curValue = NULL;
		}
	}
	if (*application->paramOut_PositionRefinement_status != NULL) {
		if (*context->paramOut_PositionRefinement_status_curValue == NULL || stringSupport_compare(*context->paramOut_PositionRefinement_status_curValue, *application->paramOut_PositionRefinement_status) != 0) {
			*context->paramOut_PositionRefinement_status_curValue = *context->paramOut_PositionRefinement_status_curValueAnchor;
			stringSupport_copy(*context->paramOut_PositionRefinement_status_curValue, *application->paramOut_PositionRefinement_status);
		}
	} else {
		if (*context->paramOut_PositionRefinement_status_curValue != NULL) {
			*context->paramOut_PositionRefinement_status_curValue = NULL;
		}
	}
	if (*application->paramOut_ParticlesDiscrimination_status != NULL) {
		if (*context->paramOut_ParticlesDiscrimination_status_curValue == NULL || stringSupport_compare(*context->paramOut_ParticlesDiscrimination_status_curValue, *application->paramOut_ParticlesDiscrimination_status) != 0) {
			*context->paramOut_ParticlesDiscrimination_status_curValue = *context->paramOut_ParticlesDiscrimination_status_curValueAnchor;
			stringSupport_copy(*context->paramOut_ParticlesDiscrimination_status_curValue, *application->paramOut_ParticlesDiscrimination_status);
		}
	} else {
		if (*context->paramOut_ParticlesDiscrimination_status_curValue != NULL) {
			*context->paramOut_ParticlesDiscrimination_status_curValue = NULL;
		}
	}
	if (*application->paramOut_LinkParticles_status != NULL) {
		if (*context->paramOut_LinkParticles_status_curValue == NULL || stringSupport_compare(*context->paramOut_LinkParticles_status_curValue, *application->paramOut_LinkParticles_status) != 0) {
			*context->paramOut_LinkParticles_status_curValue = *context->paramOut_LinkParticles_status_curValueAnchor;
			stringSupport_copy(*context->paramOut_LinkParticles_status_curValue, *application->paramOut_LinkParticles_status);
		}
	} else {
		if (*context->paramOut_LinkParticles_status_curValue != NULL) {
			*context->paramOut_LinkParticles_status_curValue = NULL;
		}
	}
	if (*application->paramOut_GenerateTrajectories_status != NULL) {
		if (*context->paramOut_GenerateTrajectories_status_curValue == NULL || stringSupport_compare(*context->paramOut_GenerateTrajectories_status_curValue, *application->paramOut_GenerateTrajectories_status) != 0) {
			*context->paramOut_GenerateTrajectories_status_curValue = *context->paramOut_GenerateTrajectories_status_curValueAnchor;
			stringSupport_copy(*context->paramOut_GenerateTrajectories_status_curValue, *application->paramOut_GenerateTrajectories_status);
		}
	} else {
		if (*context->paramOut_GenerateTrajectories_status_curValue != NULL) {
			*context->paramOut_GenerateTrajectories_status_curValue = NULL;
		}
	}
}

/**
 * ResetProfileData function.
 */
static INLINE void resetProfileData(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	profile *profileData = NULL;
	profileNode *curNode = NULL;
	DSPEProfileNode **profileQueue;
	size_t i;
	
	// Reset times and counters
	profileData = context->profileData;
	profileData->startTime = 0;
	profileData->endTime = 0;
	profileData->samplesCount = 0;
	profileData->processCount = 0;
	profileData->ticks = 0;

	// Reset queue
	profileQueue = profileData->profileQueue;
	for (i = 0; i < profileIDCount; i++) {
		curNode = (profileNode*) profileQueue[i];
		curNode->startTime = 0;
		curNode->totalTicks = 0;
		curNode->minTicks = LONG_MAX;
		curNode->maxTicks = 0;
		curNode->count = 0;
	}

	// Reset lag counters
	profileData->lagCountEnabled = 0;
	profileData->lag = 0;
	profileData->totalLag = 0;
	profileData->minLag = UINT_MAX;
	profileData->maxLag = 0;
	profileData->lagCount = 0;

	// Reset latency counters
	profileData->startLatency = 0;
	profileData->totalLatency = 0;
	profileData->minLatency = LONG_MAX;
	profileData->maxLatency = 0;
	profileData->latencyCount = 0;
}

/**
 * RunnerStartup function.
 */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_runnerStartup(DSPEApplication *application) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) application;
	DSPEElement *element = (DSPEElement*) context;

	/* Lock activatorCondition until application startup is finished */
	threadManager_lockMutex(element, context->activatorConditionMutex);

	/* Call application startup */
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_startup(application);

	/* Notify that startup has finished */
	context->activatorDone = 1;
	threadManager_wakeCondition(element, context->activatorCondition);

	/* Unock activatorCondition */
	threadManager_unlockMutex(element, context->activatorConditionMutex);
}

/**
 * RunnerPreProcess function.
 */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_runnerPreProcess(DSPEComponent *component) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) component;
	DSPEElement *element = (DSPEElement*) context;
	/* Activate coprocHandler (create engines if needed) */
	coprocManager_activateCoprocHandler((DSPEApplication*) component);



	/* Application force critical section rate initialization */
	context->forceCriticalRateCounter = PARTICLETRACKERDLLPTCOPROC_3_PUSH_DLL_APPLICATION_UPDATERATE;

	infoManager_writeInfo(element, "--- RUN STARTED ---");
	/* Application preprocessing; forces the output parameters update */
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_preProcess(component);

	setPreProcessInputParameters(context);
	/* PreProcess has ended - coproc engines can be activated */
	coprocManager_activateCoprocEngines((DSPEElement*) component);

}

/**
 * RunnerPostProcess function.
 */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_runnerPostProcess(DSPEComponent *component) {
	register size_t i;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) component;
	DSPEElement *element = (DSPEElement*) context;

	/* Suspend coprocEngines */
	coprocManager_suspendCoprocEngines((DSPEApplication*) context);


	/* Application postprocessing; forces the output parameters update */
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_postProcess(component);
	setProcessOutputParameters(context);
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_reset((ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application*) context);
	resetInputParameters(context);


	///* Show profile info */
	//infoManager_writeInfo(element, "ID\tmin [ms]\tmean [ms]\tmax [ms]\tnum measures");
	//infoManager_writeInfo(element, "--------------------------------------------------------------------------------");
	//for (i = 0;  i < profileIDCount; i++) {
	//	if (i == PTCoproc_3_PUSH_Dll_ID)
	//		/* Application profile info has already been shown */ 
	//		continue;
	//	profileManager_showProfileInfo(element, i);
	//}
	//infoManager_writeInfo(element, "--------------------------------------------------------------------------------");
	/* Reset profile data */
	resetProfileData(context);

	/* Display remaining info */
	updateInfo(element);

	//threadManager_lockSpin(element, context->infoLock);

	///* Log are written during updateInfo */
	///* Log collected info */
	//for (i = 0; i < infoIDCount; i++) {
	//	/* Write collected log */
	//	fprintf(context->logFile, "%s (%u times)\n", infoSupport_getCollectedInfoString((infoID) i), context->collectedLog[i]);
	//	context->collectedLog[i] = 0;
	//}

	//threadManager_unlockSpin(element, context->infoLock);

	infoManager_writeInfo(element, "--- RUN TERMINATED ---");
	/* Suspend coprocHandler */
	coprocManager_suspendCoprocHandler((DSPEApplication*) context);

	threadManager_lockMutex(element, context->endRunCondMutex);
	threadManager_wakeCondition(element, context->endRunCondition);
	threadManager_unlockMutex(element, context->endRunCondMutex);
	updateEngineState(context);
	engineManager_stop(element);

	if (context->quitOnStop)
		engineManager_quit(element);
}

/**
 * Run function.
 * Executes the application processing until the command stop is called.
 */
void run(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_runnerPreProcess((DSPEComponent*) context);

	/* Application processing loop, until stopped */
	while (engineManager_isExecuting((DSPEElement*) context))
		/* Application process() function call - parameters and counters are updated within forceCriticalSection */
		ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_process((DSPEComponent*) context);

	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_runnerPostProcess((DSPEComponent*) context);
}

/**
 * Start function.
 * Represents the processing thread. It executes the run
 * function until the command quit is called.
 */
THREAD_ROUTINE_LPART start(THREAD_ROUTINE_ARGS) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) args;
	DSPEElement *element = (DSPEElement*) context;
	DSPEApplication *application = (DSPEApplication*) context;
	size_t ownerIndex;

	/* Init threadHandler */
	threadManager_initThreadHandler(CAST_TO_OWNER((DSPEApplication*) context));

	ownerIndex = threadManager_getOwnerIndex(CAST_TO_OWNER((DSPEApplication*) context));

	/* Master thread infoSwap areas init */
	infoManager_initInfoSwap((DSPEElement*) context, ownerIndex);

	/* Call runner startup */
	application->startup(application);

	updateEngineState(context);
	while (1) {
		if ((engineManager_isStopped(element) || engineManager_isStopping(element)) && !engineManager_isExiting(element)) {
			threadManager_lockMutex(element, context->startCondMutex);
			threadManager_waitCondition(element, context->startCondition, context->startCondMutex);
			threadManager_unlockMutex(element, context->startCondMutex);
		}

		updateEngineState(context);
		if (engineManager_isExiting(element)) {
			break;
		}

		run(context);

		/* Forward quit request */
		updateEngineState(context);
		if (engineManager_isExiting(element)) {
			break;
		}
	}

	/* Call runner shutdown */
	application->shutdown(application);

	/*  Master thread infoSwap area dispose */
	infoManager_disposeInfoSwap((DSPEElement*) context, ownerIndex);

	THREAD_ROUTINE_RETURN;
}

/**
 * InitializeEngineThread function.
 */
void initializeEngineThread(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	const DSPEElement *element = (DSPEElement*) context->runnerDelegate;
	/* Engine thread creation */
	context->engineThread = threadManager_createThread(element, &start, context);
}

/**
 * WaitEngineThreadEnd function.
 */
void waitEngineThreadEnd(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	const DSPEElement *element = (DSPEElement*) context->runnerDelegate;
	/* Waits for end of engineThread */
	threadManager_waitThread(element, context->engineThread);
	threadManager_destroyThread(element, context->engineThread);
}

