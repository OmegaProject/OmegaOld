/**
 * File: TextualRepresentation.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef TextualRepresentation_h
#define TextualRepresentation_h

#include "RunnerGround.h"

#ifdef __cplusplus
extern "C" {
#endif

void optionPn(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context, char *opt, char *value, int *err);

void initializeUpdateDisplayThread(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context);

void waitUpdateDisplayThreadEnd(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
