/**
 * File: TextualRepresentation.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "PlatformManager.h"
#include "ErrorManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "ThreadManager.h"
#include "EngineManager.h"
#include "InfoManager.h"

#include "CriticalSection.h"
#include "TextualRepresentation.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

/**
 * OptionPn function.
 * Sets input parameters values
 */
void optionPn(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context, char *opt, char *value, int *err) {
	DSPEElement *element = (DSPEElement*) context->runnerDelegate;
	ParticleTrackerDllIntGate_StandardGate ParticleTrackerDllIntGate_StandardGate_converted;
	ParticleTrackerDllRealGate_CustomGate ParticleTrackerDllRealGate_CustomGate_converted;
	char *endp;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *application = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application*) context;
	errno = 0;

	if (stringSupport_compareNoCase(opt, "p0") == 0) {
		if (engineManager_isExecuting(element)) {
			printf("%s value cannot be modified while application is executing", opt);
			return;
		}

		/* Convert value */
		ParticleTrackerDllIntGate_StandardGate_converted = (int) strtol(value, &endp, 10);
		if (value == endp) {
			printf("\nERROR: p0 value is not an integer!\n");
			*err = 1;
			return;
		}
		if (errno == ERANGE) {
			printf("\nERROR: p0 value overflow!\n");
			*err = 1;
			return;
		}
		/* Check if value has changed */
		if (*context->paramIn_Radius_curValue == ParticleTrackerDllIntGate_StandardGate_converted)
			return;

		/* Update current value */
		*context->paramIn_Radius_curValue = ParticleTrackerDllIntGate_StandardGate_converted;

		/* Update application value */
		*application->paramIn_Radius = *context->paramIn_Radius_curValue;
	} else if (stringSupport_compareNoCase(opt, "p1") == 0) {
		if (engineManager_isExecuting(element)) {
			printf("%s value cannot be modified while application is executing", opt);
			return;
		}

		/* Convert value */
		ParticleTrackerDllRealGate_CustomGate_converted = strtod(value, &endp);
		if (value == endp) {
			printf("\nERROR: p1 value is not a double!\n");
			*err = 1;
			return;
		}
		if (errno == ERANGE) {
			printf("\nERROR: p1 value overflow!\n");
			*err = 1;
			return;
		}
		/* Check if value has changed */
		if (*context->paramIn_Cutoff_curValue == ParticleTrackerDllRealGate_CustomGate_converted)
			return;

		/* Update current value */
		*context->paramIn_Cutoff_curValue = ParticleTrackerDllRealGate_CustomGate_converted;

		/* Update application value */
		*application->paramIn_Cutoff = *context->paramIn_Cutoff_curValue;
	} else if (stringSupport_compareNoCase(opt, "p2") == 0) {
		if (engineManager_isExecuting(element)) {
			printf("%s value cannot be modified while application is executing", opt);
			return;
		}

		/* Convert value */
		ParticleTrackerDllRealGate_CustomGate_converted = strtod(value, &endp);
		if (value == endp) {
			printf("\nERROR: p2 value is not a double!\n");
			*err = 1;
			return;
		}
		if (errno == ERANGE) {
			printf("\nERROR: p2 value overflow!\n");
			*err = 1;
			return;
		}
		/* Check if value has changed */
		if (*context->paramIn_Percentile_curValue == ParticleTrackerDllRealGate_CustomGate_converted)
			return;

		/* Update current value */
		*context->paramIn_Percentile_curValue = ParticleTrackerDllRealGate_CustomGate_converted;

		/* Update application value */
		*application->paramIn_Percentile = *context->paramIn_Percentile_curValue;
	} else if (stringSupport_compareNoCase(opt, "p3") == 0) {
		if (engineManager_isExecuting(element)) {
			printf("%s value cannot be modified while application is executing", opt);
			return;
		}

		/* Convert value */
		ParticleTrackerDllRealGate_CustomGate_converted = strtod(value, &endp);
		if (value == endp) {
			printf("\nERROR: p3 value is not a double!\n");
			*err = 1;
			return;
		}
		if (errno == ERANGE) {
			printf("\nERROR: p3 value overflow!\n");
			*err = 1;
			return;
		}
		/* Check if value has changed */
		if (*context->paramIn_Displacement_curValue == ParticleTrackerDllRealGate_CustomGate_converted)
			return;

		/* Update current value */
		*context->paramIn_Displacement_curValue = ParticleTrackerDllRealGate_CustomGate_converted;

		/* Update application value */
		*application->paramIn_Displacement = *context->paramIn_Displacement_curValue;
	} else if (stringSupport_compareNoCase(opt, "p4") == 0) {
		if (engineManager_isExecuting(element)) {
			printf("%s value cannot be modified while application is executing", opt);
			return;
		}

		/* Convert value */
		ParticleTrackerDllIntGate_StandardGate_converted = (int) strtol(value, &endp, 10);
		if (value == endp) {
			printf("\nERROR: p4 value is not an integer!\n");
			*err = 1;
			return;
		}
		if (errno == ERANGE) {
			printf("\nERROR: p4 value overflow!\n");
			*err = 1;
			return;
		}
		/* Check if value has changed */
		if (*context->paramIn_Linkrange_curValue == ParticleTrackerDllIntGate_StandardGate_converted)
			return;

		/* Update current value */
		*context->paramIn_Linkrange_curValue = ParticleTrackerDllIntGate_StandardGate_converted;

		/* Update application value */
		*application->paramIn_Linkrange = *context->paramIn_Linkrange_curValue;
	} else if (stringSupport_compareNoCase(opt, "p5") == 0) {
		if (engineManager_isExecuting(element)) {
			printf("%s value cannot be modified while application is executing", opt);
			return;
		}

		/* Convert value */
		ParticleTrackerDllIntGate_StandardGate_converted = (int) strtol(value, &endp, 10);
		if (value == endp) {
			printf("\nERROR: p5 value is not an integer!\n");
			*err = 1;
			return;
		}
		if (errno == ERANGE) {
			printf("\nERROR: p5 value overflow!\n");
			*err = 1;
			return;
		}
		/* Check if value has changed */
		if (*context->paramIn_ImgsNum_curValue == ParticleTrackerDllIntGate_StandardGate_converted)
			return;

		/* Update current value */
		*context->paramIn_ImgsNum_curValue = ParticleTrackerDllIntGate_StandardGate_converted;

		/* Update application value */
		*application->paramIn_ImgsNum = *context->paramIn_ImgsNum_curValue;
	} else if (stringSupport_compareNoCase(opt, "p6") == 0) {
		if (engineManager_isExecuting(element)) {
			printf("%s value cannot be modified while application is executing", opt);
			return;
		}

		/* Convert value */
		ParticleTrackerDllIntGate_StandardGate_converted = (int) strtol(value, &endp, 10);
		if (value == endp) {
			printf("\nERROR: p6 value is not an integer!\n");
			*err = 1;
			return;
		}
		if (errno == ERANGE) {
			printf("\nERROR: p6 value overflow!\n");
			*err = 1;
			return;
		}
		/* Check if value has changed */
		if (*context->paramIn_ImgWidth_curValue == ParticleTrackerDllIntGate_StandardGate_converted)
			return;

		/* Update current value */
		*context->paramIn_ImgWidth_curValue = ParticleTrackerDllIntGate_StandardGate_converted;

		/* Update application value */
		*application->paramIn_ImgWidth = *context->paramIn_ImgWidth_curValue;
	} else if (stringSupport_compareNoCase(opt, "p7") == 0) {
		if (engineManager_isExecuting(element)) {
			printf("%s value cannot be modified while application is executing", opt);
			return;
		}

		/* Convert value */
		ParticleTrackerDllIntGate_StandardGate_converted = (int) strtol(value, &endp, 10);
		if (value == endp) {
			printf("\nERROR: p7 value is not an integer!\n");
			*err = 1;
			return;
		}
		if (errno == ERANGE) {
			printf("\nERROR: p7 value overflow!\n");
			*err = 1;
			return;
		}
		/* Check if value has changed */
		if (*context->paramIn_ImgHeight_curValue == ParticleTrackerDllIntGate_StandardGate_converted)
			return;

		/* Update current value */
		*context->paramIn_ImgHeight_curValue = ParticleTrackerDllIntGate_StandardGate_converted;

		/* Update application value */
		*application->paramIn_ImgHeight = *context->paramIn_ImgHeight_curValue;
	} else if (stringSupport_compareNoCase(opt, "p8") == 0) {
		if (engineManager_isExecuting(element)) {
			printf("%s value cannot be modified while application is executing", opt);
			return;
		}

		/* Convert value */
		ParticleTrackerDllRealGate_CustomGate_converted = strtod(value, &endp);
		if (value == endp) {
			printf("\nERROR: p8 value is not a double!\n");
			*err = 1;
			return;
		}
		if (errno == ERANGE) {
			printf("\nERROR: p8 value overflow!\n");
			*err = 1;
			return;
		}
		/* Check if value has changed */
		if (*context->paramIn_ImgMin_curValue == ParticleTrackerDllRealGate_CustomGate_converted)
			return;

		/* Update current value */
		*context->paramIn_ImgMin_curValue = ParticleTrackerDllRealGate_CustomGate_converted;

		/* Update application value */
		*application->paramIn_ImgMin = *context->paramIn_ImgMin_curValue;
	} else if (stringSupport_compareNoCase(opt, "p9") == 0) {
		if (engineManager_isExecuting(element)) {
			printf("%s value cannot be modified while application is executing", opt);
			return;
		}

		/* Convert value */
		ParticleTrackerDllRealGate_CustomGate_converted = strtod(value, &endp);
		if (value == endp) {
			printf("\nERROR: p9 value is not a double!\n");
			*err = 1;
			return;
		}
		if (errno == ERANGE) {
			printf("\nERROR: p9 value overflow!\n");
			*err = 1;
			return;
		}
		/* Check if value has changed */
		if (*context->paramIn_ImgMax_curValue == ParticleTrackerDllRealGate_CustomGate_converted)
			return;

		/* Update current value */
		*context->paramIn_ImgMax_curValue = ParticleTrackerDllRealGate_CustomGate_converted;

		/* Update application value */
		*application->paramIn_ImgMax = *context->paramIn_ImgMax_curValue;
	} else {
		printf("\nERROR: %s is not an option!\n", opt);
		*err = 1;
		return;
	}
}

/**
 * UpdateDisplay function.
 */
THREAD_ROUTINE_LPART updateDisplay(THREAD_ROUTINE_ARGS) {

	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) args;
	DSPEElement *element = (DSPEElement*) context->runnerDelegate;
	while (1) {
		/* Update engine state */
		updateEngineStateFeedback(context);

		if (engineManager_isExiting(element))
			THREAD_ROUTINE_RETURN;

		updateInfo((DSPEElement*) context->runnerDelegate);
		threadManager_delay(element, 0, 100000000);
	}
}

/**
 * InitializeUpdateDisplayThread function.
 */
void initializeUpdateDisplayThread(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	DSPEElement *element = (DSPEElement*) context->runnerDelegate;
	/* Message thread creation */
	context->updateDisplayThread = threadManager_createThread(element, &updateDisplay, context);
}

/**
 * WaitUpdateDisplayThreadEnd function.
 */
void waitUpdateDisplayThreadEnd(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	DSPEElement *element = (DSPEElement*) context->runnerDelegate;
	/* Waits for end of updateDisplay thread */
	threadManager_waitThread(element, context->updateDisplayThread);
	threadManager_destroyThread(element, context->updateDisplayThread);
}

