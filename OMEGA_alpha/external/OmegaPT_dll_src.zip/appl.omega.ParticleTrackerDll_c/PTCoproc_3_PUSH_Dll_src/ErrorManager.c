/**
 * File: ErrorManager.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "ErrorManager.h"

#include "InfoManager.h"

#include "RunnerGround.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <errno.h>

/**
 * Adds the given errorMsg to the error queue.
 * Returns the newly added errorNode for convenience.
 */
static INLINE DSPEErrorNode* addErrorNode(const DSPEElement *element, const char *errorMsg, va_list args) {
	DSPEErrorNode *node;
	size_t errorMsgLength;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	lockSpin(element, context->errorLock);
	if (context->errorQueueNodesNum >= ERROR_MAX_SIZE) {
		// Error queue is full, overwrite oldest error
		node = context->errorQueueHead;
		context->errorQueueHead = node->next;
		context->errorQueueNodesNum--;
		node->next = NULL;
	} else {
		// Retrieve node from pool (if any)
		switch (context->errorPoolNodesNum) {
		case 0:
			node = (DSPEErrorNode*) allocateMemory(element, sizeof(DSPEErrorNode));
			node->elementID = NULL;
			node->errorMsg = NULL;
			node->errorMsgLength = 0;
			node->next = NULL;
			break;
		case 1:
			node = context->errorPoolHead;
			context->errorPoolHead = NULL;
			context->errorPoolTail = NULL;
			context->errorPoolNodesNum = 0;
			node->next = NULL;
			break;
		default:
			node = context->errorPoolHead;
			context->errorPoolHead = node->next;
			context->errorPoolNodesNum--;
			node->next = NULL;
			break;
		}
	}

	errorMsgLength = (size_t) (vsnprintf(NULL, 0, errorMsg, args) + 1);
	if (node->errorMsgLength == 0) {
		node->errorMsg = (char*) allocateMemory(element, errorMsgLength);
		node->errorMsgLength = errorMsgLength;
	} else if (errorMsgLength > node->errorMsgLength) {
		node->errorMsg = (char*) reallocateMemory(node->errorMsg, errorMsgLength);
		node->errorMsgLength = errorMsgLength;
	}
	vsnprintf(node->errorMsg, node->errorMsgLength, errorMsg, args);

	if (element->getID == NULL)
		node->elementID = NULL;
	else
		node->elementID = element->getID(element);

	// Add error node to queue
	if (context->errorQueueNodesNum == 0) {
		context->errorQueueHead = node;
		context->errorQueueTail = node;
		context->errorQueueNodesNum = 1;
	} else {
		context->errorQueueTail->next = node;
		context->errorQueueTail = node;
		context->errorQueueNodesNum++;
	}
	unlockSpin(element, context->errorLock);

	return node;
}

/**
 * Displays the given error message to the screen.
 */
static INLINE void showError(const DSPEElement *element, DSPEErrorNode *node) {
	if (node == NULL)
		return;

	if (node->elementID != NULL)
		infoManager_writeInfo(element, "%s: %s", node->elementID, node->errorMsg);
	else
		infoManager_writeInfo(element, node->errorMsg);
}

/**
 * ErrorManager_initialize function
 */
void errorManager_initialize(const DSPEElement *element) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	// Always collect is set since info manager is not available
	context->alwaysCollectErrors = 1;

	context->errorLock = createSpin(element);

	context->errorPoolNodesNum = 0;
	context->errorPoolHead = NULL;
	context->errorPoolTail = NULL;

	context->errorQueueNodesNum = 0;
	context->errorQueueHead = NULL;
	context->errorQueueTail = NULL;
}

/**
 * ErrorManager_dispose function
 */
void errorManager_dispose(const DSPEElement *element) {
	DSPEErrorNode *node;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	while (context->errorQueueNodesNum > 0) {
		node = context->errorQueueHead;
		context->errorQueueHead = node->next;
		context->errorQueueNodesNum--;
		disposeMemory(node->errorMsg);
		node->next = NULL;
		disposeMemory(node);
	}

	while (context->errorPoolNodesNum > 0) {
		node = context->errorPoolHead;
		context->errorPoolHead = node->next;
		context->errorPoolNodesNum--;
		disposeMemory(node->errorMsg);
		node->next = NULL;
		disposeMemory(node);
	}
	disposeSpin(element, context->errorLock);
}

/**
 * ErrorManager_appendError function
 * Error is added to errorQueue and an error message is displayed.
 */
void errorManager_appendError(const DSPEElement *element, const char *errorMsg, ...) {
	va_list args;
	DSPEErrorNode *node;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	va_start(args, errorMsg);
	node = addErrorNode(element, errorMsg, args);
	va_end(args);
	if (!context->alwaysCollectErrors)
		showError(element, node);
}

/**
 * ErrorManager_appendStandardError function
 * Error is added to errorQueue and an error message is displayed.
 */
void errorManager_appendStandardError(const DSPEElement *element, int errorCode) {
	errorManager_appendError(element, strerror(errorCode));
}

/**
 * ErrorManager_collectError function.
 * Error is added to errorQueue but no error message is displayed.
 */
void errorManager_collectError(const DSPEElement *element, const char *errorMsg, ...) {
	va_list args;

	va_start(args, errorMsg);
	addErrorNode(element, errorMsg, args);
	va_end(args);
}

/**
 * ErrorManager_collectStandardError function
 * Error is added to errorQueue but no error message is displayed.
 */
void errorManager_collectStandardError(const DSPEElement *element, int errorCode) {
	errorManager_collectError(element, strerror(errorCode));
}

/**
 * ErrorManager_clearErrors function
 */
void errorManager_clearErrors(const DSPEElement *element) {
	DSPEErrorNode *node;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	lockSpin(element, context->errorLock);
	while (context->errorQueueNodesNum > 0) {
		node = context->errorQueueHead;
		context->errorQueueHead = node->next;
		context->errorQueueNodesNum--;
		node->next = NULL;

		// Add error node to pool
		if (context->errorPoolNodesNum == 0) {
			context->errorPoolHead = node;
			context->errorPoolTail = node;
			context->errorPoolNodesNum = 1;
		} else {
			context->errorPoolTail->next = node;
			context->errorPoolTail = node;
			context->errorPoolNodesNum++;
		}
	}
	unlockSpin(element, context->errorLock);
}

/**
 * ErrorManager_hasErrorOccurred function
 */
int errorManager_hasErrorOccurred(const DSPEElement *element) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	int hasErrors = 0;
	lockSpin(element, context->errorLock);
	hasErrors = context->errorQueueNodesNum != 0;
	unlockSpin(element, context->errorLock);
	return hasErrors;
}

/**
 * ErrorManager_showErrors function
 */
void errorManager_showErrors(const DSPEElement *element, const char *message) {
	register size_t i;
	DSPEErrorNode *node;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	lockSpin(element, context->errorLock);
	if (context->errorQueueNodesNum == 0) {
		// No errors to display
		unlockSpin(element, context->errorLock);
		return;
	}

	if (message != NULL)
		infoManager_writeInfo(element, message);
	node = context->errorQueueHead;
	for (i = 0; i < context->errorQueueNodesNum; i++) {
		showError(element, node);
		node = node->next;
	}
	unlockSpin(element, context->errorLock);
}

