/**
 * File: ProfileManager.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef ProfileManager_h
#define ProfileManager_h

#include "DSPEElements.h"

/* Profile ids */
typedef enum profileID {
	PTCoproc_3_PUSH_Dll_ID,
	PTCoproc_3_PUSH_Dll_ConvolveAllCaseCP_PUSH_ID,
	PTCoproc_3_PUSH_Dll_DilateAllCaseCP_PUSH_ID,
	PTCoproc_3_PUSH_Dll_FindThresholdCP_ID,
	PTCoproc_3_PUSH_Dll_FindParticlesCPNewAutoNext_PUSH_2_ID,
	PTCoproc_3_PUSH_Dll_PositionRefinementCP_PUSH_2_ID,
	PTCoproc_3_PUSH_Dll_ParticlesDiscriminationStateCP_PUSH_ID,
	PTCoproc_3_PUSH_Dll_LinkParticlesStateCPAutoNext_PUSH_ID,
	PTCoproc_3_PUSH_Dll_GenerateTrajectoriesStateCPAutoNextNew_PUSH_ID,
	profileIDCount
} profileID;

#ifdef __cplusplus
extern "C" {
#endif

/* PROFILE SUPPORT */

/**
 * ProfileManager_initProfileQueue function
 */
DSPEProfileNode** profileManager_initProfileQueue(const DSPEElement *element);

/**
 * ProfileManager_disposeProfileQueue function
 */
void profileManager_disposeProfileQueue(const DSPEElement *element, DSPEProfileNode **profileQueue);

/**
 * ProfileManager_initialize function
 */
void profileManager_initialize(const DSPEElement *element);

/**
 * ProfileManager_dispose function
 */
void profileManager_dispose(const DSPEElement *element);

/**
 * ProfileSupport_getProfileString function
 */
const char* profileSupport_getProfileString(const profileID id);

/**
 * ProfileSupport_getUnitProfileID function
 */
profileID profileSupport_getUnitProfileID(char* unitID);

/**
 * ProfileManager_captureStartTime function
 */
void profileManager_captureStartTime(const DSPEElement *element, profileID id);

/**
 * ProfileManager_captureEndTime function
 */
void profileManager_captureEndTime(const DSPEElement *element, profileID id);

/**
 * ProfileManager_incrementSamplesCount function
 */
void profileManager_incrementSamplesCount(const DSPEElement *element, const unsigned int increment);

/**
 * ProfileManager_getSamplesCount function
 */
unsigned int profileManager_getSamplesCount(const DSPEElement *element);

/**
 * ProfileManager_getElapsedTime function
 * Returns the elapsed time in seconds
 */
double profileManager_getElapsedTime(const DSPEElement *element);

/**
 * ProfileManager_getMeanProcessTime function
 * Returns the mean process time in milliseconds
 */
double profileManager_getMeanProcessTime(const DSPEElement *element, profileID id);

/**
 * ProfileManager_getMinProcessTime function
 * Returns the min process time in milliseconds
 */
double profileManager_getMinProcessTime(const DSPEElement *element, profileID id);

/**
 * ProfileManager_getMaxProcessTime function
 * Returns the max process time in milliseconds
 */
double profileManager_getMaxProcessTime(const DSPEElement *element, profileID id);

/**
 * ProfileManager_getThroughput function
 */
double profileManager_getThroughput(const DSPEElement *element);

/**
 * ProfileManager_isProfileUnit function
 */
int profileManager_isProfileUnit(const DSPEElement *element, profileID id);

/**
 * ProfileManager_mergeQueue function
 */
void profileManager_mergeQueue(const DSPEElement *element, DSPEProfileNode **queue);

/* LAG AND LATENCY SUPPORT */

/**
 * ProfileManager_sendSignal function
 */
void profileManager_sendSignal(const DSPEElement *element);

/**
 * ProfileManager_receiveSignal function
 */
void profileManager_receiveSignal(const DSPEElement *element);

/**
 * ProfileManager_isSignalSent function
 */
int profileManager_isSignalSent(const DSPEElement *element);

/**
 * ProfileManager_incrementLag function
 */
void profileManager_incrementLag(const DSPEElement *element, const unsigned int increment);

/**
 * ProfileManager_getMeanLag function
 */
unsigned int profileManager_getMeanLag(const DSPEElement *element);

/**
 * ProfileManager_getMinLag function
 */
unsigned int profileManager_getMinLag(const DSPEElement *element);

/**
 * ProfileManager_getMaxLag function
 */
unsigned int profileManager_getMaxLag(const DSPEElement *element);

/**
 * ProfileManager_getMeanLatency function
 * Returns the mean latency in milliseconds
 */
double profileManager_getMeanLatency(const DSPEElement *element);

/**
 * ProfileManager_getMinLatency function
 * Returns the min latency in milliseconds
 */
double profileManager_getMinLatency(const DSPEElement *element);

/**
 * ProfileManager_getMaxLatency function
 * Returns the max latency in milliseconds
 */
double profileManager_getMaxLatency(const DSPEElement *element);

/**
 * ProfileManager_showProfileInfo function
 */
void profileManager_showProfileInfo(const DSPEElement *element, profileID id);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
