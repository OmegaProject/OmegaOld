/**
 * File: RunnerGround.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef RunnerGround_h
#define RunnerGround_h

#include "DSPEElements.h"

#include "B_ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application.h"

#include <time.h>
#include <stdio.h>

/* Info node definition */
typedef struct DSPEInfoNode DSPEInfoNode;

struct DSPEInfoNode {
	DSPEInfoNode *next;

	char *info;
	size_t infoLength;
};

/* Info swap definition */
typedef struct infoSwap infoSwap;

struct infoSwap {
	/* Info pool */
	unsigned int poolNodesNum;
	DSPEInfoNode *poolHead;
	DSPEInfoNode *poolTail;

	/* Info changes list */
	unsigned int changesNodesNum;
	DSPEInfoNode *changesHead;
	DSPEInfoNode *changesTail;

	/* Log changes list */
	unsigned int logChangesNodesNum;
	DSPEInfoNode *logChangesHead;
	DSPEInfoNode *logChangesTail;

	/* Collected info */
	unsigned int *collectedInfo;

	/* Collected log */
	unsigned int *collectedLog;

	/* Info adding changes */
	int addingChanges;
	int isReading;

	/* Info changes lock */
	void *changesLock;
};

/* Engine swap definition */
typedef struct engineSwap engineSwap;

struct engineSwap {
	/* Engine new states */
	int mainState;
	int subState;

	long int skipCycles;

	/* Engine adding changes */
	int addingChanges;

	/* Engine changes lock */
	void *changesLock;
};

/* Error node definition */
typedef struct DSPEErrorNode DSPEErrorNode;

struct DSPEErrorNode {
	DSPEErrorNode *next;

	char *errorMsg;
	size_t errorMsgLength;
	char *elementID;
};

/* Profile node definition */
typedef struct profileNode profileNode;

struct profileNode {
	DSPEProfileNode node;

	clock_t startTime;
	clock_t totalTicks;
	clock_t minTicks;
	clock_t maxTicks;
	unsigned int count;
};

/* Profile definition */
typedef struct profile profile;

struct profile {
	// Time and counters
	clock_t startTime;
	clock_t endTime;
	clock_t ticks;

	unsigned int samplesCount;
	unsigned int processCount;

	// Lag support
	int lagCountEnabled;
	unsigned int lag;
	unsigned int totalLag;
	unsigned int minLag;
	unsigned int maxLag;
	unsigned int lagCount;

	// Latency support
	clock_t startLatency;
	clock_t totalLatency;
	clock_t minLatency;
	clock_t maxLatency;
	unsigned int latencyCount;

	// Profile queue
	DSPEProfileNode **profileQueue;
};

/* Application type definition */
typedef struct ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib;

/* Application definition */
struct ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib {

	/* Application */
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application application;

	/* Needed to be able to distinguish between gui thread and processing thread */
	DSPERunnerDelegate *runnerDelegate;

	/* Critical section variables */
	/* Info swaps */
	void *infoSwapLock;
	int isInfoChanged;
	int isInfoChangePending;
	infoSwap **infoSwapGui;
	infoSwap **infoSwapEngine;

	/* Engine swaps */
	void *engineSwapLock;
	int isEngineChanged;
	int isEngineChangePending;
	engineSwap *engineSwapGui;
	engineSwap *engineSwapEngine;

	/* Engine feedback swaps */
	void *engineFeedbackSwapLock;
	int isEngineFeedbackChanged;
	int isEngineFeedbackChangePending;
	engineSwap *engineFeedbackSwapGui;
	engineSwap *engineFeedbackSwapEngine;

	/* Application force critical section rate counter */
	int forceCriticalRateCounter;

	/* GUI current values */
	ParticleTrackerDllIntGate_StandardGate *paramIn_Radius_curValue;
	ParticleTrackerDllRealGate_CustomGate *paramIn_Cutoff_curValue;
	ParticleTrackerDllRealGate_CustomGate *paramIn_Percentile_curValue;
	ParticleTrackerDllRealGate_CustomGate *paramIn_Displacement_curValue;
	ParticleTrackerDllIntGate_StandardGate *paramIn_Linkrange_curValue;
	ParticleTrackerDllIntGate_StandardGate *paramIn_ImgsNum_curValue;
	ParticleTrackerDllIntGate_StandardGate *paramIn_ImgWidth_curValue;
	ParticleTrackerDllIntGate_StandardGate *paramIn_ImgHeight_curValue;
	ParticleTrackerDllRealGate_CustomGate *paramIn_ImgMin_curValue;
	ParticleTrackerDllRealGate_CustomGate *paramIn_ImgMax_curValue;
	ParticleTrackerDllStatusGate_StringGate *paramOut_DataReader_status_curValue;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Convolve_status_curValue;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Dilate_status_curValue;
	ParticleTrackerDllStatusGate_StringGate *paramOut_FindThreshold_status_curValue;
	ParticleTrackerDllStatusGate_StringGate *paramOut_FindParticles_status_curValue;
	ParticleTrackerDllStatusGate_StringGate *paramOut_PositionRefinement_status_curValue;
	ParticleTrackerDllStatusGate_StringGate *paramOut_ParticlesDiscrimination_status_curValue;
	ParticleTrackerDllStatusGate_StringGate *paramOut_LinkParticles_status_curValue;
	ParticleTrackerDllStatusGate_StringGate *paramOut_GenerateTrajectories_status_curValue;

	/* GUI current value anchors */
	ParticleTrackerDllStatusGate_StringGate *paramOut_DataReader_status_curValueAnchor;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Convolve_status_curValueAnchor;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Dilate_status_curValueAnchor;
	ParticleTrackerDllStatusGate_StringGate *paramOut_FindThreshold_status_curValueAnchor;
	ParticleTrackerDllStatusGate_StringGate *paramOut_FindParticles_status_curValueAnchor;
	ParticleTrackerDllStatusGate_StringGate *paramOut_PositionRefinement_status_curValueAnchor;
	ParticleTrackerDllStatusGate_StringGate *paramOut_ParticlesDiscrimination_status_curValueAnchor;
	ParticleTrackerDllStatusGate_StringGate *paramOut_LinkParticles_status_curValueAnchor;
	ParticleTrackerDllStatusGate_StringGate *paramOut_GenerateTrajectories_status_curValueAnchor;

	/* Engine state current values (used by gui) */
	int mainState_curValue;
	int subState_curValue;

	/* Engine state last values (used by processing thread) */
	int mainState_lastValue;
	int subState_lastValue;

	/* EngineManager variables */
	long int skipCycles;
	int quitOnStop;
	void *engineManagerLock;
	void *engineMutex;
	void *pauseCondMutex;
	void *suspendCondMutex;
	void *startCondMutex;
	void *endRunCondMutex;
	void *pauseCondition;
	void *suspendCondition;
	void *startCondition;
	void *endRunCondition;
	void *engineThread;

	/* ActivatorThread synchonization variables */
	void *activatorConditionMutex;
	void *activatorCondition;
	int activatorDone;

	void *updateDisplayThread;

	/* ErrorManager variables */
	void *errorLock;

	unsigned int errorPoolNodesNum;
	DSPEErrorNode *errorPoolHead;
	DSPEErrorNode *errorPoolTail;

	unsigned int errorQueueNodesNum;
	DSPEErrorNode *errorQueueHead;
	DSPEErrorNode *errorQueueTail;

	int alwaysCollectErrors;

	/* InfoManager support */
	/* Info pool */
	unsigned int infoPoolNodesNum;
	DSPEInfoNode *infoPoolHead;
	DSPEInfoNode *infoPoolTail;

	/* Log list */
	unsigned int logNodesNum;
	DSPEInfoNode *logHead;
	DSPEInfoNode *logTail;

	/* Collected log */
	unsigned int *collectedLog;

	/* Info lock */
	/* Lock needed to avoid concurrent access to queues and arrays declared above.
	 * Usually only the GUI thread access those data; except at postProcess when
	 * the main thread retrieves the information available into swap areas before
	 * disposing them. */
	void *infoLock;

	/* Profile variable */
	profile *profileData;

	/* Log file variable */
	FILE *logFile;

};

#ifdef __cplusplus
extern "C" {
#endif

/* LOG FILE SUPPORT */

void openLogFile(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context, int logCurrentTime);

void closeLogFile(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context);

/* 
 * REMARK: Managers using these functions cannot directly include the
 * corresponding manager header file (MemoryManager or ThreadManager)
 * to avoid circular inclusions when inline support is active.
 */

/* MEMORY SUPPORT */

void* allocateMemory(const DSPEElement *element, size_t size);

void* allocateAndInitMemory(const DSPEElement *element, size_t blockSize, unsigned int size);

void* reallocateMemory(void *pointer, size_t newSize);

void disposeMemory(void *pointer);

/* SPINLOCK SUPPORT */

void* createSpin(const DSPEElement *element);

void disposeSpin(const DSPEElement *element, void *spin);

void lockSpin(const DSPEElement *element, void *spin);

void unlockSpin(const DSPEElement *element, void *spin);

/* OWNER INDEX SUPPORT */

size_t getOwnerIndex(const DSPEOwner *owner);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
