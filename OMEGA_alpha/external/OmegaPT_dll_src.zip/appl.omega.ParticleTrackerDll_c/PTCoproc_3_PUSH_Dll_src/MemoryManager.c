/**
 * File: MemoryManager.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "MemoryManager.h"

#include "ErrorManager.h"
#include "RunnerGround.h"

#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <windows.h>
#include <stdio.h>

/**
 * MemorySupport_allocate function
 */
void* memorySupport_allocate(size_t size) {
	return malloc(size);
}

/**
 * MemorySupport_allocateAndInit function
 */
void* memorySupport_allocateAndInit(size_t blockSize, size_t size) {
	return calloc(blockSize, size);
}

/**
 * MemorySupport_realloc function
 */
void* memorySupport_realloc(void *pointer, size_t newSize) {
	return realloc(pointer, newSize);
}

/**
 * MemorySupport_dispose function
 */
void memorySupport_dispose(void *pointer) {
	free(pointer);
}

/**
 * MemorySupport_copyBlock function
 */
void memorySupport_copyBlock(void *destination, const void *source, size_t size) {
	memcpy(destination, source, size);
}

/**
 * MemorySupport_resetBlock function
 */
void memorySupport_resetBlock(void *destination, size_t size) {
	memset(destination, 0, size);
}

/**
 * MemoryManager_allocate function
 */
void* memoryManager_allocate(const DSPEElement *element, size_t size) {
	void *allocated;
	errno = 0;
	allocated = malloc(size);
	if (errno)
		errorManager_appendStandardError(element, errno);
	return allocated;
}

/**
 * MemoryManager_allocateAndInit function
 */
void* memoryManager_allocateAndInit(const DSPEElement *element, size_t blockSize, size_t size) {
	void *allocated;
	errno = 0;
	allocated = calloc(blockSize, size);
	if (errno)
		errorManager_appendStandardError(element, errno);
	return allocated;
}

/**
 * MemoryManager_allocateHandlerPool function
 */
void memoryManager_allocateHandlerPool(const DSPEElement *element, DSPEOwner *ownerExt) {
	register size_t i;
	ownerExt->handlers = (DSPEHandler**) memoryManager_allocate(element, MAX_NUM_HANDLERS * sizeof(DSPEHandler*));

	for (i = 0; i < MAX_NUM_HANDLERS; i++) {
		ownerExt->handlers[i] = NULL;
	}
}

/**
 * MemoryManager_resetHandlerPool function
 */
void memoryManager_resetHandlerPool(const DSPEElement *element, DSPEOwner *ownerExt) {
	register size_t i;
	DSPEHandler *handler = NULL;

	for (i = 0; i < MAX_NUM_HANDLERS; i++) {
		handler = ownerExt->handlers[i];
		if (handler != NULL)
			handler->reset(handler);
	}
}

/**
 * MemoryManager_disposeHandlerPool function
 */
void memoryManager_disposeHandlerPool(const DSPEElement *element, DSPEOwner *ownerExt) {
	register size_t i;
	DSPEHandler *handler = NULL;

	for (i = 0; i < MAX_NUM_HANDLERS; i++) {
		handler = ownerExt->handlers[i];
		/* Not all handlers might have been created! */
		if (handler != NULL)
			handler->dispose(handler);
	}
	/* Dispose allocated handlers array */
	memorySupport_dispose(ownerExt->handlers);
	
	// REMARK needed when disposing threadHandler on runnerDelegates, because application
	// handlers are disposed before runnerDelegate handlers!
	ownerExt->handlers = NULL;
}

/* PoolHandlers functions */

/**
 * PoolHandler reset function
 */
void memoryManager_resetPoolHandler(DSPEHandler *handler) {
	DSPEEventsPool *curPool = ((DSPEPoolHandler*) handler)->poolsHead;

	while (curPool != NULL) {
		if (curPool->reset != NULL)
			curPool->reset(curPool);
		curPool = curPool->next;
	}
}

/**
 * PoolHandler dispose function
 */
void memoryManager_disposePoolHandler(DSPEHandler *handler) {
	DSPEEventsPool *curPool = ((DSPEPoolHandler*) handler)->poolsHead;
	DSPEEventsPool *next = NULL;
	DSPEEvent *event = NULL;
	DSPECoprocEventsPool *coprocPool = ((DSPEPoolHandler*) handler)->coprocEventsPool;
	/* Dispose pools and events contained in pools */
	while (curPool != NULL) {
		next = curPool->next;
		curPool->dispose(curPool);
		curPool = next;
	}
	/* If coprocPool set */
	if (coprocPool != NULL) {
		/* Dispose events within coprocEventsPool */
		while (coprocPool->eventsHead != NULL) {
			event = (DSPEEvent*) coprocPool->eventsHead;
			coprocPool->eventsHead = (DSPECoprocEvent*) event->next;
			event->next = NULL;
			memorySupport_dispose(event);
		}
		memorySupport_dispose(coprocPool);
	}
	memorySupport_dispose(handler);
}

/**
 * PoolHandler initialization function
 */
void memoryManager_initPoolHandler(DSPEOwner *ownerExt) {
	DSPEPoolHandler *handler = NULL;
	const DSPEElement *element = CAST_TO_ELEMENT(ownerExt);
	DSPEHandler **handlers = ownerExt->handlers;

	if (handlers == NULL) {
		memoryManager_allocateHandlerPool(element, ownerExt);
		handlers = ownerExt->handlers;
	}

	handler = (DSPEPoolHandler*) memoryManager_allocate(element, sizeof(DSPEPoolHandler));
	initDSPEElement((DSPEElement*) handler, element);
	initDSPEPoolHandler(handler, element);
	((DSPEHandler*) handler)->reset = memoryManager_resetPoolHandler;
	((DSPEHandler*) handler)->dispose = memoryManager_disposePoolHandler;

	/* Add Handler */
	handlers[HANDLER_INDEX_EVENTPOOL] = (DSPEHandler*) handler;
}

/**
 * PoolHandler prealloc function
 */
void memoryManager_preAllocPoolHandler(DSPEElement *element, unsigned int size) {
	DSPEPoolHandler *handler = memoryManager_getPoolHandler(element->owner);
	DSPEEventsPool *curPool = handler->poolsHead;

	while (curPool != NULL) {
		curPool->preAlloc(curPool, size);
		curPool = curPool->next;
	}
}

/**
 * MemoryManager_addBaseEventPool function 
 */
void memoryManager_addPool(DSPEPoolHandler *handler, DSPEBaseEventsPool *pool) {
	switch (handler->poolsNumElements) {
		case 0:
			handler->poolsHead = (DSPEEventsPool*) pool;
			handler->poolsTail = (DSPEEventsPool*) pool;
			handler->poolsNumElements++;
			break;
		default:
			handler->poolsTail->next = (DSPEEventsPool*) pool;
			handler->poolsTail = (DSPEEventsPool*) pool;
			handler->poolsNumElements++;
			break;
	}
}

/**
 * MemoryManager_getBaseEventPool function 
 */
DSPEBaseEventsPool* memoryManager_getPool(DSPEPoolHandler *handler, void *gateDefID) {
	register size_t i;
	DSPEEventsPool *curPool =  handler->poolsHead;

	for (i = 0; i < handler->poolsNumElements; i++) {
		if (curPool->gateDefID == gateDefID)
			return (DSPEBaseEventsPool*) curPool;
		curPool = curPool->next;
	}
	return NULL;
}

/**
 * MemoryManager_addGroupEventPool function
 */
void memoryManager_addGroupPool(DSPEPoolHandler *handler, DSPEGroupEventsPool *pool) {
	register size_t i;
	void *gateDefRef = ((DSPEEventsPool*) pool)->gateDefID;
	DSPEEventsPool *curPool =  handler->poolsHead;

	if (handler->poolsNumElements == 0) {
		handler->poolsHead = (DSPEEventsPool*) pool;
		handler->poolsTail = (DSPEEventsPool*) pool;
		handler->poolsNumElements++;
		return;
	}

	for (i = 0; i < handler->poolsNumElements; i++) {
		/* found Pool for correct gate */
		if (curPool->gateDefID == gateDefRef) {
			switch (((DSPEGroupEventsPool*) curPool)->groupsNumElements) {
			case 0:
				((DSPEGroupEventsPool*) curPool)->groupsHead = pool;
				((DSPEGroupEventsPool*) curPool)->groupsTail = pool;
				((DSPEGroupEventsPool*) curPool)->groupsNumElements++;
				return;
			default:
				((DSPEEventsPool*) ((DSPEGroupEventsPool*) curPool)->groupsTail)->next = (DSPEEventsPool*) pool;
				((DSPEGroupEventsPool*) curPool)->groupsTail = pool;
				((DSPEGroupEventsPool*) curPool)->groupsNumElements++;
				return;
			}
		}
		/* move to next gateDefID pool */
		curPool = curPool->next;
	}
	/* Append new pool */
	handler->poolsTail->next = (DSPEEventsPool*)pool;
	handler->poolsTail = (DSPEEventsPool*) pool;
	handler->poolsNumElements++;
}

/**
 * MemoryManager_getGroupEventPool function
 */
DSPEGroupEventsPool* memoryManager_getGroupPool(DSPEPoolHandler *handler, void *gateDefID, size_t groupSize) {
	register int lookForGroupsize = 0;
	DSPEEventsPool *curPool =  handler->poolsHead;

	while (curPool != NULL) {
		/* Found pool for gateDefinition */
		if (curPool->gateDefID == gateDefID) {
			/* Found pool having same groupSize */
			if (((DSPEGroupEventsPool*) curPool)->groupSize == groupSize) {
				return (DSPEGroupEventsPool*) curPool;
			} else if (!lookForGroupsize) {
				lookForGroupsize = 1;
				/* continue on groups (different groupSizes for same gateDefinition) */
				curPool = (DSPEEventsPool*) ((DSPEGroupEventsPool*) curPool)->groupsHead;
				/* avoid doing next otherwise we loose the groupsHead! */
				continue;
			}
		}
		curPool = curPool->next;
	}
	return NULL;
}

/**
 * MemoryManager_initCoprocEventPool function
 */
DSPECoprocEventsPool* memoryManager_initCoprocPool(DSPECoprocScheduler *scheduler) {
	DSPEPoolHandler *handler = memoryManager_getPoolHandler(((DSPEElement*) scheduler)->owner);
	if (handler->coprocEventsPool == NULL) {
		handler->coprocEventsPool = (DSPECoprocEventsPool*) memorySupport_allocate(sizeof(DSPECoprocEventsPool));
		initDSPEElement((DSPEElement*) handler->coprocEventsPool, (DSPEElement*) handler);
		initDSPECoprocEventsPool(handler->coprocEventsPool);
	}
	return handler->coprocEventsPool;
}

/******************************************************************************
 * EXTERNAL EVENTS SUPPORT
 ******************************************************************************/

/**
 * MemoryManager_initExternalEventsQueue function
 */
DSPEExternalEventsQueue* memoryManager_initExternalEventsQueue(const DSPEScheduler *scheduler) {
	DSPEExternalEventsQueue *queue = (DSPEExternalEventsQueue*) memoryManager_allocate((DSPEElement*) scheduler, sizeof(DSPEExternalEventsQueue));
	initDSPEElement((DSPEElement*) queue, (DSPEElement*) scheduler);

	queue->numElements = 0;
	queue->head = NULL;
	queue->tail = NULL;

	queue->lock = createSpin((DSPEElement*) scheduler);

	return queue;
}

/**
 * MemoryManager_disposeExternalEventsQueue function
 */
void memoryManager_disposeExternalEventsQueue(const DSPEScheduler *scheduler, DSPEExternalEventsQueue *queue) {
	DSPEExternalEvent *evt;
	while (queue->numElements > 0) {
		evt = queue->head;
		queue->head = evt->next;
		queue->numElements--;
		evt->next = NULL;
		memorySupport_dispose(evt);
	}

	disposeSpin((DSPEElement*) scheduler, queue->lock);
	memorySupport_dispose(queue);
}

/**
 * MemoryManager_resetExternalEventsQueue function
 */
void memoryManager_resetExternalEventsQueue(const DSPEScheduler *scheduler) {
	DSPEExternalEventsQueue *queue = scheduler->getExternalEventsQueue(scheduler);
	DSPEExternalEventsQueue *pool = scheduler->getExternalEventsPool(scheduler);

	lockSpin((DSPEElement*) scheduler, queue->lock);
	if (queue->numElements == 0) {
		unlockSpin((DSPEElement*) scheduler, queue->lock);
		return;
	}

	// Move queue nodes to pool
	lockSpin((DSPEElement*) scheduler, pool->lock);
	if (pool->numElements == 0)
		pool->head = queue->head;
	else
		pool->tail->next = queue->head;
	pool->tail = queue->tail;
	pool->numElements += queue->numElements;

	// Reset queue
	queue->head = NULL;
	queue->tail = NULL;
	queue->numElements = 0;

	unlockSpin((DSPEElement*) scheduler, pool->lock);
	unlockSpin((DSPEElement*) scheduler, queue->lock);
}

/**
 * MemoryManager_addExternalEventToQueue function
 */
void memoryManager_addExternalEventToQueue(const DSPEScheduler *scheduler, int id) {
	DSPEExternalEventsQueue *pool = scheduler->getExternalEventsPool(scheduler);
	DSPEExternalEventsQueue *queue = scheduler->getExternalEventsQueue(scheduler);
	DSPEExternalEvent *evt = NULL;

	// Get ExternalEvent from pool
	lockSpin((DSPEElement*) scheduler, pool->lock);
	if (pool->numElements == 0) {
		unlockSpin((DSPEElement*) scheduler, pool->lock);
		// Create a new ExternalEvent
		evt = (DSPEExternalEvent*) memoryManager_allocate((DSPEElement*) scheduler, sizeof(DSPEExternalEvent));
	} else {
		// Retrieve an ExternalEvent from pool
		evt = pool->head;
		pool->head = evt->next;
		pool->numElements--;
		if (pool->numElements == 0)
			pool->tail = NULL;
		unlockSpin((DSPEElement*) scheduler, pool->lock);
	}

	// Fill event id
	evt->id = id;
	evt->next = NULL;

	// Add ExternalEvent to queue
	lockSpin((DSPEElement*) scheduler, queue->lock);
	if (queue->numElements == 0)
		queue->head = evt;
	else
		queue->tail->next = evt;
	queue->tail = evt;
	queue->numElements++;
	unlockSpin((DSPEElement*) scheduler, queue->lock);
}

/**
 * MemoryManager_getExternalEventFromQueue function
 */
DSPEExternalEvent* memoryManager_getExternalEventFromQueue(const DSPEScheduler *scheduler) {
	DSPEExternalEventsQueue *queue = scheduler->getExternalEventsQueue(scheduler);
	DSPEExternalEvent *evt = NULL;

	// Get ExternalEvent from queue
	lockSpin((DSPEElement*) scheduler, queue->lock);
	if (queue->numElements == 0) {
		unlockSpin((DSPEElement*) scheduler, queue->lock);
		return NULL;
	} else {
		evt = queue->head;
		queue->head = evt->next;
		queue->numElements--;
		if (queue->numElements == 0)
			queue->tail = NULL;
		unlockSpin((DSPEElement*) scheduler, queue->lock);
	}
	return evt;
}

/**
 * MemoryManager_addExternalEventToPool function
 */
void memoryManager_addExternalEventToPool(const DSPEScheduler *scheduler, DSPEExternalEvent *evt) {
	DSPEExternalEventsQueue *pool = scheduler->getExternalEventsPool(scheduler);

	// Add ExternalEvent to pool
	lockSpin((DSPEElement*) scheduler, pool->lock);
	if (pool->numElements == 0)
		pool->head = evt;
	else
		pool->tail->next = evt;
	pool->tail = evt;
	pool->numElements++;
	unlockSpin((DSPEElement*) scheduler, pool->lock);
}

