/**
 * File: RunnerSupport.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef RunnerSupport_h
#define RunnerSupport_h

#include "RunnerGround.h"

#ifdef __cplusplus
extern "C" {
#endif

/* InitializeRunner function */
ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib* initializeRunner();

/* DestroyRunner function */
void destroyRunner(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context);

/* InitializeLocksAndConditions function */
void initializeLocksAndConditions(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context);

/* DisposeLocksAndConditions function */
void disposeLocksAndConditions(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context);

/* RunnerStartup function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_runnerStartup(DSPEApplication *application);

/* RunnerPreProcess function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_runnerPreProcess(DSPEComponent *component);

/* RunnerPostProcess function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_runnerPostProcess(DSPEComponent *component);

/* InitializeEngineThread function */
void initializeEngineThread(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context);

/* WaitEngineThreadEnd function */
void waitEngineThreadEnd(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
