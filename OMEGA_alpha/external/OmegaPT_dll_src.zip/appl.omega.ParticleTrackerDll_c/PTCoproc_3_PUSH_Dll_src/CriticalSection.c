/**
 * File: CriticalSection.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "DSPEElements.h"
#include "ErrorManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "ThreadManager.h"
#include "EngineManager.h"
#include "InfoManager.h"

#include "CriticalSection.h"

#include <stdlib.h>
#include <limits.h>

/**
 * InitializeCurAndLastValues function.
 */
void initializeCurAndLastValues(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	/* GUI current values allocation */
	context->paramIn_Radius_curValue = ParticleTrackerDllIntGate_StandardGate_allocate((DSPEElement*) context);
	context->paramIn_Cutoff_curValue = ParticleTrackerDllRealGate_CustomGate_allocate((DSPEElement*) context);
	context->paramIn_Percentile_curValue = ParticleTrackerDllRealGate_CustomGate_allocate((DSPEElement*) context);
	context->paramIn_Displacement_curValue = ParticleTrackerDllRealGate_CustomGate_allocate((DSPEElement*) context);
	context->paramIn_Linkrange_curValue = ParticleTrackerDllIntGate_StandardGate_allocate((DSPEElement*) context);
	context->paramIn_ImgsNum_curValue = ParticleTrackerDllIntGate_StandardGate_allocate((DSPEElement*) context);
	context->paramIn_ImgWidth_curValue = ParticleTrackerDllIntGate_StandardGate_allocate((DSPEElement*) context);
	context->paramIn_ImgHeight_curValue = ParticleTrackerDllIntGate_StandardGate_allocate((DSPEElement*) context);
	context->paramIn_ImgMin_curValue = ParticleTrackerDllRealGate_CustomGate_allocate((DSPEElement*) context);
	context->paramIn_ImgMax_curValue = ParticleTrackerDllRealGate_CustomGate_allocate((DSPEElement*) context);
	context->paramOut_DataReader_status_curValue = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);
	context->paramOut_Convolve_status_curValue = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);
	context->paramOut_Dilate_status_curValue = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);
	context->paramOut_FindThreshold_status_curValue = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);
	context->paramOut_FindParticles_status_curValue = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);
	context->paramOut_PositionRefinement_status_curValue = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);
	context->paramOut_ParticlesDiscrimination_status_curValue = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);
	context->paramOut_LinkParticles_status_curValue = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);
	context->paramOut_GenerateTrajectories_status_curValue = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);

	/* GUI current value anchors allocation */
	context->paramOut_DataReader_status_curValueAnchor = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);
	context->paramOut_Convolve_status_curValueAnchor = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);
	context->paramOut_Dilate_status_curValueAnchor = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);
	context->paramOut_FindThreshold_status_curValueAnchor = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);
	context->paramOut_FindParticles_status_curValueAnchor = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);
	context->paramOut_PositionRefinement_status_curValueAnchor = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);
	context->paramOut_ParticlesDiscrimination_status_curValueAnchor = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);
	context->paramOut_LinkParticles_status_curValueAnchor = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);
	context->paramOut_GenerateTrajectories_status_curValueAnchor = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);

	/* GUI current value anchors allocation */
	ParticleTrackerDllStatusGate_StringGate_allocateManaged((DSPEElement*) context, context->paramOut_DataReader_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_allocateManaged((DSPEElement*) context, context->paramOut_Convolve_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_allocateManaged((DSPEElement*) context, context->paramOut_Dilate_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_allocateManaged((DSPEElement*) context, context->paramOut_FindThreshold_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_allocateManaged((DSPEElement*) context, context->paramOut_FindParticles_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_allocateManaged((DSPEElement*) context, context->paramOut_PositionRefinement_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_allocateManaged((DSPEElement*) context, context->paramOut_ParticlesDiscrimination_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_allocateManaged((DSPEElement*) context, context->paramOut_LinkParticles_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_allocateManaged((DSPEElement*) context, context->paramOut_GenerateTrajectories_status_curValueAnchor);

	/* GUI current value anchors initialization */
	ParticleTrackerDllStatusGate_StringGate_initManaged((DSPEElement*) context, *context->paramOut_DataReader_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_set((DSPEElement*) context, context->paramOut_DataReader_status_curValue, context->paramOut_DataReader_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_initManaged((DSPEElement*) context, *context->paramOut_Convolve_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_set((DSPEElement*) context, context->paramOut_Convolve_status_curValue, context->paramOut_Convolve_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_initManaged((DSPEElement*) context, *context->paramOut_Dilate_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_set((DSPEElement*) context, context->paramOut_Dilate_status_curValue, context->paramOut_Dilate_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_initManaged((DSPEElement*) context, *context->paramOut_FindThreshold_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_set((DSPEElement*) context, context->paramOut_FindThreshold_status_curValue, context->paramOut_FindThreshold_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_initManaged((DSPEElement*) context, *context->paramOut_FindParticles_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_set((DSPEElement*) context, context->paramOut_FindParticles_status_curValue, context->paramOut_FindParticles_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_initManaged((DSPEElement*) context, *context->paramOut_PositionRefinement_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_set((DSPEElement*) context, context->paramOut_PositionRefinement_status_curValue, context->paramOut_PositionRefinement_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_initManaged((DSPEElement*) context, *context->paramOut_ParticlesDiscrimination_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_set((DSPEElement*) context, context->paramOut_ParticlesDiscrimination_status_curValue, context->paramOut_ParticlesDiscrimination_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_initManaged((DSPEElement*) context, *context->paramOut_LinkParticles_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_set((DSPEElement*) context, context->paramOut_LinkParticles_status_curValue, context->paramOut_LinkParticles_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_initManaged((DSPEElement*) context, *context->paramOut_GenerateTrajectories_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_set((DSPEElement*) context, context->paramOut_GenerateTrajectories_status_curValue, context->paramOut_GenerateTrajectories_status_curValueAnchor);

	/* GUI current values initialization */
	ParticleTrackerDllIntGate_StandardGate_setOverride((DSPEElement*) context, context->paramIn_Radius_curValue, 3);
	ParticleTrackerDllRealGate_CustomGate_setOverride((DSPEElement*) context, context->paramIn_Cutoff_curValue, 3.0);
	ParticleTrackerDllRealGate_CustomGate_setOverride((DSPEElement*) context, context->paramIn_Percentile_curValue, 0.1);
	ParticleTrackerDllRealGate_CustomGate_setOverride((DSPEElement*) context, context->paramIn_Displacement_curValue, 10.0);
	ParticleTrackerDllIntGate_StandardGate_setOverride((DSPEElement*) context, context->paramIn_Linkrange_curValue, 1);
	ParticleTrackerDllIntGate_StandardGate_initialize((DSPEElement*) context, context->paramIn_ImgsNum_curValue);
	ParticleTrackerDllIntGate_StandardGate_initialize((DSPEElement*) context, context->paramIn_ImgWidth_curValue);
	ParticleTrackerDllIntGate_StandardGate_initialize((DSPEElement*) context, context->paramIn_ImgHeight_curValue);
	ParticleTrackerDllRealGate_CustomGate_initialize((DSPEElement*) context, context->paramIn_ImgMin_curValue);
	ParticleTrackerDllRealGate_CustomGate_initialize((DSPEElement*) context, context->paramIn_ImgMax_curValue);
	ParticleTrackerDllStatusGate_StringGate_initialize((DSPEElement*) context, context->paramOut_DataReader_status_curValue);
	ParticleTrackerDllStatusGate_StringGate_initialize((DSPEElement*) context, context->paramOut_Convolve_status_curValue);
	ParticleTrackerDllStatusGate_StringGate_initialize((DSPEElement*) context, context->paramOut_Dilate_status_curValue);
	ParticleTrackerDllStatusGate_StringGate_initialize((DSPEElement*) context, context->paramOut_FindThreshold_status_curValue);
	ParticleTrackerDllStatusGate_StringGate_initialize((DSPEElement*) context, context->paramOut_FindParticles_status_curValue);
	ParticleTrackerDllStatusGate_StringGate_initialize((DSPEElement*) context, context->paramOut_PositionRefinement_status_curValue);
	ParticleTrackerDllStatusGate_StringGate_initialize((DSPEElement*) context, context->paramOut_ParticlesDiscrimination_status_curValue);
	ParticleTrackerDllStatusGate_StringGate_initialize((DSPEElement*) context, context->paramOut_LinkParticles_status_curValue);
	ParticleTrackerDllStatusGate_StringGate_initialize((DSPEElement*) context, context->paramOut_GenerateTrajectories_status_curValue);

}

/**
 * DisposeCurAndLastValues function.
 */
void disposeCurAndLastValues(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	/* GUI current value anchors destroy */
	ParticleTrackerDllStatusGate_StringGate_disposeManaged((DSPEElement*) context, *context->paramOut_DataReader_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_disposeManaged((DSPEElement*) context, *context->paramOut_Convolve_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_disposeManaged((DSPEElement*) context, *context->paramOut_Dilate_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_disposeManaged((DSPEElement*) context, *context->paramOut_FindThreshold_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_disposeManaged((DSPEElement*) context, *context->paramOut_FindParticles_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_disposeManaged((DSPEElement*) context, *context->paramOut_PositionRefinement_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_disposeManaged((DSPEElement*) context, *context->paramOut_ParticlesDiscrimination_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_disposeManaged((DSPEElement*) context, *context->paramOut_LinkParticles_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_disposeManaged((DSPEElement*) context, *context->paramOut_GenerateTrajectories_status_curValueAnchor);

	/* GUI current value anchors destroy */
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_DataReader_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_Convolve_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_Dilate_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_FindThreshold_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_FindParticles_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_PositionRefinement_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_ParticlesDiscrimination_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_LinkParticles_status_curValueAnchor);
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_GenerateTrajectories_status_curValueAnchor);

	/* GUI current values dispose */
	ParticleTrackerDllIntGate_StandardGate_dispose((DSPEElement*) context, context->paramIn_Radius_curValue);
	ParticleTrackerDllRealGate_CustomGate_dispose((DSPEElement*) context, context->paramIn_Cutoff_curValue);
	ParticleTrackerDllRealGate_CustomGate_dispose((DSPEElement*) context, context->paramIn_Percentile_curValue);
	ParticleTrackerDllRealGate_CustomGate_dispose((DSPEElement*) context, context->paramIn_Displacement_curValue);
	ParticleTrackerDllIntGate_StandardGate_dispose((DSPEElement*) context, context->paramIn_Linkrange_curValue);
	ParticleTrackerDllIntGate_StandardGate_dispose((DSPEElement*) context, context->paramIn_ImgsNum_curValue);
	ParticleTrackerDllIntGate_StandardGate_dispose((DSPEElement*) context, context->paramIn_ImgWidth_curValue);
	ParticleTrackerDllIntGate_StandardGate_dispose((DSPEElement*) context, context->paramIn_ImgHeight_curValue);
	ParticleTrackerDllRealGate_CustomGate_dispose((DSPEElement*) context, context->paramIn_ImgMin_curValue);
	ParticleTrackerDllRealGate_CustomGate_dispose((DSPEElement*) context, context->paramIn_ImgMax_curValue);
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_DataReader_status_curValue);
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_Convolve_status_curValue);
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_Dilate_status_curValue);
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_FindThreshold_status_curValue);
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_FindParticles_status_curValue);
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_PositionRefinement_status_curValue);
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_ParticlesDiscrimination_status_curValue);
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_LinkParticles_status_curValue);
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_GenerateTrajectories_status_curValue);

}

/**
 * InitializeEngineSwap function.
 */
engineSwap* initializeEngineSwap(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	DSPEElement *element = (DSPEElement*) context->runnerDelegate;

	/* Engine swap areas allocation */
	engineSwap *swap = (engineSwap*) memoryManager_allocate(element, sizeof(engineSwap));

	/* Engine swap initialization */
	swap->mainState = 0;
	swap->subState = -1;
	swap->skipCycles = 0;

	/* Initialize engine adding changes flag */
	swap->addingChanges = 0;

	/* Initialize changes lock */
	swap->changesLock = threadManager_createSpin(element);

	return swap;
}

/**
 * DisposeEngineSwap function.
 */
void disposeEngineSwap(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context, engineSwap *swap) {
	DSPEElement *element = (DSPEElement*) context->runnerDelegate;

	/* Delete changes lock */
	threadManager_deleteSpin(element, swap->changesLock);

	memorySupport_dispose(swap);
}

/**
 * DisposeSwapAreas function.
 * Disposes swap areas and swap areas anchors
 */
void disposeSwapAreas(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	memorySupport_dispose(context->infoSwapGui);
	memorySupport_dispose(context->infoSwapEngine);

	/* Engine swap areas dispose */
	disposeEngineSwap(context, context->engineSwapGui);
	disposeEngineSwap(context, context->engineSwapEngine);
	disposeEngineSwap(context, context->engineFeedbackSwapGui);
	disposeEngineSwap(context, context->engineFeedbackSwapEngine);

}

/**
 * UpdateEnginePendingChanges function.
 */
void updateEnginePendingChanges(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	DSPEElement *element = (DSPEElement*) context;
	engineSwap *current = context->engineSwapEngine;
	int isAddingChanges = 0;

	if (!context->isEngineChangePending)
		return;

	threadManager_lockSpin(element, current->changesLock);
	isAddingChanges = current->addingChanges;
	threadManager_unlockSpin(element, current->changesLock);

	if (isAddingChanges)
		return;

	context->mainState_lastValue = current->mainState;
	context->subState_lastValue = current->subState;
	context->skipCycles = current->skipCycles;
	context->isEngineChangePending = 0;
}

/**
 * UpdateEngineChanges function.
 */
void updateEngineChanges(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	DSPEElement *element = (DSPEElement*) context;
	engineSwap *current = context->engineSwapEngine;
	int isAddingChanges = 0;

	if (context->isEngineChangePending)
		return;

	threadManager_lockSpin(element, context->engineSwapLock);
	if (context->isEngineChanged == 0) {
		threadManager_unlockSpin(element, context->engineSwapLock);
		return;
	}

	context->isEngineChanged = 0;

	/* Rotate engineSwapAreas */
	context->engineSwapEngine = context->engineSwapGui;
	context->engineSwapGui = current;
	threadManager_unlockSpin(element, context->engineSwapLock);

	current = context->engineSwapEngine;

	threadManager_lockSpin(element, current->changesLock);
	isAddingChanges = current->addingChanges;
	threadManager_unlockSpin(element, current->changesLock);

	if (isAddingChanges) {
		/* Engine changes are not ready, skip this turn */
		context->isEngineChangePending = 1;
		return;
	}

	context->mainState_lastValue = current->mainState;
	context->subState_lastValue = current->subState;
	context->skipCycles = current->skipCycles;
}

/**
 * UpdateEngineState function.
 */
void updateEngineState(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	updateEnginePendingChanges(context);
	updateEngineChanges(context);
}

/**
 * UpdateEngineStateFeedback function.
 */
void updateEngineStateFeedback(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	engineSwap *current = context->engineFeedbackSwapGui;
	DSPEElement *element = (DSPEElement*) context->runnerDelegate;
	int isAddingChanges = 0;

	if (context->isEngineFeedbackChangePending) {
		threadManager_lockSpin(element, current->changesLock);
		isAddingChanges = current->addingChanges;
		threadManager_unlockSpin(element, current->changesLock);

		if (isAddingChanges)
			return;

		context->mainState_curValue = current->mainState;
		context->subState_curValue = current->subState;
		context->isEngineFeedbackChangePending = 0;
	}

	threadManager_lockSpin(element, context->engineFeedbackSwapLock);
	if (context->isEngineFeedbackChanged == 0) {
		threadManager_unlockSpin(element, context->engineFeedbackSwapLock);
		return;
	}

	context->isEngineFeedbackChanged = 0;

	/* Rotate engineFeedbackSwapAreas */
	context->engineFeedbackSwapGui = context->engineFeedbackSwapEngine;
	context->engineFeedbackSwapEngine = current;
	threadManager_unlockSpin(element, context->engineFeedbackSwapLock);

	current = context->engineFeedbackSwapGui;

	threadManager_lockSpin(element, current->changesLock);
	isAddingChanges = current->addingChanges;
	threadManager_unlockSpin(element, current->changesLock);

	if (isAddingChanges) {
		/* Engine feedback changes are not ready, skip this turn */
		context->isEngineFeedbackChangePending = 1;
		return;
	}

	context->mainState_curValue = current->mainState;
	context->subState_curValue = current->subState;
}

/**
 * InitChangeFlags function.
 * Initialize change and change pending flags.
 */
void initializeChangeFlags(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	context->isInfoChanged = 0;
	context->isInfoChangePending = 0;
	context->isEngineChanged = 0;
	context->isEngineFeedbackChanged = 0;
	context->isEngineChangePending = 0;
	context->isEngineFeedbackChangePending = 0;
}

/**
 * ApplyInfoChanges function
 */
static INLINE void applyInfoChanges(const DSPEElement *element) {
	unsigned int count;
	DSPEInfoNode *localNode;
	infoSwap **currentSwap;
	int i;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	threadManager_lockSpin(element, context->infoSwapLock);
	currentSwap = context->infoSwapGui;
	threadManager_unlockSpin(element, context->infoSwapLock);
	
	for (i = 0; i < MAX_NUM_THREADS; i++)
		infoManager_mergeInfo(element, currentSwap[i]);

	threadManager_lockSpin(element, context->infoLock);

	/* Apply log changes */
	while (context->logNodesNum > 0) {
		localNode = context->logHead;
		/* Write to log file */
		fprintf(context->logFile, "%s\n", localNode->info);

		context->logHead = localNode->next;
		context->logNodesNum--;
		localNode->next = NULL;

		/* Add node to pool */
		if (context->infoPoolNodesNum == 0) {
			context->infoPoolHead = localNode;
			context->infoPoolTail = localNode;
			context->infoPoolNodesNum = 1;
		} else {
			context->infoPoolTail->next = localNode;
			context->infoPoolTail = localNode;
			context->infoPoolNodesNum++;
		}
	}

	/* Check if some collected log need to be written to the console
	 * since MAX_COUNT has been reached */
	for (i = 0; i < infoIDCount; i++) {
		count = context->collectedLog[i];
		if (count == UINT_MAX) {
			/* Write to console */
			fprintf(context->logFile, "%s (MAX_COUNT times)", infoSupport_getCollectedInfoString((infoID) i));
			context->collectedLog[i] = 0;
		}
	}

	threadManager_unlockSpin(element, context->infoLock);
}

/**
 * UpdateInfo function
 */
void updateInfo(const DSPEElement *element) {
	infoSwap **tmp;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	threadManager_lockSpin(element, context->infoSwapLock);
	if (context->isInfoChangePending) {
		context->isInfoChangePending = 0;
		threadManager_unlockSpin(element, context->infoSwapLock);
		applyInfoChanges(element);
		threadManager_lockSpin(element, context->infoSwapLock);
		if (context->isInfoChangePending) {
			threadManager_unlockSpin(element, context->infoSwapLock);
			return;
		}
	}

	if (context->isInfoChanged == 0) {
		threadManager_unlockSpin(element, context->infoSwapLock);
		return;
	}

	context->isInfoChanged = 0;

	// Rotate InfoSwapAreas
	tmp = context->infoSwapGui;
	context->infoSwapGui = context->infoSwapEngine;
	context->infoSwapEngine = tmp;
	threadManager_unlockSpin(element, context->infoSwapLock);

	applyInfoChanges(element);
}

