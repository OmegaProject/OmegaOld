/**
 * File: RunnerGround.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "RunnerGround.h"
#include "MemoryManager.h"
#include "ThreadManager.h"
#include "ErrorManager.h"

#include <time.h>

/* LOG FILE SUPPORT */

/**
 * OpenLogFile function.
 */
void openLogFile(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context, int logCurrentTime) {
	time_t currentTime;

	/* Open log file */
	context->logFile = fopen("PTCoproc_3_PUSH_Dll.log", "a");
	if (context->logFile == NULL)
		errorManager_appendError((DSPEElement*) context, "Error opening log file.");
	else {
		if (logCurrentTime) {
			/* Write current time to log file */
			time(&currentTime);
			fprintf(context->logFile,
					"--------------------------------------------------------------------------------\n"
					"                            %s"
					"--------------------------------------------------------------------------------\n\n", ctime(&currentTime));
		}
	}
}

/**
 * CloseLogFile function.
 */
void closeLogFile(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	/* Close log file */
	if (context->logFile != NULL) {
		fclose(context->logFile);
		context->logFile = NULL;
	}
}

/* 
 * REMARK: Managers using these functions cannot directly include the
 * corresponding manager header file (MemoryManager or ThreadManager)
 * to avoid circular inclusions when inline support is active.
 */

/* MEMORY SUPPORT */

/**
 * AllocateMemory function.
 */
void* allocateMemory(const DSPEElement *element, size_t size) {
	if (element == NULL)
		return memorySupport_allocate(size);
	return memoryManager_allocate(element, size);
}

/**
 * AllocateAndInitMemory function.
 */
void* allocateAndInitMemory(const DSPEElement *element, size_t blockSize, unsigned int size) {
	if (element == NULL)
		return memorySupport_allocateAndInit(blockSize, size);
	return memoryManager_allocateAndInit(element, blockSize, size);
}

/**
 * ReallocateMemory function.
 */
void* reallocateMemory(void *pointer, size_t newSize) {
	return memorySupport_realloc(pointer, newSize);
}

/**
 * DisposeMemory function.
 */
void disposeMemory(void *pointer) {
	memorySupport_dispose(pointer);
}

/* SPINLOCK SUPPORT */

/**
 * CreateSpin function.
 */
void* createSpin(const DSPEElement *element) {
	return threadManager_createSpin(element);
}

/**
 * DisposeSpin function.
 */
void disposeSpin(const DSPEElement *element, void *spin) {
	threadManager_deleteSpin(element, spin);
}

/**
 * LockSpin function.
 */
void lockSpin(const DSPEElement *element, void *spin) {
	threadManager_lockSpin(element, spin);
}

/**
 * UnlockSpin function.
 */
void unlockSpin(const DSPEElement *element, void *spin) {
	threadManager_unlockSpin(element, spin);
}

/* OWNER INDEX SUPPORT */

/**
 * GetOwnerIndex function.
 */
size_t getOwnerIndex(const DSPEOwner *owner) {
	return threadManager_getOwnerIndex(owner);
}

