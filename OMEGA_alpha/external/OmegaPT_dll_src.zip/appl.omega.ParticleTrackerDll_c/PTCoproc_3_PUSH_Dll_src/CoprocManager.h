/**
 * File: CoprocManager.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef CoprocManager_h
#define CoprocManager_h

#include "DSPEXTElements.h"
#include "CoprocGround.h"

typedef struct DSPECoprocInQueue DSPECoprocInQueue;

typedef struct DSPECoprocOutQueue DSPECoprocOutQueue;

typedef struct DSPECoprocEngine DSPECoprocEngine;

typedef struct DSPECoprocHandler DSPECoprocHandler;

struct DSPECoprocInQueue {
	DSPEOpInQueue inQueue;
	DSPECoprocInQueue *next;

	// If this flag is set, the queue is an exclusive one.
	// This flag is read-only, is set at initialization time.
	unsigned int exclusive;

	// REMARK: lock used for all variable that follows
	void *lock;

	// Support for exclusive queues
	unsigned int excluded;
	unsigned int reschedule;

	// Infrastructure of the queue
	size_t queueNumElements;
	DSPECoprocOp *queueHead;
	DSPECoprocOp *queueTail;
};

struct DSPECoprocOutQueue {
	DSPEOpOutQueue outQueue;

	// REMARK: lock used for all variable that follows
	void *lock;
	
	// Infrastructure of the queue
	size_t queueNumElements;
	DSPECoprocOp *queueHead;
	DSPECoprocOp *queueTail;
};

struct DSPECoprocEngine {
	DSPEElement element;
	OWNER_EXT;

	DSPECoprocEngine *next;

	void *coprocThread;

	// REMARK: the lock used for following variable is
	// the enginesPoolLock in the handler
	unsigned int state;
	// REMARK: the lock used for following variable is
	// the suspendConditionsLock in the handler
	void *engineSuspendCondition;
};

struct DSPECoprocHandler {
	DSPEHandler handler;

	// REMARK: lock used for all variable that follows
	void *opQueuesLock;

	size_t numOpQueues;
	DSPECoprocInQueue *opQueuesHead;
	DSPECoprocInQueue *opQueuesTail;

	// REMARK: lock used for all variable that follows
	void *enginesPoolLock;

	// Infrastructure of the queue
	size_t numInitializedEngines;
	size_t numSuspendedEngines;
	DSPECoprocEngine *enginesPoolHead;
	DSPECoprocEngine *enginesPoolTail;

	// REMARK: lock used for all variable that follows
	void *suspendConditionsLock;

	void *handlerSuspendCondition;

	// REMARK: lock used for accessing state
	void *handlerStateLock;

	unsigned int state;

	// REMARK: lock used for all following variables
	// Following state is needed to be sure that coproc engines start
	// working only when application preProcess has finished.
	void *preProcessEndConditionLock;
	void *preProcessEndCondition;
	void *engineReadyCondition;
	size_t numEnginesReady;
};

static INLINE void initDSPECoprocEngine(DSPECoprocEngine *engine, DSPEHandler *handler) {
	initDSPEElement((DSPEElement*) engine, (DSPEElement*) handler);
	initDSPEOwner(CAST_TO_OWNER(engine), (DSPEElement*) engine);
	((DSPEElement*) engine)->owner = CAST_TO_OWNER(engine);
}

#ifdef __cplusplus
extern "C" {
#endif

/******************************************************************************
 * COPROC ENGINES
 * Support for coprocessor engines
 ******************************************************************************/

/**
 * CoprocManager_activateCoprocEngines Function
 */
void coprocManager_activateCoprocEngines(DSPEElement *element);

/******************************************************************************
 * COPROC HANDLER
 * Support for management of coprocessors
 ******************************************************************************/

/**
 * CoprocManager_initCoprocHandler function
 */
void coprocManager_initCoprocHandler(const DSPEApplication *application);

/**
 * CoprocManager_activateCoprocHandler function
 */
void coprocManager_activateCoprocHandler(const DSPEApplication *application);

/**
 * CoprocManager_suspendCoprocHandler function
 */
void coprocManager_suspendCoprocHandler(const DSPEApplication *application);

/**
 * CoprocManager_suspendCoprocEngines function
 */
void coprocManager_suspendCoprocEngines(const DSPEApplication *application);

/******************************************************************************
 * INPUT QUEUE
 * Support for input queue - each input queue is installed on a CoprocUnitBehaviors
 ******************************************************************************/

/**
 * CoprocManager_initCoprocInQueue function
 * Last parameter must be NULL
 */
DSPEOpInQueue* coprocManager_initCoprocInQueue(const DSPEElement *context, ...);

/**
 * CoprocManager_addOpToInQueue function
 */
void coprocManager_addOpToInQueue(DSPEOpInQueue *queue, DSPEOp *op);

/**
 * CoprocManager_getInQueueSize function
 */
size_t coprocManager_getInQueueSize(const DSPEOpInQueue *queue);

/**
 * CoprocManager_isAboveMinThreshold function
 */
int coprocManager_isAboveMinThreshold(const DSPEOpInQueue *queue);

/**
 * CoprocManager_isAboveMaxThreshold function
 */
int coprocManager_isAboveMaxThreshold(const DSPEOpInQueue *queue);

/******************************************************************************
 * OUTPUT QUEUE
 * Support for output queue - output queues are installed on CoprocSchedulers
 ******************************************************************************/

/**
 * CoprocManager_initCoprocOutQueue function
 */
DSPEOpOutQueue* coprocManager_initCoprocOutQueue(const DSPECoprocScheduler *scheduler);

/**
 * CoprocManager_getOpFromOutQueue function
 */
DSPEOp* coprocManager_getOpFromOutQueue(DSPEOpOutQueue *queue);

/**
 * CoprocManager_getOutQueueSize function
 */
size_t coprocManager_getOutQueueSize(const DSPEOpOutQueue *queue);

/******************************************************************************
 * PROCESS
 * Support for processing ops
 ******************************************************************************/

/**
 * CoprocManager_coprocContribution function
 */
void coprocManager_coprocContribution(const DSPEElement *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
