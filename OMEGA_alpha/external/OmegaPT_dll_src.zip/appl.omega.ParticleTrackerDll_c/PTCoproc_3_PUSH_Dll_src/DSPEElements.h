/**
 * File: DSPEElements.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef DSPEElements_h
#define DSPEElements_h

#include "PlatformManager.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Conversion defines */
#define CAST_TO_EXTENSION(element, extension) &element->extension
#define CAST_TO_ELEMENT(extension) ((DSPEExtension*) extension)->root

// BASE

typedef struct DSPEElement DSPEElement;

typedef struct DSPEExtension DSPEExtension;

typedef struct DSPEOwner DSPEOwner;

typedef struct DSPEComponent DSPEComponent;

// DSPE

typedef struct DSPEUnit DSPEUnit;

typedef struct DSPEStructure DSPEStructure;

typedef struct DSPEConfiguration DSPEConfiguration;

typedef struct DSPERunnerDelegate DSPERunnerDelegate;

typedef struct DSPEApplication DSPEApplication;

typedef struct DSPEUnitBehaviour DSPEUnitBehaviour;

typedef struct DSPEImplementation DSPEImplementation;

typedef struct DSPEBlockOptimization DSPEBlockOptimization;

typedef struct DSPERunnerBehaviour DSPERunnerBehaviour;

// CRITICAL SECTION SUPPORT

typedef struct DSPEGateNode DSPEGateNode;

// EVENTS SUPPORT

typedef struct DSPEEvent DSPEEvent;

typedef struct DSPEGroupEvent DSPEGroupEvent;

typedef struct DSPEEventsUnit DSPEEventsUnit;

typedef struct DSPEQueueUnit DSPEQueueUnit;

typedef struct DSPEEventsApplication DSPEEventsApplication;

// HANDLER SUPPORT

typedef struct DSPEHandler DSPEHandler;

// EVENTS POOL SUPPORT

typedef struct DSPEEventsPool DSPEEventsPool;

// PROFILE SUPPORT

typedef struct DSPEProfileNode DSPEProfileNode;

// BASE

/* Common struct for all DSPE elements */
struct DSPEElement {
	const DSPEElement *container;
	DSPEApplication *application;
	const DSPEOwner *owner;

	char* (*getID) (const DSPEElement *element);
};

struct DSPEExtension {
	const DSPEElement *root;
};

/* Conversion support defines */ 
#define OWNER_EXT DSPEOwner ownerExt
#define CAST_TO_OWNER(element) &(element)->ownerExt

struct DSPEOwner {
	DSPEExtension extension;
	
	DSPEHandler **handlers;
};

/* Common struct for elements like Unit, Composite or Application, that may e.g. be scheduled */
struct DSPEComponent {
	DSPEElement element;

	void (*preprocess) (DSPEComponent *component);
	void (*process) (DSPEComponent *component);
	void (*postprocess) (DSPEComponent *component);
	void (*setBypass) (DSPEComponent *component, int bypass);
};

// DSPE

struct DSPEUnit {
	DSPEComponent component;
};

struct DSPEStructure {
	DSPEElement element;
};

struct DSPEConfiguration {
	DSPEStructure structure;
};

struct DSPERunnerDelegate {
	DSPEElement element;
	OWNER_EXT;
};

struct DSPEApplication {
	DSPEComponent component;
	OWNER_EXT;

	void (*startup) (DSPEApplication *application);
	void (*shutdown) (DSPEApplication *application);
};

struct DSPEUnitBehaviour {
	DSPEElement element;
};

struct DSPEImplementation {
	DSPEUnitBehaviour unitBehaviour;
};

struct DSPEBlockOptimization {
	DSPEImplementation implementation;
};

struct DSPERunnerBehaviour {
	DSPEElement element;
};

// CRITICAL SECTION SUPPORT

struct DSPEGateNode {
	DSPEGateNode *next;

	int isInQueue;

	void (*setValue) (DSPEElement *context, DSPEGateNode *node);
	void (*disposeNode) (DSPEElement *context, DSPEGateNode *node);
	void (*updateRep) (DSPEElement *element);
};

// EVENTS SUPPORT

struct DSPEEvent {
	unsigned int refCount;

	size_t blockSize;
	
	DSPEEvent *next;
	DSPEEventsPool *pool;

	DSPEEvent* (*clone) (DSPEEvent *event);
	void (*dispose) (DSPEEvent *event);
};

struct DSPEGroupEvent {
	DSPEEvent event;

	size_t groupSize;
};

struct DSPEEventsUnit {
	DSPEUnit unit;

	void (*queueEvent) (DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID);
	void (*sendEvent) (DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID);
	void (*armEvent) (DSPEEventsUnit *unit, unsigned int ID);
	void (*postEvent) (DSPEEventsUnit *unit, unsigned int ID);
};

struct DSPEQueueUnit {
	DSPEEventsUnit eventsUnit;

	int (*isEventAvailable) (const DSPEQueueUnit *unit);
	unsigned int (*getEventID) (const DSPEQueueUnit *unit);
	DSPEEvent* (*getEvent) (const DSPEQueueUnit *unit);
	void (*transitEvent) (DSPEQueueUnit *unit);
	size_t (*getTransitNumElements) (DSPEQueueUnit *unit, unsigned int ID);
	void (*getFirstTransitEvent) (DSPEQueueUnit *unit, unsigned int ID);
	size_t (*getCurrentNumElements) (DSPEQueueUnit *unit, unsigned int ID);
	void (*getCurrentTransitEvent) (DSPEQueueUnit *unit, unsigned int ID);
	void (*dismissEvent) (DSPEQueueUnit *unit, unsigned int ID);
};

struct DSPEEventsApplication {
	DSPEApplication application;

	void (*queueEvent) (DSPEEventsApplication *application, DSPEEvent *event, unsigned int ID);
	void (*sendEvent) (DSPEEventsApplication *application, DSPEEvent *event, unsigned int ID);
};

// HANDLER SUPPORT

struct DSPEHandler {
	DSPEElement element;
	
	void (*reset) (DSPEHandler *handler);
	void (*dispose) (DSPEHandler *handler);
};

// EVENTS POOL SUPPORT (Concrete structs moved to MemoryManager)

struct DSPEEventsPool {
	DSPEElement element;

	void *gateDefID;
	DSPEEventsPool *next;
	
	void (*preAlloc) (DSPEEventsPool *pool, size_t size);
	void (*reset) (DSPEEventsPool *pool);
	void (*dispose) (DSPEEventsPool *event);
};

// PROFILE SUPPORT

struct DSPEProfileNode {
	size_t id;
};

// INITIALIZATION FUNCTIONS

static char* getID(const DSPEElement *element) {
	return element->container->getID(element->container);
}

static INLINE void initDSPEElement(DSPEElement *element, const DSPEElement *container) {
	element->container = container;
	element->application = container->application;
	element->owner = container->owner;
	element->getID = getID;
}


static INLINE void initDSPEExtension(DSPEExtension *extension, DSPEElement *root) {
	extension->root = root;
}

static INLINE void initDSPEOwner(DSPEOwner *ownerExt, DSPEElement *root) {
	initDSPEExtension((DSPEExtension*) ownerExt, root);
	ownerExt->handlers = NULL;
}

static INLINE void initDSPERunnerDelegate(DSPERunnerDelegate *delegate, DSPEApplication *application) {
	((DSPEElement*) delegate)->container = NULL;
	((DSPEElement*) delegate)->application = application;
	((DSPEElement*) delegate)->owner = CAST_TO_OWNER(delegate);
	((DSPEElement*) delegate)->getID = NULL;
	initDSPEOwner(CAST_TO_OWNER(delegate), (DSPEElement*) delegate);
}

static INLINE void initDSPEComponent(DSPEComponent *component) {
	component->preprocess = NULL;
	component->process = NULL;
	component->postprocess = NULL;
	component->setBypass = NULL;
}

static INLINE void initDSPEHandler(DSPEHandler *handler, const DSPEElement *container) {
	initDSPEElement((DSPEElement*) handler, container);
	handler->reset = NULL;
	handler->dispose = NULL;
}

static INLINE void initDSPEEventsUnit(DSPEEventsUnit *unit) {
	initDSPEComponent((DSPEComponent*) unit);
	unit->queueEvent = NULL;
	unit->sendEvent = NULL;
	unit->armEvent = NULL;
	unit->postEvent = NULL;
}

static INLINE void initDSPEQueueUnit(DSPEQueueUnit *unit) {
	initDSPEEventsUnit((DSPEEventsUnit*) unit);
	unit->isEventAvailable = NULL;
	unit->getEventID = NULL;
	unit->getEvent = NULL;
	unit->transitEvent = NULL;
	unit->getTransitNumElements = NULL;
	unit->getFirstTransitEvent = NULL;
	unit->getCurrentNumElements = NULL;
	unit->getCurrentTransitEvent = NULL;
	unit->dismissEvent = NULL;
}

static INLINE void initDSPEApplication(DSPEApplication *application) {
	((DSPEElement*) application)->container = NULL;
	((DSPEElement*) application)->application = application;
	((DSPEElement*) application)->owner = &application->ownerExt;
	((DSPEElement*) application)->getID = NULL;
	((DSPEApplication*) application)->startup = NULL;
	((DSPEApplication*) application)->shutdown = NULL;
	initDSPEComponent((DSPEComponent*) application);
	initDSPEOwner(&application->ownerExt, (DSPEElement*) application);
}

static INLINE void initDSPEEventsApplication(DSPEEventsApplication *application) {
	initDSPEApplication((DSPEApplication*) application);
	application->queueEvent = NULL;
	application->sendEvent = NULL;
}

static INLINE void initDSPEEvent(DSPEEvent *event) {
	event->refCount = 0;
	event->blockSize = 1;
	event->next = NULL;
	event->pool = NULL;
	event->clone = NULL;
	event->dispose = NULL;
}

static INLINE void initDSPEGroupEvent(DSPEGroupEvent *event) {
 	initDSPEEvent((DSPEEvent*) event);
 	event->groupSize = 0;
}

static INLINE void initDSPEEventsPool(DSPEEventsPool *pool) {
	pool->gateDefID = NULL;
	pool->next = NULL;
	pool->preAlloc = NULL;
	pool->reset = NULL;
	pool->dispose = NULL;
}

static INLINE void initDSPEGateNode(DSPEGateNode *node) {
	node->next = NULL;
	node->isInQueue = 0;
	node->setValue = NULL;
	node->disposeNode = NULL;
	node->updateRep = NULL;
}

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
