/**
 * File: LibraryRunner.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef LibraryRunner_h
#define LibraryRunner_h

/*
 * When building the DLL code, you should define DLL_BUILD so that
 * the variables/functions are exported correctly. When using the DLL,
 * do NOT define DLL_BUILD, and then the variables/functions will
 * be imported correctly.
 */
#define DLL_BUILD

# ifdef DLL_BUILD
#    define DLLPORT __declspec (dllexport)
#  else
#    define DLLPORT __declspec (dllimport)
#  endif

#ifdef __cplusplus
extern "C" {
#endif

DLLPORT void* initRunner();

DLLPORT void disposeRunner(void *runner);

DLLPORT void startRunner(void *runner);

DLLPORT void stopRunner(void *runner);

DLLPORT int isExecuting (void *runner);

DLLPORT void setParameter(void *runner, char *opt, char *value);

DLLPORT void getParameter(void *runner, char *opt, char *value);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
