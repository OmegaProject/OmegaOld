/**
 * File: ThreadManager.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "ThreadManager.h"

#include "ErrorManager.h"
#include "MemoryManager.h"

#include "B_ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application.h"

#include <errno.h>
#include <pthread.h>
#if defined(LINUX) || defined(MAC_OSX)
#include <unistd.h>
#endif

/******************************************************************************
 * HANDLER SUPPORT
 ******************************************************************************/

/**
 * getMaxNumThread function
 */
static INLINE size_t getMaxNumEngines(const DSPEElement* element) {
	register unsigned int numProcessors = threadManager_getNumProcessors(element);
	/* Adapt numProcessors by decreasing by one */
	numProcessors--;
	/* Generate at least one coprocEngine */
	if (numProcessors <= 0)
		return 1;
	
	if (numProcessors > (MAX_NUM_THREADS - 2))
		return MAX_NUM_THREADS - 2;
	return numProcessors;
}

/**
 * getThreadHandler function
 */
static INLINE DSPEThreadHandler* getThreadHandler(const DSPEElement *context) {
	// REMARK on disposal applicationHandlers might have already disposed before runnerDelegate!
	if (context->owner->handlers == NULL)
		return NULL;
	return (DSPEThreadHandler*) context->owner->handlers[HANDLER_INDEX_THREAD];
}

/**
 * resetThreadHandler function
 */
static void resetThreadHandler(DSPEHandler *handler) {
	// Reset handler body
}

/**
 * disposeThreadHandler function
 */
static void disposeThreadHandler(DSPEHandler *handler) {
	/* Decrement global threadCounter */
	DSPEThreadHandler *applicationHandler = getThreadHandler((DSPEElement*) ((DSPEElement*) handler)->application);

	// REMARK: 
	// GUI / shell calls application_shutdown before disposing own state!
	// check for null is therefore needed because applicationHandler will be already disposed!
	if (applicationHandler != NULL && handler != (DSPEHandler*) applicationHandler) {
		applicationHandler->threadCounter--;
	}
	/* Dispose handler */
	memorySupport_dispose(handler);
}

/**
 * initGlobalThreadHandler function
 */
static INLINE void initGlobalThreadHandler(const DSPEElement *element) {
	DSPEOwner *ownerExt = CAST_TO_OWNER(element->application);
	DSPEHandler **handlers = ownerExt->handlers;
	DSPEThreadHandler *handler = NULL;

	/* Lazy initialization of handlers array */
	if (handlers == NULL) {
		memoryManager_allocateHandlerPool(element, ownerExt);
		handlers = ownerExt->handlers;
	}

	handler = (DSPEThreadHandler*) memoryManager_allocate(element, sizeof(DSPEThreadHandler));
	initDSPEElement((DSPEElement*) handler, element);
	initDSPEHandler((DSPEHandler*) handler, element);

	((DSPEHandler*) handler)->reset = resetThreadHandler;
	((DSPEHandler*) handler)->dispose = disposeThreadHandler;

	handler->threadIndex = 0;

	handler->threadCounter = 0;

	/* Add ThreadHandler to handlers */
	handlers[HANDLER_INDEX_THREAD] = (DSPEHandler*) handler;

	/* init processor affinity counter */
	handler->affinityCounter = 0;

	/* set maxNumThreads for master and GUI threads */
	handler->maxNumThreads = 2;

	/* add number of engines to maxNumThreads */
	handler->maxNumThreads += getMaxNumEngines(element);

	/* init numThreads */
	handler->numThreads = handler->maxNumThreads;
}

/**
 * ThreadManager_initThreadHandler function
 */
void threadManager_initThreadHandler(DSPEOwner *ownerExt) {
	DSPEThreadHandler *handler = NULL;
	const DSPEElement *element = CAST_TO_ELEMENT(ownerExt);
	DSPEThreadHandler *applicationHandler = getThreadHandler((DSPEElement*) element->application);
	DSPEHandler **handlers = ownerExt->handlers;

	/* Lazy initialization of global threadHandler */
	if (applicationHandler == NULL) {
		initGlobalThreadHandler(element);
		applicationHandler = getThreadHandler((DSPEElement*) element->application);
	}

	if (element == (DSPEElement*) element->application) {
		// If working with masterThread (GUI / SHELL) then dedicated thread will use global threadHandler
		// without the need of creating another one. Therefore simply set threadIndex and increment threadCounter
		handler = applicationHandler;
		handler->threadIndex = applicationHandler->threadCounter;
		applicationHandler->threadCounter++;
		return;
	}

	/* Lazy initialization of handlers array */
	if (handlers == NULL) {
		memoryManager_allocateHandlerPool(element, ownerExt);
		handlers = ownerExt->handlers;
	}

	handler = (DSPEThreadHandler*) memoryManager_allocate(element, sizeof(DSPEThreadHandler));
	initDSPEElement((DSPEElement*) handler, element);
	initDSPEHandler((DSPEHandler*) handler, element);

	((DSPEHandler*) handler)->reset = resetThreadHandler;
	((DSPEHandler*) handler)->dispose = disposeThreadHandler;

	applicationHandler = getThreadHandler((DSPEElement*) element->application);
	// Set current handler's threadIndex to actual global counter
	handler->threadIndex = applicationHandler->threadCounter;
	// REMARK: only global threadCounter on application will be used!
	handler->threadCounter = 0;

	// Increment global counter
	applicationHandler->threadCounter++;

	/* Add ThreadHandler to handlers */
	handlers[HANDLER_INDEX_THREAD] = (DSPEHandler*) handler;

	/* init processor affinity counter */
	handler->affinityCounter = 0;

	/* set maxNumThreads for master and GUI threads */
	handler->maxNumThreads = 2;

	/* add number of engines to maxNumThreads */
	handler->maxNumThreads += getMaxNumEngines(element);

	/* init numThreads */
	handler->numThreads = handler->maxNumThreads;
}

/******************************************************************************
 * THREAD SUPPORT
 ******************************************************************************/

/**
 * ThreadManager_getNumProcessors function
 * Return the number of Processors on system
 */
unsigned int threadManager_getNumProcessors(const DSPEElement *context) {
	threadNumProcessors();
}

/**
 * ThreadManager_createThread function
 * Create and start a thread
 */
void* threadManager_createThread(const DSPEElement *element, CREATE_THREAD_ROUTINE, THREAD_ROUTINE_ARGS) {
	register int error = 0;
	pthread_attr_t attributes;
	pthread_t *thread = NULL;
	error = pthread_attr_init(&attributes);
	if (error) {
		errorManager_appendStandardError(element, error);
		return NULL;
	}
	// TODO parte condizionale
	error = pthread_attr_setscope(&attributes, PTHREAD_SCOPE_SYSTEM);
	if (error) {
		errorManager_appendStandardError(element, error);
		return NULL;
	}
	// TODO risolvere problema DSPECGeneConstants allocate!
	thread = (pthread_t*) memoryManager_allocate(element, sizeof(pthread_t));
	error = pthread_create(thread, &attributes, threadRoutine, args);
	// error = pthread_create(thread, NULL, threadRoutine, args);
	if (error)
		errorManager_appendStandardError(element, error);
	return (void*) thread;
}

/**
 * ThreadManager_waitThread function
 * The calling thread is suspended until the thread passed as
 * argument is terminated.
 */
void threadManager_waitThread(const DSPEElement *element, void *thread) {
	register int error = 0;
	error = pthread_join(*((pthread_t*) thread), NULL);
	if (error)
		errorManager_appendStandardError(element, error);
}

/**
 * ThreadManager_destroyThread function
 */
void threadManager_destroyThread(const DSPEElement *element, void *thread) {
	memorySupport_dispose(thread);
}

/******************************************************************************
 * MUTEX SUPPORT
 ******************************************************************************/

/**
 * ThreadManager_createMutex function
 */
void* threadManager_createMutex(const DSPEElement *element) {
	register int error = 0;
	pthread_mutex_t *mutex = (pthread_mutex_t*) memoryManager_allocate(element, sizeof(pthread_mutex_t));
	error = pthread_mutex_init(mutex, NULL);
	if (error)
		errorManager_appendStandardError(element, error);
	return (void*) mutex;
}

/**
 * ThreadManager_lockMutex function
 */
void threadManager_lockMutex(const DSPEElement *element, void *mutex) {
	register int error = 0;
	error = pthread_mutex_lock((pthread_mutex_t*) mutex);
	if (error)
		errorManager_appendStandardError(element, error);
}

/**
 * ThreadManager_tryLockMutex function
 */
int threadManager_tryLockMutex(const DSPEElement *element, void *mutex) {
	int error = 0;
	error = pthread_mutex_trylock((pthread_mutex_t*) mutex);
	if (!error)
		return 1;
	if (error == EBUSY)
		return 0;
	else {
		errorManager_appendStandardError(element, error);
		return 0;
	}
}

/**
 * ThreadManager_unlockMutex function
 */
void threadManager_unlockMutex(const DSPEElement *element, void *mutex) {
	register int error = 0;
	error = pthread_mutex_unlock((pthread_mutex_t*) mutex);
	if (error)
		errorManager_appendStandardError(element, error);
}

/**
 * ThreadManager_deleteMutex function
 */
void threadManager_deleteMutex(const DSPEElement *element, void *mutex) {
	register int error = 0;
	error = pthread_mutex_destroy((pthread_mutex_t*) mutex);
	if (error)
		errorManager_appendStandardError(element, error);
	memorySupport_dispose(mutex);
}

/******************************************************************************
 * SPINLOCK SUPPORT
 ******************************************************************************/

/**
 * Creates a spinning lock
 */
void* threadManager_createSpin(const DSPEElement *element) {
	register int error = 0;
	pthread_spinlock_t *spin = (pthread_spinlock_t*) memoryManager_allocate(element, sizeof(pthread_spinlock_t));
	error = pthread_spin_init(spin, PTHREAD_PROCESS_PRIVATE);
	if (error)
		errorManager_appendStandardError(element, error);
	return (void*) spin;
}

/**
 * Lock a spinning lock
 */
void threadManager_lockSpin(const DSPEElement *element, void *spin) {
	register int error = 0;
	error = pthread_spin_lock((pthread_spinlock_t*) spin);
	if (error)
		errorManager_appendStandardError(element, error);
}

/**
 * Tries to lock a spinning lock
 */
int threadManager_tryLockSpin(const DSPEElement *element, void *spin) {
	int error = 0;
	error = pthread_spin_trylock((pthread_spinlock_t*) spin);
	if (!error)
		return 1;
	if (error == EBUSY)
		return 0;
	else {
		errorManager_appendStandardError(element, error);
		return 0;
	}
}

/**
 * Unlock a spinning lock
 */
void threadManager_unlockSpin(const DSPEElement *element, void *spin) {
	register int error = 0;
	error = pthread_spin_unlock((pthread_spinlock_t*) spin);
	if (error)
		errorManager_appendStandardError(element, error);
}

/**
 * Deletes a spinning lock
 */
void threadManager_deleteSpin(const DSPEElement *element, void *spin) {
	register int error = 0;
	error = pthread_spin_destroy((pthread_spinlock_t*) spin);
	if (error)
		errorManager_appendStandardError(element, error);
	memorySupport_dispose(spin);
}

/******************************************************************************
 * CONDITION SUPPORT
 ******************************************************************************/

/**
 * ThreadManager_createCondition function
 * Create and initialise condition variable
 */
void* threadManager_createCondition(const DSPEElement *element) {
	register int error = 0;
	pthread_cond_t *condition = (pthread_cond_t*) memoryManager_allocate(element, sizeof(pthread_cond_t));
	error = pthread_cond_init(condition, NULL);
	if (error)
		errorManager_appendStandardError(element, error);
	return (void*) condition;
}

/**
 * ThreadManager_waitCondition function
 */
void threadManager_waitCondition(const DSPEElement *element, void *condition, void *mutex) {
	register int error = 0;
	error = pthread_cond_wait((pthread_cond_t*) condition, (pthread_mutex_t*) mutex);
	if (error)
		errorManager_appendStandardError(element, error);
}

/**
 * Function to wake a thread waiting at a conditional variable
 */
void threadManager_wakeCondition(const DSPEElement *element, void *condition) {
	register int error = 0;
	error = pthread_cond_signal((pthread_cond_t*) condition);
	if (error)
		errorManager_appendStandardError(element, error);
}

/**
 * threadManager_wakeAllCondition function
 */
void threadManager_wakeAllCondition(const DSPEElement *element, void *condition) {
	register int error = 0;
	error = pthread_cond_broadcast((pthread_cond_t*) condition);
	if (error)
		errorManager_appendStandardError(element, error);
}

/**
 * ThreadManager_destroyCondition function
 */
void threadManager_destroyCondition(const DSPEElement *element, void *condition) {
	register int error = 0;
	error = pthread_cond_destroy((pthread_cond_t*) condition);
	if (error)
		errorManager_appendStandardError(element, error);
	memorySupport_dispose(condition);
}

/******************************************************************************
 * GENERIC SUPPORT
 ******************************************************************************/

/**
 * ThreadManager_delay function
 * The calling thread is suspended for seconds (argument 'sec')
 * and nano seconds (argument 'nsec').
 */
void threadManager_delay(const DSPEElement *element, long int sec, long int nsec) {
	register int error = 0;
	struct timespec time = {sec, nsec};
	error = threadDelay(time);
	if (error)
		errorManager_appendStandardError(element, error);
}

/**
 * ThreadManager_setAffinity function
 */
void threadManager_setAffinity(DSPEElement *element, void *thread) {
	DSPEThreadHandler* handler = NULL;
	register unsigned int numProcessors;
	register unsigned int processorID;

	/* Find out how many cpus we have */
	numProcessors = threadManager_getNumProcessors(element);

	/* Increase affinity counter */
	handler = getThreadHandler(element);
	handler->affinityCounter++;

	/* Find out on which processor the created thread has to be paced */
	processorID = (handler->affinityCounter % numProcessors);

	//TODO implement THREAD_SETAFFINITY(thread, processorID);
}

/**
 * ThreadManager_getNumThreads function
 * Return the number of active threads
 */
size_t threadManager_getNumThreads(const DSPEElement *context) {
	DSPEThreadHandler *handler = getThreadHandler(context);
	return handler->numThreads;
}

/**
 * ThreadManager_getMaxNumEngines function
 * Sets the number of engine threads
 */
size_t threadManager_getMaxNumThreads(const DSPEElement *context) {
	DSPEThreadHandler *handler = getThreadHandler(context);
	return handler->maxNumThreads;
}

/**
 * ThreadManager_getOwnerIndex function
 */
size_t threadManager_getOwnerIndex(const DSPEOwner *owner) {
	return ((DSPEThreadHandler*) owner->handlers[HANDLER_INDEX_THREAD])->threadIndex;
}

