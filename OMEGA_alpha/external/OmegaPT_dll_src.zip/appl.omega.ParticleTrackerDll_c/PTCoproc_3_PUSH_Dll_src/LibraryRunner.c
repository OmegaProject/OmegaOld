/**
 * File: LibraryRunner.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "LibraryRunner.h"

#include "MemoryManager.h"
#include "ErrorManager.h"
#include "InfoManager.h"
#include "EngineManager.h"
#include "ThreadManager.h"
#include "StringManager.h"

#include "RunnerGround.h"
#include "TextualRepresentation.h"
#include "CriticalSection.h"
#include "RunnerSupport.h"

/**
 * InitRunner function
 */
void* initRunner() {
	return (void*) initializeRunner();
}

/**
 * DisposeRunner function
 */
void disposeRunner(void *runner) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) runner;

	engineManager_quit((DSPEElement*) context->runnerDelegate);
	destroyRunner(context);
}

/**
 * StartRunner function
 */
void startRunner(void *runner) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) runner;

	engineManager_run((DSPEElement*) context->runnerDelegate);
}

/**
 * StopRunner function
 */
void stopRunner(void *runner) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) runner;
	DSPEElement *element = (DSPEElement*) context->runnerDelegate;

	engineManager_stop(element);
	// Wait that engine has stopped
	while (!engineManager_isStopped(element)) {
		threadManager_lockMutex(element, context->endRunCondMutex);
		threadManager_waitCondition(element, context->endRunCondition, context->endRunCondMutex);
		threadManager_unlockMutex(element, context->endRunCondMutex);
		updateEngineStateFeedback(context);
	}
}

/**
 * IsExecuting function
 */
int isExecuting(void *runner) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) runner;
	DSPEElement *element = (DSPEElement*) context->runnerDelegate;

	updateEngineStateFeedback(context);
	return engineManager_isExecuting(element);
}

/**
 * SetParameter function
 */
void setParameter(void *runner, char *opt, char *value) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) runner;
	int error = 0;

	// REMARK: Process parameters are not allowed
	updateEngineStateFeedback(context);
	if (engineManager_isExecuting((DSPEElement*) context->runnerDelegate))
		return;

	optionPn(context, opt, value, &error);
}

/**
 * GetParameter function
 */
void getParameter(void *runner, char *opt, char *value) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) runner;

	// REMARK: Process parameters are not allowed
	updateEngineStateFeedback(context);
	if (engineManager_isExecuting((DSPEElement*) context->runnerDelegate))
		return;
	/* Parameter inputs */
	if (stringSupport_compareNoCase(opt, "p0") == 0) {
		sprintf(value, "%d",  *context->paramIn_Radius_curValue);
	} else if (stringSupport_compareNoCase(opt, "p1") == 0) {
		sprintf(value, "%.8lf",  *context->paramIn_Cutoff_curValue);
	} else if (stringSupport_compareNoCase(opt, "p2") == 0) {
		sprintf(value, "%.8lf",  *context->paramIn_Percentile_curValue);
	} else if (stringSupport_compareNoCase(opt, "p3") == 0) {
		sprintf(value, "%.8lf",  *context->paramIn_Displacement_curValue);
	} else if (stringSupport_compareNoCase(opt, "p4") == 0) {
		sprintf(value, "%d",  *context->paramIn_Linkrange_curValue);
	} else if (stringSupport_compareNoCase(opt, "p5") == 0) {
		sprintf(value, "%d",  *context->paramIn_ImgsNum_curValue);
	} else if (stringSupport_compareNoCase(opt, "p6") == 0) {
		sprintf(value, "%d",  *context->paramIn_ImgWidth_curValue);
	} else if (stringSupport_compareNoCase(opt, "p7") == 0) {
		sprintf(value, "%d",  *context->paramIn_ImgHeight_curValue);
	} else if (stringSupport_compareNoCase(opt, "p8") == 0) {
		sprintf(value, "%.8lf",  *context->paramIn_ImgMin_curValue);
	} else if (stringSupport_compareNoCase(opt, "p9") == 0) {
		sprintf(value, "%.8lf",  *context->paramIn_ImgMax_curValue);
	}

	/* Parameter outputs */
	else if (stringSupport_compareNoCase(opt, "p10") == 0) {
		sprintf(value, "%s",  *context->paramOut_DataReader_status_curValue);
	} else if (stringSupport_compareNoCase(opt, "p11") == 0) {
		sprintf(value, "%s",  *context->paramOut_Convolve_status_curValue);
	} else if (stringSupport_compareNoCase(opt, "p12") == 0) {
		sprintf(value, "%s",  *context->paramOut_Dilate_status_curValue);
	} else if (stringSupport_compareNoCase(opt, "p13") == 0) {
		sprintf(value, "%s",  *context->paramOut_FindThreshold_status_curValue);
	} else if (stringSupport_compareNoCase(opt, "p14") == 0) {
		sprintf(value, "%s",  *context->paramOut_FindParticles_status_curValue);
	} else if (stringSupport_compareNoCase(opt, "p15") == 0) {
		sprintf(value, "%s",  *context->paramOut_PositionRefinement_status_curValue);
	} else if (stringSupport_compareNoCase(opt, "p16") == 0) {
		sprintf(value, "%s",  *context->paramOut_ParticlesDiscrimination_status_curValue);
	} else if (stringSupport_compareNoCase(opt, "p17") == 0) {
		sprintf(value, "%s",  *context->paramOut_LinkParticles_status_curValue);
	} else if (stringSupport_compareNoCase(opt, "p18") == 0) {
		sprintf(value, "%s",  *context->paramOut_GenerateTrajectories_status_curValue);
	}
}

