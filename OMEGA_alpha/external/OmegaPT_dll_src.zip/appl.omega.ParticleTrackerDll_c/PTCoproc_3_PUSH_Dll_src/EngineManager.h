/**
 * File: EngineManager.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef EngineManager_h
#define EngineManager_h

#include "DSPEElements.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * EngineManager_initialize function
 */
void engineManager_initialize(const DSPEElement *element);

/**
 * EngineManager_dispose function
 */
void engineManager_dispose(const DSPEElement *element);

/**
 * EngineManager_isExecuting function
 */
int engineManager_isExecuting(const DSPEElement *element);

/**
 * EngineManager_isStopping function
 */
int engineManager_isStopping(const DSPEElement *element);

/**
 * EngineManager_isStopped function
 */
int engineManager_isStopped(const DSPEElement *element);

/**
 * EngineManager_isRunning function
 */
int engineManager_isRunning(const DSPEElement *element);

/**
 * EngineManager_isPaused function
 */
int engineManager_isPaused(const DSPEElement *element);

/**
 * EngineManager_isSkipping function
 */
int engineManager_isSkipping(const DSPEElement *element);

/**
 * EngineManager_isExiting function
 */
int engineManager_isExiting(const DSPEElement *element);

/**
 * EngineManager_isSuspended function
 */
int engineManager_isSuspended(const DSPEElement *element);

/**
 * EngineManager_run function
 */
void engineManager_run(const DSPEElement *element);

/**
 * EngineManager_stop function
 */
void engineManager_stop(const DSPEElement *element);

/**
 * Pause function
 * Usually called by the main thread when the user calls the
 * command pause
 */
void engineManager_pause(const DSPEElement *element);

/**
 * EngineManager_skip function
 */
void engineManager_skip(const DSPEElement *element, long int cycles);

/**
 * EngineManager_quit function
 */
void engineManager_quit(const DSPEElement *element);

/**
 * Suspend function
 * Usually called by the processing application thread.
 * (e.g. a player unit implementation when the data buffers
 * are full).
 * NB: the thread will suspend at the end of the process phase
 */
void engineManager_suspend(const DSPEElement *element);

/**
 * Freeze function
 * This can be called from the processing application thread
 * only, because the calling thread is immediately
 * suspended !!!
 * (e.g. a player unit implementation when the
 * data buffers are full).application It returns the
 * info if the processing application thread has been stopped
 */
int engineManager_freeze(const DSPEElement *element);

/**
 * Resume function
 * Usually called by a third thread
 * (e.g. a player when the data buffers aren't full any longer)
 */
void engineManager_resume(const DSPEElement *element);

/**
 * EngineManager_performIdleTime function
 */
void engineManager_performIdleTime(const DSPEElement *element);

/**
 * EngineManager_forceCriticalSection function.
 * Returns engineManager stopped state.
 */
int engineManager_forceCriticalSection(const DSPEElement *element);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
