/**
 * File: InfoManager.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "InfoManager.h"

#include "RunnerGround.h"

#include "StringManager.h"
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <limits.h>

/**
 * InitializeInfoSwap function.
 */
static INLINE infoSwap* initializeInfoSwap(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context) {
	DSPEElement *element = (DSPEElement*) context->runnerDelegate;

	/* Info swap area allocation */
	infoSwap *swap = (infoSwap*) allocateMemory(element, sizeof(infoSwap));

	/* Initialize info pool */
	swap->poolHead = NULL;
	swap->poolTail = NULL;
	swap->poolNodesNum = 0;

	/* Initialize info changes list */
	swap->changesHead = NULL;
	swap->changesTail = NULL;
	swap->changesNodesNum = 0;

	/* Initialize log changes list */
	swap->logChangesHead = NULL;
	swap->logChangesTail = NULL;
	swap->logChangesNodesNum = 0;

	/* Initialize info adding changes flag */
	swap->addingChanges = 0;
	swap->isReading = 0;

	/* Initialize changes lock */
	swap->changesLock = createSpin(element);

	/* Initialize collected info array */
	swap->collectedInfo = (unsigned int*) allocateAndInitMemory(element, infoIDCount, sizeof(unsigned int));

	/* Initialize collected log array */
	swap->collectedLog = (unsigned int*) allocateAndInitMemory(element, infoIDCount, sizeof(unsigned int));

	return swap;
}

/**
 * DisposeInfoSwap function.
 */
static INLINE void disposeInfoSwap(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context, infoSwap *swap) {
	register size_t i;
	int isReading;
	DSPEInfoNode *node;
	DSPEElement *element = (DSPEElement*) context->runnerDelegate;

	/* Merge infoSwap before disposing */
	infoManager_mergeInfo(element, swap);	

	/* wait until reading on swap area has finished */
	do {
		lockSpin(element, swap->changesLock);
		isReading = swap->isReading;
		unlockSpin(element, swap->changesLock);
	} while (isReading);

	/* Dispose collected info array */
	disposeMemory(swap->collectedInfo);

	/* Dispose collected log array */
	disposeMemory(swap->collectedLog);

	//FIXME testare! le code di seguito dovrebbero sempre essere pulite in seguito al merge precedente

	/* Dispose changes nodes */
	for (i = 0; i < swap->changesNodesNum; i++) {
		node = swap->changesHead;
		swap->changesHead = node->next;
		node->next = NULL;
		disposeMemory(node->info);
		disposeMemory(node);
	}

	/* Dispose log changes nodes */
	for (i = 0; i < swap->logChangesNodesNum; i++) {
		node = swap->logChangesHead;
		swap->logChangesHead = node->next;
		node->next = NULL;
		disposeMemory(node->info);
		disposeMemory(node);
	}

	/* Dispose pool nodes */
	for (i = 0; i < swap->poolNodesNum; i++) {
		node = swap->poolHead;
		swap->poolHead = node->next;
		node->next = NULL;
		disposeMemory(node->info);
		disposeMemory(node);
	}

	/* Delete changes lock */
	disposeSpin(element, swap->changesLock);

	disposeMemory(swap);
}

/**
 * InfoManager_initInfoSwap function
 */
void infoManager_initInfoSwap(DSPEElement *element, size_t index) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	lockSpin(element, context->infoSwapLock);
	context->infoSwapEngine[index] = initializeInfoSwap(context);
	context->infoSwapGui[index] = initializeInfoSwap(context);
	unlockSpin(element, context->infoSwapLock);
}

/**
 * InfoManager_disposeInfoSwap function
 */
void infoManager_disposeInfoSwap(DSPEElement *element, size_t index) {
	infoSwap *engineSwap;
	infoSwap *guiSwap;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	
	lockSpin(element, context->infoSwapLock);
	/* Set local pointers to swap areas */
	engineSwap = context->infoSwapEngine[index];
	guiSwap = context->infoSwapGui[index];

	/* Set global infoSwap areas to NULL. This will prevent accesses to areas during dispose */
	context->infoSwapEngine[index] = NULL;
	context->infoSwapGui[index] = NULL;
	unlockSpin(element, context->infoSwapLock);	

	/* Dispose swap areas */
	disposeInfoSwap(context, engineSwap);
	disposeInfoSwap(context, guiSwap);
}

/**
 * MergeCollectedInfo function
 */
static INLINE void mergeCollectedInfo(const DSPEElement *element, infoSwap *swap, int isLog) {
	int i;
	unsigned int count;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	lockSpin(element, context->infoLock);

	for (i = 0; i < infoIDCount; i++) {
		if (isLog) {
			count = swap->collectedLog[i];
			if (count == 0)
				continue;
			swap->collectedLog[i] = 0;
		} else {
			count = swap->collectedInfo[i];
			if (count == 0)
				continue;
			swap->collectedInfo[i] = 0;
		}

		/* Increment counter */
		if (context->collectedLog[i] > UINT_MAX - count)
			context->collectedLog[i] = UINT_MAX;
		else
			context->collectedLog[i] += count;
	}

	unlockSpin(element, context->infoLock);
}

/**
 * CloneInfoNode function
 */
static INLINE void cloneInfoNode(const DSPEElement *element, DSPEInfoNode *node) {
	DSPEInfoNode *cloneNode;
	size_t infoLength = 0;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	// FIXME Non si pu? riutilizzare direttamente il nodo che c'? nella swap area??

	lockSpin(element, context->infoLock);

	/* Check if the queue is full */
	if (context->logNodesNum >= LOG_HISTORY) {
		/* The queue is full - overwrite oldest log */
		cloneNode = context->logHead;
		context->logHead = cloneNode->next;
		context->logNodesNum--;
		cloneNode->next = NULL;
	} else {
		/* Retrieve node from pool (if any) */
		switch (context->infoPoolNodesNum) {
		case 0:
			cloneNode = (DSPEInfoNode*) allocateMemory(element, sizeof(DSPEInfoNode));
			cloneNode->next = NULL;
			cloneNode->info = NULL;
			cloneNode->infoLength = 0;
			break;
		case 1:
			cloneNode = context->infoPoolHead;
			context->infoPoolHead = NULL;
			context->infoPoolTail = NULL;
			context->infoPoolNodesNum = 0;
			cloneNode->next = NULL;
			break;
		default:
			cloneNode = context->infoPoolHead;
			context->infoPoolHead = cloneNode->next;
			context->infoPoolNodesNum--;
			cloneNode->next = NULL;
			break;
		}
	}

	/* Add info to node */
	infoLength = node->infoLength;
	if (cloneNode->infoLength == 0) {
		cloneNode->info = (char*) allocateMemory(element, infoLength);
		cloneNode->infoLength = infoLength;
	} else if (infoLength > cloneNode->infoLength) {
		cloneNode->info = (char*) reallocateMemory(cloneNode->info, infoLength);
		cloneNode->infoLength = infoLength;
	}
	stringSupport_copy(cloneNode->info, node->info);

	/* Add info node to queue */
	if (context->logNodesNum == 0) {
		context->logHead = cloneNode;
		context->logTail = cloneNode;
		context->logNodesNum = 1;
	} else {
		context->logTail->next = cloneNode;
		context->logTail = cloneNode;
		context->logNodesNum++;
	}

	unlockSpin(element, context->infoLock);
}

/**
 * MergeInfo function
 */
static INLINE void mergeInfo(const DSPEElement *element, infoSwap *swap, int isLog) {
	DSPEInfoNode *swapNode;

	if (isLog) {
		while (swap->logChangesNodesNum > 0) {
			swapNode = swap->logChangesHead;

			cloneInfoNode(element, swapNode);

			swap->logChangesHead = swapNode->next;
			swap->logChangesNodesNum--;
			swapNode->next = NULL;

			// Add node to pool
			if (swap->poolNodesNum == 0) {
				swap->poolHead = swapNode;
				swap->poolTail = swapNode;
				swap->poolNodesNum = 1;
			} else {
				swap->poolTail->next = swapNode;
				swap->poolTail = swapNode;
				swap->poolNodesNum++;
			}
		}
	} else {
		while (swap->changesNodesNum > 0) {
			swapNode = swap->changesHead;

			cloneInfoNode(element, swapNode);

			swap->changesHead = swapNode->next;
			swap->changesNodesNum--;
			swapNode->next = NULL;

			// Add node to pool
			if (swap->poolNodesNum == 0) {
				swap->poolHead = swapNode;
				swap->poolTail = swapNode;
				swap->poolNodesNum = 1;
			} else {
				swap->poolTail->next = swapNode;
				swap->poolTail = swapNode;
				swap->poolNodesNum++;
			}
		}
	}
}

/**
 * InfoManager_mergeInfo function
 */
void infoManager_mergeInfo(const DSPEElement *element, infoSwap *swap) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	/* Swap area might be NULL if not initialized or during dispose */
	if (swap == NULL)
		return;

	lockSpin(element, swap->changesLock);
	if (swap->addingChanges) {
		unlockSpin(element, swap->changesLock);
		/* Info changes are not ready, skip this turn */
		lockSpin(element, context->infoSwapLock);
		context->isInfoChangePending = 1;
		unlockSpin(element, context->infoSwapLock);
		return;
	} else if (swap->isReading) {
		unlockSpin(element, swap->changesLock);
		/* Merge is done by someone else */
		return;
	}

	swap->isReading = 1;
	unlockSpin(element, swap->changesLock);

	// Merge collected info
	mergeCollectedInfo(element, swap, 0);
	// Merge collected logs
	mergeCollectedInfo(element, swap, 1);

	// Merge info
	mergeInfo(element, swap, 0);
	// Merge logs
	mergeInfo(element, swap, 1);
		
	lockSpin(element, swap->changesLock);
	swap->isReading = 0;
	unlockSpin(element, swap->changesLock);
}

/**
 * GetCurrentInfoSwap function.
 */
static INLINE infoSwap* getCurrentInfoSwap(const DSPEElement *element) {
	infoSwap *current;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	lockSpin(element, context->infoSwapLock);
	current = context->infoSwapEngine[getOwnerIndex(element->owner)];
	unlockSpin(element, context->infoSwapLock);

	lockSpin(element, current->changesLock);
	current->addingChanges = 1;
	unlockSpin(element, current->changesLock);

	return current;
}

/**
 * SetInfoChanged function.
 */
static INLINE void setInfoChanged(const DSPEElement *element, infoSwap *swap) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;
	lockSpin(element, swap->changesLock);
	swap->addingChanges = 0;
	unlockSpin(element, swap->changesLock);

	// Set flag
	lockSpin(element, context->infoSwapLock);
	context->isInfoChanged = 1;
	unlockSpin(element, context->infoSwapLock);
}

/**
 * AddInfo function.
 */
static INLINE void addInfo(const DSPEElement *element, const char *info, va_list args, int isLog) {
	DSPEInfoNode *node;
	size_t infoLength = 0;
	infoSwap *swap = getCurrentInfoSwap(element);

	/* Check if the queue is full */
	if (!isLog && swap->changesNodesNum >= INFO_HISTORY) {
		/* The queue is full - overwrite oldest info */
		node = swap->changesHead;
		swap->changesHead = node->next;
		swap->changesNodesNum--;
		node->next = NULL;
	} else if (isLog && swap->logChangesNodesNum >= LOG_HISTORY) {
		/* The queue is full - overwrite oldest log */
		node = swap->logChangesHead;
		swap->logChangesHead = node->next;
		swap->logChangesNodesNum--;
		node->next = NULL;
	} else {
		/* Retrieve node from pool (if any) */
		switch (swap->poolNodesNum) {
		case 0:
			node = (DSPEInfoNode*) allocateMemory(element, sizeof(DSPEInfoNode));
			node->next = NULL;
			node->info = NULL;
			node->infoLength = 0;
			break;
		case 1:
			node = swap->poolHead;
			swap->poolHead = NULL;
			swap->poolTail = NULL;
			swap->poolNodesNum = 0;
			node->next = NULL;
			break;
		default:
			node = swap->poolHead;
			swap->poolHead = node->next;
			swap->poolNodesNum--;
			node->next = NULL;
			break;
		}
	}

	/* Add info to node */
	infoLength = (size_t) (vsnprintf(NULL, 0, info, args) + 1);
	if (node->infoLength == 0) {
		node->info = (char*) allocateMemory(element, infoLength);
		node->infoLength = infoLength;
	} else if (infoLength > node->infoLength) {
		node->info = (char*) reallocateMemory(node->info, infoLength);
		node->infoLength = infoLength;
	}
	vsnprintf(node->info, node->infoLength, info, args);

	if (isLog) {
		/* Add info node to log changes queue */
		if (swap->logChangesNodesNum == 0) {
			swap->logChangesHead = node;
			swap->logChangesTail = node;
			swap->logChangesNodesNum = 1;
		} else {
			swap->logChangesTail->next = node;
			swap->logChangesTail = node;
			swap->logChangesNodesNum++;
		}
	} else {
		/* Add info node to changes queue */
		if (swap->changesNodesNum == 0) {
			swap->changesHead = node;
			swap->changesTail = node;
			swap->changesNodesNum = 1;
		} else {
			swap->changesTail->next = node;
			swap->changesTail = node;
			swap->changesNodesNum++;
		}
	}

	setInfoChanged(element, swap);
}

/**
 * InfoManager_initialize function
 */
void infoManager_initialize(const DSPEElement *element) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	/* Initialize info pool */
	context->infoPoolHead = NULL;
	context->infoPoolTail = NULL;
	context->infoPoolNodesNum = 0;

	/* Initialize log list */
	context->logHead = NULL;
	context->logTail = NULL;
	context->logNodesNum = 0;

	/* Initialize collected log array */
	context->collectedLog = (unsigned int*) allocateAndInitMemory(element, infoIDCount, sizeof(unsigned int));

	/* Initialize info lock */
	context->infoLock = createSpin(element);
}

/**
 * InfoManager_dispose function
 */
void infoManager_dispose(const DSPEElement *element) {
	register size_t i;
	unsigned int count;
	DSPEInfoNode *node;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	/* Dispose info pool nodes */
	for (i = 0; i < context->infoPoolNodesNum; i++) {
		node = context->infoPoolHead;
		context->infoPoolHead = node->next;
		node->next = NULL;
		disposeMemory(node->info);
		disposeMemory(node);
	}

	/* Dispose collected log array */
	for (i = 0; i < infoIDCount; i++) {
		count = context->collectedLog[i];
		if (count > 0)
			/* Write info to log file */
			fprintf(context->logFile, "%s (%u times)\n", infoSupport_getCollectedInfoString((infoID) i), count);
	}
	disposeMemory(context->collectedLog);

	/* Dispose log nodes */
	for (i = 0; i < context->logNodesNum; i++) {
		node = context->logHead;
		/* Write info to log file */
		fprintf(context->logFile, "%s\n", node->info);
		context->logHead = node->next;
		node->next = NULL;
		disposeMemory(node->info);
		disposeMemory(node);
	}

	/* Dispose info lock */
	disposeSpin(element, context->infoLock);
}

/**
 * InfoManager_writeInfo function
 */
void infoManager_writeInfo(const DSPEElement *element, const char *info, ...) {
	va_list args;
	/* Add info to node */
	va_start(args, info);
	addInfo(element, info, args, 0);
	va_end(args);
}

/**
 * InfoManager_logInfo function
 */
void infoManager_logInfo(const DSPEElement *element, const char *info, ...) {
	va_list args;
	/* Add info to node */
	va_start(args, info);
	addInfo(element, info, args, 1);
	va_end(args);
}

/**
 * CollectInfo function.
 */
static INLINE void collectInfo(const DSPEElement *element, const infoID id, const unsigned int increment, int isLog) {
	infoSwap *swap = getCurrentInfoSwap(element);

	/* Increment collect counter */
	if (isLog) {
		if (swap->collectedLog[id] > UINT_MAX - increment)
			swap->collectedLog[id] = UINT_MAX;
		else
			swap->collectedLog[id] += increment;
	} else {
		if (swap->collectedInfo[id] > UINT_MAX - increment)
			swap->collectedInfo[id] = UINT_MAX;
		else
			swap->collectedInfo[id] += increment;
	}

	setInfoChanged(element, swap);
}

/**
 * InfoManager_collectAndWriteInfo function
 */
void infoManager_collectAndWriteInfo(const DSPEElement *element, const infoID id, const unsigned int increment) {

	collectInfo(element, id, increment, 0);
}

/**
 * InfoManager_collectAndLogInfo function
 */
void infoManager_collectAndLogInfo(const DSPEElement *element, const infoID id, const unsigned int increment) {

	collectInfo(element, id, increment, 1);
}

/**
 * InfoSupport_getCollectedInfoString function.
 */
const char* infoSupport_getCollectedInfoString(const infoID id) {
	switch (id) {
	case coprocEngineSuspend:
		return "Coprocessor engine suspended";
	case coprocContribution:
		return "Performing coprocessor contribution";
	case coprocQueueFull:
		return "Coprocessor queue is full";
	case coprocFirstElementAdded:
		return "Added first op to an empty queue";
	case coprocQueuePoolEmptyForContribution:
		return "QueuePool is empty for coprocContribution";
	// FIXME may be used by the master thread or by the coproc engine. This situation
	// could lead to concurrent access!
	//case coprocLastElementProcessed:
	//	return "Processing the last element in the queue, queue is not rescheduled";
	//case coprocQueuePoolEmpty:
	//	return "QueuePool is empty";
	//case coprocQueuePoolFirstAdded:
	//	return "First queue added to queuePool";
	default:
		return "Invalid info id";
	}
}

/**
 * InfoSupport_getCurrentTime function.
 */
clock_t infoSupport_getCurrentTime() {
	return clock();
}

/**
 * InfoSupport_getMilliseconds function.
 */
double infoSupport_getMilliseconds(clock_t ticks) {
	return ticks * 1000.0 / CLOCKS_PER_SEC;
}

