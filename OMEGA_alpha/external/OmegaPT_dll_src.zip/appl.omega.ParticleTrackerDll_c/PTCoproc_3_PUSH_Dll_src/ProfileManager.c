/**
 * File: ProfileManager.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "ProfileManager.h"

#include "StringManager.h"
#include "InfoManager.h"
#include "RunnerGround.h"

#include <limits.h>

/* PROFILE SUPPORT */

/**
 * ProfileManager_initProfileQueue function
 */
DSPEProfileNode** profileManager_initProfileQueue(const DSPEElement *element) {
	size_t i;
	profileNode *node;
	DSPEProfileNode **profileQueue = (DSPEProfileNode**) allocateMemory(element, profileIDCount * sizeof(profileNode*));
	for (i = 0; i < profileIDCount; i++) {
		// Initialize profileNode
		node = (profileNode*) allocateMemory(element, sizeof(profileNode));
		node->totalTicks = 0;
		node->minTicks = LONG_MAX;
		node->maxTicks = 0;
		node->count = 0;
		((DSPEProfileNode*) node)->id = i;

		profileQueue[i] = (DSPEProfileNode*) node;
	}
	return profileQueue;
}

/**
 * ProfileManager_disposeProfileQueue function
 */
void profileManager_disposeProfileQueue(const DSPEElement *element, DSPEProfileNode **profileQueue) {
	size_t i;

	for (i = 0; i < profileIDCount; i++)
		disposeMemory(profileQueue[i]);
	disposeMemory(profileQueue);
}

/**
 * ProfileManager_initialize function
 */
void profileManager_initialize(const DSPEElement *element) {
	profile *profileData = NULL;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	profileData = (profile*) allocateMemory(element, sizeof(profile));

	// Initialize queue
	profileData->profileQueue = profileManager_initProfileQueue(element);

	// Initialize times and counters
	profileData->startTime = 0;
	profileData->endTime = 0;
	profileData->samplesCount = 0;
	profileData->processCount = 0;
	profileData->ticks = 0;

	// Initialize lag counters
	profileData->lagCountEnabled = 0;
	profileData->lag = 0;
	profileData->totalLag = 0;
	profileData->minLag = UINT_MAX;
	profileData->maxLag = 0;
	profileData->lagCount = 0;

	// Initialize latency counters
	profileData->startLatency = 0;
	profileData->totalLatency = 0;
	profileData->minLatency = LONG_MAX;
	profileData->maxLatency = 0;
	profileData->latencyCount = 0;

	context->profileData = profileData;
}

/**
 * ProfileManager_dispose function
 */
void profileManager_dispose(const DSPEElement *element) {
	profile *profileData = NULL;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	profileData = context->profileData;
	profileManager_disposeProfileQueue(element, profileData->profileQueue);
	profileData->profileQueue = NULL;
	disposeMemory(profileData);
}

/**
 * ProfileSupport_getProfileString function
 */
const char* profileSupport_getProfileString(const profileID id) {
	switch (id) {
	case PTCoproc_3_PUSH_Dll_ID:
		return "PTCoproc_3_PUSH_Dll";
	case PTCoproc_3_PUSH_Dll_ConvolveAllCaseCP_PUSH_ID:
		return "PTCoproc_3_PUSH_Dll_ConvolveAllCaseCP_PUSH";
	case PTCoproc_3_PUSH_Dll_DilateAllCaseCP_PUSH_ID:
		return "PTCoproc_3_PUSH_Dll_DilateAllCaseCP_PUSH";
	case PTCoproc_3_PUSH_Dll_FindThresholdCP_ID:
		return "PTCoproc_3_PUSH_Dll_FindThresholdCP";
	case PTCoproc_3_PUSH_Dll_FindParticlesCPNewAutoNext_PUSH_2_ID:
		return "PTCoproc_3_PUSH_Dll_FindParticlesCPNewAutoNext_PUSH_2";
	case PTCoproc_3_PUSH_Dll_PositionRefinementCP_PUSH_2_ID:
		return "PTCoproc_3_PUSH_Dll_PositionRefinementCP_PUSH_2";
	case PTCoproc_3_PUSH_Dll_ParticlesDiscriminationStateCP_PUSH_ID:
		return "PTCoproc_3_PUSH_Dll_ParticlesDiscriminationStateCP_PUSH";
	case PTCoproc_3_PUSH_Dll_LinkParticlesStateCPAutoNext_PUSH_ID:
		return "PTCoproc_3_PUSH_Dll_LinkParticlesStateCPAutoNext_PUSH";
	case PTCoproc_3_PUSH_Dll_GenerateTrajectoriesStateCPAutoNextNew_PUSH_ID:
		return "PTCoproc_3_PUSH_Dll_GenerateTrajectoriesStateCPAutoNextNew_PUSH";
	default:
		return "Invalid profile id";
	}
}

/**
 * ProfileSupport_getUnitProfileID function
 */
profileID profileSupport_getUnitProfileID(char* unitID) {
	if (stringSupport_compare(unitID, "PTCoproc_3_PUSH_Dll_ConvolveAllCaseCP_PUSH") == 0)
		return PTCoproc_3_PUSH_Dll_ConvolveAllCaseCP_PUSH_ID;
	if (stringSupport_compare(unitID, "PTCoproc_3_PUSH_Dll_DilateAllCaseCP_PUSH") == 0)
		return PTCoproc_3_PUSH_Dll_DilateAllCaseCP_PUSH_ID;
	if (stringSupport_compare(unitID, "PTCoproc_3_PUSH_Dll_FindThresholdCP") == 0)
		return PTCoproc_3_PUSH_Dll_FindThresholdCP_ID;
	if (stringSupport_compare(unitID, "PTCoproc_3_PUSH_Dll_FindParticlesCPNewAutoNext_PUSH_2") == 0)
		return PTCoproc_3_PUSH_Dll_FindParticlesCPNewAutoNext_PUSH_2_ID;
	if (stringSupport_compare(unitID, "PTCoproc_3_PUSH_Dll_PositionRefinementCP_PUSH_2") == 0)
		return PTCoproc_3_PUSH_Dll_PositionRefinementCP_PUSH_2_ID;
	if (stringSupport_compare(unitID, "PTCoproc_3_PUSH_Dll_ParticlesDiscriminationStateCP_PUSH") == 0)
		return PTCoproc_3_PUSH_Dll_ParticlesDiscriminationStateCP_PUSH_ID;
	if (stringSupport_compare(unitID, "PTCoproc_3_PUSH_Dll_LinkParticlesStateCPAutoNext_PUSH") == 0)
		return PTCoproc_3_PUSH_Dll_LinkParticlesStateCPAutoNext_PUSH_ID;
	if (stringSupport_compare(unitID, "PTCoproc_3_PUSH_Dll_GenerateTrajectoriesStateCPAutoNextNew_PUSH") == 0)
		return PTCoproc_3_PUSH_Dll_GenerateTrajectoriesStateCPAutoNextNew_PUSH_ID;
	return 0;
}

/**
 * GetProfileQueue function.
 */
static INLINE DSPEProfileNode** getProfileQueue(const DSPEElement *element) {
	if (element->owner == CAST_TO_OWNER(element->application))
		return ((ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application)->profileData->profileQueue;
	return ((DSPEProfileCoprocOp*) element)->profileQueue;
}

/**
 * GetProfileNode function.
 */
static INLINE profileNode* getProfileNode(const DSPEElement *element, profileID id) {
	return (profileNode*) getProfileQueue(element)[id];
}

/**
 * ProfileManager_captureStartTime function
 */
void profileManager_captureStartTime(const DSPEElement *element, profileID id) {
	profile *profileData = NULL;
	profileNode *node = NULL;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	profileData = context->profileData;
	if (id == PTCoproc_3_PUSH_Dll_ID) {
		// Application profile
		profileData->startTime = infoSupport_getCurrentTime();
		profileData->endTime = 0;
		profileData->samplesCount = 0;
		profileData->processCount = 0;
		profileData->ticks = 0;
		return;
	}
	// Unit profile - Find node
	node = getProfileNode(element, id);
	// Capture start time
	node->startTime = infoSupport_getCurrentTime();
}

/**
 * ProfileManager_captureEndTime function
 */
void profileManager_captureEndTime(const DSPEElement *element, profileID id) {
	profile *profileData = NULL;
	profileNode *node = NULL;
	clock_t ticks = 0;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (id == PTCoproc_3_PUSH_Dll_ID) {
		// Application profile
		profileData = context->profileData;
		profileData->endTime = infoSupport_getCurrentTime();
		profileData->ticks = profileData->endTime - profileData->startTime;
		return;
	}
	// Unit profile - Find node
	node = getProfileNode(element, id);
	if (node->startTime == 0)
		// CaptureStartTime has not been called
		return;

	// Compute elapsed ticks
	ticks = infoSupport_getCurrentTime() - node->startTime;
	node->totalTicks += ticks;
	if (ticks < node->minTicks)
		node->minTicks = ticks;
	if (ticks > node->maxTicks)
		node->maxTicks = ticks;
	node->count++;
}

/**
 * ProfileManager_incrementSamplesCount function
 */
void profileManager_incrementSamplesCount(const DSPEElement *element, const unsigned int increment) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	context->profileData->samplesCount += increment;
	context->profileData->processCount++;
}

/**
 * ProfileManager_getSamplesCount function
 */
unsigned int profileManager_getSamplesCount(const DSPEElement *element) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	return context->profileData->samplesCount;
}

/**
 * ProfileManager_getElapsedTime function
 * Returns the elapsed time in seconds
 */
double profileManager_getElapsedTime(const DSPEElement *element) {
	profile *profileData = NULL;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	profileData = context->profileData;
	if (profileData->endTime == 0)
		// The application is still running, compute elapsed time in seconds
		return infoSupport_getMilliseconds(infoSupport_getCurrentTime() - profileData->startTime) / 1000.0;

	// The application is stopped, compute elapsed time in seconds
	return infoSupport_getMilliseconds(profileData->endTime - profileData->startTime) / 1000.0;
}

/**
 * ProfileManager_getMeanProcessTime function
 * Returns the mean process time in milliseconds
 */
double profileManager_getMeanProcessTime(const DSPEElement *element, profileID id) {
	profile *profileData = NULL;
	profileNode *node = NULL;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (id == PTCoproc_3_PUSH_Dll_ID) {
		// Application profile
		profileData = context->profileData;
		if (profileData->processCount == 0)
			return 0.0;
		// Compute mean process time in milliseconds
		return infoSupport_getMilliseconds(profileData->endTime - profileData->startTime) / profileData->processCount;
	}

	// Unit profile - Find node
	node = getProfileNode(element, id);
	if (node->count == 0)
		// CaptureEndTime has not been called
		return 0.0;

	// Compute mean process time in milliseconds
	return infoSupport_getMilliseconds(node->totalTicks) / node->count;
}

/**
 * ProfileManager_getMinProcessTime function
 * Returns the min process time in milliseconds
 */
double profileManager_getMinProcessTime(const DSPEElement *element, profileID id) {
	profileNode *node = NULL;

	if (id == PTCoproc_3_PUSH_Dll_ID)
		// Application min process time not avaiable
		return 0.0;

	// Unit profile - Find node
	node = getProfileNode(element, id);
	if (node->count == 0)
		return 0.0;
	// Compute min process time in milliseconds
	return infoSupport_getMilliseconds(node->minTicks);
}

/**
 * ProfileManager_getMaxProcessTime function
 * Returns the max process time in milliseconds
 */
double profileManager_getMaxProcessTime(const DSPEElement *element, profileID id) {
	profileNode *node = NULL;

	if (id == PTCoproc_3_PUSH_Dll_ID)
		// Application max process time not avaiable
		return 0.0;

	// Unit profile - Find node
	node = getProfileNode(element, id);
	if (node->count == 0)
		return 0.0;
	// Compute max process time in milliseconds
	return infoSupport_getMilliseconds(node->maxTicks);
}

/**
 * ProfileManager_getThroughput function
 */
double profileManager_getThroughput(const DSPEElement *element) {
	profile *profileData = NULL;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	profileData = context->profileData;
	if (profileData->ticks == 0)
		return 0.0;
	return profileData->samplesCount * 1000.0 / infoSupport_getMilliseconds(profileData->ticks);
}

/**
 * ProfileManager_isProfileUnit function
 */
int profileManager_isProfileUnit(const DSPEElement *element, profileID id) {
	// Profile unit support disabled.
	return 0;
}

/**
 * ProfileManager_mergeQueue function
 */
void profileManager_mergeQueue(const DSPEElement *element, DSPEProfileNode **queue) {
	DSPEProfileNode **profileQueue = NULL;
	profileNode *curNode = NULL;
	profileNode *applNode = NULL;
	size_t i;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	profileQueue = context->profileData->profileQueue;
	if (profileQueue == queue)
		// No queues to merge
		return;

	for (i = 0; i < profileIDCount; i++) {
		curNode = (profileNode*) queue[i];
		if (curNode->count == 0)
			continue;
		applNode = (profileNode*) profileQueue[i];

		applNode->count += curNode->count;
		applNode->totalTicks += curNode->totalTicks;
		if (curNode->minTicks < applNode->minTicks)
			applNode->minTicks = curNode->minTicks;
		if (curNode->maxTicks > applNode->maxTicks)
			applNode->maxTicks = curNode->maxTicks;

		// Reset node data
		curNode->count = 0;
		curNode->maxTicks = 0;
		curNode->minTicks = LONG_MAX;
		curNode->startTime = 0;
		curNode->totalTicks = 0;
	}
}

/* LAG AND LATENCY SUPPORT */

/**
 * ProfileManager_sendSignal function
 */
void profileManager_sendSignal(const DSPEElement *element) {
	profile *profileData = NULL;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	profileData = context->profileData;
	if (profileData->lagCountEnabled)
		return;

	profileData->lag = 0;
	profileData->lagCountEnabled = 1;
	profileData->startLatency = infoSupport_getCurrentTime();
}

/**
 * ProfileManager_receiveSignal function
 */
void profileManager_receiveSignal(const DSPEElement *element) {
	profile *profileData = NULL;
	clock_t ticks = 0;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	profileData = context->profileData;
	if (!profileData->lagCountEnabled)
		return;

	profileData->lagCountEnabled = 0;
	// Compute lag
	profileData->totalLag += profileData->lag;
	if (profileData->lag < profileData->minLag)
		profileData->minLag = profileData->lag;
	if (profileData->lag > profileData->maxLag)
		profileData->maxLag = profileData->lag;
	profileData->lagCount++;

	// Compute latency
	ticks = infoSupport_getCurrentTime() - profileData->startLatency;
	profileData->totalLatency += ticks;
	if (ticks < profileData->minLatency)
		profileData->minLatency = ticks;
	if (ticks > profileData->maxLatency)
		profileData->maxLatency = ticks;
	profileData->latencyCount++;
}

/**
 * ProfileManager_isSignalSent function
 */
int profileManager_isSignalSent(const DSPEElement *element) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	return context->profileData->lagCountEnabled;
}

/**
 * ProfileManager_incrementLag function
 */
void profileManager_incrementLag(const DSPEElement *element, const unsigned int increment) {
	profile *profileData = NULL;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	profileData = context->profileData;
	if (!profileData->lagCountEnabled)
		return;
	profileData->lag += increment;
}

/**
 * ProfileManager_getMeanLag function
 */
unsigned int profileManager_getMeanLag(const DSPEElement *element) {
	profile *profileData = NULL;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	profileData = context->profileData;
	if (profileData->lagCount == 0)
		return 0;
	return profileData->totalLag / profileData->lagCount;
}

/**
 * ProfileManager_getMinLag function
 */
unsigned int profileManager_getMinLag(const DSPEElement *element) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (context->profileData->lagCount == 0)
		return 0;
	return context->profileData->minLag;
}

/**
 * ProfileManager_getMaxLag function
 */
unsigned int profileManager_getMaxLag(const DSPEElement *element) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (context->profileData->lagCount == 0)
		return 0;
	return context->profileData->maxLag;
}

/**
 * ProfileManager_getMeanLatency function
 * Returns the mean latency in milliseconds
 */
double profileManager_getMeanLatency(const DSPEElement *element) {
	profile *profileData = NULL;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	profileData = context->profileData;
	if (profileData->latencyCount == 0)
		return 0.0;
	return infoSupport_getMilliseconds(profileData->totalLatency) / profileData->latencyCount;
}

/**
 * ProfileManager_getMinLatency function
 * Returns the min latency in milliseconds
 */
double profileManager_getMinLatency(const DSPEElement *element) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (context->profileData->latencyCount == 0)
		return 0.0;
	return infoSupport_getMilliseconds(context->profileData->minLatency);
}

/**
 * ProfileManager_getMaxLatency function
 * Returns the max latency in milliseconds
 */
double profileManager_getMaxLatency(const DSPEElement *element) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;

	if (context->profileData->latencyCount == 0)
		return 0.0;
	return infoSupport_getMilliseconds(context->profileData->maxLatency);
}

/**
 * ProfileManager_showProfileInfo function
 */
void profileManager_showProfileInfo(const DSPEElement *element, profileID id) {
	const char *applID;
	profile *profileData = NULL;
	profileNode *node = NULL;
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) element->application;


	if (id == PTCoproc_3_PUSH_Dll_ID) {
		// Application
		profileData = context->profileData;
		applID = profileSupport_getProfileString(id);
		infoManager_writeInfo(element, "\n%s elapsed time:\t%.3f\ts", applID, profileManager_getElapsedTime(element));
		infoManager_writeInfo(element, "%s mean process time for sample (average of %u measures):\t%.3f\tms", applID, profileData->processCount, profileManager_getMeanProcessTime(element, PTCoproc_3_PUSH_Dll_ID));
		if (profileData->samplesCount > 0)
			infoManager_writeInfo(element, "%s throughput:\t%.3f\tsamples/second", applID, profileManager_getThroughput(element));
		if (profileData->lagCount > 0)
			infoManager_writeInfo(element, "%s lag (average of %u measures, min mean max):\t%u\t%u\t%u\tsamples", applID, profileData->lagCount, profileManager_getMinLag(element), profileManager_getMeanLag(element), profileManager_getMaxLag(element));
		if (profileData->latencyCount > 0)
			infoManager_writeInfo(element, "%s latency (average of %u measures, min mean max):\t%.3f\t%.3f\t%.3f\tms", applID, profileData->latencyCount, profileManager_getMinLatency(element), profileManager_getMeanLatency(element), profileManager_getMaxLatency(element));
		infoManager_writeInfo(element, "");
		return;
	}
	// Unit - Find node
	node = getProfileNode(element, id);
	if (node->count > 0)
		infoManager_writeInfo(element, "%s process time:\t%.3f\t%.3f\t%.3f\t%u", profileSupport_getProfileString(id), infoSupport_getMilliseconds(node->minTicks), profileManager_getMeanProcessTime(element, id), infoSupport_getMilliseconds(node->maxTicks), node->count);
}

