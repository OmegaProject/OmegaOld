/**
 * File: CoprocManager.c
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#include "CoprocManager.h"

#include "MemoryManager.h"
#include "ThreadManager.h"
#include "StringManager.h"
#include "InfoManager.h"

#include "RunnerGround.h"

#include <stdarg.h>

#define COPROC_HANDLER_TYPE 1

#define COPROC_QUEUEMIN_THRESHOLD 5
#define COPROC_QUEUEMAX_THRESHOLD 20

#define ENGINE_BOOTSTRAPPING 0
#define ENGINE_ACTIVE 1
#define ENGINE_SUSPENDED 2

#define HANDLER_INITIALIZING 0
#define HANDLER_INITIALIZED 1
#define HANDLER_PREPROCESSING 2
#define HANDLER_ACTIVE 3
#define HANDLER_WAIT_SUSPEND 4
#define HANDLER_SLEEPING 5
#define HANDLER_TERMINATING 6

/******************************************************************************
 * POOL OF ENGINES
 * Support for collecting engines - each engine wraps and manages a thread
 ******************************************************************************/

/**
 * addEngineToPool Function
 */
static INLINE void addEngineToPool(DSPECoprocHandler *handler, DSPECoprocEngine *engine) {
	engine->state = ENGINE_SUSPENDED;
	if (handler->numSuspendedEngines == 0) {
		handler->enginesPoolHead = engine;
		handler->enginesPoolTail = engine;
		handler->numSuspendedEngines = 1;
	} else {
		handler->enginesPoolTail->next = engine;
		handler->enginesPoolTail = engine;
		handler->numSuspendedEngines++;
	}
}

/**
 * getEngineFromPool function
 */
static INLINE DSPECoprocEngine* getEngineFromPool(DSPECoprocHandler *handler) {
	DSPECoprocEngine *engine = NULL;
	switch (handler->numSuspendedEngines) {
	case 0:
		return NULL;
	case 1:
		engine = handler->enginesPoolHead;
		handler->enginesPoolHead = NULL;
		handler->enginesPoolTail = NULL;
		handler->numSuspendedEngines = 0;
		break;
	default:
		engine = handler->enginesPoolHead;
		handler->enginesPoolHead = engine->next;
		handler->numSuspendedEngines--;
		break;
	}
	engine->state = ENGINE_ACTIVE;
	engine->next = NULL;
	return engine;
}

/**
 * getEngineForDispose function
 */
static INLINE DSPECoprocEngine* getEngineForDispose(DSPECoprocHandler *handler) {
	DSPECoprocEngine *engine = NULL;
	DSPECoprocEngine *prevEngine = NULL;
	DSPECoprocEngine *engineToRemove = NULL;
	size_t maxThreadIndex = 0;
	size_t curSize;

	switch (handler->numSuspendedEngines) {
	case 0:
		return NULL;
	case 1:
		engine = handler->enginesPoolHead;
		handler->enginesPoolHead = NULL;
		handler->enginesPoolTail = NULL;
		handler->numSuspendedEngines = 0;
		break;
	default:
		/* Find engine with greatest threadIndex */
		engine = handler->enginesPoolHead;
		while (engine != NULL) {
			curSize = threadManager_getOwnerIndex(CAST_TO_OWNER(engine));
			if (curSize > maxThreadIndex)  {
				engineToRemove = engine;
				maxThreadIndex = curSize;
			}
			engine = engine->next;
		}

		/* Remove engine */
		engine = handler->enginesPoolHead;
		while (engine != NULL) {
			if (engine == engineToRemove) {
				if (prevEngine == NULL) {
					handler->enginesPoolHead = engine->next;
				} else {
					prevEngine->next = engine->next;
				}
				if (engine->next == NULL)
					handler->enginesPoolTail = prevEngine;
				break;
			}
			prevEngine = engine;
			engine = engine->next;
		}

		handler->numSuspendedEngines--;
		break;
	}
	engine->state = ENGINE_ACTIVE;
	engine->next = NULL;
	return engine;
}

/******************************************************************************
 * COPROC ENGINES
 * Support for coprocessor engines
 ******************************************************************************/

/**
 * coprocRoutine function
 */
static THREAD_ROUTINE_LPART coprocRoutine(THREAD_ROUTINE_ARGS);

/**
 * CoprocManager_getCoprocHandler function
 */
static INLINE DSPECoprocHandler* getCoprocHandler(const DSPEElement *context) {
	return (DSPECoprocHandler*) (CAST_TO_OWNER(context->application))->handlers[HANDLER_INDEX_COPROC];
}

/**
 * disposeAnEngine Function
 */
static INLINE void disposeAnEngine(DSPECoprocHandler *handler) {
	size_t index;
	DSPECoprocEngine *engine = NULL;
	DSPEOwner *owner = NULL;

	// Following operations (getEngine and wake up) have to be performed atomically.
	// Therefore, the spin is released only after locking the mutex.
	threadManager_lockSpin((DSPEElement*) handler, handler->enginesPoolLock);
	engine = getEngineForDispose(handler);
	threadManager_lockMutex((DSPEElement*) handler, handler->suspendConditionsLock);
	threadManager_unlockSpin((DSPEElement*) handler, handler->enginesPoolLock);
	// Each engine has a sleep condition for each thread, no need to use wakeAll
	threadManager_wakeCondition((DSPEElement*) handler, engine->engineSuspendCondition);
	threadManager_unlockMutex((DSPEElement*) handler, handler->suspendConditionsLock);
	handler->numInitializedEngines--;

	// REMARK: uses deferred cancellation of threads instead of asynchronous
	// cancellation. Engines needs therefore to get active a while in order to terminate
	// the thread.

	// It is safe to wait for a thread even if the thread already terminated:
	// "function suspends execution of the calling thread until the target thread terminates,
	// unless the target thread has already terminated".
	threadManager_waitThread((DSPEElement*) handler, engine->coprocThread);
	threadManager_destroyThread((DSPEElement*) handler, engine->coprocThread);
	threadManager_destroyCondition((DSPEElement*) handler, engine->engineSuspendCondition);

	owner = CAST_TO_OWNER(engine);
	index = threadManager_getOwnerIndex(owner);
	infoManager_disposeInfoSwap((DSPEElement*) handler, index);

	/* Dispose handlers */
	memoryManager_disposeHandlerPool((DSPEElement*) handler, owner);

	/* Free engine memory */
	memorySupport_dispose(engine);
}

/**
 * initAnEngine function
 */
static INLINE void initAnEngine(DSPECoprocHandler *handler) {
	size_t index;
	DSPEOwner *owner = NULL;
	DSPECoprocEngine *engine = (DSPECoprocEngine*) memoryManager_allocate((DSPEElement*) handler, sizeof(DSPECoprocEngine));
	initDSPECoprocEngine(engine, (DSPEHandler*) handler);
	owner = CAST_TO_OWNER(engine);

	engine->state = ENGINE_BOOTSTRAPPING;
	engine->next = NULL;

	/* Raise number of created engines */
	handler->numInitializedEngines++;

	/* Initialize ThreadHandler for engine */
	threadManager_initThreadHandler(owner);
	index = threadManager_getOwnerIndex(owner);
	infoManager_initInfoSwap((DSPEElement*) handler, index);

	engine->engineSuspendCondition = threadManager_createCondition((DSPEElement*) handler);

	engine->state = ENGINE_ACTIVE;

	// REMARK: always have to be the last call performed here
	engine->coprocThread = threadManager_createThread((DSPEElement*) handler, &coprocRoutine, engine);
}

/**
 * resumeAnEngine function
 * REMARK: context needed to grant locality of processing and avoid concurrent
 * access to global resources (error manager, info manager, ...)
 */
static INLINE void resumeAnEngine(const DSPEElement *context, DSPECoprocHandler *handler) {
	DSPECoprocEngine *engine = NULL;

	// Following operations (check sleepingEngines, getEngine and wake up) have to be
	// performed atomically in order to grant that the pool contains only sleeping engines.
	// Therefore, the spin is released only after locking the mutex.
	threadManager_lockSpin(context, handler->enginesPoolLock);
	if (handler->numSuspendedEngines == 0) {
		threadManager_unlockSpin(context, handler->enginesPoolLock);
		return;
	}

	// Do not wake-up threads if the handler is waiting for turn-off or if it is sleeping
	threadManager_lockSpin(context, handler->handlerStateLock);
	if (handler->state == HANDLER_WAIT_SUSPEND || handler->state == HANDLER_SLEEPING) {
		threadManager_unlockSpin(context, handler->handlerStateLock);
		threadManager_unlockSpin(context, handler->enginesPoolLock);
		return;
	}
	threadManager_unlockSpin(context, handler->handlerStateLock);

	// IMPORTANT: an engine that is contained in the pool has to be in the sleeping state.
	// If the opposite situation arise, then there is the risk to try to wake up a
	// non sleeping engine. For this reason no check is performed here before wake up.
	engine = getEngineFromPool(handler);

	// engine == 0 never happen. the check is done at the beginning of this method.
	// No further check is performed here.

	threadManager_lockMutex(context, handler->suspendConditionsLock);
	threadManager_unlockSpin(context, handler->enginesPoolLock);

	// Each engine has a sleep condition for its thread, no need to use wakeAll
	threadManager_wakeCondition(context, engine->engineSuspendCondition);

	threadManager_unlockMutex(context, handler->suspendConditionsLock);
}

/**
 * suspendCoprocEngine Function
 * REMARK: This function has to be called only while enginesPoolLock is locked!
 */
static INLINE void suspendCoprocEngine(DSPECoprocHandler *handler, DSPECoprocEngine *engine) {

	// IMPORTANT: in order to avoid deadlocks on the handlerSuspendCondition, need here to wake up
	// the master thread in every situation.

	// Only the master thread waits at the handlerSuspendCondition, no need to use wakeAll
	threadManager_wakeCondition((DSPEElement*) engine, handler->handlerSuspendCondition);

	//REMARK: uses while loop to avoid spurious wakeups
	while (engine->state == ENGINE_SUSPENDED)
		threadManager_waitCondition((DSPEElement*) engine, engine->engineSuspendCondition, handler->suspendConditionsLock);
}

/**
 * CoprocManager_activateCoprocEngines Function
 */
void coprocManager_activateCoprocEngines(DSPEElement *element) {
	DSPECoprocHandler *handler = getCoprocHandler(element);

	/* Need to wait here that all engines threads are created */
	/* REMARK: uses while loop to avoid spurious wake-ups or race conditions */
	threadManager_lockMutex(element, handler->preProcessEndConditionLock);
	while (handler->numEnginesReady < handler->numInitializedEngines)
		threadManager_waitCondition(element, handler->engineReadyCondition, handler->preProcessEndConditionLock);
	threadManager_unlockMutex(element, handler->preProcessEndConditionLock);

	/* Set handler state to active */
	threadManager_lockSpin(element, handler->handlerStateLock);
	handler->state = HANDLER_ACTIVE;
	threadManager_unlockSpin(element, handler->handlerStateLock);

	/* Wake all coproc engines */
	threadManager_lockMutex(element, handler->preProcessEndConditionLock);
	threadManager_wakeAllCondition(element, handler->preProcessEndCondition);
	threadManager_unlockMutex(element, handler->preProcessEndConditionLock);
}

/******************************************************************************
 * POOL OF INPUT QUEUES
 * Support for collecting input queues
 ******************************************************************************/

/**
 * resetQueuePool function
 */
static INLINE void resetQueuePool(DSPECoprocHandler *queueContainer) {
	// REMARK: Just reset the main queue (containing op queues) to empty here.
	// Coproc units are responsible to reset each single queue.
	// The remaining state of the handler (pool of engines, state, ...) has to keep
	// alive.
	queueContainer->opQueuesHead = NULL;
	queueContainer->opQueuesTail = NULL;
	queueContainer->numOpQueues = 0;
}

/**
 * disposeQueuePool function
 */
static INLINE void disposeQueuePool(DSPECoprocHandler *queueContainer) {
	threadManager_deleteSpin((DSPEElement*) queueContainer, queueContainer->opQueuesLock);
}

/**
 * initQueuePool function
 */
static INLINE void initQueuePool(const DSPEElement *context, DSPECoprocHandler *queueContainer) {
	queueContainer->opQueuesHead = NULL;
	queueContainer->opQueuesTail = NULL;
	queueContainer->numOpQueues = 0;
	queueContainer->opQueuesLock = threadManager_createSpin(context);
}

/**
 * addQueueToPool function
 * REMARK: context needed to grant locality of processing and avoid concurrent
 * access to global resources (error manager, info manager, ...)
 */
static INLINE void addQueueToPool(const DSPEElement *context, DSPEOpInQueue *queue) {
	// REMARK: handler is read only, it is set at initialization time.
	// No need to protect this operation with locks.
	DSPECoprocHandler *queueContainer = (DSPECoprocHandler*) ((DSPEElement*) queue)->container;
	DSPECoprocInQueue *curQueue = NULL;
	size_t queueNumElements;
	size_t curQueueNumElements;

	threadManager_lockSpin(context, queueContainer->opQueuesLock);
	if (queueContainer->numOpQueues == 0) {
		queueContainer->opQueuesHead = (DSPECoprocInQueue*) queue;
		queueContainer->opQueuesTail = (DSPECoprocInQueue*) queue;
		queueContainer->numOpQueues = 1;
		threadManager_unlockSpin(context, queueContainer->opQueuesLock);
	} else {
		/* get numElements of queue we want to schedule */
		threadManager_lockSpin(context, ((DSPECoprocInQueue*) queue)->lock);
		queueNumElements = ((DSPECoprocInQueue*) queue)->queueNumElements;
		threadManager_unlockSpin(context, ((DSPECoprocInQueue*) queue)->lock);

		/* set curQueue and curQueueNumElements */
		curQueue = queueContainer->opQueuesHead;
		threadManager_lockSpin(context, curQueue->lock);
		curQueueNumElements = curQueue->queueNumElements;
		threadManager_unlockSpin(context, curQueue->lock);

		if (queueNumElements > curQueueNumElements) {
			/* Prepend if greater */
			((DSPECoprocInQueue*) queue)->next = curQueue;
			queueContainer->opQueuesHead = (DSPECoprocInQueue*) queue;
		} else {
			/* Append otherwise */
			queueContainer->opQueuesTail->next = (DSPECoprocInQueue*) queue;
			queueContainer->opQueuesTail = (DSPECoprocInQueue*) queue;
		}
		queueContainer->numOpQueues++;
		threadManager_unlockSpin(context, queueContainer->opQueuesLock);
	}
	
	// Remark: Engines are resumed every time a queue is scheduled to
	// grant that the maximum number of engines are always at work (atomic management of
	// engines also grant that it is not possible to suspend an engine while a queue 
	// is being scheduled for processing).
	resumeAnEngine(context, queueContainer);
}

/**
 * getQueueFromPool function
 * REMARK: context needed to grant locality of processing and avoid concurrent
 * access to global resources (error manager, info manager, ...)
 */
static INLINE DSPECoprocInQueue* getQueueFromPool(const DSPEElement *context, DSPECoprocHandler *queueContainer) {
	DSPECoprocInQueue *opQueue = NULL;

	// REMARK - situations to consider when implementing the handler:
	// 1. this code is called frequently, the less operations (and locks) are
	//    required, the better it is.
	// 2. if it is required to process queues with more elements first, the order of 
	//    processing should be established while adding them to the main queue.
	//    This prevents excess of operations here.
	// 3. it may happens that queues are registered to the handler but ops are never queued.
	//    This may happen if e.g. the wrong kind of implementation has been chosen
	//	  (e.g. coproc instead of state), or if the impl has nothing to send to the
	//	  coproc for a while. Take this fact in consideration in order to avoid
	//	  unnecessary operations.
	// Current version has been implemented with a simple rotation of the queues (first-come-first-serve)
	// An implementation that favors queues containing the highest number of elements, requires operations like
	// tempQueue->queueNumElements > opQueue->queueNumElements with consequent double lock and infrastructure
	// to find the queue with the highest number of elements.
	
	// TODO - consider introducing an alternative version where it also checks the other queues
	// and not only the one in opQueuesHead. There might be other queues that satisfy the
	// coprocManager_isAboveMinThreshold condition that could then be returned.

	threadManager_lockSpin((DSPEElement*) queueContainer, queueContainer->opQueuesLock);
	if (queueContainer->numOpQueues == 0) {
		threadManager_unlockSpin((DSPEElement*) queueContainer, queueContainer->opQueuesLock);
		return NULL;
	} else if (queueContainer->numOpQueues == 1) {
		opQueue = queueContainer->opQueuesHead;
		queueContainer->opQueuesHead = NULL;
		queueContainer->opQueuesTail = NULL;
		queueContainer->numOpQueues = 0;
	} else {
		opQueue = queueContainer->opQueuesHead;
		queueContainer->opQueuesHead = opQueue->next;
		queueContainer->numOpQueues--;
	}
	opQueue->next = NULL;
	threadManager_unlockSpin((DSPEElement*) queueContainer, queueContainer->opQueuesLock);

	return opQueue;
}

/**
 * checkAndRequeue function
 * REMARK: context needed to grant locality of processing and avoid concurrent
 * access to global resources (error manager, info manager, ...)
 */
static INLINE void checkAndRequeue(const DSPEElement *context, DSPEOpInQueue *queue) {
	// the following code is executed only for exclusive queues.
	// reschedules the queue after processing if required.
	threadManager_lockSpin(context, ((DSPECoprocInQueue*) queue)->lock);
	((DSPECoprocInQueue*) queue)->excluded = 0;
	
	// handle situations of queues with a request for rescheduling
	if (((DSPECoprocInQueue*) queue)->reschedule) {
		((DSPECoprocInQueue*) queue)->reschedule = 0;
		threadManager_unlockSpin(context, ((DSPECoprocInQueue*) queue)->lock);
		// reschedules the queue if it is not empty
		addQueueToPool(context, queue);
	} else
		threadManager_unlockSpin(context, ((DSPECoprocInQueue*) queue)->lock);
}

/******************************************************************************
 * COPROC HANDLER
 * Support for management of coprocessors
 ******************************************************************************/

/**
 * CoprocManager_addCoprocHandler function
 */
static INLINE void addCoprocHandler(const DSPEApplication *application, DSPECoprocHandler *handler) {
	const DSPEOwner *ownerExt = CAST_TO_OWNER(application);
	DSPEHandler **handlers = ownerExt->handlers;

	/* lazy initialization of handlers array */
	if (handlers == NULL) {
		memoryManager_allocateHandlerPool((DSPEElement*) application, ownerExt);
		handlers = ownerExt->handlers;
	}

	/* Add CoprocHandler to handlers */
	handlers[HANDLER_INDEX_COPROC] = (DSPEHandler*) handler;
}

/**
 * resetCoprocHandler function
 */
static void resetCoprocHandler(DSPEHandler *handler) {

	resetQueuePool((DSPECoprocHandler*) handler);

	((DSPECoprocHandler*) handler)->numEnginesReady = ((DSPECoprocHandler*) handler)->numSuspendedEngines;
}

/**
 * disposeCoprocHandler function
 */
static void disposeCoprocHandler(DSPEHandler *handler) {
	threadManager_lockSpin((DSPEElement*) handler, ((DSPECoprocHandler*) handler)->handlerStateLock);
	// Set the handler status to terminating, coproc routines will then terminate.
	((DSPECoprocHandler*) handler)->state = HANDLER_TERMINATING;
	threadManager_unlockSpin((DSPEElement*) handler, ((DSPECoprocHandler*) handler)->handlerStateLock);
	disposeQueuePool((DSPECoprocHandler*) handler);

	while (((DSPECoprocHandler*) handler)->numInitializedEngines > 0)
		disposeAnEngine((DSPECoprocHandler*) handler);

	threadManager_destroyCondition((DSPEElement*) handler, ((DSPECoprocHandler*) handler)->handlerSuspendCondition);
	threadManager_deleteMutex((DSPEElement*) handler, ((DSPECoprocHandler*) handler)->suspendConditionsLock);
	threadManager_deleteSpin((DSPEElement*) handler, ((DSPECoprocHandler*) handler)->enginesPoolLock);
	threadManager_deleteSpin((DSPEElement*) handler, ((DSPECoprocHandler*) handler)->handlerStateLock);

	threadManager_destroyCondition((DSPEElement*) handler, ((DSPECoprocHandler*) handler)->preProcessEndCondition);
	threadManager_destroyCondition((DSPEElement*) handler, ((DSPECoprocHandler*) handler)->engineReadyCondition);
	threadManager_deleteMutex((DSPEElement*) handler, ((DSPECoprocHandler*) handler)->preProcessEndConditionLock);

	memorySupport_dispose(handler);
}

/**
 * CoprocManager_initCoprocHandler function
 */
void coprocManager_initCoprocHandler(const DSPEApplication *application) {
	/* CoprocHandler allocation and initialization */
	DSPECoprocHandler *handler = (DSPECoprocHandler*) memoryManager_allocate((DSPEElement*) application, sizeof(DSPECoprocHandler));
	initDSPEElement((DSPEElement*) handler, (DSPEElement*) application);
	initDSPEHandler((DSPEHandler*) handler, (DSPEElement*) application);
	((DSPEHandler*) handler)->reset = resetCoprocHandler;
	((DSPEHandler*) handler)->dispose = disposeCoprocHandler;

	/* Add CoprocHandler to handlers */
	addCoprocHandler(application, handler);

	handler->state = HANDLER_INITIALIZING;
	handler->handlerStateLock = threadManager_createSpin((DSPEElement*) application);
	initQueuePool((DSPEElement*) application, handler);

	handler->handlerSuspendCondition = threadManager_createCondition((DSPEElement*) application);
	handler->suspendConditionsLock = threadManager_createMutex((DSPEElement*) application);

	handler->numInitializedEngines = 0;
	handler->numSuspendedEngines = 0;
	handler->enginesPoolHead = NULL;
	handler->enginesPoolTail = NULL;
	handler->enginesPoolLock = threadManager_createSpin((DSPEElement*) application);

	handler->preProcessEndCondition = threadManager_createCondition((DSPEElement*) application);
	handler->engineReadyCondition = threadManager_createCondition((DSPEElement*) application);
	handler->preProcessEndConditionLock = threadManager_createMutex((DSPEElement*) application);
	handler->numEnginesReady = 0;

	// REMARK: this operation has to be performed here (before engine initialization),
	// because the state is accessed by threads during engine initialization.
	// doing this initialization later could involve concurrent accesses and the need for locks.
	handler->state = HANDLER_INITIALIZED;
}

/**
 * CoprocManager_activateCoprocHandler function
 */
void coprocManager_activateCoprocHandler(const DSPEApplication *application) {
	DSPECoprocHandler *handler = getCoprocHandler((DSPEElement*) application);
	register size_t i = 0;
	register size_t numEngines = 0;

	if (handler->state == HANDLER_SLEEPING) {
		handler->state = HANDLER_PREPROCESSING;
	} else if (handler->state == HANDLER_INITIALIZED) {
		handler->state = HANDLER_PREPROCESSING;

		// REMARK: numEngines is the total number of threads including master and GUI threads
		// therefore remove master and gui to have number of engines thread
		numEngines = threadManager_getNumThreads((DSPEElement*) application);
		numEngines -= MIN_NUM_THREADS;
		
		/* Lazy initialization. This will create the coproc threads */
		for (i = 0; i < numEngines; i++)
			initAnEngine(handler);
	}
}

/**
 * CoprocManager_suspendCoprocHandler function
 */
void coprocManager_suspendCoprocHandler(const DSPEApplication *application) {
	DSPECoprocHandler *handler = getCoprocHandler((DSPEElement*) application);

	threadManager_lockSpin((DSPEElement*) application, handler->handlerStateLock);
	handler->state = HANDLER_SLEEPING;
	threadManager_unlockSpin((DSPEElement*) application, handler->handlerStateLock);
}

/**
 * CoprocManager_suspendCoprocEngines function
 */
void coprocManager_suspendCoprocEngines(const DSPEApplication *application) {
	DSPECoprocHandler *handler = getCoprocHandler((DSPEElement*) application);

	threadManager_lockSpin((DSPEElement*) application, handler->handlerStateLock);
	handler->state = HANDLER_WAIT_SUSPEND;
	threadManager_unlockSpin((DSPEElement*) application, handler->handlerStateLock);

	// Following operations (wait that all engines are suspended) have to be performed
	// atomically. Therefore, the spin is released only after locking the mutex.

	// Need to wait here that all engines are suspended
	//REMARK: uses while loop to avoid spurious wake-ups or race conditions
	threadManager_lockSpin((DSPEElement*) application, handler->enginesPoolLock);
	while (handler->numSuspendedEngines < handler->numInitializedEngines) {
		threadManager_lockMutex((DSPEElement*) application, handler->suspendConditionsLock);
		threadManager_unlockSpin((DSPEElement*) application, handler->enginesPoolLock);
		threadManager_waitCondition((DSPEElement*) application, handler->handlerSuspendCondition, handler->suspendConditionsLock);
		threadManager_unlockMutex((DSPEElement*) application, handler->suspendConditionsLock);
		threadManager_lockSpin((DSPEElement*) application, handler->enginesPoolLock);
	}
	threadManager_unlockSpin((DSPEElement*) application, handler->enginesPoolLock);
}

/******************************************************************************
 * INPUT QUEUE
 * Support for input queue - each input queue is installed on a CoprocUnitBehaviors
 ******************************************************************************/

/**
 * resetCoprocInQueue function
 */
static void resetCoprocInQueue(DSPEOpInQueue *queue) {

	threadManager_lockSpin((DSPEElement*) queue, ((DSPECoprocInQueue*) queue)->lock);
	((DSPECoprocInQueue*) queue)->next = NULL;
	// REMARK: Just reset the queue to 0 here, client code
	// (e.g. OPs pool) is responsible to dispose OPs.
	((DSPECoprocInQueue*) queue)->queueNumElements = 0;
	((DSPECoprocInQueue*) queue)->queueHead = NULL;
	((DSPECoprocInQueue*) queue)->queueTail = NULL;
	((DSPECoprocInQueue*) queue)->excluded = 0;
	((DSPECoprocInQueue*) queue)->reschedule = 0;
	threadManager_unlockSpin((DSPEElement*) queue, ((DSPECoprocInQueue*) queue)->lock);
}

/**
 * disposeCoprocInQueue function
 */
static void disposeCoprocInQueue(DSPEOpInQueue *queue) {

	threadManager_deleteSpin((DSPEElement*) queue, ((DSPECoprocInQueue*) queue)->lock);
	memorySupport_dispose((DSPECoprocInQueue*) queue);
}

/**
 * CoprocManager_initCoprocInQueue function
 * Last parameter must be NULL
 */
DSPEOpInQueue* coprocManager_initCoprocInQueue(const DSPEElement *context, ...) {
	va_list ap;
	char* overrideString = NULL;
	DSPECoprocHandler *handler = NULL;
	DSPECoprocInQueue *inputQueue = (DSPECoprocInQueue*) memoryManager_allocate(context, sizeof(DSPECoprocInQueue));

	/* Queue Container is Handler! Therefore get Handler and init inputQueue with handler! */
	handler = getCoprocHandler(context);
	initDSPEElement((DSPEElement*) inputQueue, (DSPEElement*) handler);
	
	inputQueue->next = NULL;
	inputQueue->lock = threadManager_createSpin(context);
	inputQueue->queueNumElements = 0;
	inputQueue->queueHead = NULL;
	inputQueue->queueTail = NULL;
	inputQueue->excluded = 0;
	inputQueue->reschedule = 0;

	// REMARK defaults:
	// shared if unit doesn't have permanent states
	// exclusive if unit has permanent states
	// by setting opQueueType this behavior can be overridden
	inputQueue->exclusive = NON_EXCLUSIVE_QUEUE;
	/* Overriding default values */
	va_start(ap, context);
	/* get first override string */
	overrideString = va_arg(ap, char*);
	while (overrideString != NULL) {
		if (stringSupport_compare("OVERRIDE_EXCLUSIVE", overrideString) == 0) {
			/* Exclusive queue override */
			inputQueue->exclusive = va_arg(ap, unsigned int);
		} else {
			/* no such overrideString found, skip value */
			va_arg(ap, void*);
		}
		/* Get next overrideString */
		overrideString = va_arg(ap, char*);
	}
	va_end(ap);

	
	((DSPEOpInQueue*) inputQueue)->dispose = disposeCoprocInQueue;
	((DSPEOpInQueue*) inputQueue)->reset = resetCoprocInQueue;
	return (DSPEOpInQueue*) inputQueue;
}

/**
 * CoprocManager_addOpToInQueue function
 */
void coprocManager_addOpToInQueue(DSPEOpInQueue *queue, DSPEOp *op) {
	DSPECoprocOp *coprocOp = (DSPECoprocOp*) op;
	const DSPEElement *source = NULL;
	coprocOp->next = NULL;

	threadManager_lockSpin((DSPEElement*) queue, ((DSPECoprocInQueue*) queue)->lock);

	if (((DSPECoprocInQueue*) queue)->queueNumElements == 0) {
		((DSPECoprocInQueue*) queue)->queueHead = coprocOp;
		((DSPECoprocInQueue*) queue)->queueTail = coprocOp;
		((DSPECoprocInQueue*) queue)->queueNumElements = 1;

		if (((DSPECoprocInQueue*) queue)->excluded) {
			// If the queue is empty, need to schedule it, but if the queue is currently excluded,
			// therefore an exclusive one, its last op is currently processed and need to postpone rescheduling
			// after processing. A reschedule request is therefore set in the op and handled after processing.
			((DSPECoprocInQueue*) queue)->reschedule = 1;
			threadManager_unlockSpin((DSPEElement*) queue, ((DSPECoprocInQueue*) queue)->lock);
			return;
		}
		threadManager_unlockSpin((DSPEElement*) queue, ((DSPECoprocInQueue*) queue)->lock);
		source = ((DSPEElement*) op)->container;
		
		// The queue is scheduled here only if it is empty. If instead it contains some element,
		// it will be rescheduled directly during processing.
		addQueueToPool(source, queue);
		return;
	} else {
		((DSPECoprocInQueue*) queue)->queueTail->next = coprocOp;
		((DSPECoprocInQueue*) queue)->queueTail = coprocOp;
		((DSPECoprocInQueue*) queue)->queueNumElements++;
		if (((DSPECoprocInQueue*) queue)->queueNumElements > COPROC_QUEUEMAX_THRESHOLD) {
			threadManager_unlockSpin((DSPEElement*) queue, ((DSPECoprocInQueue*) queue)->lock);
			return;
		}
		threadManager_unlockSpin((DSPEElement*) queue, ((DSPECoprocInQueue*) queue)->lock);
	}
}

/**
 * getOpFromInQueue function
 */
static DSPECoprocOp* getOpFromInQueue(const DSPEElement *context, DSPECoprocInQueue *queue) {
	DSPECoprocOp *currentOp = NULL;

	// REMARK: exclusive flag is read only, it is set at initialization time.
	// No need to protect this operation with locks.
	unsigned int exclusive = queue->exclusive;
	if (exclusive) {
		// If it is an exclusive queue (has persistent state), need to exclude
		// it from processing in order to avoid having 2 or more engines work on
		// the same queue at the same time.
		// This may e.g. happen if the last op in a queue is still in the processing
		// phase and a new op reschedules the queue for processing.
		// OPs may have a persistent state and hence such kind of sharing of queues
		// is not granted to be immune from concurrent accesses.
		threadManager_lockSpin(context, queue->lock);
		queue->excluded = 1;
	} else
		threadManager_lockSpin(context, queue->lock);
	
	// REMARK: queues are scheduled only if they contain ops. There's therefore
	// no need to handle the situation with queueNumElements == 0;
	if (queue->queueNumElements == 1) {
		currentOp = queue->queueHead;
		queue->queueHead = NULL;
		queue->queueTail = NULL;
		queue->queueNumElements = 0;
		currentOp->next = NULL;
		threadManager_unlockSpin(context, queue->lock);
	} else {
		currentOp = queue->queueHead;
		queue->queueHead = currentOp->next;
		queue->queueNumElements--;
		currentOp->next = NULL;

		if (exclusive) {
			// If it is an exclusive queue, need to wait to reschedule it after processing.
			// Alternatively the queue can be safely rescheduled to favor concurrent processing.
			queue->reschedule = 1;
			threadManager_unlockSpin(context, queue->lock);
		} else {
			threadManager_unlockSpin(context, queue->lock);
			addQueueToPool(context, (DSPEOpInQueue*) queue);
		}
	}

	return currentOp;
}

/**
 * CoprocManager_getInQueueSize function
 */
size_t coprocManager_getInQueueSize(const DSPEOpInQueue *queue) {
	size_t size = 0;
	threadManager_lockSpin((DSPEElement*) queue, ((DSPECoprocInQueue*) queue)->lock);
	size = ((DSPECoprocInQueue*) queue)->queueNumElements;
	threadManager_unlockSpin((DSPEElement*) queue, ((DSPECoprocInQueue*) queue)->lock);
	return size;
}

/**
 * CoprocManager_isAboveMinThreshold function
 */
int coprocManager_isAboveMinThreshold(const DSPEOpInQueue *queue) {
	int result = 0;
	threadManager_lockSpin((DSPEElement*) queue, ((DSPECoprocInQueue*) queue)->lock);
	if (((DSPECoprocInQueue*) queue)->queueNumElements > COPROC_QUEUEMIN_THRESHOLD)
		result = 1;
	threadManager_unlockSpin((DSPEElement*) queue, ((DSPECoprocInQueue*) queue)->lock);
	return result;
}

/**
 * CoprocManager_isAboveMaxThreshold function
 */
int coprocManager_isAboveMaxThreshold(const DSPEOpInQueue *queue) {
	int result = 0;
	threadManager_lockSpin((DSPEElement*) queue, ((DSPECoprocInQueue*) queue)->lock);
	if (((DSPECoprocInQueue*) queue)->queueNumElements > COPROC_QUEUEMAX_THRESHOLD)
		result = 1;
	threadManager_unlockSpin((DSPEElement*) queue, ((DSPECoprocInQueue*) queue)->lock);
	return result;
}

/******************************************************************************
 * OUTPUT QUEUE
 * Support for output queue - output queues are installed on CoprocSchedulers
 ******************************************************************************/

/**
 * resetCoprocOutQueue function
 * Reset the given output queue
 */
static void resetCoprocOutQueue(DSPEOpOutQueue *queue) {
	threadManager_lockSpin((DSPEElement*) queue, ((DSPECoprocOutQueue*) queue)->lock);
	// REMARK: Just reset the queue to 0 here, client code
	// (e.g. OPs pool) is responsible to dispose OPs.
	((DSPECoprocOutQueue*) queue)->queueHead = NULL;
	((DSPECoprocOutQueue*) queue)->queueTail = NULL;
	((DSPECoprocOutQueue*) queue)->queueNumElements = 0;
	threadManager_unlockSpin((DSPEElement*) queue, ((DSPECoprocOutQueue*) queue)->lock);
}

/**
 * disposeCoprocOutQueue
 * Disposes the given output queue
 */
static void disposeCoprocOutQueue(DSPEOpOutQueue *queue) {
	threadManager_deleteSpin((DSPEElement*) queue, ((DSPECoprocOutQueue*) queue)->lock);
	memorySupport_dispose(queue);
}

/**
 * CoprocManager_initCoprocOutQueue function
 */
DSPEOpOutQueue* coprocManager_initCoprocOutQueue(const DSPECoprocScheduler *scheduler) {
	DSPECoprocOutQueue *outputQueue = (DSPECoprocOutQueue*) memoryManager_allocate((DSPEElement*) scheduler, sizeof(DSPECoprocOutQueue));
	initDSPEElement((DSPEElement*) outputQueue, (DSPEElement*) scheduler);

	outputQueue->queueNumElements = 0;
	outputQueue->queueHead = NULL;
	outputQueue->queueTail = NULL;

	outputQueue->lock = threadManager_createSpin((DSPEElement*) scheduler);

	((DSPEOpOutQueue*) outputQueue)->dispose = disposeCoprocOutQueue;
	((DSPEOpOutQueue*) outputQueue)->reset = resetCoprocOutQueue;
	return (DSPEOpOutQueue*) outputQueue;
}

/**
 * addOpToOutQueue function
 * REMARK: context needed to grant locality of processing and avoid concurrent access
 */
static INLINE void addOpToOutQueue(const DSPEElement *context, DSPECoprocOutQueue *queue, DSPECoprocOp *op) {
	threadManager_lockSpin(context, queue->lock);
	if (queue->queueNumElements == 0) {
		queue->queueHead = op;
		queue->queueTail = op;
		queue->queueNumElements = 1;
	} else {
		queue->queueTail->next = op;
		queue->queueTail = op;
		queue->queueNumElements++;
	}
	threadManager_unlockSpin(context, queue->lock);
}

/**
 * CoprocManager_getOpFromOutQueue function
 */
DSPEOp* coprocManager_getOpFromOutQueue(DSPEOpOutQueue *queue) {
	// TODO ridurre di nuovo il synch ad un'unica variabile -> num Ops!?
	// La soluzione precedente sembra concettualmente possibile solo se il thread in lettura ? uno solo.
	// In questo caso il thread in lettura dovrebbe effettivamente sempre essere solo uno.
	// Sono le due fasi della processOP() che invece hanno accesso concorrente.

	DSPECoprocOp *currentOp = NULL;
	threadManager_lockSpin((DSPEElement*) queue, ((DSPECoprocOutQueue*) queue)->lock);
	
	if (((DSPECoprocOutQueue*) queue)->queueNumElements == 0) {
		threadManager_unlockSpin((DSPEElement*) queue, ((DSPECoprocOutQueue*) queue)->lock);
		return NULL;
	} else if (((DSPECoprocOutQueue*) queue)->queueNumElements == 1) {
		currentOp = ((DSPECoprocOutQueue*) queue)->queueHead;
		((DSPECoprocOutQueue*) queue)->queueHead = NULL;
		((DSPECoprocOutQueue*) queue)->queueTail = NULL;
		((DSPECoprocOutQueue*) queue)->queueNumElements = 0;
	} else {
		currentOp = ((DSPECoprocOutQueue*) queue)->queueHead;
		((DSPECoprocOutQueue*) queue)->queueHead = currentOp->next;
		((DSPECoprocOutQueue*) queue)->queueNumElements--;
	}
	currentOp->next = NULL;
	
	threadManager_unlockSpin((DSPEElement*) queue, ((DSPECoprocOutQueue*) queue)->lock);
	
	return (DSPEOp*) currentOp;
}

/**
 * CoprocManager_getOutQueueSize function
 */
size_t coprocManager_getOutQueueSize(const DSPEOpOutQueue *queue) {
	size_t size = 0;
	threadManager_lockSpin((DSPEElement*) queue, ((DSPECoprocOutQueue*) queue)->lock);
	size = ((DSPECoprocOutQueue*) queue)->queueNumElements;
	threadManager_unlockSpin((DSPEElement*) queue, ((DSPECoprocOutQueue*) queue)->lock);
	return size;
}

/******************************************************************************
 * PROCESS
 * Support for processing ops
 ******************************************************************************/

/**
 * processOp function
 * REMARK: context needed to grant locality of processing and avoid concurrent
 * access to global resources (error manager, info manager, ...)
 */
static INLINE void processOp(const DSPEElement *context, DSPECoprocInQueue *queue) {
	DSPECoprocOp *currentOp = NULL;
	DSPECoprocScheduler *scheduler = NULL;
	DSPECoprocOutQueue *outQueue = NULL;
	const DSPEElement *source = NULL;

	/* Get op from op's input queue */
	currentOp = getOpFromInQueue(context, queue);
	// Switches the owner of the op to the current context of execution to grant
	// locality of processing and avoid concurrent access to global resources (error manager, info manager, ...)
	((DSPEElement*) currentOp)->owner = context->owner;

	// Processes the op
	((DSPEOp*) currentOp)->execute((DSPEOp*) currentOp);

	// Reschedules the queue as soon as possible!
	// REMARK: exclusive flag is read only, it is set at initialization time.
	// No need to protect this operation with locks.
	if (queue->exclusive)
		checkAndRequeue(context, (DSPEOpInQueue*) queue);

	source = ((DSPEElement*) currentOp)->container;

	// Switches the owner of the op back to the original one
	((DSPEElement*) currentOp)->owner = source->owner;

	// Put the processed op in the results queue
	// REMARK: outQueue is set in the scheduler at initialization time. It is therefore
	// read only. There's no need to protect this code with a lock.
	scheduler = (DSPECoprocScheduler*) source->container;
	outQueue = (DSPECoprocOutQueue*) scheduler->getOutQueue(scheduler);

	// Add processed op to outQueue
	addOpToOutQueue(context, outQueue, currentOp);
}

/**
 * CoprocManager_coprocContribution function
 */
void coprocManager_coprocContribution(const DSPEElement *context) {
	DSPECoprocHandler *handler = getCoprocHandler((DSPEElement*) context);
	DSPECoprocInQueue *opQueue = getQueueFromPool(context, handler);
	if (opQueue == NULL) {
		return;
	}
	processOp(context, opQueue);
}

/**
 * waitPreProcessEnd function
 */
static INLINE void waitPreProcessEnd(const DSPECoprocEngine *engine) {
	DSPECoprocHandler *handler = (DSPECoprocHandler*) ((DSPEElement*) engine)->container;

	threadManager_lockMutex((DSPEElement*) engine, handler->preProcessEndConditionLock);
	handler->numEnginesReady++;

	/* IMPORTANT: in order to avoid deadlocks on the engineReadyCondition, need here to wake up */
	/* the master thread in every situation. */

	/* Only the master thread waits at the engineReadyCondition, no need to use wakeAll */
	threadManager_wakeCondition((DSPEElement*) engine, handler->engineReadyCondition);
	threadManager_unlockMutex((DSPEElement*) engine, handler->preProcessEndConditionLock);

	/* Wait preProcess end */
	threadManager_lockMutex((DSPEElement*) engine, handler->preProcessEndConditionLock);
	threadManager_lockSpin((DSPEElement*) engine, handler->handlerStateLock);

	//REMARK wait until preprocessing is finished!
	/* While loop to avoid spurious wake-ups! */
	while (handler->state == HANDLER_PREPROCESSING) {
		threadManager_unlockSpin((DSPEElement*) engine, handler->handlerStateLock);
		threadManager_waitCondition((DSPEElement*) engine, handler->preProcessEndCondition, handler->preProcessEndConditionLock);
		threadManager_lockSpin((DSPEElement*) engine, handler->handlerStateLock);
	}
	threadManager_unlockSpin((DSPEElement*) engine, handler->handlerStateLock);
	threadManager_unlockMutex((DSPEElement*) engine, handler->preProcessEndConditionLock);
}

/**
 * coprocRoutine function
 */
static THREAD_ROUTINE_LPART coprocRoutine(THREAD_ROUTINE_ARGS) {
	DSPECoprocInQueue *opQueue = NULL;
	DSPECoprocEngine *engine = (DSPECoprocEngine*) args;
	DSPECoprocHandler *handler = (DSPECoprocHandler*) ((DSPEElement*) engine)->container;
	DSPECoprocHandler *queueContainer = handler;

	waitPreProcessEnd(engine);

	for (;;) {

		threadManager_lockSpin((DSPEElement*) engine, queueContainer->opQueuesLock);
		// REMARK: the condition is important to avoid both scheduled queues and waiting
		// engines present at the same time.
		if (queueContainer->numOpQueues == 0) {
			// IMPORTANT: engines have to be present in the pool only if they are in the suspended state.
			// If the opposite situation could arise due to race conditions, then there is the risk to
			// try to resume a non suspended engine. For this reason all of the following operations
			// (add engine to pool and suspend it) have to be performed in an atomic way (the
			// spin is released only after locking the mutex).

			// Furthermore, addEngineToPool has to be done atomically in the same
			// lock with the wakeup handlerSuspendCondition call (performed within suspendCoprocEngine()).
			// This avoids the following deadlock:
			// 1) in the suspendCoproc procedure, check the condition and get preempted before starting to wait
			// 2) meanwhile, here, add the engine to pool and wakeup ... but in suspendCoproc it is still not waiting
			// 3) then in suspendCoproc starts waiting ... nobody will then wake it up
			threadManager_lockSpin((DSPEElement*) engine, handler->enginesPoolLock);
			addEngineToPool(handler, engine);

			threadManager_lockMutex((DSPEElement*) engine, handler->suspendConditionsLock);
			threadManager_unlockSpin((DSPEElement*) engine, queueContainer->opQueuesLock);
			threadManager_unlockSpin((DSPEElement*) engine, handler->enginesPoolLock);
			
			suspendCoprocEngine(handler, engine);
			
			threadManager_unlockMutex((DSPEElement*) engine, handler->suspendConditionsLock);
		} else {
			threadManager_unlockSpin((DSPEElement*) engine, queueContainer->opQueuesLock);

			opQueue = getQueueFromPool((DSPEElement*) engine, handler);

			// Processes ops
			if (opQueue != NULL) {
				processOp((DSPEElement*) engine, opQueue);
			}
		}
		// For a coproc engine, the handler state is read only. This state is modified
		// only by the master thread on preProcess, postProcess or shutdown. Lock/unlock
		// is performed only to avoid concurrent access. For those reasons, checks on
		// handler state don't need to be performed atomically with addEngineToPool and
		// suspendCoprocEngine.  
		threadManager_lockSpin((DSPEElement*) engine, handler->handlerStateLock);
		// Terminates the thread if required
		if (handler->state == HANDLER_ACTIVE) {
			threadManager_unlockSpin((DSPEElement*) engine, handler->handlerStateLock);
		} else {
			if (handler->state == HANDLER_WAIT_SUSPEND) {
				threadManager_unlockSpin((DSPEElement*) engine, handler->handlerStateLock);

				// See comment above.
				threadManager_lockSpin((DSPEElement*) engine, handler->enginesPoolLock);

				addEngineToPool(handler, engine);

				threadManager_lockMutex((DSPEElement*) engine, handler->suspendConditionsLock);
				threadManager_unlockSpin((DSPEElement*) engine, handler->enginesPoolLock);

				suspendCoprocEngine(handler, engine);

				threadManager_unlockMutex((DSPEElement*) engine, handler->suspendConditionsLock);
				threadManager_lockSpin((DSPEElement*) engine, handler->handlerStateLock);
			}

			if (handler->state == HANDLER_TERMINATING) {
				threadManager_unlockSpin((DSPEElement*) engine, handler->handlerStateLock);
				break;
			} else if (handler->state == HANDLER_PREPROCESSING) {
				threadManager_unlockSpin((DSPEElement*) engine, handler->handlerStateLock);
				/* Engine resumed after a stop since the application has been restarted. */
				/* Need to wait the end of application preProcess */
				waitPreProcessEnd(engine);
			} else
				threadManager_unlockSpin((DSPEElement*) engine, handler->handlerStateLock);
		}
	}
	THREAD_ROUTINE_RETURN;
}

