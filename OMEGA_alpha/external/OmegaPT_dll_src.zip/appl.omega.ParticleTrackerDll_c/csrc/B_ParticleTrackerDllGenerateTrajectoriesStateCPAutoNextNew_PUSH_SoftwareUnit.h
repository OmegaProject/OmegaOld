/**
 * File: B_ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef B_ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_h
#define B_ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_h

#include "DSPEElements.h"

#include "B_ParticleTrackerDllNextGate_SignalGate.h"
#include "B_ParticleTrackerDllIntGate_StandardGate.h"
#include "B_ParticleTrackerDllBoolGate_StandardGate.h"
#include "B_ParticleTrackerDllRealGate_CustomGate.h"
#include "B_ParticleTrackerDllStatusGate_StringGate.h"

/* Queue node type definition */
typedef struct ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueNode ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueNode;

/* Queue node type definition */
struct ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueNode {
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueNode *next;
	unsigned int ID;
	DSPEEvent *event;
	/* Transit node support */
	short inTransit;
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueNode *nextInTransit;
};

/* State type definition */
typedef struct ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit;

/* State definition */ 
struct ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit {

	DSPEQueueUnit queueUnit;

	unsigned int poolNumNodes;
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueNode *poolHead;
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueNode *poolTail;

	unsigned int queueNumNodes;
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueNode *queueHead;
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueNode *queueTail;

	/* Parameter gates */
	ParticleTrackerDllIntGate_StandardGate *paramIn_stop;
	ParticleTrackerDllBoolGate_StandardGate *paramIn_Verbose;
	ParticleTrackerDllIntGate_StandardGate *paramIn_Radius;
	ParticleTrackerDllRealGate_CustomGate *paramIn_Cutoff;
	ParticleTrackerDllRealGate_CustomGate *paramIn_Percentile;
	ParticleTrackerDllRealGate_CustomGate *paramIn_Displacement;
	ParticleTrackerDllIntGate_StandardGate *paramIn_Linkrange;
	ParticleTrackerDllIntGate_StandardGate *paramOut_stop;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status;
	ParticleTrackerDllStatusGate_StringGate *paramOut_FileStatus;
	ParticleTrackerDllIntGate_StandardGate *paramOut_FoundTrajectories;


	/* Output parameters places */
	ParticleTrackerDllIntGate_StandardGate *paramOut_stop_place;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status_place;
	ParticleTrackerDllStatusGate_StringGate *paramOut_FileStatus_place;
	ParticleTrackerDllIntGate_StandardGate *paramOut_FoundTrajectories_place;


	/* Output parameters places anchors */
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status_placeAnchor;
	ParticleTrackerDllStatusGate_StringGate *paramOut_FileStatus_placeAnchor;

	/* Gates numLinks */
	unsigned int dataIn_SequenceValues_numLinks;
	unsigned int dataIn_PTFrame_numLinks;
	unsigned int dataOut_Trajectory_numLinks;
	unsigned int paramIn_next_numLinks;
	unsigned int paramIn_stop_numLinks;
	unsigned int paramIn_Verbose_numLinks;
	unsigned int paramIn_Radius_numLinks;
	unsigned int paramIn_Cutoff_numLinks;
	unsigned int paramIn_Percentile_numLinks;
	unsigned int paramIn_Displacement_numLinks;
	unsigned int paramIn_Linkrange_numLinks;
	unsigned int paramOut_next_numLinks;
	unsigned int paramOut_stop_numLinks;
	unsigned int paramOut_Status_numLinks;
	unsigned int paramOut_FileStatus_numLinks;
	unsigned int paramOut_LastFrameProcessed_numLinks;
	unsigned int paramOut_FoundTrajectories_numLinks;

	/* unit ID */
	char *ID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID);

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_releaseEvent(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit *context);

int ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_isEventAvailable(const DSPEQueueUnit *unit);

DSPEEvent* ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_getEvent(const DSPEQueueUnit *unit);

unsigned int ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_getEventID(const DSPEQueueUnit *unit);

/* getID function */
char* ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_getID(const DSPEElement *element);

/* Alloc function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_alloc(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit *context);

/* Earlyconnect function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_earlyConnect(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit *context);

/* Postprocess function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_postProcess(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit *context);

/* Reset function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_reset(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit *context);

/* Shutdown function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_shutdown(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
