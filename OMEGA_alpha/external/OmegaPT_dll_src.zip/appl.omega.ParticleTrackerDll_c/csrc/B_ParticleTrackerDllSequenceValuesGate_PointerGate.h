/**
 * File: B_ParticleTrackerDllSequenceValuesGate_PointerGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef B_ParticleTrackerDllSequenceValuesGate_PointerGate_h
#define B_ParticleTrackerDllSequenceValuesGate_PointerGate_h

#include "DSPEXTElements.h"

#include "B_ParticleTrackerDllTracker_Requirement.h"

#define PARTICLETRACKERDLLSEQUENCEVALUESGATE_POINTERGATE_TYPECATEGORY "Pointer"
#define PARTICLETRACKERDLLSEQUENCEVALUESGATE_POINTERGATE_DEFAULTVALUE 0

typedef PTSequenceValues* ParticleTrackerDllSequenceValuesGate_PointerGate;

#ifdef __cplusplus
extern "C" {
#endif

/* Allocate function */
ParticleTrackerDllSequenceValuesGate_PointerGate* ParticleTrackerDllSequenceValuesGate_PointerGate_allocate(DSPEElement *context);

/* Initialise function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_initialize(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate *place);

/* SetOverride function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_setOverride(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate *place, ParticleTrackerDllSequenceValuesGate_PointerGate value);

/* Set function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_set(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate *place, ParticleTrackerDllSequenceValuesGate_PointerGate *value);

/* Dispose function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_dispose(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate *place);

/* AllocateGroup function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_allocateGroup(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t size);

/* InitialiseGroup function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_initializeGroup(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t size);

/* SetOverrideGroup function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_setOverrideGroup(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t size, ParticleTrackerDllSequenceValuesGate_PointerGate value);

/* SetGroup function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_setGroup(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t size, ParticleTrackerDllSequenceValuesGate_PointerGate **value);

/* DisposeGroup function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_disposeGroup(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t size);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
