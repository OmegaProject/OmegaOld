/**
 * File: RProd_ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef RProd_ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_h
#define RProd_ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_h

#include "B_ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation.h"
#include "B_ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit.h"
#include "B_ParticleTrackerDllMaskGate_PointerGate.h"
#include "B_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "B_ParticleTrackerDllPTFrameGate_MessageGate.h"

/* Real SoftwareUnit state type definition */
typedef struct ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realProd ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realProd;

/* Real SoftwareUnit state definition */
struct ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realProd {

	/* Base unit state */
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation implState;
	
	/* Data transit queues */
	size_t dataIn_PTFrame_transitNumElements;
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_queueNode *dataIn_PTFrame_transitHead;
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_queueNode *dataIn_PTFrame_transitTail;
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_queueNode *dataIn_PTFrame_curTransit;
	unsigned int dataIn_PTFrame_curTransitIndex;

	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;
	DSPEEvent *dataOut_PTFrame_place;
	DSPEEvent *dataOut_PTFrame_armMarker;

	/* Data pending events support */
	size_t dataOut_PTFrame_pendingEvents;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;

	/* EventPools */
	ParticleTrackerDllPTFrameGate_MessageGate_pool *dataOut_PTFrame_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame_unlinked;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame_unlinked;


	/* Data gates */
	ParticleTrackerDllMaskGate_PointerGate *dataIn_Mask;
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;

	/* Unit profile ID */
	int unitProfileID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_transitEventRealProd(DSPEQueueUnit *unit);

size_t ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getTransitNumElementsRealProd(DSPEQueueUnit *unit, unsigned int ID);

size_t ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getCurrentNumElementsRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getFirstTransitRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getCurTransitRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_dismissEventRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_dismissAllEventsRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_armEventRealProd(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_postEventRealProd(DSPEEventsUnit *unit, unsigned int ID);

/**
 * initOp function
 */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_initOpRealProd(DSPECoprocUnit *unit, DSPEOp *op);

/* Earlyalloc function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_earlyAllocRealProd(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realProd *context);

/* Alloc function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_allocRealProd(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realProd *context);

/* Earlyconnect function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_earlyConnectRealProd(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realProd *context);

/* Connect function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_connectRealProd(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realProd *context);

/* Startup function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_startupRealProd(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realProd *context);

/* Preprocess function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_preProcessRealProd(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_processRealProd(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_postProcessRealProd(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_resetRealProd(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realProd *context);

/* Shutdown function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_shutdownRealProd(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realProd *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
