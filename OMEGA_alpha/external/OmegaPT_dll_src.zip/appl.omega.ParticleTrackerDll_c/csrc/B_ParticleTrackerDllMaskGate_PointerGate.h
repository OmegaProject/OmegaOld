/**
 * File: B_ParticleTrackerDllMaskGate_PointerGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef B_ParticleTrackerDllMaskGate_PointerGate_h
#define B_ParticleTrackerDllMaskGate_PointerGate_h

#include "DSPEXTElements.h"

#define PARTICLETRACKERDLLMASKGATE_POINTERGATE_TYPECATEGORY "Pointer"
#define PARTICLETRACKERDLLMASKGATE_POINTERGATE_DEFAULTVALUE 0

typedef int* ParticleTrackerDllMaskGate_PointerGate;

#ifdef __cplusplus
extern "C" {
#endif

/* Allocate function */
ParticleTrackerDllMaskGate_PointerGate* ParticleTrackerDllMaskGate_PointerGate_allocate(DSPEElement *context);

/* Initialise function */
void ParticleTrackerDllMaskGate_PointerGate_initialize(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate *place);

/* SetOverride function */
void ParticleTrackerDllMaskGate_PointerGate_setOverride(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate *place, ParticleTrackerDllMaskGate_PointerGate value);

/* Set function */
void ParticleTrackerDllMaskGate_PointerGate_set(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate *place, ParticleTrackerDllMaskGate_PointerGate *value);

/* Dispose function */
void ParticleTrackerDllMaskGate_PointerGate_dispose(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate *place);

/* AllocateGroup function */
void ParticleTrackerDllMaskGate_PointerGate_allocateGroup(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t size);

/* InitialiseGroup function */
void ParticleTrackerDllMaskGate_PointerGate_initializeGroup(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t size);

/* SetOverrideGroup function */
void ParticleTrackerDllMaskGate_PointerGate_setOverrideGroup(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t size, ParticleTrackerDllMaskGate_PointerGate value);

/* SetGroup function */
void ParticleTrackerDllMaskGate_PointerGate_setGroup(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t size, ParticleTrackerDllMaskGate_PointerGate **value);

/* DisposeGroup function */
void ParticleTrackerDllMaskGate_PointerGate_disposeGroup(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t size);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
