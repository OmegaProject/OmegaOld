/**
 * File: B_ParticleTrackerDllMaskGate_PointerGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#include "MemoryManager.h"

#include "B_ParticleTrackerDllMaskGate_PointerGate.h"

/* Allocate function */
ParticleTrackerDllMaskGate_PointerGate* ParticleTrackerDllMaskGate_PointerGate_allocate(DSPEElement *context) {
	return memoryManager_allocate(context, sizeof(ParticleTrackerDllMaskGate_PointerGate));
}

/* Initialise function */
void ParticleTrackerDllMaskGate_PointerGate_initialize(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate *place) {
	*place = PARTICLETRACKERDLLMASKGATE_POINTERGATE_DEFAULTVALUE;
}

/* SetOverride function */
void ParticleTrackerDllMaskGate_PointerGate_setOverride(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate *place, ParticleTrackerDllMaskGate_PointerGate value) {
	*place = value;
}

/* Set function */
void ParticleTrackerDllMaskGate_PointerGate_set(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate *place, ParticleTrackerDllMaskGate_PointerGate *value) {
	*place = *value;
}

/* Dispose function */
void ParticleTrackerDllMaskGate_PointerGate_dispose(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate *place) {
	memorySupport_dispose(place);
}

/* AllocateGroup function */
void ParticleTrackerDllMaskGate_PointerGate_allocateGroup(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	place[i] = ParticleTrackerDllMaskGate_PointerGate_allocate(context);
	}
}

/* InitialiseGroup function */
void ParticleTrackerDllMaskGate_PointerGate_initializeGroup(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
	 	ParticleTrackerDllMaskGate_PointerGate_initialize(context, place[i]);
	}
}

/* SetOverrideGroup function */
void ParticleTrackerDllMaskGate_PointerGate_setOverrideGroup(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t size, ParticleTrackerDllMaskGate_PointerGate value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllMaskGate_PointerGate_setOverride(context, place[i], value);
	}
}

/* SetGroup function */
void ParticleTrackerDllMaskGate_PointerGate_setGroup(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t size, ParticleTrackerDllMaskGate_PointerGate **value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllMaskGate_PointerGate_set(context, place[i], value[i]);
	}
}

/* DisposeGroup function */
void ParticleTrackerDllMaskGate_PointerGate_disposeGroup(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	memorySupport_dispose(place[i]);
	}
}

