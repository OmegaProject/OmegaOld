/**
 * File: B_ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef B_ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_h
#define B_ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_h

#include "DSPEXTElements.h"

#include "B_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "B_ParticleTrackerDllPTFrameGate_MessageGate.h"
#include "B_ParticleTrackerDllTrajectory_MessageGate.h"
#include "B_ParticleTrackerDllNextGate_SignalGate.h"
#include "B_ParticleTrackerDllIntGate_StandardGate.h"
#include "B_ParticleTrackerDllBoolGate_StandardGate.h"
#include "B_ParticleTrackerDllRealGate_CustomGate.h"
#include "B_ParticleTrackerDllStatusGate_StringGate.h"

#include "B_ParticleTrackerDllTracker_Requirement.h"
#include "B_ParticleTrackerDllDebug_Requirement.h"
#include "B_ParticleTrackerDllStringList_Requirement.h"
#include "B_ParticleTrackerDllTrajectories_Requirement.h"

/* Functional implementation state type definition */
typedef struct ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_func ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_func;

/* This struct may contain user defined additional state variables for the unit */
struct ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_func {

	DSPEStateImplementation stateImplementation;

	//Place additional state variables after this line -- SYD-ADDITIONAL-STATE-START
	StringList* sl;
	StringList* slTrajectories;
	TrajectoriesList* tl;
	int counter;
	//SYD-ADDITIONAL-STATE-END  -- Place additional state variables before this line

};

/******************************************************************************
 * FOLLOWING CODE IS NOT INTENDED TO BE MODIFIED BY USERS                     *
 ******************************************************************************/

/* State type definition */
typedef struct ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation;

/* State definition */ 
struct ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation {

	/* Functional implementation state */
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_func functionalState;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame;
	ParticleTrackerDllTrajectory_MessageGate *dataOut_Trajectory;

	/* Parameter gates */
	ParticleTrackerDllIntGate_StandardGate *paramIn_stop;
	ParticleTrackerDllBoolGate_StandardGate *paramIn_Verbose;
	ParticleTrackerDllIntGate_StandardGate *paramIn_Radius;
	ParticleTrackerDllRealGate_CustomGate *paramIn_Cutoff;
	ParticleTrackerDllRealGate_CustomGate *paramIn_Percentile;
	ParticleTrackerDllRealGate_CustomGate *paramIn_Displacement;
	ParticleTrackerDllIntGate_StandardGate *paramIn_Linkrange;
	ParticleTrackerDllIntGate_StandardGate *paramOut_stop;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status;
	ParticleTrackerDllStatusGate_StringGate *paramOut_FileStatus;
	ParticleTrackerDllIntGate_StandardGate *paramOut_FoundTrajectories;


	/* numLinks flags */
	unsigned int dataIn_SequenceValues_numLinks;
	unsigned int dataIn_PTFrame_numLinks;
	unsigned int dataOut_Trajectory_numLinks;
	unsigned int paramIn_next_numLinks;
	unsigned int paramIn_stop_numLinks;
	unsigned int paramIn_Verbose_numLinks;
	unsigned int paramIn_Radius_numLinks;
	unsigned int paramIn_Cutoff_numLinks;
	unsigned int paramIn_Percentile_numLinks;
	unsigned int paramIn_Displacement_numLinks;
	unsigned int paramIn_Linkrange_numLinks;
	unsigned int paramOut_next_numLinks;
	unsigned int paramOut_stop_numLinks;
	unsigned int paramOut_Status_numLinks;
	unsigned int paramOut_FileStatus_numLinks;
	unsigned int paramOut_LastFrameProcessed_numLinks;
	unsigned int paramOut_FoundTrajectories_numLinks;

	/* State */
	unsigned int state;

	/* Automatic execute support */
	unsigned int isReadyToExecute;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

/* Startup function */
void ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_startup(ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *context);

/* Preprocess function */
void ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_preProcess(ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *context);

/* Process function */
void ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_process(ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *context);

/* Postprocess function */
void ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_postProcess(ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *context);

/* Shutdown function */
void ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_shutdown(ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
