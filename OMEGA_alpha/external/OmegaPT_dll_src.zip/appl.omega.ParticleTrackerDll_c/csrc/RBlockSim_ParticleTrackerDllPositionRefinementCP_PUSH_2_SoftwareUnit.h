/**
 * File: RBlockSim_ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef RBlockSim_ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_h
#define RBlockSim_ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_h

#include "B_ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation.h"
#include "B_ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit.h"
#include "RBlock_ParticleTrackerDllMaskGate_PointerGate.h"
#include "RBlock_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "RBlock_ParticleTrackerDllPTFrameGate_MessageGate.h"

/* Block SoftwareUnit state type definition */
typedef struct ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockSim ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockSim;

/* Block SoftwareUnit state definition */
struct ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockSim {

	/* Base unit state */
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation implState;
	
	/* Block size */
	size_t blockSize;

	/* Samples to process */
	size_t samplesToProcess;

	/* Data transit queues */
	size_t dataIn_PTFrame_transitNumElements;
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_queueNode *dataIn_PTFrame_transitHead;
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_queueNode *dataIn_PTFrame_transitTail;
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_queueNode *dataIn_PTFrame_curTransit;
	unsigned int dataIn_PTFrame_curTransitIndex;

	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;
	DSPEEvent *dataOut_PTFrame_place;
	DSPEEvent *dataOut_PTFrame_armMarker;

	/* Data pending events support */
	size_t dataOut_PTFrame_pendingEvents;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;

	/* EventPools */
	ParticleTrackerDllPTFrameGate_MessageGate_poolBlock *dataOut_PTFrame_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame_unlinked;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame_unlinked;


	/* Data gates */
	ParticleTrackerDllMaskGate_PointerGate *dataIn_Mask;
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;


	/* Data gates sizes */
	size_t dataIn_Mask_size;
	size_t dataIn_SequenceValues_size;
	size_t dataOut_PTFrame_size;


	/* Data gates factors */
	size_t dataIn_Mask_factor;
	size_t dataIn_SequenceValues_factor;
	size_t dataOut_PTFrame_factor;


	/* Data gates counters */
	size_t dataIn_Mask_counter;
	size_t dataIn_SequenceValues_counter;
	size_t dataOut_PTFrame_counter;


	/* Data gates counters */
	size_t dataOut_PTFrame_samplesCounter;

	/* Unit profile ID */
	int unitProfileID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_transitEventBlockSim(DSPEQueueUnit *unit);

size_t ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getTransitNumElementsBlockSim(DSPEQueueUnit *unit, unsigned int ID);

size_t ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getTransitNumElementsBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getFirstTransitBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getCurTransitBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_dismissEventBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_dismissAllEventsBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_armEventBlockSim(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_postEventBlockSim(DSPEEventsUnit *unit, unsigned int ID);

/**
 * initOp function
 */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_initOpBlockSim(DSPECoprocUnit *unit, DSPEOp *op);

/* Earlyalloc function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_earlyAllocBlockSim(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockSim *context);

/* Alloc function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_allocBlockSim(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockSim *context);

/* Earlyconnect function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_earlyConnectBlockSim(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockSim *context);

/* Connect function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_connectBlockSim(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockSim *context);

/* Startup function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_startupBlockSim(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockSim *context);

/* Preprocess function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_preProcessBlockSim(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_processBlockSim(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_postProcessBlockSim(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_resetBlockSim(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockSim *context);

/* Shutdown function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_shutdownBlockSim(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockSim *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
