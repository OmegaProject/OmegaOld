/**
 * File: B_ParticleTrackerDllTrajectory_MessageGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef B_ParticleTrackerDllTrajectory_MessageGate_h
#define B_ParticleTrackerDllTrajectory_MessageGate_h

#include "DSPEXTElements.h"
#include "MemoryGround.h"

#include "B_ParticleTrackerDllTrajectories_Requirement.h"


#define PARTICLETRACKERDLLTRAJECTORY_MESSAGEGATE_TYPECATEGORY "Message"
#define PARTICLETRACKERDLLTRAJECTORY_MESSAGEGATE_DEFAULTVALUE 0

typedef Trajectory* ParticleTrackerDllTrajectory_MessageGate;


/* EventGate state type definition */
typedef struct ParticleTrackerDllTrajectory_MessageGate_event ParticleTrackerDllTrajectory_MessageGate_event;

/* EventGate state definition */
struct ParticleTrackerDllTrajectory_MessageGate_event {
	DSPEEvent event;
	
	ParticleTrackerDllTrajectory_MessageGate *value;
};

/* Event clone state type definition */
typedef struct ParticleTrackerDllTrajectory_MessageGate_cloneEvent ParticleTrackerDllTrajectory_MessageGate_cloneEvent;

/* Event clone state definition */
struct ParticleTrackerDllTrajectory_MessageGate_cloneEvent {
	ParticleTrackerDllTrajectory_MessageGate_event event;

	DSPEEvent *original;
};

/* EventGate pool type definition */
typedef struct ParticleTrackerDllTrajectory_MessageGate_pool ParticleTrackerDllTrajectory_MessageGate_pool;

/* EventGate pool definition */
struct ParticleTrackerDllTrajectory_MessageGate_pool {
	DSPEBaseEventsPool pool;

	// Pool for events
	size_t eventNumElements;
	ParticleTrackerDllTrajectory_MessageGate_event *headEvent;
	ParticleTrackerDllTrajectory_MessageGate_event *tailEvent;

	// Pool for clones
	size_t cloneNumElements;
	ParticleTrackerDllTrajectory_MessageGate_cloneEvent *headClone;
	ParticleTrackerDllTrajectory_MessageGate_cloneEvent *tailClone;
};


/* GroupEventGate state type definition */
typedef struct ParticleTrackerDllTrajectory_MessageGate_groupEvent ParticleTrackerDllTrajectory_MessageGate_groupEvent;

/* GroupEventGate state definition */
struct ParticleTrackerDllTrajectory_MessageGate_groupEvent {
	DSPEGroupEvent event;
	
	ParticleTrackerDllTrajectory_MessageGate **value;
};

/* GroupEvent clone state type definition */
typedef struct ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent;

/* GroupEvent clone state definition */
struct ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent {
	ParticleTrackerDllTrajectory_MessageGate_groupEvent event;

	DSPEGroupEvent *original;
};

/* GroupEvent container state type definition */
typedef struct ParticleTrackerDllTrajectory_MessageGate_eventContainer ParticleTrackerDllTrajectory_MessageGate_eventContainer;

/* GroupEvent container state definition */
struct ParticleTrackerDllTrajectory_MessageGate_eventContainer {
	ParticleTrackerDllTrajectory_MessageGate_groupEvent event;

	DSPEEvent **containedEvents;
};

/* GroupEventGate pool type definition */
typedef struct ParticleTrackerDllTrajectory_MessageGate_groupPool ParticleTrackerDllTrajectory_MessageGate_groupPool;

/* GroupEventGate pool definition */
struct ParticleTrackerDllTrajectory_MessageGate_groupPool {
	DSPEGroupEventsPool pool;

	/* Pool for Events */
	size_t eventNumElements;
	ParticleTrackerDllTrajectory_MessageGate_groupEvent *headEvent;
	ParticleTrackerDllTrajectory_MessageGate_groupEvent *tailEvent;
	
	/* Pool for Clones */
	size_t cloneNumElements;
	ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent *headClone;
	ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent *tailClone;
	
	/* Pool for EventContainers */
	size_t containerNumElements;
	ParticleTrackerDllTrajectory_MessageGate_eventContainer *headContainer;
	ParticleTrackerDllTrajectory_MessageGate_eventContainer *tailContainer;
};

/* EventGate node type definition */
typedef struct ParticleTrackerDllTrajectory_MessageGate_node ParticleTrackerDllTrajectory_MessageGate_node; 

/* EventGate node definition */ 
struct ParticleTrackerDllTrajectory_MessageGate_node {
	DSPEGateNode node;

	ParticleTrackerDllTrajectory_MessageGate *localVar;
	ParticleTrackerDllTrajectory_MessageGate value;
	int sendEvent;
	unsigned int eventID;
	DSPEApplication *application;
	DSPEEventsPool *pool;
};

#ifdef __cplusplus
extern "C" {
#endif

/* eventPool initialization function */
ParticleTrackerDllTrajectory_MessageGate_pool* ParticleTrackerDllTrajectory_MessageGate_initPool(const DSPEOwner *owner);

/* eventPool preAlloc function */
void ParticleTrackerDllTrajectory_MessageGate_preAllocPool(DSPEEventsPool *pool, size_t size);

/* eventPool reset function */
void ParticleTrackerDllTrajectory_MessageGate_resetPool(DSPEEventsPool *pool);

/* Allocate function */
ParticleTrackerDllTrajectory_MessageGate_event* ParticleTrackerDllTrajectory_MessageGate_allocate(ParticleTrackerDllTrajectory_MessageGate_pool *pool);

/* Initialise function */
void ParticleTrackerDllTrajectory_MessageGate_initialize(ParticleTrackerDllTrajectory_MessageGate_event *event);

/**
 * Copy function
 */
void ParticleTrackerDllTrajectory_MessageGate_copy(ParticleTrackerDllTrajectory_MessageGate_event *event, ParticleTrackerDllTrajectory_MessageGate value);

/* Clone event function */
DSPEEvent* ParticleTrackerDllTrajectory_MessageGate_clone(DSPEEvent *event);

/* Dispose function */
void ParticleTrackerDllTrajectory_MessageGate_dispose(DSPEEvent *event);

/* Dispose clone function */
void ParticleTrackerDllTrajectory_MessageGate_disposeClone(DSPEEvent *event);

/* eventPool dispose function */
void ParticleTrackerDllTrajectory_MessageGate_disposePool(DSPEEventsPool *pool);

/* Allocate function */
ParticleTrackerDllTrajectory_MessageGate* ParticleTrackerDllTrajectory_MessageGate_allocateUnlinked(DSPEElement *context);

/* Initialise function */
void ParticleTrackerDllTrajectory_MessageGate_initializeUnlinked(DSPEElement *context, ParticleTrackerDllTrajectory_MessageGate *place);

/* Dispose function */
void ParticleTrackerDllTrajectory_MessageGate_disposeUnlinked(DSPEElement *context, ParticleTrackerDllTrajectory_MessageGate *place);

/* groupEventPool initialization function */
ParticleTrackerDllTrajectory_MessageGate_groupPool* ParticleTrackerDllTrajectory_MessageGate_initGroupPool(const DSPEOwner *owner, size_t groupSize);

/* eventPool preAlloc function */
void ParticleTrackerDllTrajectory_MessageGate_preAllocGroupPool(DSPEEventsPool *pool, size_t size);

/* eventPool reset function */
void ParticleTrackerDllTrajectory_MessageGate_resetGroupPool(DSPEEventsPool *pool);

/* AllocateGroup function */
ParticleTrackerDllTrajectory_MessageGate_groupEvent* ParticleTrackerDllTrajectory_MessageGate_allocateGroup(ParticleTrackerDllTrajectory_MessageGate_groupPool *grpPool);

/* CreateGroup function */
void ParticleTrackerDllTrajectory_MessageGate_createGroup(ParticleTrackerDllTrajectory_MessageGate_groupEvent *event, size_t index);

/* InitialiseGroup function */
void ParticleTrackerDllTrajectory_MessageGate_initializeGroup(ParticleTrackerDllTrajectory_MessageGate_groupEvent *event, size_t index);

/**
 * Copy function
 */
void ParticleTrackerDllTrajectory_MessageGate_copyGroup(ParticleTrackerDllTrajectory_MessageGate_groupEvent *event, ParticleTrackerDllTrajectory_MessageGate value, size_t index);

/* CloneGroup event function */
DSPEEvent* ParticleTrackerDllTrajectory_MessageGate_cloneGroup(DSPEEvent *event);

/* SubClone event function */
DSPEEvent* ParticleTrackerDllTrajectory_MessageGate_subClone(DSPEGroupEvent *event, DSPEEventsPool *pool, size_t index);

/**
 * Allocate containerEvent function
 */
ParticleTrackerDllTrajectory_MessageGate_eventContainer* ParticleTrackerDllTrajectory_MessageGate_allocateContainer(ParticleTrackerDllTrajectory_MessageGate_groupPool *grpPool);

/**
 * Dispose containerEvent function
 */
void ParticleTrackerDllTrajectory_MessageGate_disposeContainer(DSPEEvent *event);

/* DisposeGroup function */
void ParticleTrackerDllTrajectory_MessageGate_disposeGroup(DSPEEvent *event);

/* Dispose GroupClone function */
void ParticleTrackerDllTrajectory_MessageGate_disposeGroupClone(DSPEEvent *event);

/* eventPool dispose function */
void ParticleTrackerDllTrajectory_MessageGate_disposeGroupPool(DSPEEventsPool *pool);

/* CreateNode function */
ParticleTrackerDllTrajectory_MessageGate_node* ParticleTrackerDllTrajectory_MessageGate_createNode(ParticleTrackerDllTrajectory_MessageGate *localVar, DSPEApplication *application, DSPEEventsPool *pool, unsigned int eventID);

/* DisposeNode function */
void ParticleTrackerDllTrajectory_MessageGate_disposeNode(DSPEElement *context, DSPEGateNode *node);

/* SetValue function */
void ParticleTrackerDllTrajectory_MessageGate_setValue(DSPEElement *context, DSPEGateNode *node);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
