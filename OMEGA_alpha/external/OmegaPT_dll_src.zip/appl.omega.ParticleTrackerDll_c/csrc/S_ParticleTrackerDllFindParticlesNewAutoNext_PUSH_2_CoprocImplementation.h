/**
 * File: S_ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef S_ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_h
#define S_ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_h

#include "PlatformManager.h"
#include "MemoryManager.h"
#include "CoprocManager.h"
#include "ProfileManager.h"

#include "B_ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation.h"

/* CoprocEvent ID */
#define pIn_Coproc_event 100

/* Input EventGate IDs */
#define pIn_next_event 1000
#define dIn_PTFrame_event 1001
#define dIn_PTThreshold_event 1002

#define pOut_next_event 1000
#define dOut_PTFrame_event 1001

#ifdef __cplusplus
extern "C" {
#endif

static INLINE int isEventAvailable(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	return unit->isEventAvailable(unit);
}

static INLINE unsigned int getEventID(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	return unit->getEventID(unit);
}

/* Move inputEvent to specific transitQueue */
static INLINE void transitEvent(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	unit->transitEvent(unit);
}

static INLINE void getDE_PTFrame(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	// TODO utilizzare l'ID della gate, rispettivamente l'index per le GroupGates per verificare che il valore rischiesto sia quello dell'evento in coda
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	DSPEEvent *event = unit->getEvent(unit);
	if (event == NULL)
		return; /* notify error here */
	context->dataIn_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value;
}

static INLINE void getDE_PTThreshold(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	// TODO utilizzare l'ID della gate, rispettivamente l'index per le GroupGates per verificare che il valore rischiesto sia quello dell'evento in coda
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	DSPEEvent *event = unit->getEvent(unit);
	if (event == NULL)
		return; /* notify error here */
	context->dataIn_PTThreshold = ((ParticleTrackerDllPTThresholdGate_MessageGate_event*) event)->value;
}

static INLINE size_t getTransitNumElementsDE_PTFrame(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	// TODO utilizzare l'ID della gate, rispettivamente l'index per le GroupGates per verificare che il valore richiesto sia quello dell'evento in coda
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	return unit->getTransitNumElements(unit, dIn_PTFrame_event);
}

static INLINE size_t getTransitNumElementsDE_PTThreshold(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	// TODO utilizzare l'ID della gate, rispettivamente l'index per le GroupGates per verificare che il valore richiesto sia quello dell'evento in coda
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	return unit->getTransitNumElements(unit, dIn_PTThreshold_event);
}

static INLINE void getFirstTransitDE_PTFrame(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	// TODO utilizzare l'ID della gate, rispettivamente l'index per le GroupGates per verificare che il valore richiesto sia quello dell'evento in coda
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	unit->getFirstTransitEvent(unit, dIn_PTFrame_event );
}

static INLINE void getFirstTransitDE_PTThreshold(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	// TODO utilizzare l'ID della gate, rispettivamente l'index per le GroupGates per verificare che il valore richiesto sia quello dell'evento in coda
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	unit->getFirstTransitEvent(unit, dIn_PTThreshold_event );
}

static INLINE size_t getCurrentNumElementsDE_PTFrame(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	// TODO utilizzare l'ID della gate, rispettivamente l'index per le GroupGates per verificare che il valore richiesto sia quello dell'evento in coda
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	return unit->getCurrentNumElements(unit, dIn_PTFrame_event);
}

static INLINE size_t getCurrentNumElementsDE_PTThreshold(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	// TODO utilizzare l'ID della gate, rispettivamente l'index per le GroupGates per verificare che il valore richiesto sia quello dell'evento in coda
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	return unit->getCurrentNumElements(unit, dIn_PTThreshold_event);
}

static INLINE void getCurTransitDE_PTFrame(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	unit->getCurrentTransitEvent(unit, dIn_PTFrame_event);
}

static INLINE void getCurTransitDE_PTThreshold(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	unit->getCurrentTransitEvent(unit, dIn_PTThreshold_event);
}

static INLINE void dismissDE_PTFrame(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	//TODO valutare possibilita' di un unico dismiss
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	unit->dismissEvent(unit, dIn_PTFrame_event);
}

static INLINE void dismissDE_PTThreshold(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	//TODO valutare possibilita' di un unico dismiss
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	unit->dismissEvent(unit, dIn_PTThreshold_event);
}

/* SignalGate send advanced */
static INLINE void sendPE_next(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	DSPEEventsUnit *unit = (DSPEEventsUnit*) ((DSPEElement*) context)->container;
	if (unit->sendEvent == NULL)
		return;
	unit->armEvent(unit, pOut_next_event);
	unit->postEvent(unit, pOut_next_event);
}
static INLINE void armDE_PTFrame(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	DSPEEventsUnit *unit = (DSPEEventsUnit*) ((DSPEElement*) context)->container;
	if (unit->armEvent == 0)
		return;
	unit->armEvent(unit, dOut_PTFrame_event);
}

/* Forward send request to unit */
static INLINE void sendDE_PTFrame(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	DSPEEventsUnit *unit = (DSPEEventsUnit*) ((DSPEElement*) context)->container;
	if (unit->sendEvent == NULL)
		return;
	unit->postEvent(unit, dOut_PTFrame_event);
}

// COPROCESSOR SUPPORT

static INLINE int isCoprocFull(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	return coprocManager_isAboveMaxThreshold(context->opQueue);
}

static INLINE void queueOp(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context, DSPEOp *op) {
	coprocManager_addOpToInQueue(context->opQueue, op);
	context->opsBusy++;
}

static INLINE DSPEOp* getProcessedOp(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	// TODO utilizzare l'ID della gate, rispettivamente l'index per le GroupGates per verificare che il valore rischiesto sia quello dell'evento in coda
	DSPEOp* op = NULL;
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	DSPECoprocEvent *event = (DSPECoprocEvent*) unit->getEvent(unit);
	op = event->op;
	context->curOp = (ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op*) op;
	return op;
}

/**
 * doProcessing function.
 */
static void ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_doProcessing(DSPEOp *op) {
	ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op *context = (ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op*) op;
	register size_t i;

	/* Data gate anchors */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues_anchor = context->dataIn_SequenceValues;
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame_anchor = context->dataIn_PTFrame;
	ParticleTrackerDllPTThresholdGate_MessageGate *dataIn_PTThreshold_anchor = context->dataIn_PTThreshold;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame_anchor = context->dataOut_PTFrame;

	/* Capture unit process start time */
	profileManager_captureStartTime((DSPEElement*) op, (profileID) ((DSPEProfileCoprocOp*) op)->unitProfileID);

	/* call process according samplesToProcess */
	for (i = 0; i < context->blockSize; i++) {
		/* Call process function */
		ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_process(context);

		/* Increment data pointers to process each sample */
		context->dataIn_SequenceValues++;
		context->dataIn_PTFrame++;
		context->dataIn_PTThreshold++;
		context->dataOut_PTFrame++;
	}
	/* Capture unit process end time */
	profileManager_captureEndTime((DSPEElement*) op, (profileID) ((DSPEProfileCoprocOp*) op)->unitProfileID);


	/* Data gate anchors restore */
	context->dataIn_SequenceValues = dataIn_SequenceValues_anchor;
	context->dataIn_PTFrame = dataIn_PTFrame_anchor;
	context->dataIn_PTThreshold = dataIn_PTThreshold_anchor;
	context->dataOut_PTFrame = dataOut_PTFrame_anchor;
}

/* Coprocessor initialization */
static INLINE void initOp(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *implState, ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op *context) {
	/* Coproc additional state variables initialization */
	context->particles = 0;
	context->prevParticlesSize = 0;

}

/* Create op */
static INLINE ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op* createOp(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	DSPECoprocUnit *unit = (DSPECoprocUnit*) ((DSPEElement*) context)->container;
	ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op *newOp = NULL;

	newOp = (ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op*) memoryManager_allocate((DSPEElement*) context, sizeof(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op));
	initDSPECoprocOp((DSPEElement*) context, (DSPECoprocOp*) newOp);
	unit->initOp(unit, (DSPEOp*) newOp);
	/* Initialize additional state if present */
	initOp(context, newOp);
	/* Container of op has to be the Unit */
	initDSPEElement((DSPEElement*) newOp, (DSPEElement*) unit);
	/* Install execute function pointer */
	((DSPEOp*) newOp)->execute = ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_doProcessing;
	/* Allocate non event parameter gates */
	newOp->paramIn_stop = (ParticleTrackerDllIntGate_StandardGate*) memoryManager_allocate((DSPEElement*) context, sizeof(ParticleTrackerDllIntGate_StandardGate));
	newOp->paramIn_Linkrange = (ParticleTrackerDllIntGate_StandardGate*) memoryManager_allocate((DSPEElement*) context, sizeof(ParticleTrackerDllIntGate_StandardGate));
	newOp->paramOut_Status = (ParticleTrackerDllStatusGate_StringGate*) memoryManager_allocate((DSPEElement*) context, sizeof(ParticleTrackerDllStatusGate_StringGate));

	/* Allocate non event data gates */
	newOp->dataIn_SequenceValues = (ParticleTrackerDllSequenceValuesGate_PointerGate*) memoryManager_allocate((DSPEElement*) context, newOp->blockSize * sizeof(ParticleTrackerDllSequenceValuesGate_PointerGate));

	/* Initialize profile variables */
	((DSPEProfileCoprocOp*) newOp)->profileQueue = profileManager_initProfileQueue((DSPEElement*) context);
	((DSPEProfileCoprocOp*) newOp)->unitProfileID = (int) profileSupport_getUnitProfileID(((DSPEElement*) context)->getID((DSPEElement*) context));

	return newOp;
}

/* Destroy op */
static INLINE void destroyOp(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op *op) {
	DSPEProfileCoprocOp *coprocOp = NULL;

	/* Dispose allocated non event gates */
	memorySupport_dispose(op->dataIn_SequenceValues);
	memorySupport_dispose(op->paramIn_stop);
	memorySupport_dispose(op->paramIn_Linkrange);
	memorySupport_dispose(op->paramOut_Status);

	/* Dispose profile queue */
	coprocOp = (DSPEProfileCoprocOp*) op;
	profileManager_disposeProfileQueue((DSPEElement*) op, coprocOp->profileQueue);
	coprocOp->profileQueue = NULL;
	disposeDSPECoprocOp((DSPECoprocOp*) op);
	memorySupport_dispose(op);
}

// OPBUFFER SUPPORT
/* Return an empty op */
static INLINE ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op* getEmptyOp(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op *currentOp = NULL;
	DSPECoprocUnit *unit = (DSPECoprocUnit*) ((DSPEElement*) context)->container;

	if (context->opPoolNumElements == 0) {
		currentOp = createOp(context);
		currentOp->processed = 0;
	} else if (context->opPoolNumElements == 1) {
		currentOp = context->opPoolHead;
		context->opPoolHead = NULL;
		context->opPoolTail = NULL;
		context->opPoolNumElements = 0;
	} else {
		currentOp = context->opPoolHead;
		context->opPoolHead = currentOp->next;
		context->opPoolNumElements--;
	}

	currentOp->next = NULL;
	// REMARK: Initialize op's blockSize. Called here to be able to init the op's
	// blockSize when the variable blockSize is enabled (within CoprocScheduler).
	// Cannot call conditionally since no info is available.
	unit->initOp(unit, (DSPEOp*) currentOp);

	if (context->opBufferNumElements == 0) {
		context->opBufferHead = currentOp;
		context->opBufferTail = currentOp;
		context->opBufferNumElements = 1;
	} else {
		context->opBufferTail->next = currentOp;
		context->opBufferTail = currentOp;
		context->opBufferNumElements++;
	}
	return currentOp;
}

/* Return the first buffered op if it can be released, 0 otherwise */
static INLINE ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op* getBufferedOp(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	if (context->opBufferNumElements == 0)
		return NULL;
	else if (context->opBufferHead->processed == 1)
		return context->opBufferHead;
	else
		return NULL;
}

/* Return the next op or NULL if the buffer is empty */
static INLINE ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op* getNextOp(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context) {
	if (context->opBufferNumElements == 0)
		return NULL;
	else
		return context->opBufferHead;
}

/* Release op */
static INLINE void releaseOp(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context, ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op *coprocOp) {
	if (context->opBufferHead != coprocOp)
		return;
	context->opsBusy--;
	if (context->opBufferNumElements == 1) {
		context->opBufferHead = NULL;
		context->opBufferTail = NULL;
		context->opBufferNumElements = 0;
	} else {
		context->opBufferHead = coprocOp->next;
		context->opBufferNumElements--;
	}
	coprocOp->next = NULL;
	coprocOp->processed = 0;

	if (context->opPoolNumElements == 0) {
		context->opPoolHead = coprocOp;
		context->opPoolTail = coprocOp;
		context->opPoolNumElements = 1;
	} else {
		context->opPoolTail->next = coprocOp;
		context->opPoolTail = coprocOp;
		context->opPoolNumElements++;
	}
}

/* TransferAllGatesOnOp function */
static INLINE void transferAllGatesOnOp(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *implState) {
	/* Set context to currentOp */
	ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op *context = implState->curOp;
	/* Load input data gates */
	context->dataIn_PTFrame = implState->dataIn_PTFrame;
	context->dataIn_PTThreshold = implState->dataIn_PTThreshold;
	/* Load output data gates */
	context->dataOut_PTFrame = implState->dataOut_PTFrame;
	/* Load output non event parameter gates */
	memorySupport_copyBlock(context->paramIn_stop, implState->paramIn_stop, sizeof(ParticleTrackerDllIntGate_StandardGate));
	memorySupport_copyBlock(context->paramIn_Linkrange, implState->paramIn_Linkrange, sizeof(ParticleTrackerDllIntGate_StandardGate));
	memorySupport_copyBlock(context->paramOut_Status, implState->paramOut_Status, sizeof(ParticleTrackerDllStatusGate_StringGate));
	/* Load output non event data gates */
	memorySupport_copyBlock(context->dataIn_SequenceValues, implState->dataIn_SequenceValues, context->blockSize * sizeof(ParticleTrackerDllSequenceValuesGate_PointerGate));
}

#ifdef __cplusplus
} /* extern "C" */
#endif

#undef pIn_Coproc_event

#undef pIn_next_event
#undef dIn_PTFrame_event
#undef dIn_PTThreshold_event
#undef pOut_next_event
#undef dOut_PTFrame_event

#endif
