/**
 * File: F_ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation.c
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#include "InfoManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "EngineManager.h"
#include "B_ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation.h"
#include "S_ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation.h"

#include "B_ParticleTrackerDllStringList_Requirement.h"

/**
 * Convenience defines to access unit state variables.
 */
#define currState context->state
/* Input ParameterGates Shortcuts */
#define pIn_stop (*context->paramIn_stop)
#define pIn_Verbose (*context->paramIn_Verbose)
#define pIn_Radius (*context->paramIn_Radius)
#define pIn_Cutoff (*context->paramIn_Cutoff)
#define pIn_Percentile (*context->paramIn_Percentile)
#define pIn_Displacement (*context->paramIn_Displacement)
#define pIn_Linkrange (*context->paramIn_Linkrange)

/* Output ParameterGates Shortcuts */
#define pOut_stop (*context->paramOut_stop)
#define pOut_Status (*context->paramOut_Status)
#define pOut_Status_set(str) stringSupport_copy(*context->paramOut_Status, str)
#define pOut_FileStatus (*context->paramOut_FileStatus)
#define pOut_FileStatus_set(str) stringSupport_copy(*context->paramOut_FileStatus, str)
#define pOut_FoundTrajectories (*context->paramOut_FoundTrajectories)

/* Input DataGates Shortcuts */
#define dIn_SequenceValues (*context->dataIn_SequenceValues)
#define dIn_PTFrame (*context->dataIn_PTFrame)

/* Output DataGates Shortcuts */
#define dOut_Trajectory (*context->dataOut_Trajectory)

/* numLinks shortcuts */
#define dIn_SequenceValues_numLinks context->dataIn_SequenceValues_numLinks
#define dIn_PTFrame_numLinks context->dataIn_PTFrame_numLinks
#define dOut_Trajectory_numLinks context->dataOut_Trajectory_numLinks
#define pIn_next_numLinks context->paramIn_next_numLinks
#define pIn_stop_numLinks context->paramIn_stop_numLinks
#define pIn_Verbose_numLinks context->paramIn_Verbose_numLinks
#define pIn_Radius_numLinks context->paramIn_Radius_numLinks
#define pIn_Cutoff_numLinks context->paramIn_Cutoff_numLinks
#define pIn_Percentile_numLinks context->paramIn_Percentile_numLinks
#define pIn_Displacement_numLinks context->paramIn_Displacement_numLinks
#define pIn_Linkrange_numLinks context->paramIn_Linkrange_numLinks
#define pOut_next_numLinks context->paramOut_next_numLinks
#define pOut_stop_numLinks context->paramOut_stop_numLinks
#define pOut_Status_numLinks context->paramOut_Status_numLinks
#define pOut_FileStatus_numLinks context->paramOut_FileStatus_numLinks
#define pOut_LastFrameProcessed_numLinks context->paramOut_LastFrameProcessed_numLinks
#define pOut_FoundTrajectories_numLinks context->paramOut_FoundTrajectories_numLinks

/* AdditionalStateVariables shortcuts */
#define addS_sl context->functionalState.sl
#define addS_slTrajectories context->functionalState.slTrajectories
#define addS_tl context->functionalState.tl
#define addS_counter context->functionalState.counter

/* AdditionalStateVariables default values */
#define ADDS_SL_DEFAULTVALUE 0
#define ADDS_SLTRAJECTORIES_DEFAULTVALUE 0
#define ADDS_TL_DEFAULTVALUE 0
#define ADDS_COUNTER_DEFAULTVALUE 0

/* Input EventGate IDs */
#define pIn_next_event 1000
#define dIn_PTFrame_event 1001

/* Common event shortcuts */
#define event_isAvailable() isEventAvailable(context)
#define event_transit() transitEvent(context)
#define event_getID() getEventID(context)

/* Parameter Output support function shortcuts */
#define pOut_next_sendEvent() sendPE_next(context)

#define pOut_LastFrameProcessed_sendEvent() sendPE_LastFrameProcessed(context)

/* Data Input getEvent function shortcuts */
#define dIn_PTFrame_getEvent() getDE_PTFrame(context)

/* Data Input transit support functions */
#define dIn_PTFrame_transitNumElements() getTransitNumElementsDE_PTFrame(context)
#define dIn_PTFrame_getFirstTransit() getFirstTransitDE_PTFrame(context)
#define dIn_PTFrame_currentNumElements() getCurrentNumElementsDE_PTFrame(context)
#define dIn_PTFrame_getCurTransit() getCurTransitDE_PTFrame(context)
#define dIn_PTFrame_dismissEvent() dismissDE_PTFrame(context)

/* Data Output support function shortcuts */
#define dOut_Trajectory_armEvent() armDE_Trajectory(context)
#define dOut_Trajectory_sendEvent() sendDE_Trajectory(context)

/* MemoryManager function shortcuts */
#define memory_allocate(size) memoryManager_allocate((DSPEElement*) context, size)
#define memory_allocateAndInit(blockSize, size) memoryManager_allocateAndInit((DSPEElement*) context, blockSize, size)
#define memory_realloc(pointer, newSize) memorySupport_realloc(pointer, newSize)
#define memory_dispose(pointer) memorySupport_dispose(pointer)
#define memory_copyBlock(destination, source, size) memorySupport_copyBlock(destination, source, size)
#define memory_resetBlock(destination, size) memorySupport_resetBlock(destination, size)

/* StringManager function shortcuts */
#define string_copy(destination, source) stringSupport_copy(destination, source)
#define string_nCopy(destination, source, numChars) stringSupport_nCopy(destination, source, numChars)
#define string_compare(first, second) stringSupport_compare(first, second)
#define string_nCompare(first, second, numChars) stringSupport_nCompare(first, second, numChars)
#define string_compareNoCase(first, second) stringSupport_compareNoCase(first, second)
#define string_nCompareNoCase(first, second, numChars) stringSupport_nCompareNoCase(first, second, numChars)
#define string_length(string) stringSupport_length(string)

/* EngineManager function shortcuts */
#define engine_run() engineManager_run((DSPEElement*) context)
#define engine_stop() engineManager_stop((DSPEElement*) context)
#define engine_pause() engineManager_pause((DSPEElement*) context)
#define engine_skip(cycles) engineManager_skip((DSPEElement*) context, cycles)
#define engine_quit() engineManager_quit((DSPEElement*) context)
#define engine_suspend() engineManager_suspend((DSPEElement*) context)
#define engine_freeze() engineManager_freeze((DSPEElement*) context)
#define engine_resume() engineManager_resume((DSPEElement*) context)

#define engine_isExecuting() engineManager_isExecuting((DSPEElement*) context)
#define engine_isStopping() engineManager_isStopping((DSPEElement*) context)
#define engine_isStopped() engineManager_isStopped((DSPEElement*) context)
#define engine_isPaused() engineManager_isPaused((DSPEElement*) context)
#define engine_isSkipping() engineManager_isSkipping((DSPEElement*) context)
#define engine_isExiting() engineManager_isExiting((DSPEElement*) context)
#define engine_isSuspended() engineManager_isSuspended((DSPEElement*) context)

/* InfoManager function shortcuts */
#if defined(INFOMANAGER_BYPASS_CONSOLE) && (INFOMANAGER_BYPASS_CONSOLE == 1)
#define info_writeInfo(info, ...)
#define info_collectAndWriteInfo(id)
#define info_nCollectAndWriteInfo(id, increment)
#else
#define info_writeInfo(info, ...) infoManager_writeInfo((DSPEElement*) context, info , ##__VA_ARGS__)
#define info_collectAndWriteInfo(id) infoManager_collectAndWriteInfo((DSPEElement*) context, id, 1)
#define info_nCollectAndWriteInfo(id, increment) infoManager_collectAndWriteInfo((DSPEElement*) context, id, increment)
#endif
#if defined(INFOMANAGER_BYPASS_LOG) && (INFOMANAGER_BYPASS_LOG == 1)
#define info_logInfo(info, ...)
#define info_collectAndLogInfo(id)
#define info_nCollectAndLogInfo(id, increment)
#else
#define info_logInfo(info, ...) infoManager_logInfo((DSPEElement*) context, info , ##__VA_ARGS__)
#define info_collectAndLogInfo(id) infoManager_collectAndLogInfo((DSPEElement*) context, id, 1)
#define info_nCollectAndLogInfo(id, increment) infoManager_collectAndLogInfo((DSPEElement*) context, id, increment)
#endif

/**
 * Startup algorithm. Unit initialization should take place here.
 * This function will be called ONCE at application startup.
 */
void ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_startup(ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *context) {
//Place implementation after this line -- SYD-STARTUP-START
	addS_sl = initStringList();
	//addS_slTrajectories = initStringList();
//SYD-STARTUP-END -- Place implementation before this line
}

/**
 * PreProcess algorithm. Process phase initialization should take place here.
 * This function will be called ONCE before the process phase.
 */
void ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_preProcess(ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *context) {
//Place implementation after this line -- SYD-PREPROCESS-START
	pOut_FoundTrajectories = 0;

	addS_tl = TRAJ_CreateNewTrajectoriesList();

	PT_AddConfigInfoToStringList(addS_sl, pIn_Radius, pIn_Cutoff, pIn_Percentile, pIn_Displacement, pIn_Linkrange, pIn_Verbose);
	PT_AddSequenceInfoToStringList(addS_sl, dIn_SequenceValues);
	PT_AddTrajectoriesInfoToStringList(addS_sl);

	if(pIn_Radius <= 0) {
		pOut_Status_set("Radius must be greater than 0");
		info_writeInfo(pOut_Status);
		engine_stop();
		return;
	}

	if(pIn_Cutoff < 0) {
		pOut_Status_set("Cutoff must be non negative");
		info_writeInfo(pOut_Status);
		engine_stop();
		return;
	}

	if(pIn_Percentile <= 0) {
		pOut_Status_set("Percentile must be greater than 0");
		info_writeInfo(pOut_Status);
		engine_stop();
		return;
	}

	if(pIn_Displacement <= 0) {
		pOut_Status_set("Displacement must be greater than 0");
		info_writeInfo(pOut_Status);
		engine_stop();
		return;
	}

	if(pIn_Linkrange < 1) {
		pOut_Status_set("Linkrange must be greater than 1");
		info_writeInfo(pOut_Status);
		engine_stop();
		return;
	}

	pOut_Status_set("Running");
//SYD-PREPROCESS-END -- Place implementation before this line
}

/**
 * Process algorithm. What the unit really does should take place here.
 * This function will be called at each process cycle.
 */
void ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_process(ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *context) {
//Place implementation after this line -- SYD-PROCESS-START
	int i, l, nop, id;
	PTParticle p;
	Trajectory *traj;
	int nextFrameId, nextParticleId;

	nop = dIn_PTFrame->pl->number_of_particles;
	id = dIn_PTFrame->id;

	for(i = 0; i < nop; i++) {
		nextFrameId = -1;
		nextParticleId = -1;
		p = dIn_PTFrame->pl->particle[i];
		if(TRAJ_IsTrajNextP(addS_tl, id, i) != NULL) {
			traj = TRAJ_IsTrajNextP(addS_tl, id, i);
			TRAJ_AddPNodeToTraj(traj, id, p.x, p.y, p.m0, p.m2, p.score);
			for(l = 0; l < pIn_Linkrange; l++) {
				if(p.next[l] != -1) {
					nextParticleId = p.next[l];
					nextFrameId = id+l+1;
					break;
				}
			}
			TRAJ_SetTrajNext(traj, nextFrameId, nextParticleId);
			// REMARK: Added by Loris to be able to send an event each time a new trajectory is complete!
			// Trajectories with only one particle are ignored!
			if (nextFrameId == -1 && nextParticleId == -1 && traj->numberOfParticle > 1) {
				dOut_Trajectory_armEvent();
				dOut_Trajectory = traj;
				dOut_Trajectory_sendEvent();
				pOut_FoundTrajectories++;
			}
		} else {
			if(TRAJ_IsTrajFirstP(p, pIn_Linkrange)) {
				traj = TRAJ_AddTrajNodeToTl(addS_tl, addS_counter);
				addS_counter++;
				TRAJ_AddPNodeToTraj(traj, id, p.x, p.y, p.m0, p.m2, p.score);
				for(l = 0; l < pIn_Linkrange; l++) {
					if(p.next[l] != -1) {
						nextParticleId = p.next[l];
						nextFrameId = id+l+1;
						break;
					}
				}
				TRAJ_SetTrajNext(traj, nextFrameId, nextParticleId);
				// REMARK: Don't need to check if trajectory is complete. If the
				// trajectory is complete, it contains only 1 node -> the trajectory
				// is ignored
			}
		}
	}

	//TRAJ_CleanAndPrintTrajNotActive(addS_tl, addS_sl);

	if(dIn_PTFrame->id == dIn_SequenceValues->numberOfImages -1) {
		if(addS_tl->numberOfTrajectories != 0) {
			TRAJ_CheckForUnusedTraj(addS_tl);
			//TRAJ_CleanAndPrintAllTraj(addS_tl, addS_sl);
		}
		pOut_Status_set("No more frame to process");
		info_writeInfo(pOut_Status);
		
		pOut_LastFrameProcessed_sendEvent();
	}

	PT_ResetPTFrame(dIn_PTFrame);
//SYD-PROCESS-END -- Place implementation before this line 
}

/**
 * PostProcess algorithm. Process phase cleanup should take place here.
 * This function will be called ONCE after the process phase.
 */
void ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_postProcess(ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *context) {
//Place implementation after this line -- SYD-POSTPROCESS-START
	time_t currentTime;
	struct tm *tm;
	char fileName[128];

	addString(addS_sl, "%% %d trajectories found\n", addS_tl->nott);

	if(pIn_Verbose) {
		currentTime = time(NULL);
		tm = localtime(&currentTime);
		sprintf(fileName, "PTResult_%d%02d%02d_%02d%02d%02d.txt",
				1900 + tm->tm_year,
				1 + tm->tm_mon,
				tm->tm_mday,
				tm->tm_hour,
				tm->tm_min,
				tm->tm_sec);
		//addAll(addS_sl, addS_slTrajectories);
		if(PT_WriteResults(addS_sl, fileName, currentTime))
			sprintf(pOut_FileStatus, "%s", fileName);
		else
			pOut_FileStatus_set("Error writing results");
	} else {
		pOut_FileStatus_set("No output file");
	}

	releaseStringList(addS_sl);
	TRAJ_DestroyTrajectories(addS_tl);
	//releaseStringList(addS_slTrajectories);
//SYD-POSTPROCESS-END -- Place implementation before this line 
}

/**
 * Shutdown algorithm. Unit cleanup should take place here.
 * This function will be called ONCE at application shutdown.
 */
void ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_shutdown(ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *context) {
//Place implementation after this line -- SYD-SHUTDOWN-START
	memory_dispose(addS_sl);
	//memory_dispose(addS_slTrajectories);
//SYD-SHUTDOWN-END -- Place implementation before this line
}

#undef currState
/* Input ParameterGates Shortcuts */
#undef pIn_stop
#undef pIn_Verbose
#undef pIn_Radius
#undef pIn_Cutoff
#undef pIn_Percentile
#undef pIn_Displacement
#undef pIn_Linkrange

/* Output ParameterGates Shortcuts */
#undef pOut_stop
#undef pOut_Status
#undef pOut_Status_set
#undef pOut_FileStatus
#undef pOut_FileStatus_set
#undef pOut_FoundTrajectories

/* Input DataGates Shortcuts */
#undef dIn_SequenceValues
#undef dIn_PTFrame

/* Output DataGates Shortcuts */
#undef dOut_Trajectory

/* numLinks shortcuts */
#undef dIn_SequenceValues_numLinks
#undef dIn_PTFrame_numLinks
#undef dOut_Trajectory_numLinks
#undef pIn_next_numLinks
#undef pIn_stop_numLinks
#undef pIn_Verbose_numLinks
#undef pIn_Radius_numLinks
#undef pIn_Cutoff_numLinks
#undef pIn_Percentile_numLinks
#undef pIn_Displacement_numLinks
#undef pIn_Linkrange_numLinks
#undef pOut_next_numLinks
#undef pOut_stop_numLinks
#undef pOut_Status_numLinks
#undef pOut_FileStatus_numLinks
#undef pOut_LastFrameProcessed_numLinks
#undef pOut_FoundTrajectories_numLinks

/* AdditionalStateVariables shortcuts */
#undef addS_sl
#undef addS_slTrajectories
#undef addS_tl
#undef addS_counter

#undef ADDS_SL_DEFAULTVALUE
#undef ADDS_SLTRAJECTORIES_DEFAULTVALUE
#undef ADDS_TL_DEFAULTVALUE
#undef ADDS_COUNTER_DEFAULTVALUE

#undef pIn_next_event
#undef dIn_PTFrame_event
#undef event_isAvailable
#undef event_getID

#undef event_transit

#undef pOut_next_sendEvent

#undef pOut_LastFrameProcessed_sendEvent

#undef dIn_PTFrame_getEvent

#undef dIn_PTFrame_transitNumElements
#undef dIn_PTFrame_getFirstTransit
#undef dIn_PTFrame_currentNumElements
#undef dIn_PTFrame_getCurTransit
#undef dIn_PTFrame_dismissEvent

#undef dOut_Trajectory_armEvent
#undef dOut_Trajectory_sendEvent

/* MemoryManager function shortcuts */
#undef memory_allocate
#undef memory_allocateAndInit
#undef memory_realloc
#undef memory_dispose
#undef memory_copyBlock
#undef memory_resetBlock

/* StringManager function shortcuts */
#undef string_copy
#undef string_nCopy
#undef string_compare
#undef string_nCompare
#undef string_compareNoCase
#undef string_nCompareNoCase
#undef string_length

/* EngineManager function shortcuts */
#undef engine_run
#undef engine_stop
#undef engine_pause
#undef engine_skip
#undef engine_quit
#undef engine_suspend
#undef engine_freeze
#undef engine_resume

#undef engine_isExecuting
#undef engine_isStopping
#undef engine_isStopped
#undef engine_isPaused
#undef engine_isSkipping
#undef engine_isExiting
#undef engine_isSuspended

/* InfoManager function shortcuts */
#undef info_writeInfo
#undef info_collectAndWriteInfo
#undef info_nCollectAndWriteInfo
#undef info_logInfo
#undef info_collectAndLogInfo
#undef info_nCollectAndLogInfo

