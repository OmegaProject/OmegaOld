/**
 * File: RBlockProd_ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit.c
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#include "PlatformManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "EngineManager.h"
#include "ProfileManager.h"
#include "ErrorManager.h"

#include "RBlockProd_ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit.h"

/* NoEvent ID */
#define NOEVENT 10

/* InitEvent ID */
#define pIn_Init_event 0

#define pIn_next_event 1000
#define dIn_PTFrame_event 1001

#define pOut_next_event 1000
#define pOut_LastFrameProcessed_event 1001
#define dOut_Trajectory_event 1002

/******************************************************************************
 * NEXT EVENT SUPPORT FUNCTIONS
 ******************************************************************************/

/* output next handler function */
static INLINE void handleOutgoingNextRequest(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context) {
	((DSPEEventsUnit*) context)->armEvent((DSPEEventsUnit*) context, pOut_next_event);
	((DSPEEventsUnit*) context)->postEvent((DSPEEventsUnit*) context, pOut_next_event);
}

/* input next handler function */
static INLINE void handleIncomingNextRequest(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context) {
	/* Forwarding next request */
	handleOutgoingNextRequest(context);
}

/******************************************************************************
 * GATE AUTOMATION SUPPORT FUNCTIONS
 ******************************************************************************/

/**
 * loadAllTransitEvents function
 */
static INLINE void loadAllTransitEvents(ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *implState) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) implState)->container;

	unit->getCurrentTransitEvent(unit, dIn_PTFrame_event);
}

/**
 * armAllTransferEvents function
 */
static INLINE void armAllTransferEvents(ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *implState) {
	DSPEEventsUnit *unit = (DSPEEventsUnit*) ((DSPEElement*) implState)->container;

}

/* Handle incoming event */
static INLINE void handleInputEvent(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context) {
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *implState = &context->implState;
	implState->isReadyToExecute = 1;
	loadAllTransitEvents(implState);
	armAllTransferEvents(implState);
}

/******************************************************************************
 * EVENT SUPPORT FUNCTIONS
 ******************************************************************************/

static INLINE void resetEventPlaces(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context) {
	DSPEEvent *event = NULL;
	context->paramOut_next_armMarker = NULL;
	
	while (context->paramOut_next_place != NULL) {
		event = (DSPEEvent*) context->paramOut_next_place;
		context->paramOut_next_place = event->next;
		/* force disposal */
		event->refCount = 1;
		event->dispose(event);
	}
	context->paramOut_LastFrameProcessed_armMarker = NULL;
	
	while (context->paramOut_LastFrameProcessed_place != NULL) {
		event = (DSPEEvent*) context->paramOut_LastFrameProcessed_place;
		context->paramOut_LastFrameProcessed_place = event->next;
		/* force disposal */
		event->refCount = 1;
		event->dispose(event);
	}
	context->dataOut_Trajectory_armMarker = NULL;
	
	while (context->dataOut_Trajectory_place != NULL) {
		event = (DSPEEvent*) context->dataOut_Trajectory_place;
		context->dataOut_Trajectory_place = event->next;
		/* force disposal */
		event->refCount = 1;
		event->dispose(event);
	}
}

static INLINE void initQueue(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *unit) {
	/* Data transit queues */
	unit->dataIn_PTFrame_transitNumElements = 0;
	unit->dataIn_PTFrame_transitHead = NULL;
	unit->dataIn_PTFrame_transitTail = NULL;
	unit->dataIn_PTFrame_curTransit = NULL;
	unit->dataIn_PTFrame_curTransitIndex = 0;
	
}

static INLINE void resetQueue(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *unit) {
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_dismissAllEventsBlockProd((DSPEQueueUnit*) unit, dIn_PTFrame_event);
}

/**
 * Transit input event function
 */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_transitEventBlockProd(DSPEQueueUnit *unit) {
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context = (ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd*) unit;
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueNode *node = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->queueHead;
	
	/* Prevent multiple transits */
	if (node->inTransit == 1)
		return;

	switch (node->ID) {
	case dIn_PTFrame_event:
		if (context->dataIn_PTFrame_transitNumElements == 0) {
			context->dataIn_PTFrame_transitHead = node;
			context->dataIn_PTFrame_transitTail = node;
			context->dataIn_PTFrame_transitNumElements = 1;
		} else {
			context->dataIn_PTFrame_transitTail->nextInTransit = node;
			context->dataIn_PTFrame_transitTail = node;
			context->dataIn_PTFrame_transitNumElements++;
		}
		/* set curTransit if needed */
		if (context->dataIn_PTFrame_curTransit == NULL) {
			context->dataIn_PTFrame_curTransit = node;
			context->dataIn_PTFrame_curTransitIndex = 0;
		}
		context->dataIn_PTFrame_curTransitIndex++;
		node->inTransit = 1;
		break;
	}
}

size_t ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_getTransitNumElementsBlockProd(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context = (ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd*) unit;

	switch (ID) {
	case dIn_PTFrame_event:
		return context->dataIn_PTFrame_transitNumElements;
	}
	return 0;
}

size_t ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_getCurrentNumElementsBlockProd(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context = (ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd*) unit;

	switch (ID) {
	case dIn_PTFrame_event:
		return context->dataIn_PTFrame_curTransitIndex;
	}
	return 0;
}

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_getFirstTransitBlockProd(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context = (ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd*) unit;
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *implState = &context->implState;
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueNode *node = NULL;
	
	switch (ID) {
	case dIn_PTFrame_event:
		node = context->dataIn_PTFrame_transitHead;
		if (node == NULL)
			return;
		/* Set UnitBehaviour input gate pointer */
		implState->dataIn_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) node->event)->value;
		break;
	}
}

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_getCurTransitBlockProd(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context = (ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd*) unit;
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *implState = &context->implState;
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueNode *node = NULL;
	
	switch (ID) {
	case dIn_PTFrame_event:
		node = context->dataIn_PTFrame_curTransit;
		if (node == NULL)
			return;
		context->dataIn_PTFrame_curTransit = node->nextInTransit;
		if (node->nextInTransit == NULL)
			context->dataIn_PTFrame_curTransitIndex = 0;
		else
			context->dataIn_PTFrame_curTransitIndex--;
		/* set implementation's gate pointer */
		implState->dataIn_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) node->event)->value;
		break;
	}
}

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_dismissEventBlockProd(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context = (ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd*) unit;
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *implState = (ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation*) &context->implState;
	DSPEEvent *event = NULL;
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueNode *node = NULL;

	switch (ID) {
	case dIn_PTFrame_event:
		node = context->dataIn_PTFrame_transitHead;
		if (context->dataIn_PTFrame_transitNumElements == 1) {
			context->dataIn_PTFrame_transitHead = NULL;
			context->dataIn_PTFrame_transitTail = NULL;
			context->dataIn_PTFrame_transitNumElements = 0;
		} else {
			context->dataIn_PTFrame_transitHead = node->nextInTransit;
			context->dataIn_PTFrame_transitNumElements--;
		}
		/* Set implementation pointer to secure unlinked place */
		implState->dataIn_PTFrame = context->dataIn_PTFrame_unlinked;
		break;
	}
	node->inTransit = 0;
	node->nextInTransit = NULL;
	
	// If node is the headNode within the queue let unitReleaseEvent do the disposal!
	if (node == ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->queueHead)
		return;
	
	event = node->event;
	event->dispose(event);
	node->event = NULL;
	node->ID = 0;
	
	/* Move node to pool */
	if (((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->poolNumNodes == 0) {
		((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->poolHead = node;
		((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->poolTail = node;
		((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->poolNumNodes = 1;
	} else {
		((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->poolTail->next = node;
		((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->poolTail = node;
		((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->poolNumNodes++;
	}
}

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_dismissAllEventsBlockProd(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context = (ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd*) unit;

	switch (ID) {
	case dIn_PTFrame_event:
		while (context->dataIn_PTFrame_transitNumElements != 0)
			ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_dismissEventBlockProd(unit, ID);
		/* Reset curTransit */
		context->dataIn_PTFrame_curTransit = NULL;
		context->dataIn_PTFrame_curTransitIndex = 0;
		break;
	}
}

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_armEventBlockProd(DSPEEventsUnit *unit, unsigned int ID) {
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context = (ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd*) unit;
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *implState = &context->implState;

	register size_t i;
	DSPEEvent *event = NULL;
	DSPEEvent *insert = NULL;

	switch (ID) {
	case pOut_next_event:
		/* If gate is unlinked no event will be sent. Avoid creating event */
		if (implState->paramOut_next_numLinks == 0)
			return;
		insert = context->paramOut_next_armMarker;
		event = (DSPEEvent*) ParticleTrackerDllNextGate_SignalGate_allocate(context->paramOut_next_pool);
		event->refCount = 1;
		if (insert == NULL)
			context->paramOut_next_place = event;
		else
			insert->next = event;
		context->paramOut_next_armMarker = event;
		break;
	case pOut_LastFrameProcessed_event:
		/* If gate is unlinked no event will be sent. Avoid creating event */
		if (implState->paramOut_LastFrameProcessed_numLinks == 0)
			return;
		insert = context->paramOut_LastFrameProcessed_armMarker;
		event = (DSPEEvent*) ParticleTrackerDllNextGate_SignalGate_allocate(context->paramOut_LastFrameProcessed_pool);
		event->refCount = 1;
		if (insert == NULL)
			context->paramOut_LastFrameProcessed_place = event;
		else
			insert->next = event;
		context->paramOut_LastFrameProcessed_armMarker = event;
		break;
	case dOut_Trajectory_event:
		/* If gate is unlinked no event will be sent. Avoid creating event */
		if (implState->dataOut_Trajectory_numLinks == 0)
			return;
		insert = context->dataOut_Trajectory_armMarker;
		if (insert == NULL) {
			if (context->dataOut_Trajectory_place == NULL) {
				event = (DSPEEvent*) ParticleTrackerDllTrajectory_MessageGate_allocateBlock(context->dataOut_Trajectory_pool);
				event->refCount = 1;
				context->dataOut_Trajectory_place = event;
				context->dataOut_Trajectory_armMarker = event;
				implState->dataOut_Trajectory = ((ParticleTrackerDllTrajectory_MessageGate_event*) event)->value;
				/* create clones if needed */
				for (i = 0; i < context->dataOut_Trajectory_factor - 1; i++) {
					insert = event;
					event = insert->clone(insert);
					event->refCount = 1;
					((ParticleTrackerDllTrajectory_MessageGate_event*) event)->value += context->blockSize;
					/* append clone */
					insert->next = event;
				}
			} else {
				event = context->dataOut_Trajectory_place;
				context->dataOut_Trajectory_armMarker = event;
				implState->dataOut_Trajectory = ((ParticleTrackerDllTrajectory_MessageGate_event*) event)->value;
			}
		} else if (insert->next == NULL) {
			event = (DSPEEvent*) ParticleTrackerDllTrajectory_MessageGate_allocateBlock(context->dataOut_Trajectory_pool);
			event->refCount = 1;
			context->dataOut_Trajectory_armMarker->next = event;
			context->dataOut_Trajectory_armMarker = event;
			implState->dataOut_Trajectory = ((ParticleTrackerDllTrajectory_MessageGate_event*) event)->value;
			/* create clones if needed */
			for (i = 0; i < context->dataOut_Trajectory_factor - 1; i++) {
				insert = event;
				event = insert->clone(insert);
				event->refCount = 1;
				((ParticleTrackerDllTrajectory_MessageGate_event*) event)->value += context->blockSize;
				/* append clone */
				insert->next = event;
			}
		} else {
			/* use insert->next*/
			event = insert->next;
			context->dataOut_Trajectory_armMarker = event;
			implState->dataOut_Trajectory = ((ParticleTrackerDllTrajectory_MessageGate_event*) event)->value;
		}
		break;
	}
}

/* BlockUnit Post Function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_postEventBlockProd(DSPEEventsUnit *unit, unsigned int ID) {
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context = (ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd*) unit;
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *implState = &context->implState;
	DSPEEvent *event = NULL;
	switch (ID) {
	case pOut_next_event:
		/* If gate is unlinked no event will be sent */
		if (implState->paramOut_next_numLinks == 0)
			return;
		event = context->paramOut_next_place;
		if (event == NULL)
			return;
		context->paramOut_next_place = event->next;
		if (context->paramOut_next_place == NULL)
			context->paramOut_next_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
		break;
	case pOut_LastFrameProcessed_event:
		/* If gate is unlinked no event will be sent */
		if (implState->paramOut_LastFrameProcessed_numLinks == 0)
			return;
		event = context->paramOut_LastFrameProcessed_place;
		if (event == NULL)
			return;
		context->paramOut_LastFrameProcessed_place = event->next;
		if (context->paramOut_LastFrameProcessed_place == NULL)
			context->paramOut_LastFrameProcessed_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
		break;
	case dOut_Trajectory_event:
		/* If gate is unlinked no event will be sent */
		if (implState->dataOut_Trajectory_numLinks == 0)
			return;
		/* Restore save place to write */
		implState->dataOut_Trajectory = context->dataOut_Trajectory_unlinked;
		event = context->dataOut_Trajectory_place;
		if (event == NULL)
			return;
		context->dataOut_Trajectory_place = event->next;
		if (context->dataOut_Trajectory_armMarker == event || context->dataOut_Trajectory_place == NULL)
			context->dataOut_Trajectory_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
		break;
	}

}

/* Initialize gate values */
static INLINE void initValues(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *implState = &context->implState;
	ParticleTrackerDllPTFrameGate_MessageGate_initializeUnlinkedBlock((DSPEElement*) context, context->dataIn_PTFrame_unlinked, context->blockSize);
	implState->dataIn_PTFrame = context->dataIn_PTFrame_unlinked;
	ParticleTrackerDllTrajectory_MessageGate_initializeUnlinkedBlock((DSPEElement*) context, context->dataOut_Trajectory_unlinked, context->blockSize);
	implState->dataOut_Trajectory = context->dataOut_Trajectory_unlinked;

}

/******************************************************************************
 * COMMON UNIT FUNCTIONS
 ******************************************************************************/

/* Earlyalloc function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_earlyAllocBlockProd(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context) {
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *implState = &context->implState;

	initDSPEElement((DSPEElement*) &context->implState, (DSPEElement*) context);
	initDSPEQueueUnit((DSPEQueueUnit*) context);
	((DSPEComponent*) context)->preprocess = ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_preProcessBlockProd;
	((DSPEComponent*) context)->process = ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_processBlockProd;
	((DSPEComponent*) context)->postprocess = ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_postProcessBlockProd;
	/* Data gates size initialization */
	context->dataIn_SequenceValues_size = context->blockSize;
	context->dataOut_Trajectory_size = context->blockSize;

	implState->isReadyToExecute = 0;

	/* Implementation AdditionalStateVariables initialization */
	implState->functionalState.sl = 0;
	implState->functionalState.slTrajectories = 0;
	implState->functionalState.tl = 0;
	implState->functionalState.counter = 0;
	/* Unit profile ID initialization */
	context->unitProfileID = (int) profileSupport_getUnitProfileID(((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->ID);
}

/* Alloc function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_allocBlockProd(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context) {
	const DSPEOwner *owner = ((DSPEElement*) context)->owner;

	/* Base alloc() function call */
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_alloc(&context->baseState);

	initQueue(context);
	((DSPEQueueUnit*) context)->transitEvent = ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_transitEventBlockProd;
	((DSPEQueueUnit*) context)->getTransitNumElements = ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_getTransitNumElementsBlockProd;
	((DSPEQueueUnit*) context)->getCurrentNumElements = ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_getCurrentNumElementsBlockProd;
	((DSPEQueueUnit*) context)->dismissEvent = ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_dismissEventBlockProd;
	((DSPEQueueUnit*) context)->getFirstTransitEvent = ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_getFirstTransitBlockProd;
	((DSPEQueueUnit*) context)->getCurrentTransitEvent = ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_getCurTransitBlockProd;
	((DSPEEventsUnit*) context)->armEvent = ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_armEventBlockProd;
	((DSPEEventsUnit*) context)->postEvent = ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_postEventBlockProd;

	/* Initializing event Hooks and Inserts */
	context->paramOut_next_place = NULL;
	context->paramOut_next_armMarker = NULL;
	context->paramOut_LastFrameProcessed_place = NULL;
	context->paramOut_LastFrameProcessed_armMarker = NULL;

	/* Allocate unlinked places for input event gates */
	context->dataIn_PTFrame_unlinked = ParticleTrackerDllPTFrameGate_MessageGate_allocateUnlinkedBlock((DSPEElement*) context, context->blockSize);
	context->dataOut_Trajectory_unlinked = ParticleTrackerDllTrajectory_MessageGate_allocateUnlinkedBlock((DSPEElement*) context, context->blockSize);


	/* Data output gates factor and counter initialization */
	context->dataOut_Trajectory_factor = context->dataOut_Trajectory_size / context->blockSize;

	/* Initialize eventPools for parameter gates */
	context->paramOut_next_pool = ParticleTrackerDllNextGate_SignalGate_initPool(owner);
	context->paramOut_LastFrameProcessed_pool = ParticleTrackerDllNextGate_SignalGate_initPool(owner);

	context->dataOut_Trajectory_place = NULL;
	context->dataOut_Trajectory_armMarker = NULL;

	/* Initialize eventPools for data gates */
	context->dataOut_Trajectory_pool = ParticleTrackerDllTrajectory_MessageGate_initPoolBlock(owner, context->dataOut_Trajectory_size);

}

/* Earlyconnect function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_earlyConnectBlockProd(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *implState = &context->implState;

	/* Implementation output parameters gates initialization */
	implState->paramOut_stop = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramOut_stop_place;
	implState->paramOut_Status = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramOut_Status_place;
	implState->paramOut_FileStatus = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramOut_FileStatus_place;
	implState->paramOut_FoundTrajectories = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramOut_FoundTrajectories_place;


	/* Base earlyconnect() function call */
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_earlyConnect(&context->baseState);

	/* Input data gates factor and counter initialization */
	context->dataIn_SequenceValues_factor = context->dataIn_SequenceValues_size / context->blockSize;

	/* Input data gates factor and counter initialization */
	context->dataIn_SequenceValues_counter = context->dataIn_SequenceValues_factor;

}

/* Connect function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_connectBlockProd(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *implState = &context->implState;

	/* Implementation input parameters gates initialization */
	implState->paramIn_stop = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramIn_stop;
	implState->paramIn_Verbose = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramIn_Verbose;
	implState->paramIn_Radius = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramIn_Radius;
	implState->paramIn_Cutoff = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramIn_Cutoff;
	implState->paramIn_Percentile = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramIn_Percentile;
	implState->paramIn_Displacement = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramIn_Displacement;
	implState->paramIn_Linkrange = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramIn_Linkrange;

	/* Implementation data gates initialization */
	implState->dataIn_SequenceValues = context->dataIn_SequenceValues;

	/* Implementation gates numLinks initialization */
	implState->dataIn_SequenceValues_numLinks = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->dataIn_SequenceValues_numLinks;
	implState->dataIn_PTFrame_numLinks = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->dataIn_PTFrame_numLinks;
	implState->dataOut_Trajectory_numLinks = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->dataOut_Trajectory_numLinks;
	implState->paramIn_next_numLinks = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramIn_next_numLinks;
	implState->paramIn_stop_numLinks = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramIn_stop_numLinks;
	implState->paramIn_Verbose_numLinks = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramIn_Verbose_numLinks;
	implState->paramIn_Radius_numLinks = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramIn_Radius_numLinks;
	implState->paramIn_Cutoff_numLinks = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramIn_Cutoff_numLinks;
	implState->paramIn_Percentile_numLinks = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramIn_Percentile_numLinks;
	implState->paramIn_Displacement_numLinks = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramIn_Displacement_numLinks;
	implState->paramIn_Linkrange_numLinks = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramIn_Linkrange_numLinks;
	implState->paramOut_next_numLinks = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramOut_next_numLinks;
	implState->paramOut_stop_numLinks = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramOut_stop_numLinks;
	implState->paramOut_Status_numLinks = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramOut_Status_numLinks;
	implState->paramOut_FileStatus_numLinks = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramOut_FileStatus_numLinks;
	implState->paramOut_LastFrameProcessed_numLinks = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramOut_LastFrameProcessed_numLinks;
	implState->paramOut_FoundTrajectories_numLinks = ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramOut_FoundTrajectories_numLinks;

}

/* Startup function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_startupBlockProd(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context) {
	/* Initialize gate values */
	initValues(context);


	/* Implementation startup() call */
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_startup(&context->implState);

}

/* Preprocess function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_preProcessBlockProd(DSPEComponent *component) {
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context = (ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd*) component;
	/* Implementation preprocess() call */
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_preProcess(&context->implState);
}

/* Process function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_processBlockProd(DSPEComponent *component) {
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context = (ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd*) component;
	/* Implementation state local variable initialization */
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *implState = &context->implState;
	const unsigned int ID = (((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->queueNumNodes == 0) ? NOEVENT : ((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->queueHead->ID;
	/* Loop counter */
	register size_t i;

	/* Implementation data gates and counters update */
	if (context->dataIn_SequenceValues_counter == context->dataIn_SequenceValues_factor) {
		implState->dataIn_SequenceValues = context->dataIn_SequenceValues;
		context->dataIn_SequenceValues_counter = 0;
	} else {
		implState->dataIn_SequenceValues++;
	}

	/* Switch input event ID */
	switch (ID) {
	case pIn_Init_event:
		/* consider initEvent as next */
		handleInputEvent(context);
		break;
	case dIn_PTFrame_event:
		/* AutoTransit inputEvents */
		((DSPEQueueUnit*) context)->transitEvent((DSPEQueueUnit*) context);
		/* Handle incoming event */
		handleInputEvent(context);
		break;
	case pIn_next_event:
		handleIncomingNextRequest(context);
		break;
	}
	/* FIXME workaround: State unit in Push, out Push, no pending events */
	if (*((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramIn_stop) {
		/* Forward input stop request */
		*((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramOut_stop = 1;
	} else if (*((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramOut_stop) {
		/* no input stop -> unlock stop */
		// REMARK: it shouldn't be necessary to send next because next will be forwarded automatically  
		*((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context)->paramOut_stop = 0;
	}
	/* Automatic execute support */
	if (implState->isReadyToExecute) {
		implState->isReadyToExecute = 0;

	/* Capture unit process start time */
	profileManager_captureStartTime((DSPEElement*) context, (profileID) context->unitProfileID);


	/* Blocksize loop */
	for (i = 0; i < context->samplesToProcess - 1; i++) {

		/* Implementation process() call */
		ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_process(implState);

		/* Block loop pointers increment */
		implState->dataIn_SequenceValues++;


		/* Block loop event Input pointers increment */
		if (implState->dataIn_PTFrame != context->dataIn_PTFrame_unlinked)
			implState->dataIn_PTFrame++;

		/* For Implementation having Advanced EventSupport also pointers for data output events have to be incremented */
		if (implState->dataOut_Trajectory != NULL)
			implState->dataOut_Trajectory++;

	}

	/* Implementation process() call */
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_process(implState);

	/* Capture unit process end time */
	profileManager_captureEndTime((DSPEElement*) context, (profileID) context->unitProfileID);

		/* Dismiss input events */
		((DSPEQueueUnit*) context)->dismissEvent((DSPEQueueUnit*) context, dIn_PTFrame_event);
	} /* End of automaticExecute support */
	/* Block counters increment */
	context->dataIn_SequenceValues_counter++;


	/* Restore unlinked pointers on unitBehaviour */
	if (implState->dataIn_PTFrame != context->dataIn_PTFrame_unlinked)
		implState->dataIn_PTFrame = context->dataIn_PTFrame_unlinked;
	/* Release event */
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_releaseEvent((ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit*) context);
}

/* Postprocess function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_postProcessBlockProd(DSPEComponent *component) {
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context = (ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd*) component;

	/* Implementation postprocess() call */
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_postProcess(&context->implState);

	/* Move all output events that have been armed but not sent to their related pool */
	resetEventPlaces(context);

	/* Move all events from transitQueue back to their related pool */
	resetQueue(context);

	/* Base postprocess() function call */
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_postProcess(&context->baseState);
}

/* Reset function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_resetBlockProd(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context) {
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation *implState = &context->implState;

	/* Base reset() function call */
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_reset(&context->baseState);

	/* Initialize gate values */
	initValues(context);
	implState->isReadyToExecute = 0;

	/* Implementation AdditionalStateVariables initialization */
	implState->functionalState.tl = 0;
	implState->functionalState.counter = 0;
}

/* Shutdown function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_shutdownBlockProd(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockProd *context) {
	/* Implementation shutdown() call */
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation_shutdown(&context->implState);



	/* Base shutdown() function call */
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_shutdown(&context->baseState);

	/* Dispose unlinked places for input event gates */
	ParticleTrackerDllPTFrameGate_MessageGate_disposeUnlinkedBlock((DSPEElement*) context, context->dataIn_PTFrame_unlinked);
	ParticleTrackerDllTrajectory_MessageGate_disposeUnlinkedBlock((DSPEElement*) context, context->dataOut_Trajectory_unlinked);

}

