/**
 * File: RProd_ParticleTrackerDllLibraryDataWriter_SoftwareUnit.c
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#include "PlatformManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "EngineManager.h"

#include "RProd_ParticleTrackerDllLibraryDataWriter_SoftwareUnit.h"

#define PENDING_EVENTS_MAX 10

#define pIn_LastFrameProcessed_event 1000
#define dIn_Trajectory_event 1001

#define pOut_next_event 1000

/******************************************************************************
 * GATE AUTOMATION SUPPORT FUNCTIONS
 ******************************************************************************/

/******************************************************************************
 * EVENT SUPPORT FUNCTIONS
 ******************************************************************************/

static INLINE void resetEventPlaces(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context) {
	DSPEEvent *event = NULL;
	context->paramOut_next_armMarker = NULL;
	
	while (context->paramOut_next_place != NULL) {
		event = (DSPEEvent*) context->paramOut_next_place;
		context->paramOut_next_place = event->next;
		/* force disposal */
		event->refCount = 1;
		event->dispose(event);
	}
}

static INLINE void initQueue(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *unit) {
	/* Data transit queues */
	unit->dataIn_Trajectory_transitNumElements = 0;
	unit->dataIn_Trajectory_transitHead = NULL;
	unit->dataIn_Trajectory_transitTail = NULL;
	unit->dataIn_Trajectory_curTransit = NULL;
	unit->dataIn_Trajectory_curTransitIndex = 0;
	
}

static INLINE void resetQueue(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *unit) {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_dismissAllEventsRealProd((DSPEQueueUnit*) unit, dIn_Trajectory_event);
}

/**
 * Transit input event function
 */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_transitEventRealProd(DSPEQueueUnit *unit) {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context = (ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd*) unit;
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *node = ((ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) context)->queueHead;
	
	switch (node->ID) {
	case dIn_Trajectory_event:
		if (context->dataIn_Trajectory_transitNumElements == 0) {
			context->dataIn_Trajectory_transitHead = node;
			context->dataIn_Trajectory_transitTail = node;
			context->dataIn_Trajectory_transitNumElements = 1;
		} else {
			context->dataIn_Trajectory_transitTail->nextInTransit = node;
			context->dataIn_Trajectory_transitTail = node;
			context->dataIn_Trajectory_transitNumElements++;
		}
		/* set curTransit if needed */
		if (context->dataIn_Trajectory_curTransit == NULL) {
			context->dataIn_Trajectory_curTransit = node;
			context->dataIn_Trajectory_curTransitIndex = 0;
		}
		context->dataIn_Trajectory_curTransitIndex++;
		node->inTransit = 1;
		break;
	}
}

size_t ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getTransitNumElementsRealProd(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context = (ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd*) unit;
	
	switch (ID) {
	case dIn_Trajectory_event:
		return context->dataIn_Trajectory_transitNumElements;
	}
	return 0;
}

size_t ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getCurrentNumElementsRealProd(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context = (ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd*) unit;
	
	switch (ID) {
	case dIn_Trajectory_event:
		return context->dataIn_Trajectory_curTransitIndex;
	}
	return 0;
}

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getFirstTransitRealProd(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context = (ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd*) unit;
	ParticleTrackerDllLibraryDataWriter_StateImplementation *implState = &context->implState;
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *node = NULL;
	
	switch (ID) {
	case dIn_Trajectory_event:
		node = context->dataIn_Trajectory_transitHead;
		if (node == NULL)
			return;
		/* Set UnitBehaviour input gate pointer */
		implState->dataIn_Trajectory = ((ParticleTrackerDllTrajectory_MessageGate_event*) node->event)->value;
		break;
	}
}

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getCurTransitRealProd(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context = (ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd*) unit;
	ParticleTrackerDllLibraryDataWriter_StateImplementation *implState = &context->implState;
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *node = NULL;
	
	switch (ID) {
	case dIn_Trajectory_event:
		node = context->dataIn_Trajectory_curTransit;
		if (node == NULL)
			return;
		context->dataIn_Trajectory_curTransit = node->nextInTransit;
		if (node->nextInTransit == NULL)
			context->dataIn_Trajectory_curTransitIndex = 0;
		else
			context->dataIn_Trajectory_curTransitIndex--;
		/* set implementation's gate pointer */
		implState->dataIn_Trajectory = ((ParticleTrackerDllTrajectory_MessageGate_event*) node->event)->value;
		break;
	}
}

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_dismissEventRealProd(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context = (ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd*) unit;
	ParticleTrackerDllLibraryDataWriter_StateImplementation *implState = (ParticleTrackerDllLibraryDataWriter_StateImplementation*) &context->implState;
	DSPEEvent *event = NULL;
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *node = NULL;

	switch (ID) {
	case dIn_Trajectory_event:
		node = context->dataIn_Trajectory_transitHead;
		if (context->dataIn_Trajectory_transitNumElements == 1) {
			context->dataIn_Trajectory_transitHead = NULL;
			context->dataIn_Trajectory_transitTail = NULL;
			context->dataIn_Trajectory_transitNumElements = 0;
		} else {
			context->dataIn_Trajectory_transitHead = node->nextInTransit;
			context->dataIn_Trajectory_transitNumElements--;
		}
		/* Set implementation pointer to secure unlinked place */
		implState->dataIn_Trajectory = context->dataIn_Trajectory_unlinked;
		break;

	}
	node->inTransit = 0;
	node->nextInTransit = NULL;
	
	// If node is the headNode within the queue let unitReleaseEvent do the disposal!
	if (node == ((ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) context)->queueHead)
		return;
	
	event = node->event;
	event->dispose(event);
	node->event = NULL;
	node->ID = 0;
	
	/* Move node to pool */
	if (((ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) context)->poolNumNodes == 0) {
		((ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) context)->poolHead = node;
		((ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) context)->poolTail = node;
		((ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) context)->poolNumNodes = 1;
	} else {
		((ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) context)->poolTail->next = node;
		((ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) context)->poolTail = node;
		((ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) context)->poolNumNodes++;
	}
}

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_dismissAllEventsRealProd(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context = (ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd*) unit;

	switch (ID) {
	case dIn_Trajectory_event:
		while (context->dataIn_Trajectory_transitNumElements != 0)
			ParticleTrackerDllLibraryDataWriter_SoftwareUnit_dismissEventRealProd(unit, ID);
		/* Reset curTransit */
		context->dataIn_Trajectory_curTransit = NULL;
		context->dataIn_Trajectory_curTransitIndex = 0;
		break;
	}
}

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_armEventRealProd(DSPEEventsUnit *unit, unsigned int ID) {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context = (ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd*) unit;
	ParticleTrackerDllLibraryDataWriter_StateImplementation *implState = &context->implState;

	DSPEEvent *event = NULL;
	DSPEEvent *insert = NULL;

	switch (ID) {
	case pOut_next_event:
		/* If gate is unlinked no event will be sent. Avoid creating event */
		if (implState->paramOut_next_numLinks == 0)
			return;
		insert = context->paramOut_next_armMarker;
		event = (DSPEEvent*) ParticleTrackerDllNextGate_SignalGate_allocate(context->paramOut_next_pool);
		event->refCount = 1;
		if (insert == NULL)
			context->paramOut_next_place = event;
		else
			insert->next = event;
		context->paramOut_next_armMarker = event;
		break;
	}
}

/* RealUnit Post Function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_postEventRealProd(DSPEEventsUnit *unit, unsigned int ID) {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context = (ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd*) unit;
	ParticleTrackerDllLibraryDataWriter_StateImplementation *implState = &context->implState;
	DSPEEvent *event = NULL;

	switch (ID) {
	case pOut_next_event:
		/* If gate is unlinked no event will be sent */
		if (implState->paramOut_next_numLinks == 0)
			return;
		event = context->paramOut_next_place;
		if (event == NULL)
			return;
		context->paramOut_next_place = event->next;
		if (context->paramOut_next_place == NULL)
			context->paramOut_next_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
		break;
	}

}

/* Initialize gate values */
static INLINE void initValues(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllLibraryDataWriter_StateImplementation *implState = &context->implState;
	ParticleTrackerDllTrajectory_MessageGate_initializeUnlinked((DSPEElement*) context, context->dataIn_Trajectory_unlinked);
	implState->dataIn_Trajectory = context->dataIn_Trajectory_unlinked;

}

/******************************************************************************
 * COMMON UNIT FUNCTIONS
 ******************************************************************************/

/* Earlyalloc function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_earlyAllocRealProd(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context) {
	ParticleTrackerDllLibraryDataWriter_StateImplementation *implState = &context->implState;

	initDSPEElement((DSPEElement*) &context->implState, (DSPEElement*) context);
	initDSPEQueueUnit((DSPEQueueUnit*) context);
	((DSPEComponent*) context)->preprocess = ParticleTrackerDllLibraryDataWriter_SoftwareUnit_preProcessRealProd;
	((DSPEComponent*) context)->process = ParticleTrackerDllLibraryDataWriter_SoftwareUnit_processRealProd;
	((DSPEComponent*) context)->postprocess = ParticleTrackerDllLibraryDataWriter_SoftwareUnit_postProcessRealProd;

	/* Implementation AdditionalStateVariables initialization */
	implState->functionalState.receivedTrajectories = 0;
	implState->functionalState.lastFrameProcessed = 0;
}

/* Alloc function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_allocRealProd(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context) {
	const DSPEOwner *owner = ((DSPEElement*) context)->owner;

	/* Base alloc() function call */
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_alloc(&context->baseState);

	((DSPEEventsUnit*) context)->armEvent = ParticleTrackerDllLibraryDataWriter_SoftwareUnit_armEventRealProd;
	((DSPEEventsUnit*) context)->postEvent = ParticleTrackerDllLibraryDataWriter_SoftwareUnit_postEventRealProd;
	initQueue(context);
	((DSPEQueueUnit*) context)->transitEvent = ParticleTrackerDllLibraryDataWriter_SoftwareUnit_transitEventRealProd;
	((DSPEQueueUnit*) context)->getTransitNumElements = ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getTransitNumElementsRealProd;
	((DSPEQueueUnit*) context)->getCurrentNumElements = ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getCurrentNumElementsRealProd;
	((DSPEQueueUnit*) context)->dismissEvent = ParticleTrackerDllLibraryDataWriter_SoftwareUnit_dismissEventRealProd;
	((DSPEQueueUnit*) context)->getFirstTransitEvent = ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getFirstTransitRealProd;
	((DSPEQueueUnit*) context)->getCurrentTransitEvent = ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getCurTransitRealProd;
	/* Initializing event Hooks and Inserts */
	context->paramOut_next_place = NULL;
	context->paramOut_next_armMarker = NULL;

	/* Initialize eventPools for parameter gates */
	context->paramOut_next_pool = ParticleTrackerDllNextGate_SignalGate_initPool(owner);

	/* Allocate unlinked places for input event gates */
	context->dataIn_Trajectory_unlinked = ParticleTrackerDllTrajectory_MessageGate_allocateUnlinked((DSPEElement*) context);

}

/* Earlyconnect function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_earlyConnectRealProd(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllLibraryDataWriter_StateImplementation *implState = &context->implState;

	/* Implementation output parameters gates initialization */
	implState->paramOut_stop = ((ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) context)->paramOut_stop_place;


	/* Base earlyconnect() function call */
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_earlyConnect(&context->baseState);

}

/* Connect function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_connectRealProd(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllLibraryDataWriter_StateImplementation *implState = &context->implState;

	/* Implementation input parameters gates initialization */
	implState->paramIn_FoundTrajectories = ((ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) context)->paramIn_FoundTrajectories;

	/* Implementation gates numLinks initialization */
	implState->dataIn_Trajectory_numLinks = ((ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) context)->dataIn_Trajectory_numLinks;
	implState->paramIn_LastFrameProcessed_numLinks = ((ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) context)->paramIn_LastFrameProcessed_numLinks;
	implState->paramIn_FoundTrajectories_numLinks = ((ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) context)->paramIn_FoundTrajectories_numLinks;
	implState->paramOut_next_numLinks = ((ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) context)->paramOut_next_numLinks;
	implState->paramOut_stop_numLinks = ((ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) context)->paramOut_stop_numLinks;

}

/* Startup function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_startupRealProd(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context) {
	/* Initialize gate values */
	initValues(context);



	/* Implementation startup() call */
	ParticleTrackerDllLibraryDataWriter_StateImplementation_startup(&context->implState);

}

/* Preprocess function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_preProcessRealProd(DSPEComponent *component) {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context = (ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd*) component;

	/* Implementation preprocess() call */
	ParticleTrackerDllLibraryDataWriter_StateImplementation_preProcess(&context->implState);

}

/* Process function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_processRealProd(DSPEComponent *component) {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context = (ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd*) component;
	/* Implementation state local variable initialization */
	ParticleTrackerDllLibraryDataWriter_StateImplementation *implState = &context->implState;

	/* Implementation process() call */
	ParticleTrackerDllLibraryDataWriter_StateImplementation_process(implState);


	/* Restore unlinked pointers on unitBehaviour */
	if (implState->dataIn_Trajectory != context->dataIn_Trajectory_unlinked)
		implState->dataIn_Trajectory = context->dataIn_Trajectory_unlinked;
	/* Release event */
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_releaseEvent((ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) context);
}

/* Postprocess function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_postProcessRealProd(DSPEComponent *component) {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context = (ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd*) component;

	/* Move all events from transitQueue back to their related pool */
	resetQueue(context);

	/* Base postprocess() function call */
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_postProcess(&context->baseState);
}

/* Reset function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_resetRealProd(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context) {
	ParticleTrackerDllLibraryDataWriter_StateImplementation *implState = &context->implState;

	/* Base reset() function call */
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_reset(&context->baseState);

	/* Initialize gate values */
	initValues(context);

	/* Implementation AdditionalStateVariables initialization */
	implState->functionalState.receivedTrajectories = 0;
	implState->functionalState.lastFrameProcessed = 0;
}

/* Shutdown function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_shutdownRealProd(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context) {
	/* Implementation shutdown() call */
	ParticleTrackerDllLibraryDataWriter_StateImplementation_shutdown(&context->implState);

	/* Base shutdown() function call */
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_shutdown(&context->baseState);

	/* Dispose unlinked places for input event gates */
	ParticleTrackerDllTrajectory_MessageGate_disposeUnlinked((DSPEElement*) context, context->dataIn_Trajectory_unlinked);

}

