/**
 * File: S_ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef S_ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_h
#define S_ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_h

#include "PlatformManager.h"
#include "MemoryManager.h"
#include "CoprocManager.h"
#include "ProfileManager.h"

#include "B_ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation.h"

/* CoprocEvent ID */
#define pIn_Coproc_event 100

/* Input EventGate IDs */
#define pIn_next_event 1000
#define dIn_PTFrame_event 1001

#define pOut_next_event 1000
#define dOut_PTFrame_event 1001

#ifdef __cplusplus
extern "C" {
#endif

static INLINE int isEventAvailable(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	return unit->isEventAvailable(unit);
}

static INLINE unsigned int getEventID(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	return unit->getEventID(unit);
}

/* Move inputEvent to specific transitQueue */
static INLINE void transitEvent(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	unit->transitEvent(unit);
}

static INLINE void getDE_PTFrame(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
	// TODO utilizzare l'ID della gate, rispettivamente l'index per le GroupGates per verificare che il valore rischiesto sia quello dell'evento in coda
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	DSPEEvent *event = unit->getEvent(unit);
	if (event == NULL)
		return; /* notify error here */
	context->dataIn_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value;
}

static INLINE size_t getTransitNumElementsDE_PTFrame(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
	// TODO utilizzare l'ID della gate, rispettivamente l'index per le GroupGates per verificare che il valore richiesto sia quello dell'evento in coda
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	return unit->getTransitNumElements(unit, dIn_PTFrame_event);
}

static INLINE void getFirstTransitDE_PTFrame(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
	// TODO utilizzare l'ID della gate, rispettivamente l'index per le GroupGates per verificare che il valore richiesto sia quello dell'evento in coda
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	unit->getFirstTransitEvent(unit, dIn_PTFrame_event );
}

static INLINE size_t getCurrentNumElementsDE_PTFrame(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
	// TODO utilizzare l'ID della gate, rispettivamente l'index per le GroupGates per verificare che il valore richiesto sia quello dell'evento in coda
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	return unit->getCurrentNumElements(unit, dIn_PTFrame_event);
}

static INLINE void getCurTransitDE_PTFrame(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	unit->getCurrentTransitEvent(unit, dIn_PTFrame_event);
}

static INLINE void dismissDE_PTFrame(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
	//TODO valutare possibilita' di un unico dismiss
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	unit->dismissEvent(unit, dIn_PTFrame_event);
}

/* SignalGate send advanced */
static INLINE void sendPE_next(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
	DSPEEventsUnit *unit = (DSPEEventsUnit*) ((DSPEElement*) context)->container;
	if (unit->sendEvent == NULL)
		return;
	unit->armEvent(unit, pOut_next_event);
	unit->postEvent(unit, pOut_next_event);
}
static INLINE void armDE_PTFrame(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
	DSPEEventsUnit *unit = (DSPEEventsUnit*) ((DSPEElement*) context)->container;
	if (unit->armEvent == 0)
		return;
	unit->armEvent(unit, dOut_PTFrame_event);
}

/* Forward send request to unit */
static INLINE void sendDE_PTFrame(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
	DSPEEventsUnit *unit = (DSPEEventsUnit*) ((DSPEElement*) context)->container;
	if (unit->sendEvent == NULL)
		return;
	unit->postEvent(unit, dOut_PTFrame_event);
}

// COPROCESSOR SUPPORT

static INLINE int isCoprocFull(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
	return coprocManager_isAboveMaxThreshold(context->opQueue);
}

static INLINE void queueOp(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context, DSPEOp *op) {
	coprocManager_addOpToInQueue(context->opQueue, op);
	context->opsBusy++;
}

static INLINE DSPEOp* getProcessedOp(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
	// TODO utilizzare l'ID della gate, rispettivamente l'index per le GroupGates per verificare che il valore rischiesto sia quello dell'evento in coda
	DSPEOp* op = NULL;
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	DSPECoprocEvent *event = (DSPECoprocEvent*) unit->getEvent(unit);
	op = event->op;
	context->curOp = (ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op*) op;
	return op;
}

/**
 * doProcessing function.
 */
static void ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_doProcessing(DSPEOp *op) {
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op *context = (ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op*) op;
	register size_t i;

	/* Data gate anchors */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues_anchor = context->dataIn_SequenceValues;
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame_anchor = context->dataIn_PTFrame;
	ParticleTrackerDllMaskGate_PointerGate *dataOut_Mask_anchor = context->dataOut_Mask;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame_anchor = context->dataOut_PTFrame;

	/* Capture unit process start time */
	profileManager_captureStartTime((DSPEElement*) op, (profileID) ((DSPEProfileCoprocOp*) op)->unitProfileID);

	/* call process according samplesToProcess */
	for (i = 0; i < context->blockSize; i++) {
		/* Call process function */
		ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_process(context);

		/* Increment data pointers to process each sample */
		context->dataIn_SequenceValues++;
		context->dataIn_PTFrame++;
		context->dataOut_Mask++;
		context->dataOut_PTFrame++;
	}
	/* Capture unit process end time */
	profileManager_captureEndTime((DSPEElement*) op, (profileID) ((DSPEProfileCoprocOp*) op)->unitProfileID);


	/* Data gate anchors restore */
	context->dataIn_SequenceValues = dataIn_SequenceValues_anchor;
	context->dataIn_PTFrame = dataIn_PTFrame_anchor;
	context->dataOut_Mask = dataOut_Mask_anchor;
	context->dataOut_PTFrame = dataOut_PTFrame_anchor;
}

/* Coprocessor initialization */
static INLINE void initOp(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState, ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op *context) {
	/* CoprocOp persistent state initialization */
	context->persistent = implState->persistent;

}

/* Create op */
static INLINE ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op* createOp(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
	DSPECoprocUnit *unit = (DSPECoprocUnit*) ((DSPEElement*) context)->container;
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op *newOp = NULL;

	newOp = (ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op*) memoryManager_allocate((DSPEElement*) context, sizeof(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op));
	initDSPECoprocOp((DSPEElement*) context, (DSPECoprocOp*) newOp);
	unit->initOp(unit, (DSPEOp*) newOp);
	/* Initialize additional state if present */
	initOp(context, newOp);
	/* Container of op has to be the Unit */
	initDSPEElement((DSPEElement*) newOp, (DSPEElement*) unit);
	/* Install execute function pointer */
	((DSPEOp*) newOp)->execute = ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_doProcessing;
	/* Allocate non event parameter gates */
	newOp->paramIn_Radius = (ParticleTrackerDllIntGate_StandardGate*) memoryManager_allocate((DSPEElement*) context, sizeof(ParticleTrackerDllIntGate_StandardGate));
	newOp->paramOut_Status = (ParticleTrackerDllStatusGate_StringGate*) memoryManager_allocate((DSPEElement*) context, sizeof(ParticleTrackerDllStatusGate_StringGate));

	/* Allocate non event data gates */
	newOp->dataIn_SequenceValues = (ParticleTrackerDllSequenceValuesGate_PointerGate*) memoryManager_allocate((DSPEElement*) context, newOp->blockSize * sizeof(ParticleTrackerDllSequenceValuesGate_PointerGate));
	newOp->dataOut_Mask = (ParticleTrackerDllMaskGate_PointerGate*) memoryManager_allocate((DSPEElement*) context, newOp->blockSize * sizeof(ParticleTrackerDllMaskGate_PointerGate));

	/* Initialize profile variables */
	((DSPEProfileCoprocOp*) newOp)->profileQueue = profileManager_initProfileQueue((DSPEElement*) context);
	((DSPEProfileCoprocOp*) newOp)->unitProfileID = (int) profileSupport_getUnitProfileID(((DSPEElement*) context)->getID((DSPEElement*) context));

	return newOp;
}

/* Destroy op */
static INLINE void destroyOp(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op *op) {
	DSPEProfileCoprocOp *coprocOp = NULL;

	/* Dispose allocated non event gates */
	memorySupport_dispose(op->dataIn_SequenceValues);
	memorySupport_dispose(op->dataOut_Mask);
	memorySupport_dispose(op->paramIn_Radius);
	memorySupport_dispose(op->paramOut_Status);

	/* Dispose profile queue */
	coprocOp = (DSPEProfileCoprocOp*) op;
	profileManager_disposeProfileQueue((DSPEElement*) op, coprocOp->profileQueue);
	coprocOp->profileQueue = NULL;
	disposeDSPECoprocOp((DSPECoprocOp*) op);
	memorySupport_dispose(op);
}

// OPBUFFER SUPPORT
/* Return an empty op */
static INLINE ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op* getEmptyOp(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op *currentOp = NULL;
	DSPECoprocUnit *unit = (DSPECoprocUnit*) ((DSPEElement*) context)->container;

	if (context->opPoolNumElements == 0) {
		currentOp = createOp(context);
		currentOp->processed = 0;
	} else if (context->opPoolNumElements == 1) {
		currentOp = context->opPoolHead;
		context->opPoolHead = NULL;
		context->opPoolTail = NULL;
		context->opPoolNumElements = 0;
	} else {
		currentOp = context->opPoolHead;
		context->opPoolHead = currentOp->next;
		context->opPoolNumElements--;
	}

	currentOp->next = NULL;
	// REMARK: Initialize op's blockSize. Called here to be able to init the op's
	// blockSize when the variable blockSize is enabled (within CoprocScheduler).
	// Cannot call conditionally since no info is available.
	unit->initOp(unit, (DSPEOp*) currentOp);

	if (context->opBufferNumElements == 0) {
		context->opBufferHead = currentOp;
		context->opBufferTail = currentOp;
		context->opBufferNumElements = 1;
	} else {
		context->opBufferTail->next = currentOp;
		context->opBufferTail = currentOp;
		context->opBufferNumElements++;
	}
	return currentOp;
}

/* Return the first buffered op if it can be released, 0 otherwise */
static INLINE ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op* getBufferedOp(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
	if (context->opBufferNumElements == 0)
		return NULL;
	else if (context->opBufferHead->processed == 1)
		return context->opBufferHead;
	else
		return NULL;
}

/* Return the next op or NULL if the buffer is empty */
static INLINE ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op* getNextOp(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
	if (context->opBufferNumElements == 0)
		return NULL;
	else
		return context->opBufferHead;
}

/* Release op */
static INLINE void releaseOp(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context, ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op *coprocOp) {
	if (context->opBufferHead != coprocOp)
		return;
	context->opsBusy--;
	if (context->opBufferNumElements == 1) {
		context->opBufferHead = NULL;
		context->opBufferTail = NULL;
		context->opBufferNumElements = 0;
	} else {
		context->opBufferHead = coprocOp->next;
		context->opBufferNumElements--;
	}
	coprocOp->next = NULL;
	coprocOp->processed = 0;

	if (context->opPoolNumElements == 0) {
		context->opPoolHead = coprocOp;
		context->opPoolTail = coprocOp;
		context->opPoolNumElements = 1;
	} else {
		context->opPoolTail->next = coprocOp;
		context->opPoolTail = coprocOp;
		context->opPoolNumElements++;
	}
}

/* TransferAllGatesOnOp function */
static INLINE void transferAllGatesOnOp(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState) {
	/* Set context to currentOp */
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op *context = implState->curOp;
	/* Load input data gates */
	context->dataIn_PTFrame = implState->dataIn_PTFrame;
	/* Load output data gates */
	context->dataOut_PTFrame = implState->dataOut_PTFrame;
	/* Load output non event parameter gates */
	memorySupport_copyBlock(context->paramIn_Radius, implState->paramIn_Radius, sizeof(ParticleTrackerDllIntGate_StandardGate));
	memorySupport_copyBlock(context->paramOut_Status, implState->paramOut_Status, sizeof(ParticleTrackerDllStatusGate_StringGate));
	/* Load output non event data gates */
	memorySupport_copyBlock(context->dataIn_SequenceValues, implState->dataIn_SequenceValues, context->blockSize * sizeof(ParticleTrackerDllSequenceValuesGate_PointerGate));
	memorySupport_copyBlock(context->dataOut_Mask, implState->dataOut_Mask, context->blockSize * sizeof(ParticleTrackerDllMaskGate_PointerGate));
}

#ifdef __cplusplus
} /* extern "C" */
#endif

#undef pIn_Coproc_event

#undef pIn_next_event
#undef dIn_PTFrame_event
#undef pOut_next_event
#undef dOut_PTFrame_event

#endif
