/**
 * File: B_ParticleTrackerDllPTFilteredGate_MessageGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef B_ParticleTrackerDllPTFilteredGate_MessageGate_h
#define B_ParticleTrackerDllPTFilteredGate_MessageGate_h

#include "DSPEXTElements.h"
#include "MemoryGround.h"

#include "B_ParticleTrackerDllTracker_Requirement.h"


#define PARTICLETRACKERDLLPTFILTEREDGATE_MESSAGEGATE_TYPECATEGORY "Message"
#define PARTICLETRACKERDLLPTFILTEREDGATE_MESSAGEGATE_DEFAULTVALUE 0

typedef PTFiltered* ParticleTrackerDllPTFilteredGate_MessageGate;


/* EventGate state type definition */
typedef struct ParticleTrackerDllPTFilteredGate_MessageGate_event ParticleTrackerDllPTFilteredGate_MessageGate_event;

/* EventGate state definition */
struct ParticleTrackerDllPTFilteredGate_MessageGate_event {
	DSPEEvent event;

	ParticleTrackerDllPTFilteredGate_MessageGate *value;
	ParticleTrackerDllPTFilteredGate_MessageGate anchor;
};

/* Event clone state type definition */
typedef struct ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent;

/* Event clone state definition */
struct ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent {
	ParticleTrackerDllPTFilteredGate_MessageGate_event event;

	DSPEEvent *original;
};

/* EventGate pool type definition */
typedef struct ParticleTrackerDllPTFilteredGate_MessageGate_pool ParticleTrackerDllPTFilteredGate_MessageGate_pool;

/* EventGate pool definition */
struct ParticleTrackerDllPTFilteredGate_MessageGate_pool {
	DSPEBaseEventsPool pool;

	// Pool for events
	size_t eventNumElements;
	ParticleTrackerDllPTFilteredGate_MessageGate_event *headEvent;
	ParticleTrackerDllPTFilteredGate_MessageGate_event *tailEvent;

	// Pool for clones
	size_t cloneNumElements;
	ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent *headClone;
	ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent *tailClone;
};


/* GroupEventGate state type definition */
typedef struct ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent;

/* GroupEventGate state definition */
struct ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent {
	DSPEGroupEvent event;

	ParticleTrackerDllPTFilteredGate_MessageGate **value;
	ParticleTrackerDllPTFilteredGate_MessageGate *anchor;
};

/* GroupEvent clone state type definition */
typedef struct ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupEvent ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupEvent;

/* GroupEvent clone state definition */
struct ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupEvent {
	ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent event;

	DSPEGroupEvent *original;
};

/* GroupEvent container state type definition */
typedef struct ParticleTrackerDllPTFilteredGate_MessageGate_eventContainer ParticleTrackerDllPTFilteredGate_MessageGate_eventContainer;

/* GroupEvent container state definition */
struct ParticleTrackerDllPTFilteredGate_MessageGate_eventContainer {
	ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent event;

	DSPEEvent **containedEvents;
};

/* GroupEventGate pool type definition */
typedef struct ParticleTrackerDllPTFilteredGate_MessageGate_groupPool ParticleTrackerDllPTFilteredGate_MessageGate_groupPool;

/* GroupEventGate pool definition */
struct ParticleTrackerDllPTFilteredGate_MessageGate_groupPool {
	DSPEGroupEventsPool pool;

	/* Pool for Events */
	size_t eventNumElements;
	ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent *headEvent;
	ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent *tailEvent;
	
	/* Pool for Clones */
	size_t cloneNumElements;
	ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupEvent *headClone;
	ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupEvent *tailClone;
	
	/* Pool for EventContainers */
	size_t containerNumElements;
	ParticleTrackerDllPTFilteredGate_MessageGate_eventContainer *headContainer;
	ParticleTrackerDllPTFilteredGate_MessageGate_eventContainer *tailContainer;
};

/* EventGate node type definition */
typedef struct ParticleTrackerDllPTFilteredGate_MessageGate_node ParticleTrackerDllPTFilteredGate_MessageGate_node; 

/* EventGate node definition */ 
struct ParticleTrackerDllPTFilteredGate_MessageGate_node {
	DSPEGateNode node;

	ParticleTrackerDllPTFilteredGate_MessageGate *localVar;
	ParticleTrackerDllPTFilteredGate_MessageGate value;
	int sendEvent;
	unsigned int eventID;
	DSPEApplication *application;
	DSPEEventsPool *pool;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Allocate function */
ParticleTrackerDllPTFilteredGate_MessageGate ParticleTrackerDllPTFilteredGate_MessageGate_allocateValue(DSPEElement *context);

/* Initialise function */
void ParticleTrackerDllPTFilteredGate_MessageGate_initValue(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate data);

/* Copy function */
void ParticleTrackerDllPTFilteredGate_MessageGate_copyValue(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate destination, ParticleTrackerDllPTFilteredGate_MessageGate source);

/* Dispose function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeValue(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate data);

/* AllocateManaged function */
void ParticleTrackerDllPTFilteredGate_MessageGate_allocateManaged(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate *anchor);
/* InitManaged function */
void ParticleTrackerDllPTFilteredGate_MessageGate_initManaged(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate anchor);

/* DisposeManaged function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeManaged(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate anchor);

/* AllocateGroupManaged function */
void ParticleTrackerDllPTFilteredGate_MessageGate_allocateGroupManaged(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate **anchor, size_t size);
/* InitGroupManaged function */
void ParticleTrackerDllPTFilteredGate_MessageGate_initGroupManaged(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate **anchor, size_t size);

/* DisposeGroupManaged function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeGroupManaged(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate **anchor, size_t size);

/* eventPool initialization function */
ParticleTrackerDllPTFilteredGate_MessageGate_pool* ParticleTrackerDllPTFilteredGate_MessageGate_initPool(const DSPEOwner *owner);

/* eventPool preAlloc function */
void ParticleTrackerDllPTFilteredGate_MessageGate_preAllocPool(DSPEEventsPool *pool, size_t size);

/* eventPool reset function */
void ParticleTrackerDllPTFilteredGate_MessageGate_resetPool(DSPEEventsPool *pool);

/* Allocate function */
ParticleTrackerDllPTFilteredGate_MessageGate_event* ParticleTrackerDllPTFilteredGate_MessageGate_allocate(ParticleTrackerDllPTFilteredGate_MessageGate_pool *pool);

/* Create function */
void ParticleTrackerDllPTFilteredGate_MessageGate_create(ParticleTrackerDllPTFilteredGate_MessageGate_event *event);

/* Initialise function */
void ParticleTrackerDllPTFilteredGate_MessageGate_initialize(ParticleTrackerDllPTFilteredGate_MessageGate_event *event);

/**
 * Copy function
 */
void ParticleTrackerDllPTFilteredGate_MessageGate_copy(ParticleTrackerDllPTFilteredGate_MessageGate_event *event, ParticleTrackerDllPTFilteredGate_MessageGate value);

/* Clone event function */
DSPEEvent* ParticleTrackerDllPTFilteredGate_MessageGate_clone(DSPEEvent *event);

/* Dispose function */
void ParticleTrackerDllPTFilteredGate_MessageGate_dispose(DSPEEvent *event);

/* Dispose clone function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeClone(DSPEEvent *event);

/* Destroy function */
void ParticleTrackerDllPTFilteredGate_MessageGate_destroy(ParticleTrackerDllPTFilteredGate_MessageGate_event *event);

/* eventPool dispose function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposePool(DSPEEventsPool *pool);

/* Allocate function */
ParticleTrackerDllPTFilteredGate_MessageGate* ParticleTrackerDllPTFilteredGate_MessageGate_allocateUnlinked(DSPEElement *context);

/* Initialise function */
void ParticleTrackerDllPTFilteredGate_MessageGate_initializeUnlinked(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate *place);

/* Set function */
void ParticleTrackerDllPTFilteredGate_MessageGate_set(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate *place, ParticleTrackerDllPTFilteredGate_MessageGate *value);

/* Dispose function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeUnlinked(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate *place);

/* groupEventPool initialization function */
ParticleTrackerDllPTFilteredGate_MessageGate_groupPool* ParticleTrackerDllPTFilteredGate_MessageGate_initGroupPool(const DSPEOwner *owner, size_t groupSize);

/* eventPool preAlloc function */
void ParticleTrackerDllPTFilteredGate_MessageGate_preAllocGroupPool(DSPEEventsPool *pool, size_t size);

/* eventPool reset function */
void ParticleTrackerDllPTFilteredGate_MessageGate_resetGroupPool(DSPEEventsPool *pool);

/* AllocateGroup function */
ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent* ParticleTrackerDllPTFilteredGate_MessageGate_allocateGroup(ParticleTrackerDllPTFilteredGate_MessageGate_groupPool *grpPool);

/* CreateGroup function */
void ParticleTrackerDllPTFilteredGate_MessageGate_createGroup(ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent *event, size_t index);

/* InitialiseGroup function */
void ParticleTrackerDllPTFilteredGate_MessageGate_initializeGroup(ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent *event, size_t index);

/**
 * Copy function
 */
void ParticleTrackerDllPTFilteredGate_MessageGate_copyGroup(ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent *event, ParticleTrackerDllPTFilteredGate_MessageGate value, size_t index);

/* CloneGroup event function */
DSPEEvent* ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroup(DSPEEvent *event);

/* SubClone event function */
DSPEEvent* ParticleTrackerDllPTFilteredGate_MessageGate_subClone(DSPEGroupEvent *event, DSPEEventsPool *pool, size_t index);

/**
 * Allocate containerEvent function
 */
ParticleTrackerDllPTFilteredGate_MessageGate_eventContainer* ParticleTrackerDllPTFilteredGate_MessageGate_allocateContainer(ParticleTrackerDllPTFilteredGate_MessageGate_groupPool *grpPool);

/**
 * Dispose containerEvent function
 */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeContainer(DSPEEvent *event);

/* DisposeGroup function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeGroup(DSPEEvent *event);

/* Dispose GroupClone function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeGroupClone(DSPEEvent *event);

/* DestroyGroup function */
void ParticleTrackerDllPTFilteredGate_MessageGate_destroyGroup(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent *event);

/* eventPool dispose function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeGroupPool(DSPEEventsPool *pool);

/* CreateNode function */
ParticleTrackerDllPTFilteredGate_MessageGate_node* ParticleTrackerDllPTFilteredGate_MessageGate_createNode(ParticleTrackerDllPTFilteredGate_MessageGate *localVar, DSPEApplication *application, DSPEEventsPool *pool, unsigned int eventID);

/* DisposeNode function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeNode(DSPEElement *context, DSPEGateNode *node);

/* SetValue function */
void ParticleTrackerDllPTFilteredGate_MessageGate_setValue(DSPEElement *context, DSPEGateNode *node);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
