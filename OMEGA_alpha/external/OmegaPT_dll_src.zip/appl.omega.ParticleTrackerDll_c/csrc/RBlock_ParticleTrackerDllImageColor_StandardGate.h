/**
 * File: RBlock_ParticleTrackerDllImageColor_StandardGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef RBlock_ParticleTrackerDllImageColor_StandardGate_h
#define RBlock_ParticleTrackerDllImageColor_StandardGate_h

#include "B_ParticleTrackerDllImageColor_StandardGate.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Allocate function */
ParticleTrackerDllImageColor_StandardGate* ParticleTrackerDllImageColor_StandardGate_allocateBlock(DSPEElement *context, size_t size);

/* Initialise function */
void ParticleTrackerDllImageColor_StandardGate_initializeBlock(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate *place, size_t size);

/* SetOverrideBlock function */
void ParticleTrackerDllImageColor_StandardGate_setOverrideBlock(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate *place, size_t size, ParticleTrackerDllImageColor_StandardGate value);

/* SetBlock function */
void ParticleTrackerDllImageColor_StandardGate_setBlock(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate *place, size_t size, ParticleTrackerDllImageColor_StandardGate *value);

/* Dispose function */
void ParticleTrackerDllImageColor_StandardGate_disposeBlock(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate *place);

/* AllocateGroup function */
void ParticleTrackerDllImageColor_StandardGate_allocateGroupBlock(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate **place, size_t groupSize, size_t *gateSize);

/* InitialiseGroup function */
void ParticleTrackerDllImageColor_StandardGate_initializeGroupBlock(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate **place, size_t groupSize, size_t *gateSize);

/* SetOverrideGroupBlock function */
void ParticleTrackerDllImageColor_StandardGate_setOverrideGroupBlock(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllImageColor_StandardGate value);

/* SetGroupBlock function */
void ParticleTrackerDllImageColor_StandardGate_setGroupBlock(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllImageColor_StandardGate **value);

/* DisposeGroup function */
void ParticleTrackerDllImageColor_StandardGate_disposeGroupBlock(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate **place, size_t size);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
