/**
 * File: B_ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef B_ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_h
#define B_ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_h

#include "DSPEXTElements.h"

#include "MemoryGround.h"

#include "RProd_ParticleTrackerDllLibraryDataReader_SoftwareUnit.h"
#include "RProd_ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit.h"
#include "RProd_ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit.h"
#include "RProd_ParticleTrackerDllFindThresholdCP_SoftwareUnit.h"
#include "RProd_ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit.h"
#include "RProd_ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit.h"
#include "RProd_ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit.h"
#include "RProd_ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit.h"
#include "RProd_ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit.h"
#include "RProd_ParticleTrackerDllLibraryDataWriter_SoftwareUnit.h"

/* Queue node type definition */
typedef struct ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_queueNode ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_queueNode;

/* Queue node type definition */
struct ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_queueNode {
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_queueNode *next;
	DSPEComponent *component;
};

/* Scheduler state type definition */
typedef struct ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler;

/* Scheduler state definition */
struct ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler {

	DSPECoprocScheduler coprocScheduler;

	// Used to resume the container only once, even if 2 or more events are sent outside at the same time
	unsigned int resumeContainer;

	/* Scheduler Queue */
	unsigned int poolNumNodes;
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_queueNode *poolHead;
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_queueNode *poolTail;

	unsigned int queueNumNodes;
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_queueNode *queueHead;
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_queueNode *queueTail;
	/* Ops Queue */
	DSPEOpOutQueue *outQueue;

	/* External events pool and queue */
	DSPEExternalEventsQueue *externalEventsPool;
	DSPEExternalEventsQueue *externalEventsQueue;

	/* Units */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_realProd LibraryDataReader;
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_realProd ConvolveAllCaseCP_PUSH;
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_realProd DilateAllCaseCP_PUSH;
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_realProd FindThresholdCP;
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_realProd FindParticlesCPNewAutoNext_PUSH_2;
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realProd PositionRefinementCP_PUSH_2;
	ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_realProd ParticlesDiscriminationStateCP_PUSH;
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_realProd LinkParticlesStateCPAutoNext_PUSH;
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_realProd GenerateTrajectoriesStateCPAutoNextNew_PUSH;
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd LibraryDataWriter;

	/* NamePrefix for Bypass Units */
	char *namePrefix;

	/* Local pointer to coprocEvents pool located on DSPEPoolHandler */
	DSPECoprocEventsPool *coprocEventsPool;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendDilateAllCaseCP_PUSHEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID);

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendConvolveAllCaseCP_PUSHEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID);

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendLinkParticlesStateCPAutoNext_PUSHEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID);

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendGenerateTrajectoriesStateCPAutoNextNew_PUSHEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID);

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendFindParticlesCPNewAutoNext_PUSH_2Event(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID);

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendPositionRefinementCP_PUSH_2Event(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID);

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendParticlesDiscriminationStateCP_PUSHEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID);

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendLibraryDataWriterEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID);

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendLibraryDataReaderEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID);

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendFindThresholdCPEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID);

DSPEOpOutQueue* ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_getOutQueue(const DSPECoprocScheduler *scheduler);

int ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_isIdle(const DSPEScheduler *scheduler);

/* Earlyalloc function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_earlyAlloc(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context);

/* Alloc function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_alloc(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context);

/* Earlyconnect function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_earlyConnect(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context);

/* Connect function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_connect(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context);

/* Startup function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_startup(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context);

/* Preprocess function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_preProcess(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context);

/* Process function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_process(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context);

/* Postprocess function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_postProcess(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context);

/* Reset function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_reset(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context);

/* Shutdown function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_shutdown(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
