/**
 * File: RBlock_ParticleTrackerDllIntGate_StandardGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef RBlock_ParticleTrackerDllIntGate_StandardGate_h
#define RBlock_ParticleTrackerDllIntGate_StandardGate_h

#include "B_ParticleTrackerDllIntGate_StandardGate.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Allocate function */
ParticleTrackerDllIntGate_StandardGate* ParticleTrackerDllIntGate_StandardGate_allocateBlock(DSPEElement *context, size_t size);

/* Initialise function */
void ParticleTrackerDllIntGate_StandardGate_initializeBlock(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate *place, size_t size);

/* SetOverrideBlock function */
void ParticleTrackerDllIntGate_StandardGate_setOverrideBlock(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate *place, size_t size, ParticleTrackerDllIntGate_StandardGate value);

/* SetBlock function */
void ParticleTrackerDllIntGate_StandardGate_setBlock(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate *place, size_t size, ParticleTrackerDllIntGate_StandardGate *value);

/* Dispose function */
void ParticleTrackerDllIntGate_StandardGate_disposeBlock(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate *place);

/* AllocateGroup function */
void ParticleTrackerDllIntGate_StandardGate_allocateGroupBlock(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t groupSize, size_t *gateSize);

/* InitialiseGroup function */
void ParticleTrackerDllIntGate_StandardGate_initializeGroupBlock(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t groupSize, size_t *gateSize);

/* SetOverrideGroupBlock function */
void ParticleTrackerDllIntGate_StandardGate_setOverrideGroupBlock(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllIntGate_StandardGate value);

/* SetGroupBlock function */
void ParticleTrackerDllIntGate_StandardGate_setGroupBlock(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllIntGate_StandardGate **value);

/* DisposeGroup function */
void ParticleTrackerDllIntGate_StandardGate_disposeGroupBlock(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t size);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
