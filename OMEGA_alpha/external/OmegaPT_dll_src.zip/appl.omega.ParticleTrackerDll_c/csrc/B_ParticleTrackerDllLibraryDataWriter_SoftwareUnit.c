/**
 * File: B_ParticleTrackerDllLibraryDataWriter_SoftwareUnit.c
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#include "PlatformManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "EngineManager.h"

#include "B_ParticleTrackerDllLibraryDataWriter_SoftwareUnit.h"

#define pIn_LastFrameProcessed_event 1000
#define dIn_Trajectory_event 1001

#define pOut_next_event 1000

static INLINE void initQueue(ParticleTrackerDllLibraryDataWriter_SoftwareUnit *unit) {
	unit->poolNumNodes = 0;
	unit->poolHead = NULL;
	unit->poolTail = NULL;

	unit->queueNumNodes = 0;
	unit->queueHead = NULL;
	unit->queueTail = NULL;

}

static INLINE void resetQueue(ParticleTrackerDllLibraryDataWriter_SoftwareUnit *unit) {
	// REMARK: avoid calling the installed release function because of possible
	// overriding implementations. Just need to release the event here.
	// TODO non esistono piu versioni sovrascritte!!
	while (unit->queueNumNodes != 0)
		ParticleTrackerDllLibraryDataWriter_SoftwareUnit_releaseEvent(unit);
}

static INLINE void disposeQueue(ParticleTrackerDllLibraryDataWriter_SoftwareUnit *unit) {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *node = unit->poolHead;
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *tmp = NULL;

	/* Dispose queueNodes in pool */
	while (node != NULL) {
		tmp = node->next;
		node->next = NULL;
		memorySupport_dispose(node);
		node = tmp;
	}
}

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID) {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit *context = (ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) unit;
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *node = NULL;
	
	switch (context->poolNumNodes) {
	case 0:
		node = (ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode*) memoryManager_allocate((DSPEElement*) context, sizeof(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode));
		node->nextInTransit = NULL;
		break;
	case 1:
		node = context->poolHead;
		context->poolHead = NULL;
		context->poolTail = NULL;
		context->poolNumNodes = 0;
		break;
	default:
		node = context->poolHead;
		context->poolHead = node->next;
		context->poolNumNodes--;
		break;
	}

	node->next = NULL;
	node->ID = ID;
	node->event = event;
	event->refCount++;

	if (context->queueNumNodes == 0) {
		context->queueHead = node;
		context->queueTail = node;
		context->queueNumNodes = 1;
	} else {
		context->queueTail->next = node;
		context->queueTail = node;
		context->queueNumNodes++;
	}
	node->inTransit = 0;
}

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_releaseEvent(ParticleTrackerDllLibraryDataWriter_SoftwareUnit *context) {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *node = context->queueHead;
	DSPEEvent *event = NULL;
	
	switch (context->queueNumNodes) {
	case 0:
		/* No events in queue */
		// REMARK: this could happen if we have idleTimeSequence and we want to re-schedule a unit
		return;
	case 1:
		context->queueHead = NULL;
		context->queueTail = NULL;
		context->queueNumNodes = 0;
		break;
	default:
		context->queueHead = node->next;
		context->queueNumNodes--;
		break;
	}

	node->next = NULL;

	/* REMARK:
	 * If node is in transit avoid disposing event and putting the node 
	 * back to pool. This will happen when user calls dismiss function 
	 */
	if (node->inTransit == 1)
		return;
	
	event = node->event;
	event->dispose(event);
	node->event = NULL;
	node->ID = 0;

	if (context->poolNumNodes == 0) {
		context->poolHead = node;
		context->poolTail = node;
		context->poolNumNodes = 1;
	} else {
		context->poolTail->next = node;
		context->poolTail = node;
		context->poolNumNodes++;
	}
}

int ParticleTrackerDllLibraryDataWriter_SoftwareUnit_isEventAvailable(const DSPEQueueUnit *unit) {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit *context = (ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) unit;
	return context->queueNumNodes != 0;
}

DSPEEvent* ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getEvent(const DSPEQueueUnit *unit) {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit *context = (ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) unit;
	return context->queueHead->event;
}

unsigned int ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getEventID(const DSPEQueueUnit *unit) {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit *context = (ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) unit;
	return context->queueHead->ID;
}

/* getID function */
char* ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getID(const DSPEElement *element) {
	return ((const ParticleTrackerDllLibraryDataWriter_SoftwareUnit*) element)->ID;
}

/* Initialize gate values */
static INLINE void initValues(ParticleTrackerDllLibraryDataWriter_SoftwareUnit *context) {
	/* Parameter Output gates initializazion */
	ParticleTrackerDllIntGate_StandardGate_initialize((DSPEElement*) context, context->paramOut_stop_place);
}

/* Alloc function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_alloc(ParticleTrackerDllLibraryDataWriter_SoftwareUnit *context) {
	((DSPEElement*) context)->getID = ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getID;
	initQueue(context);

	((DSPEEventsUnit*) context)->queueEvent = ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueEvent;
	((DSPEQueueUnit*) context)->isEventAvailable = ParticleTrackerDllLibraryDataWriter_SoftwareUnit_isEventAvailable;
	((DSPEQueueUnit*) context)->getEventID = ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getEventID;
	((DSPEQueueUnit*) context)->getEvent = ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getEvent;

	/* Output parameters places allocation */
	context->paramOut_stop_place = ParticleTrackerDllIntGate_StandardGate_allocate((DSPEElement*) context);

	/* Initialize gate values */
	initValues(context);
}

/* Earlyconnect function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_earlyConnect(ParticleTrackerDllLibraryDataWriter_SoftwareUnit *context) {
	/* Gates numLinks initialization */
	context->dataIn_Trajectory_numLinks = 0;
	context->paramIn_LastFrameProcessed_numLinks = 0;
	context->paramIn_FoundTrajectories_numLinks = 0;
	context->paramOut_next_numLinks = 0;
	context->paramOut_stop_numLinks = 0;


	/* Output parameters gates initialization */
	context->paramOut_stop = context->paramOut_stop_place;

}


/* Postprocess function
 * Remark: this function is not installed as pointer to function because it will be called
 * from either RealUnit's postProcess or BlockUnit's postProcess function.
 */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_postProcess(ParticleTrackerDllLibraryDataWriter_SoftwareUnit *context) {
	resetQueue(context);

}

/* Reset function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_reset(ParticleTrackerDllLibraryDataWriter_SoftwareUnit *context) {
	/* Initialize gate values */
	initValues(context);
}

/* Shutdown function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_shutdown(ParticleTrackerDllLibraryDataWriter_SoftwareUnit *context) {
	disposeQueue(context);

	/* Output parameters places dispose */
	ParticleTrackerDllIntGate_StandardGate_dispose((DSPEElement*) context, context->paramOut_stop_place);

	/* UnitID dispose */
	memorySupport_dispose(context->ID);
}

