/**
 * File: RBlock_ParticleTrackerDllSequenceValuesGate_PointerGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#include "MemoryManager.h"

#include "RBlock_ParticleTrackerDllSequenceValuesGate_PointerGate.h"

/* Allocate function */
ParticleTrackerDllSequenceValuesGate_PointerGate* ParticleTrackerDllSequenceValuesGate_PointerGate_allocateBlock(DSPEElement *context, size_t size) {
	return memoryManager_allocate(context, size * sizeof(ParticleTrackerDllSequenceValuesGate_PointerGate));
}

/* Initialise function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_initializeBlock(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate *place, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllSequenceValuesGate_PointerGate_initialize(context, &place[i]);
	}
}

/* SetOverrideBlock function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_setOverrideBlock(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate *place, size_t size, ParticleTrackerDllSequenceValuesGate_PointerGate value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllSequenceValuesGate_PointerGate_setOverride(context, &place[i], value);
	}
}

/* Set function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_setBlock(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate *place, size_t size, ParticleTrackerDllSequenceValuesGate_PointerGate *value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		place[i] = value[i]; 
	}
}

/* Dispose function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_disposeBlock(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate *place) {
	memorySupport_dispose(place);
}

/* AllocateGroup function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_allocateGroupBlock(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t groupSize, size_t *gateSize) {
	register size_t i;	
	for (i = 0; i < groupSize; i++) {
	 	place[i] = ParticleTrackerDllSequenceValuesGate_PointerGate_allocateBlock(context, gateSize[i]);	
	}
}

/* InitialiseGroup function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_initializeGroupBlock(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t groupSize, size_t *gateSize) {
	register size_t i;
	for (i = 0; i < groupSize; i++) {
		ParticleTrackerDllSequenceValuesGate_PointerGate_initializeBlock(context, place[i], gateSize[i]);
	}
}

/* SetOverrideGroupBlock function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_setOverrideGroupBlock(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllSequenceValuesGate_PointerGate value) {
	register size_t i;
	for (i = 0; i < groupSize; i++) {
		ParticleTrackerDllSequenceValuesGate_PointerGate_setOverrideBlock(context, place[i], gateSize[i], value);
	}
}

/* SetGroupBlock function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_setGroupBlock(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllSequenceValuesGate_PointerGate **value) {
	register size_t i;
	for (i = 0; i < groupSize; i++) {
		ParticleTrackerDllSequenceValuesGate_PointerGate_setBlock(context, place[i], gateSize[i], value[i]);
	}
}

/* DisposeGroup function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_disposeGroupBlock(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	memorySupport_dispose(place[i]);
	}
}

