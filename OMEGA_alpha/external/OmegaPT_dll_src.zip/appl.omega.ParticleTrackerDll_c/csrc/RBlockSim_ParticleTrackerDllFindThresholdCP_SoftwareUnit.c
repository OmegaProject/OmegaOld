/**
 * File: RBlockSim_ParticleTrackerDllFindThresholdCP_SoftwareUnit.c
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#include "PlatformManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "EngineManager.h"
#include "ProfileManager.h"
#include "CoprocManager.h"

#include "RBlockSim_ParticleTrackerDllFindThresholdCP_SoftwareUnit.h"

#include "S_ParticleTrackerDllFindThreshold_CoprocImplementation.h"

#define PENDING_EVENTS_MAX 10

/* NoEvent ID */
#define NOEVENT 10

#define dIn_PTFiltered_event 1000

#define dOut_PTThreshold_event 1000

/* CoprocEvent ID */
#define pIn_Coproc_event 100

/******************************************************************************
 * GATE AUTOMATION SUPPORT FUNCTIONS
 ******************************************************************************/

/**
 * loadAllTransitEvents function
 */
static INLINE void loadAllTransitEvents(ParticleTrackerDllFindThreshold_CoprocImplementation *implState) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) implState)->container;

	unit->getCurrentTransitEvent(unit, dIn_PTFiltered_event);
}

/**
 * armAllTransferEvents function
 */
static INLINE void armAllTransferEvents(ParticleTrackerDllFindThreshold_CoprocImplementation *implState) {
	DSPEEventsUnit *unit = (DSPEEventsUnit*) ((DSPEElement*) implState)->container;

	unit->armEvent(unit, dOut_PTThreshold_event);
}

/* Handle incoming event */
static INLINE void handleInputEvent(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context) {
	ParticleTrackerDllFindThreshold_CoprocImplementation *implState = &context->implState;

	/* Set currentOp by getting op from pool */
	implState->curOp = getEmptyOp(implState);
	loadAllTransitEvents(implState);
	armAllTransferEvents(implState);
	transferAllGatesOnOp(implState);
}

/**
 * dismissOp function
 */
static INLINE void dismissOp(ParticleTrackerDllFindThreshold_CoprocImplementation *implState) {
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context = (ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim*) ((DSPEElement*) implState)->container;
	/* Copy returning ops parameter value to implementation pointer */
	memorySupport_copyBlock(implState->paramIn_Percentile, implState->curOp->paramIn_Percentile, sizeof(ParticleTrackerDllRealGate_CustomGate));
	memorySupport_copyBlock(implState->paramOut_Status, implState->curOp->paramOut_Status, sizeof(ParticleTrackerDllStatusGate_StringGate));
	/* Copy returning ops data block to implementation pointer */
	memorySupport_copyBlock(implState->dataIn_SequenceValues, implState->curOp->dataIn_SequenceValues, implState->curOp->blockSize * sizeof(ParticleTrackerDllSequenceValuesGate_PointerGate));

	/* Merge profile info */
	profileManager_mergeQueue((DSPEElement*) implState, ((DSPEProfileCoprocOp*) implState->curOp)->profileQueue);


	/* Dismiss input events */
	((DSPEQueueUnit*) context)->dismissEvent((DSPEQueueUnit*) context, dIn_PTFiltered_event);

	/* AutomaticSend data events */
	((DSPEEventsUnit*) context)->postEvent((DSPEEventsUnit*) context, dOut_PTThreshold_event);
}

/******************************************************************************
 * OP BUFFER SUPPORT
 ******************************************************************************/

/**
 * Initialize opBuffer function
 */
static INLINE void initOpBuffer(ParticleTrackerDllFindThreshold_CoprocImplementation *implState) {
	implState->opPoolHead = NULL;
	implState->opPoolTail = NULL;
	implState->opPoolNumElements = 0;
	implState->opBufferHead = NULL;
	implState->opBufferTail = NULL;
	implState->opBufferNumElements = 0;
}

/**
 * Dispose opBuffer function
 */
static INLINE void disposeOpBuffer(ParticleTrackerDllFindThreshold_CoprocImplementation *implState) {
	ParticleTrackerDllFindThreshold_CoprocImplementation_op *currentOp = NULL;
	while (implState->opPoolNumElements > 0) {
		currentOp = implState->opPoolHead;
		implState->opPoolHead = currentOp->next;
		implState->opPoolNumElements--;
		currentOp->next = NULL;
		destroyOp(currentOp);
	}
	implState->opPoolHead = NULL;
	implState->opPoolTail = NULL;
	implState->opPoolNumElements = 0;
}

/**
 * Handle coproc event function
 */
static INLINE void handleCoprocEvent(ParticleTrackerDllFindThreshold_CoprocImplementation *implState) {
	ParticleTrackerDllFindThreshold_CoprocImplementation_op *currentOp = (ParticleTrackerDllFindThreshold_CoprocImplementation_op*) getProcessedOp(implState);
	currentOp->processed = 1;

	/* Remove processed coprocOp from buffer */
	currentOp = getBufferedOp(implState);
	while (currentOp != NULL) {
		/* Set current op */
		implState->curOp = currentOp;
		/* Call unit's dismissOp function */
		dismissOp(implState);
		releaseOp(implState, currentOp);
		currentOp = getBufferedOp(implState);
	}

	/* Restore unitBehaviour's currentOp to NULL */
	implState->curOp = NULL;
}

/**
 * Release opBuffer function
 */
static INLINE void releaseOpBuffer(ParticleTrackerDllFindThreshold_CoprocImplementation *implState) {
	ParticleTrackerDllFindThreshold_CoprocImplementation_op *currentOp = getNextOp(implState);
	while (currentOp != NULL) {
		implState->curOp = currentOp;
		releaseOp(implState, currentOp);
		currentOp = getNextOp(implState);
	}
}

/******************************************************************************
 * EVENT SUPPORT FUNCTIONS
 ******************************************************************************/

static INLINE void resetEventPlaces(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context) {
	DSPEEvent *event = NULL;
	context->dataOut_PTThreshold_armMarker = NULL;
	
	while (context->dataOut_PTThreshold_place != NULL) {
		event = (DSPEEvent*) context->dataOut_PTThreshold_place;
		context->dataOut_PTThreshold_place = event->next;
		/* force disposal */
		event->refCount = 1;
		event->dispose(event);
	}
}

static INLINE void initQueue(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *unit) {
	/* Data transit queues */
	unit->dataIn_PTFiltered_transitNumElements = 0;
	unit->dataIn_PTFiltered_transitHead = NULL;
	unit->dataIn_PTFiltered_transitTail = NULL;
	unit->dataIn_PTFiltered_curTransit = NULL;
	unit->dataIn_PTFiltered_curTransitIndex = 0;
	
}

static INLINE void resetQueue(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *unit) {
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_dismissAllEventsBlockSim((DSPEQueueUnit*) unit, dIn_PTFiltered_event);
}

/**
 * Transit input event function
 */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_transitEventBlockSim(DSPEQueueUnit *unit) {
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context = (ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim*) unit;
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode *node = ((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context)->queueHead;
	
	/* Prevent multiple transits */
	if (node->inTransit == 1)
		return;

	switch (node->ID) {
	case dIn_PTFiltered_event:
		if (context->dataIn_PTFiltered_transitNumElements == 0) {
			context->dataIn_PTFiltered_transitHead = node;
			context->dataIn_PTFiltered_transitTail = node;
			context->dataIn_PTFiltered_transitNumElements = 1;
		} else {
			context->dataIn_PTFiltered_transitTail->nextInTransit = node;
			context->dataIn_PTFiltered_transitTail = node;
			context->dataIn_PTFiltered_transitNumElements++;
		}
		/* set curTransit if needed */
		if (context->dataIn_PTFiltered_curTransit == NULL) {
			context->dataIn_PTFiltered_curTransit = node;
			context->dataIn_PTFiltered_curTransitIndex = 0;
		}
		context->dataIn_PTFiltered_curTransitIndex++;
		node->inTransit = 1;
		break;
	}
}

size_t ParticleTrackerDllFindThresholdCP_SoftwareUnit_getTransitNumElementsBlockSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context = (ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim*) unit;

	switch (ID) {
	case dIn_PTFiltered_event:
		return context->dataIn_PTFiltered_transitNumElements;
	}
	return 0;
}

size_t ParticleTrackerDllFindThresholdCP_SoftwareUnit_getCurrentNumElementsBlockSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context = (ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim*) unit;

	switch (ID) {
	case dIn_PTFiltered_event:
		return context->dataIn_PTFiltered_curTransitIndex;
	}
	return 0;
}

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_getFirstTransitBlockSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context = (ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim*) unit;
	ParticleTrackerDllFindThreshold_CoprocImplementation *implState = &context->implState;
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode *node = NULL;
	
	switch (ID) {
	case dIn_PTFiltered_event:
		node = context->dataIn_PTFiltered_transitHead;
		if (node == NULL)
			return;
		/* Set UnitBehaviour input gate pointer */
		implState->dataIn_PTFiltered = ((ParticleTrackerDllPTFilteredGate_MessageGate_event*) node->event)->value;
		break;
	}
}

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_getCurTransitBlockSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context = (ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim*) unit;
	ParticleTrackerDllFindThreshold_CoprocImplementation *implState = &context->implState;
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode *node = NULL;
	
	switch (ID) {
	case dIn_PTFiltered_event:
		node = context->dataIn_PTFiltered_curTransit;
		if (node == NULL)
			return;
		context->dataIn_PTFiltered_curTransit = node->nextInTransit;
		if (node->nextInTransit == NULL)
			context->dataIn_PTFiltered_curTransitIndex = 0;
		else
			context->dataIn_PTFiltered_curTransitIndex--;
		/* set implementation's gate pointer */
		implState->dataIn_PTFiltered = ((ParticleTrackerDllPTFilteredGate_MessageGate_event*) node->event)->value;
		break;
	}
}

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_dismissEventBlockSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context = (ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim*) unit;
	ParticleTrackerDllFindThreshold_CoprocImplementation *implState = (ParticleTrackerDllFindThreshold_CoprocImplementation*) &context->implState;
	DSPEEvent *event = NULL;
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode *node = NULL;

	switch (ID) {
	case dIn_PTFiltered_event:
		node = context->dataIn_PTFiltered_transitHead;
		if (context->dataIn_PTFiltered_transitNumElements == 1) {
			context->dataIn_PTFiltered_transitHead = NULL;
			context->dataIn_PTFiltered_transitTail = NULL;
			context->dataIn_PTFiltered_transitNumElements = 0;
		} else {
			context->dataIn_PTFiltered_transitHead = node->nextInTransit;
			context->dataIn_PTFiltered_transitNumElements--;
		}
		/* Set implementation pointer to secure unlinked place */
		implState->dataIn_PTFiltered = context->dataIn_PTFiltered_unlinked;
		break;
	}
	node->inTransit = 0;
	node->nextInTransit = NULL;
	
	// If node is the headNode within the queue let unitReleaseEvent do the disposal!
	if (node == ((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context)->queueHead)
		return;
	
	event = node->event;
	event->dispose(event);
	node->event = NULL;
	node->ID = 0;
	
	/* Move node to pool */
	if (((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context)->poolNumNodes == 0) {
		((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context)->poolHead = node;
		((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context)->poolTail = node;
		((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context)->poolNumNodes = 1;
	} else {
		((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context)->poolTail->next = node;
		((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context)->poolTail = node;
		((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context)->poolNumNodes++;
	}
}

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_dismissAllEventsBlockSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context = (ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim*) unit;

	switch (ID) {
	case dIn_PTFiltered_event:
		while (context->dataIn_PTFiltered_transitNumElements != 0)
			ParticleTrackerDllFindThresholdCP_SoftwareUnit_dismissEventBlockSim(unit, ID);
		/* Reset curTransit */
		context->dataIn_PTFiltered_curTransit = NULL;
		context->dataIn_PTFiltered_curTransitIndex = 0;
		break;
	}
}

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_armEventBlockSim(DSPEEventsUnit *unit, unsigned int ID) {
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context = (ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim*) unit;
	ParticleTrackerDllFindThreshold_CoprocImplementation *implState = &context->implState;

	register size_t i;
	DSPEEvent *event = NULL;
	DSPEEvent *insert = NULL;

	switch (ID) {
	case dOut_PTThreshold_event:
		insert = context->dataOut_PTThreshold_armMarker;
		if (insert == NULL) {
			if (context->dataOut_PTThreshold_place == NULL) {
				event = (DSPEEvent*) ParticleTrackerDllPTThresholdGate_MessageGate_allocateBlock(context->dataOut_PTThreshold_pool);
				event->refCount = 1;
				context->dataOut_PTThreshold_place = event;
				context->dataOut_PTThreshold_armMarker = event;
				implState->dataOut_PTThreshold = ((ParticleTrackerDllPTThresholdGate_MessageGate_event*) event)->value;
				/* create clones if needed */
				for (i = 0; i < context->dataOut_PTThreshold_factor - 1; i++) {
					insert = event;
					event = insert->clone(insert);
					event->refCount = 1;
					((ParticleTrackerDllPTThresholdGate_MessageGate_event*) event)->value += context->blockSize;
					/* append clone */
					insert->next = event;
				}
			} else {
				event = context->dataOut_PTThreshold_place;
				context->dataOut_PTThreshold_armMarker = event;
				implState->dataOut_PTThreshold = ((ParticleTrackerDllPTThresholdGate_MessageGate_event*) event)->value;
			}
		} else if (insert->next == NULL) {
			event = (DSPEEvent*) ParticleTrackerDllPTThresholdGate_MessageGate_allocateBlock(context->dataOut_PTThreshold_pool);
			event->refCount = 1;
			context->dataOut_PTThreshold_armMarker->next = event;
			context->dataOut_PTThreshold_armMarker = event;
			implState->dataOut_PTThreshold = ((ParticleTrackerDllPTThresholdGate_MessageGate_event*) event)->value;
			/* create clones if needed */
			for (i = 0; i < context->dataOut_PTThreshold_factor - 1; i++) {
				insert = event;
				event = insert->clone(insert);
				event->refCount = 1;
				((ParticleTrackerDllPTThresholdGate_MessageGate_event*) event)->value += context->blockSize;
				/* append clone */
				insert->next = event;
			}
		} else {
			/* use insert->next*/
			event = insert->next;
			context->dataOut_PTThreshold_armMarker = event;
			implState->dataOut_PTThreshold = ((ParticleTrackerDllPTThresholdGate_MessageGate_event*) event)->value;
		}
		break;
	}
}

/* BlockUnit Post Function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_postEventBlockSim(DSPEEventsUnit *unit, unsigned int ID) {
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context = (ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim*) unit;
	ParticleTrackerDllFindThreshold_CoprocImplementation *implState = &context->implState;
	DSPEEvent *event = NULL;
	switch (ID) {
	case dOut_PTThreshold_event:
		/* Restore save place to write */
		implState->dataOut_PTThreshold = context->dataOut_PTThreshold_unlinked;
		event = context->dataOut_PTThreshold_place;
		if (event == NULL)
			return;
		context->dataOut_PTThreshold_place = event->next;
		if (context->dataOut_PTThreshold_armMarker == event || context->dataOut_PTThreshold_place == NULL)
			context->dataOut_PTThreshold_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
		break;
	}

}

/**
 * InitOp function
 */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_initOpBlockSim(DSPECoprocUnit *unit, DSPEOp *op) {
	((ParticleTrackerDllFindThreshold_CoprocImplementation_op*) op)->blockSize = ((ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim*) unit)->samplesToProcess;
}

/* Initialize gate values */
static INLINE void initValues(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllFindThreshold_CoprocImplementation *implState = &context->implState;
	ParticleTrackerDllPTFilteredGate_MessageGate_initBlockManaged((DSPEElement*) context, context->dataIn_PTFiltered_unlinkedAnchor, context->blockSize);
	ParticleTrackerDllPTFilteredGate_MessageGate_setBlock((DSPEElement*) context, context->dataIn_PTFiltered_unlinked, context->blockSize, context->dataIn_PTFiltered_unlinkedAnchor);
	implState->dataIn_PTFiltered = context->dataIn_PTFiltered_unlinked;
	ParticleTrackerDllPTThresholdGate_MessageGate_initBlockManaged((DSPEElement*) context, context->dataOut_PTThreshold_unlinkedAnchor, context->blockSize);
	ParticleTrackerDllPTThresholdGate_MessageGate_setBlock((DSPEElement*) context, context->dataOut_PTThreshold_unlinked, context->blockSize, context->dataOut_PTThreshold_unlinkedAnchor);
	implState->dataOut_PTThreshold = context->dataOut_PTThreshold_unlinked;

}

/******************************************************************************
 * COMMON UNIT FUNCTIONS
 ******************************************************************************/

/* Earlyalloc function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_earlyAllocBlockSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context) {
	ParticleTrackerDllFindThreshold_CoprocImplementation *implState = &context->implState;

	initDSPEElement((DSPEElement*) &context->implState, (DSPEElement*) context);
	initDSPECoprocUnit((DSPECoprocUnit*) context);
	((DSPEComponent*) context)->preprocess = ParticleTrackerDllFindThresholdCP_SoftwareUnit_preProcessBlockSim;
	((DSPEComponent*) context)->process = ParticleTrackerDllFindThresholdCP_SoftwareUnit_processBlockSim;
	((DSPEComponent*) context)->postprocess = ParticleTrackerDllFindThresholdCP_SoftwareUnit_postProcessBlockSim;
	/* Data gates size initialization */
	context->dataIn_SequenceValues_size = context->blockSize;
	context->dataOut_PTThreshold_size = context->blockSize;

	implState->curOp = NULL;
	implState->opsBusy = 0;
	/* Allocate permanent state */
	implState->persistent = (ParticleTrackerDllFindThreshold_CoprocImplementation_persistent*) memoryManager_allocate((DSPEElement*) context, sizeof(ParticleTrackerDllFindThreshold_CoprocImplementation_persistent));

	/* Op PermanentStateVariables initialization */
	(*implState->persistent).percentile = 0;
	/* Unit profile ID initialization */
	context->unitProfileID = (int) profileSupport_getUnitProfileID(((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context)->ID);
}

/* Alloc function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_allocBlockSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context) {
	const DSPEOwner *owner = ((DSPEElement*) context)->owner;

	/* Base alloc() function call */
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_alloc(&context->baseState);

	initQueue(context);
	((DSPEQueueUnit*) context)->transitEvent = ParticleTrackerDllFindThresholdCP_SoftwareUnit_transitEventBlockSim;
	((DSPEQueueUnit*) context)->getTransitNumElements = ParticleTrackerDllFindThresholdCP_SoftwareUnit_getTransitNumElementsBlockSim;
	((DSPEQueueUnit*) context)->getCurrentNumElements = ParticleTrackerDllFindThresholdCP_SoftwareUnit_getCurrentNumElementsBlockSim;
	((DSPEQueueUnit*) context)->dismissEvent = ParticleTrackerDllFindThresholdCP_SoftwareUnit_dismissEventBlockSim;
	((DSPEQueueUnit*) context)->getFirstTransitEvent = ParticleTrackerDllFindThresholdCP_SoftwareUnit_getFirstTransitBlockSim;
	((DSPEQueueUnit*) context)->getCurrentTransitEvent = ParticleTrackerDllFindThresholdCP_SoftwareUnit_getCurTransitBlockSim;
	((DSPECoprocUnit*) context)->initOp = ParticleTrackerDllFindThresholdCP_SoftwareUnit_initOpBlockSim;
	((DSPEEventsUnit*) context)->armEvent = ParticleTrackerDllFindThresholdCP_SoftwareUnit_armEventBlockSim;
	((DSPEEventsUnit*) context)->postEvent = ParticleTrackerDllFindThresholdCP_SoftwareUnit_postEventBlockSim;

	/* Allocate unlinked places for input event gates */
	context->dataIn_PTFiltered_unlinked = ParticleTrackerDllPTFilteredGate_MessageGate_allocateUnlinkedBlock((DSPEElement*) context, context->blockSize);
	context->dataIn_PTFiltered_unlinkedAnchor = ParticleTrackerDllPTFilteredGate_MessageGate_allocateUnlinkedBlock((DSPEElement*) context, context->blockSize);
	ParticleTrackerDllPTFilteredGate_MessageGate_allocateBlockManaged((DSPEElement*) context, context->dataIn_PTFiltered_unlinkedAnchor, context->blockSize);
	context->dataOut_PTThreshold_unlinked = ParticleTrackerDllPTThresholdGate_MessageGate_allocateUnlinkedBlock((DSPEElement*) context, context->blockSize);
	context->dataOut_PTThreshold_unlinkedAnchor = ParticleTrackerDllPTThresholdGate_MessageGate_allocateUnlinkedBlock((DSPEElement*) context, context->blockSize);
	ParticleTrackerDllPTThresholdGate_MessageGate_allocateBlockManaged((DSPEElement*) context, context->dataOut_PTThreshold_unlinkedAnchor, context->blockSize);


	/* Data output gates factor and counter initialization */
	context->dataOut_PTThreshold_factor = context->dataOut_PTThreshold_size / context->blockSize;

	context->dataOut_PTThreshold_place = NULL;
	context->dataOut_PTThreshold_armMarker = NULL;

	/* Initialize eventPools for data gates */
	context->dataOut_PTThreshold_pool = ParticleTrackerDllPTThresholdGate_MessageGate_initPoolBlock(owner, context->dataOut_PTThreshold_size);

}

/* Earlyconnect function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_earlyConnectBlockSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllFindThreshold_CoprocImplementation *implState = &context->implState;

	/* Implementation output parameters gates initialization */
	implState->paramOut_Status = ((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context)->paramOut_Status_place;


	/* Base earlyconnect() function call */
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_earlyConnect(&context->baseState);

	/* Input data gates factor and counter initialization */
	context->dataIn_SequenceValues_factor = context->dataIn_SequenceValues_size / context->blockSize;

	/* Input data gates factor and counter initialization */
	context->dataIn_SequenceValues_counter = context->dataIn_SequenceValues_factor;

}

/* Connect function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_connectBlockSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllFindThreshold_CoprocImplementation *implState = &context->implState;

	/* Implementation input parameters gates initialization */
	implState->paramIn_Percentile = ((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context)->paramIn_Percentile;

	/* Implementation data gates initialization */
	implState->dataIn_SequenceValues = context->dataIn_SequenceValues;

	/* Implementation gates numLinks initialization */
	implState->dataIn_SequenceValues_numLinks = ((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context)->dataIn_SequenceValues_numLinks;
	implState->dataIn_PTFiltered_numLinks = ((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context)->dataIn_PTFiltered_numLinks;
	implState->dataOut_PTThreshold_numLinks = ((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context)->dataOut_PTThreshold_numLinks;
	implState->paramIn_Percentile_numLinks = ((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context)->paramIn_Percentile_numLinks;
	implState->paramOut_Status_numLinks = ((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context)->paramOut_Status_numLinks;

}

/* Startup function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_startupBlockSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context) {
	/* Initialize gate values */
	initValues(context);

	context->implState.opQueue = coprocManager_initCoprocInQueue((DSPEElement*) context, NULL);

	initOpBuffer(&context->implState);
}

/* Preprocess function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_preProcessBlockSim(DSPEComponent *component) {
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context = (ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim*) component;
	/* Implementation preprocess() call */
	ParticleTrackerDllFindThreshold_CoprocImplementation_preProcess(&context->implState);
}

/* Process function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_processBlockSim(DSPEComponent *component) {
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context = (ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim*) component;
	/* Implementation state local variable initialization */
	ParticleTrackerDllFindThreshold_CoprocImplementation *implState = &context->implState;
	const unsigned int ID = (((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context)->queueNumNodes == 0) ? NOEVENT : ((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context)->queueHead->ID;

	/* Implementation data gates and counters update */
	if (context->dataIn_SequenceValues_counter == context->dataIn_SequenceValues_factor) {
		implState->dataIn_SequenceValues = context->dataIn_SequenceValues;
		context->dataIn_SequenceValues_counter = 0;
	} else {
		implState->dataIn_SequenceValues++;
	}

	/* Switch input event ID */
	switch (ID) {
	case dIn_PTFiltered_event:
		/* AutoTransit inputEvents */
		((DSPEQueueUnit*) context)->transitEvent((DSPEQueueUnit*) context);
		/* Handle incoming event */
		handleInputEvent(context);
		break;
	case pIn_Coproc_event:
		handleCoprocEvent(&context->implState);

		break;
	}


	/* AutoBuffer Support - if curOp has been set put curOp to coproc input queue */
	if (implState->curOp != NULL) {
		queueOp(implState, (DSPEOp*) implState->curOp);
	}
	implState->curOp = NULL;
	/* Block counters increment */
	context->dataIn_SequenceValues_counter++;


	/* Restore unlinked pointers on unitBehaviour */
	if (implState->dataIn_PTFiltered != context->dataIn_PTFiltered_unlinked)
		implState->dataIn_PTFiltered = context->dataIn_PTFiltered_unlinked;
	/* Release event */
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_releaseEvent((ParticleTrackerDllFindThresholdCP_SoftwareUnit*) context);
}

/* Postprocess function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_postProcessBlockSim(DSPEComponent *component) {
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context = (ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim*) component;

	/* Release opBuffer. Puts all ops that haven't been processed back to opPool */
	releaseOpBuffer(&context->implState);

	/* Move all output events that have been armed but not sent to their related pool */
	resetEventPlaces(context);

	/* Move all events from transitQueue back to their related pool */
	resetQueue(context);
	/* Reset unit's opInputQueue */
	context->implState.opQueue->reset(context->implState.opQueue);


	/* Base postprocess() function call */
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_postProcess(&context->baseState);
}

/* Reset function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_resetBlockSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context) {
	ParticleTrackerDllFindThreshold_CoprocImplementation *implState = &context->implState;

	ParticleTrackerDllFindThreshold_CoprocImplementation_op *currentOp = implState->opPoolHead;

	/* Base reset() function call */
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_reset(&context->baseState);

	/* Initialize gate values */
	initValues(context);
	implState->curOp = NULL;
	implState->opsBusy = 0;

	/* Coproc PersistentStateVariables initialization */
	(*implState->persistent).percentile = 0;

	/* Reset temporary states on ops in pool*/
	while (currentOp != NULL) {
		/* Merge profile info */
		profileManager_mergeQueue((DSPEElement*) implState, ((DSPEProfileCoprocOp*) currentOp)->profileQueue);
	
		currentOp = currentOp->next;
	}
}

/* Shutdown function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_shutdownBlockSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context) {

	disposeOpBuffer(&context->implState);
	context->implState.opQueue->dispose(context->implState.opQueue);

	/* Base shutdown() function call */
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_shutdown(&context->baseState);

	/* Dispose unlinked places for input event gates */
	ParticleTrackerDllPTFilteredGate_MessageGate_disposeUnlinkedBlock((DSPEElement*) context, context->dataIn_PTFiltered_unlinked);
	ParticleTrackerDllPTFilteredGate_MessageGate_disposeBlockManaged((DSPEElement*) context, context->dataIn_PTFiltered_unlinkedAnchor, context->blockSize);
	ParticleTrackerDllPTFilteredGate_MessageGate_disposeUnlinkedBlock((DSPEElement*) context, context->dataIn_PTFiltered_unlinkedAnchor);
	ParticleTrackerDllPTThresholdGate_MessageGate_disposeUnlinkedBlock((DSPEElement*) context, context->dataOut_PTThreshold_unlinked);
	ParticleTrackerDllPTThresholdGate_MessageGate_disposeBlockManaged((DSPEElement*) context, context->dataOut_PTThreshold_unlinkedAnchor, context->blockSize);
	ParticleTrackerDllPTThresholdGate_MessageGate_disposeUnlinkedBlock((DSPEElement*) context, context->dataOut_PTThreshold_unlinkedAnchor);

	/* Dispose permanent state */
	memorySupport_dispose(context->implState.persistent);
}

