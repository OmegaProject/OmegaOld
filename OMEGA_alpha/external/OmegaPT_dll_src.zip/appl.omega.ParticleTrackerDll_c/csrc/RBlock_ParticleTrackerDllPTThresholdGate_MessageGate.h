/**
 * File: RBlock_ParticleTrackerDllPTThresholdGate_MessageGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef RBlock_ParticleTrackerDllPTThresholdGate_MessageGate_h
#define RBlock_ParticleTrackerDllPTThresholdGate_MessageGate_h

#include "B_ParticleTrackerDllPTThresholdGate_MessageGate.h"

/* EventGate pool type definition */
typedef struct ParticleTrackerDllPTThresholdGate_MessageGate_poolBlock ParticleTrackerDllPTThresholdGate_MessageGate_poolBlock;

/* EventGate pool definition */
struct ParticleTrackerDllPTThresholdGate_MessageGate_poolBlock {
	DSPEBlockEventsPool pool;

	// Pool for Events
	size_t eventNumElements;
	ParticleTrackerDllPTThresholdGate_MessageGate_event *headEvent;
	ParticleTrackerDllPTThresholdGate_MessageGate_event *tailEvent;

	// Pool for Clones
	size_t cloneNumElements;
	ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent *headClone;
	ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent *tailClone;
};

/* BlockEventGroupGate pool type definition */
typedef struct ParticleTrackerDllPTThresholdGate_MessageGate_poolGroupBlock ParticleTrackerDllPTThresholdGate_MessageGate_poolGroupBlock;

/* BlockEventGroupGate pool definition */
struct ParticleTrackerDllPTThresholdGate_MessageGate_poolGroupBlock {
	DSPEGroupBlockEventsPool pool;

	/* Pool for Events */
	size_t eventNumElements;
	ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *headEvent;
	ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *tailEvent;
	
	/* Pool for Clones */
	size_t cloneNumElements;
	ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroupEvent *headClone;
	ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroupEvent *tailClone;
	
	/* Pool for EventContainers */
	size_t containerNumElements;
	ParticleTrackerDllPTThresholdGate_MessageGate_eventContainer *headContainer;
	ParticleTrackerDllPTThresholdGate_MessageGate_eventContainer *tailContainer;
};

#ifdef __cplusplus
extern "C" {
#endif

/* AllocateBlockManaged function */
void ParticleTrackerDllPTThresholdGate_MessageGate_allocateBlockManaged(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate *anchor, size_t size);

/* InitBlockManaged function */
void ParticleTrackerDllPTThresholdGate_MessageGate_initBlockManaged(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate *anchor, size_t size);

/* DisposeBlockManaged function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeBlockManaged(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate *anchor, size_t size);

/* AllocateGroupBlockManaged function */
void ParticleTrackerDllPTThresholdGate_MessageGate_allocateGroupBlockManaged(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate **anchor, size_t size, size_t *gateSize);

/* InitGroupBlockManaged function */
void ParticleTrackerDllPTThresholdGate_MessageGate_initGroupBlockManaged(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate **anchor, size_t size, size_t *gateSize);

/* DisposeGroupBlockManaged function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeGroupBlockManaged(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate **anchor, size_t size, size_t *gateSize);

/* eventPool initialization function */
ParticleTrackerDllPTThresholdGate_MessageGate_poolBlock* ParticleTrackerDllPTThresholdGate_MessageGate_initPoolBlock(const DSPEOwner *owner, size_t size);

/* eventPool preAlloc function */
void ParticleTrackerDllPTThresholdGate_MessageGate_preAllocPoolBlock(DSPEEventsPool *pool, size_t size);

/* eventPool reset function */
void ParticleTrackerDllPTThresholdGate_MessageGate_resetPoolBlock(DSPEEventsPool *pool);

/* Allocate function */
ParticleTrackerDllPTThresholdGate_MessageGate_event* ParticleTrackerDllPTThresholdGate_MessageGate_allocateBlock(ParticleTrackerDllPTThresholdGate_MessageGate_poolBlock *pool);

/* Create function */
void ParticleTrackerDllPTThresholdGate_MessageGate_createBlock(ParticleTrackerDllPTThresholdGate_MessageGate_event *event);

/* Initialise function */
void ParticleTrackerDllPTThresholdGate_MessageGate_initializeBlock(ParticleTrackerDllPTThresholdGate_MessageGate_event *event);

/* Clone event function */
DSPEEvent* ParticleTrackerDllPTThresholdGate_MessageGate_cloneBlock(DSPEEvent *event);

/* Dispose function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeBlock(DSPEEvent *event);

/* Dispose clone function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeCloneBlock(DSPEEvent *event);

/* Destroy function */
void ParticleTrackerDllPTThresholdGate_MessageGate_destroyBlock(ParticleTrackerDllPTThresholdGate_MessageGate_event *event);

/* eventPool dispose function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposePoolBlock(DSPEEventsPool *pool);

/* Allocate function */
ParticleTrackerDllPTThresholdGate_MessageGate* ParticleTrackerDllPTThresholdGate_MessageGate_allocateUnlinkedBlock(DSPEElement *context, size_t size);

/* Initialise function */
void ParticleTrackerDllPTThresholdGate_MessageGate_initializeUnlinkedBlock(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate *place, size_t size);

/* Set function */
void ParticleTrackerDllPTThresholdGate_MessageGate_setBlock(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate *place, size_t size, ParticleTrackerDllPTThresholdGate_MessageGate *value);

/* Dispose function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeUnlinkedBlock(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate *place);

/* groupEventPool initialization function */
ParticleTrackerDllPTThresholdGate_MessageGate_poolGroupBlock* ParticleTrackerDllPTThresholdGate_MessageGate_initGroupPoolBlock(const DSPEOwner *owner, size_t groupSize, size_t blockSize);

/* eventPool preAlloc function */
void ParticleTrackerDllPTThresholdGate_MessageGate_preAllocGroupPoolBlock(DSPEEventsPool *pool, size_t size);

/* eventPool reset function */
void ParticleTrackerDllPTThresholdGate_MessageGate_resetGroupPoolBlock(DSPEEventsPool *pool);

/* AllocateGroup function */
ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent* ParticleTrackerDllPTThresholdGate_MessageGate_allocateGroupBlock(ParticleTrackerDllPTThresholdGate_MessageGate_poolGroupBlock *pool);

/* CreateGroup function */
void ParticleTrackerDllPTThresholdGate_MessageGate_createGroupBlock(ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *event, size_t index);

/* InitialiseGroup function */
void ParticleTrackerDllPTThresholdGate_MessageGate_initializeGroupBlock(ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *event, size_t index);

/* CloneGroup event function */
DSPEEvent* ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroupBlock(DSPEEvent *event);

/* SubClone event function */
DSPEEvent* ParticleTrackerDllPTThresholdGate_MessageGate_subCloneBlock(DSPEGroupEvent *event, DSPEEventsPool *pool, size_t index);

/**
 * Allocate containerEvent function
 */
ParticleTrackerDllPTThresholdGate_MessageGate_eventContainer* ParticleTrackerDllPTThresholdGate_MessageGate_allocateContainerBlock(ParticleTrackerDllPTThresholdGate_MessageGate_poolGroupBlock *pool);

/**
 * Dispose containerEvent function
 */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeContainerBlock(DSPEEvent *event);

/* DisposeGroup function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeGroupBlock(DSPEEvent *event);

/* Dispose GroupClone function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeGroupCloneBlock(DSPEEvent *event);

/* DestroyGroup function */
void ParticleTrackerDllPTThresholdGate_MessageGate_destroyGroupBlock(ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *event);

/* eventPool dispose function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeGroupPoolBlock(DSPEEventsPool *pool);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
