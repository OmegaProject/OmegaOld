/**
 * File: B_ParticleTrackerDllImagesColor_StringGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "StringManager.h"
#include "MemoryManager.h"

#include "B_ParticleTrackerDllImagesColor_StringGate.h"

/* AllocateValue function */
ParticleTrackerDllImagesColor_StringGate ParticleTrackerDllImagesColor_StringGate_allocateValue(DSPEElement *context) {
	return memoryManager_allocate(context, PARTICLETRACKERDLLIMAGESCOLOR_STRINGGATE_MAXIMUMSIZE + 1);
}
/* InitValue function */
void ParticleTrackerDllImagesColor_StringGate_initValue(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate anchor) {
	stringSupport_copy(anchor, PARTICLETRACKERDLLIMAGESCOLOR_STRINGGATE_DEFAULTVALUE);
}

/* CopyValue function */
void ParticleTrackerDllImagesColor_StringGate_copyValue(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate destination, ParticleTrackerDllImagesColor_StringGate source) {
	stringSupport_copy(destination, source);
}

/* CompareValue function */
int ParticleTrackerDllImagesColor_StringGate_compareValue(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate first, ParticleTrackerDllImagesColor_StringGate second) {
	return stringSupport_compare(first, second);
}

/* DisposeValue function */
void ParticleTrackerDllImagesColor_StringGate_disposeValue(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate anchor) {
	memorySupport_dispose(anchor);
}

/* AllocateManaged function */
void ParticleTrackerDllImagesColor_StringGate_allocateManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *anchor) {
	*anchor = ParticleTrackerDllImagesColor_StringGate_allocateValue(context);
}
/* InitManaged function */
void ParticleTrackerDllImagesColor_StringGate_initManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate anchor) {
	ParticleTrackerDllImagesColor_StringGate_initValue(context, anchor);
}

/* DisposeManaged function */
void ParticleTrackerDllImagesColor_StringGate_disposeManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate anchor) {
	ParticleTrackerDllImagesColor_StringGate_disposeValue(context, anchor);
}

/* AllocateGroupManaged function */
void ParticleTrackerDllImagesColor_StringGate_allocateGroupManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **anchor, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllImagesColor_StringGate_allocateManaged(context, anchor[i]);
	}
}
/* InitGroupManaged function */
void ParticleTrackerDllImagesColor_StringGate_initGroupManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **anchor, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllImagesColor_StringGate_initValue(context, *anchor[i]);
	}
}

/* DisposeGroupManaged function */
void ParticleTrackerDllImagesColor_StringGate_disposeGroupManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **anchor, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllImagesColor_StringGate_disposeValue(context, *anchor[i]);
	}
}

/* Allocate function */
ParticleTrackerDllImagesColor_StringGate* ParticleTrackerDllImagesColor_StringGate_allocate(DSPEElement *context) {
	return memoryManager_allocate(context, sizeof(ParticleTrackerDllImagesColor_StringGate));
}

/* Initialise function */
void ParticleTrackerDllImagesColor_StringGate_initialize(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *place) {
	stringSupport_copy(*place, PARTICLETRACKERDLLIMAGESCOLOR_STRINGGATE_DEFAULTVALUE);
}

/* SetOverride function */
void ParticleTrackerDllImagesColor_StringGate_setOverride(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *place, ParticleTrackerDllImagesColor_StringGate value) {
	stringSupport_copy(*place, value);
}

/* Set function */
void ParticleTrackerDllImagesColor_StringGate_set(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *place, ParticleTrackerDllImagesColor_StringGate *value) {
	*place = *value;
}

/* Dispose function */
void ParticleTrackerDllImagesColor_StringGate_dispose(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *place) {
	memorySupport_dispose(place);
}

/* AllocateGroup function */
void ParticleTrackerDllImagesColor_StringGate_allocateGroup(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	place[i] = ParticleTrackerDllImagesColor_StringGate_allocate(context);
	}
}

/* InitialiseGroup function */
void ParticleTrackerDllImagesColor_StringGate_initializeGroup(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
	 	ParticleTrackerDllImagesColor_StringGate_initialize(context, place[i]);
	}
}

/* SetOverrideGroup function */
void ParticleTrackerDllImagesColor_StringGate_setOverrideGroup(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t size, ParticleTrackerDllImagesColor_StringGate value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllImagesColor_StringGate_setOverride(context, place[i], value);
	}
}

/* SetGroup function */
void ParticleTrackerDllImagesColor_StringGate_setGroup(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t size, ParticleTrackerDllImagesColor_StringGate **value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllImagesColor_StringGate_set(context, place[i], value[i]);
	}
}

/* DisposeGroup function */
void ParticleTrackerDllImagesColor_StringGate_disposeGroup(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	memorySupport_dispose(place[i]);
	}
}

/* CreateNode function */
ParticleTrackerDllImagesColor_StringGate_node* ParticleTrackerDllImagesColor_StringGate_createNode(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *gate, ParticleTrackerDllImagesColor_StringGate *localVar) {
	ParticleTrackerDllImagesColor_StringGate_node *node = (ParticleTrackerDllImagesColor_StringGate_node*) memoryManager_allocate(context, sizeof(ParticleTrackerDllImagesColor_StringGate_node));
	initDSPEGateNode((DSPEGateNode*) node);
	node->gate = gate;
	if (gate != 0)
		node->gateAnchor = *node->gate;
	else
		node->gateAnchor = 0;
	node->localVar = localVar;
	if (localVar != 0)
		node->localVarAnchor = *node->localVar;
	else
		node->localVarAnchor = 0;
	node->value = ParticleTrackerDllImagesColor_StringGate_allocate(context);
	ParticleTrackerDllImagesColor_StringGate_allocateManaged(context, node->value);
	ParticleTrackerDllImagesColor_StringGate_initialize(context, node->value);
	node->valueAnchor = *node->value;
	((DSPEGateNode*) node)->setValue = ParticleTrackerDllImagesColor_StringGate_setValue;
	((DSPEGateNode*) node)->disposeNode = ParticleTrackerDllImagesColor_StringGate_disposeNode;
	return node;
}

/* DisposeNode function */
void ParticleTrackerDllImagesColor_StringGate_disposeNode(DSPEElement *context, DSPEGateNode *node) {
	ParticleTrackerDllImagesColor_StringGate_node *tmpNode = (ParticleTrackerDllImagesColor_StringGate_node*) node;
	node->next = NULL;
	//ParticleTrackerDllImagesColor_StringGate_destroy(tmpNode->valueAnchor);
	ParticleTrackerDllImagesColor_StringGate_disposeManaged(context, *tmpNode->value);
	ParticleTrackerDllImagesColor_StringGate_dispose(context, tmpNode->value);
	memorySupport_dispose(tmpNode);
}

/* SetValue function */
void ParticleTrackerDllImagesColor_StringGate_setValue(DSPEElement *context, DSPEGateNode *node) {
	ParticleTrackerDllImagesColor_StringGate_node *tmpNode = (ParticleTrackerDllImagesColor_StringGate_node*) node;
	if (tmpNode->gate != 0) {
		if (*tmpNode->value != 0) {
			*tmpNode->gate = tmpNode->gateAnchor;
			stringSupport_copy(*tmpNode->gate, *tmpNode->value);
		} else
			*tmpNode->gate = 0;
	}
	if (tmpNode->localVar != 0) {
		if (*tmpNode->value != 0) {
			*tmpNode->localVar = tmpNode->localVarAnchor;
			stringSupport_copy(*tmpNode->localVar, *tmpNode->value);
		} else
			*tmpNode->localVar = 0;
	}
}

