/**
 * File: B_ParticleTrackerDllRealGate_CustomGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#include "MemoryManager.h"

#include "B_ParticleTrackerDllRealGate_CustomGate.h"

/* Allocate function */
ParticleTrackerDllRealGate_CustomGate* ParticleTrackerDllRealGate_CustomGate_allocate(DSPEElement *context) {
	return memoryManager_allocate(context, sizeof(ParticleTrackerDllRealGate_CustomGate));
}

/* Initialise function */
void ParticleTrackerDllRealGate_CustomGate_initialize(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate *place) {
	*place = PARTICLETRACKERDLLREALGATE_CUSTOMGATE_DEFAULTVALUE;
}

/* Set function */
void ParticleTrackerDllRealGate_CustomGate_setOverride(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate *place, ParticleTrackerDllRealGate_CustomGate value) {
	*place = value;
}

/* Set function */
void ParticleTrackerDllRealGate_CustomGate_set(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate *place, ParticleTrackerDllRealGate_CustomGate *value) {
	*place = *value;
}

/* Dispose function */
void ParticleTrackerDllRealGate_CustomGate_dispose(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate *place) {
	memorySupport_dispose(place);
}

/* AllocateGroup function */
void ParticleTrackerDllRealGate_CustomGate_allocateGroup(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	place[i] = ParticleTrackerDllRealGate_CustomGate_allocate(context);
	}
}

/* InitialiseGroup function */
void ParticleTrackerDllRealGate_CustomGate_initializeGroup(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
	 	ParticleTrackerDllRealGate_CustomGate_initialize(context, place[i]);
	}
}

/* SetOverrideGroup function */
void ParticleTrackerDllRealGate_CustomGate_setOverrideGroup(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t size, ParticleTrackerDllRealGate_CustomGate value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllRealGate_CustomGate_setOverride(context, place[i], value);
	}
}

/* SetGroup function */
void ParticleTrackerDllRealGate_CustomGate_setGroup(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t size, ParticleTrackerDllRealGate_CustomGate **value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllRealGate_CustomGate_set(context, place[i], value[i]);
	}
}

/* DisposeGroup function */
void ParticleTrackerDllRealGate_CustomGate_disposeGroup(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	memorySupport_dispose(place[i]);
	}
}

/* CreateNode function */
ParticleTrackerDllRealGate_CustomGate_node* ParticleTrackerDllRealGate_CustomGate_createNode(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate *gate, ParticleTrackerDllRealGate_CustomGate *localVar) {
	ParticleTrackerDllRealGate_CustomGate_node *node = (ParticleTrackerDllRealGate_CustomGate_node*) memoryManager_allocate(context, sizeof(ParticleTrackerDllRealGate_CustomGate_node));
	initDSPEGateNode((DSPEGateNode*) node);
	node->gate = gate;
	node->localVar = localVar;
	((DSPEGateNode*) node)->setValue = ParticleTrackerDllRealGate_CustomGate_setValue;
	((DSPEGateNode*) node)->disposeNode = ParticleTrackerDllRealGate_CustomGate_disposeNode;
	return node;
}

/* DisposeNode function */
void ParticleTrackerDllRealGate_CustomGate_disposeNode(DSPEElement *context, DSPEGateNode *node) {
	node->next = NULL;
	memorySupport_dispose(node);
}

/* SetValue function */
void ParticleTrackerDllRealGate_CustomGate_setValue(DSPEElement *context, DSPEGateNode *node) {
	ParticleTrackerDllRealGate_CustomGate_node *tmpNode = (ParticleTrackerDllRealGate_CustomGate_node*) node;
	if (tmpNode->gate != 0)
		*tmpNode->gate = tmpNode->value;
	if (tmpNode->localVar != 0)
		*tmpNode->localVar = tmpNode->value;
}

