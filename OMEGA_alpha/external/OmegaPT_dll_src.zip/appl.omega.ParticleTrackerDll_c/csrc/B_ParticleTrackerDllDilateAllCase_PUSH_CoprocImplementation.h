/**
 * File: B_ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef B_ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_h
#define B_ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_h

#include "CoprocGround.h"
#include "DSPEXTElements.h"

#include "B_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "B_ParticleTrackerDllPTFrameGate_MessageGate.h"
#include "B_ParticleTrackerDllMaskGate_PointerGate.h"
#include "B_ParticleTrackerDllNextGate_SignalGate.h"
#include "B_ParticleTrackerDllIntGate_StandardGate.h"
#include "B_ParticleTrackerDllStatusGate_StringGate.h"

/* Coproc persistent state type definition */
typedef struct ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_persistent ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_persistent;

/* This struct may contain user defined persistent state variables */
struct ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_persistent {
	//Place persistent state variables after this line -- SYD-PERSISTENT-STATE-START
	int kernelWidth;
	int* mask;
	//SYD-PERSISTENT-STATE-END  -- Place persistent state variables before this line
};

/* Coproc Operation type definition */
typedef struct ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op;

/* This struct may contain user defined additional state variables */
struct ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op {

	DSPEProfileCoprocOp coprocOp;

	/* BlockSize */
	size_t blockSize;

	/* CoprocOp Buffer support */
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op *next;
	unsigned int processed;

	/* Coproc persistent state */
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_persistent *persistent;

	//Place additional state variables after this line -- SYD-ADDITIONAL-STATE-START
	//SYD-ADDITIONAL-STATE-END  -- Place additional state variables before this line


	/* Transfered Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame;
	ParticleTrackerDllMaskGate_PointerGate *dataOut_Mask;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame;


	/* Transfered Parameter gates */
	ParticleTrackerDllIntGate_StandardGate *paramIn_Radius;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status;

};



/* Functional implementation state type definition */
typedef struct ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_func ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_func;

/* This struct may contain user defined additional state variables for the unit */
struct ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_func {

	DSPECoprocImplementation coprocImplementation;

	//Place local state variables after this line -- SYD-LOCAL-STATE-START
	//SYD-LOCAL-STATE-END  -- Place local state variables before this line
};

/******************************************************************************
 * FOLLOWING CODE IS NOT INTENDED TO BE MODIFIED BY USERS                     *
 ******************************************************************************/

/* State type definition */
typedef struct ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation;

/* State definition */ 
struct ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation {

	/* Functional implementation state */
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_func functionalState;

	/* Current working op state var */
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op *curOp;

	DSPEOpInQueue *opQueue;

	/* Coproc permanent state */
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_persistent* persistent;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame;
	ParticleTrackerDllMaskGate_PointerGate *dataOut_Mask;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame;

	/* Parameter gates */
	ParticleTrackerDllIntGate_StandardGate *paramIn_stop;
	ParticleTrackerDllIntGate_StandardGate *paramIn_Radius;
	ParticleTrackerDllIntGate_StandardGate *paramOut_stop;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status;


	/* numLinks flags */
	unsigned int dataIn_SequenceValues_numLinks;
	unsigned int dataIn_PTFrame_numLinks;
	unsigned int dataOut_Mask_numLinks;
	unsigned int dataOut_PTFrame_numLinks;
	unsigned int paramIn_next_numLinks;
	unsigned int paramIn_stop_numLinks;
	unsigned int paramIn_Radius_numLinks;
	unsigned int paramOut_next_numLinks;
	unsigned int paramOut_stop_numLinks;
	unsigned int paramOut_Status_numLinks;

	/* State */
	unsigned int state;

	/* opBuffer support */
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op *opPoolHead;
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op *opPoolTail;
	size_t opPoolNumElements;
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op *opBufferHead;
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op *opBufferTail;
	size_t opBufferNumElements;

	unsigned int opsBusy;
	unsigned int waitingInNext;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

/* Preprocess function */
void ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_preProcess(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context);

/* Process function */
void ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_process(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op *context);

/* Postprocess function */
void ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_postProcess(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
