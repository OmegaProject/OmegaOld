/**
 * File: S_ParticleTrackerDllLibraryDataReader_StateImplementation.h
 *
 * @author Loris
 * @created Thu May 26 10:23:50 CEST 2011
 */
#ifndef S_ParticleTrackerDllLibraryDataReader_StateImplementation_h
#define S_ParticleTrackerDllLibraryDataReader_StateImplementation_h

#include "PlatformManager.h"

#include "B_ParticleTrackerDllLibraryDataReader_StateImplementation.h"

/* Input EventGate IDs */
#define pIn_sourceNext_event 1000
#define pIn_next_event 1001

#define pOut_next_event 1000
#define dOut_PTFrame_event 1001

#ifdef __cplusplus
extern "C" {
#endif

static INLINE int isEventAvailable(ParticleTrackerDllLibraryDataReader_StateImplementation *context) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	return unit->isEventAvailable(unit);
}

static INLINE unsigned int getEventID(ParticleTrackerDllLibraryDataReader_StateImplementation *context) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	return unit->getEventID(unit);
}

/* Move inputEvent to specific transitQueue */
static INLINE void transitEvent(ParticleTrackerDllLibraryDataReader_StateImplementation *context) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	unit->transitEvent(unit);
}

/* SignalGate send advanced */
static INLINE void sendPE_next(ParticleTrackerDllLibraryDataReader_StateImplementation *context) {
	DSPEEventsUnit *unit = (DSPEEventsUnit*) ((DSPEElement*) context)->container;
	if (unit->sendEvent == NULL)
		return;
	unit->armEvent(unit, pOut_next_event);
	unit->postEvent(unit, pOut_next_event);
}
static INLINE void armDE_PTFrame(ParticleTrackerDllLibraryDataReader_StateImplementation *context) {
	DSPEEventsUnit *unit = (DSPEEventsUnit*) ((DSPEElement*) context)->container;
	if (unit->armEvent == 0)
		return;
	unit->armEvent(unit, dOut_PTFrame_event);
}

/* Forward send request to unit */
static INLINE void sendDE_PTFrame(ParticleTrackerDllLibraryDataReader_StateImplementation *context) {
	DSPEEventsUnit *unit = (DSPEEventsUnit*) ((DSPEElement*) context)->container;
	if (unit->sendEvent == NULL)
		return;
	unit->postEvent(unit, dOut_PTFrame_event);
}

#ifdef __cplusplus
} /* extern "C" */
#endif

#undef pIn_sourceNext_event
#undef pIn_next_event
#undef pOut_next_event
#undef dOut_PTFrame_event

#endif
