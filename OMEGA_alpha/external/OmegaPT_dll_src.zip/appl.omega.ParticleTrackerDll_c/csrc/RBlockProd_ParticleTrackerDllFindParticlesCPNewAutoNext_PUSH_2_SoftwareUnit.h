/**
 * File: RBlockProd_ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef RBlockProd_ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_h
#define RBlockProd_ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_h

#include "B_ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation.h"
#include "B_ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit.h"
#include "RBlock_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "RBlock_ParticleTrackerDllPTFrameGate_MessageGate.h"
#include "RBlock_ParticleTrackerDllPTThresholdGate_MessageGate.h"

/* Block SoftwareUnit state type definition */
typedef struct ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_blockProd ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_blockProd;

/* Block SoftwareUnit state definition */
struct ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_blockProd {

	/* Base unit state */
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation implState;
	
	/* Block size */
	size_t blockSize;

	/* Samples to process */
	size_t samplesToProcess;

	/* Data transit queues */
	size_t dataIn_PTFrame_transitNumElements;
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_queueNode *dataIn_PTFrame_transitHead;
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_queueNode *dataIn_PTFrame_transitTail;
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_queueNode *dataIn_PTFrame_curTransit;
	unsigned int dataIn_PTFrame_curTransitIndex;
	size_t dataIn_PTThreshold_transitNumElements;
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_queueNode *dataIn_PTThreshold_transitHead;
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_queueNode *dataIn_PTThreshold_transitTail;
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_queueNode *dataIn_PTThreshold_curTransit;
	unsigned int dataIn_PTThreshold_curTransitIndex;

	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;
	DSPEEvent *dataOut_PTFrame_place;
	DSPEEvent *dataOut_PTFrame_armMarker;

	/* Data pending events support */
	size_t dataOut_PTFrame_pendingEvents;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;

	/* EventPools */
	ParticleTrackerDllPTFrameGate_MessageGate_poolBlock *dataOut_PTFrame_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame_unlinked;
	ParticleTrackerDllPTThresholdGate_MessageGate *dataIn_PTThreshold_unlinked;
	ParticleTrackerDllPTThresholdGate_MessageGate *dataIn_PTThreshold_unlinkedAnchor;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame_unlinked;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;


	/* Data gates sizes */
	size_t dataIn_SequenceValues_size;
	size_t dataOut_PTFrame_size;


	/* Data gates factors */
	size_t dataIn_SequenceValues_factor;
	size_t dataOut_PTFrame_factor;


	/* Data gates counters */
	size_t dataIn_SequenceValues_counter;
	size_t dataOut_PTFrame_counter;


	/* Data gates counters */
	size_t dataOut_PTFrame_samplesCounter;

	/* Unit profile ID */
	int unitProfileID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_transitEventBlockProd(DSPEQueueUnit *unit);

size_t ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_getTransitNumElementsBlockProd(DSPEQueueUnit *unit, unsigned int ID);

size_t ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_getTransitNumElementsBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_getFirstTransitBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_getCurTransitBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_dismissEventBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_dismissAllEventsBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_armEventBlockProd(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_postEventBlockProd(DSPEEventsUnit *unit, unsigned int ID);

/**
 * initOp function
 */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_initOpBlockProd(DSPECoprocUnit *unit, DSPEOp *op);

/* Earlyalloc function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_earlyAllocBlockProd(ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_blockProd *context);

/* Alloc function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_allocBlockProd(ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_blockProd *context);

/* Earlyconnect function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_earlyConnectBlockProd(ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_blockProd *context);

/* Connect function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_connectBlockProd(ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_blockProd *context);

/* Startup function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_startupBlockProd(ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_blockProd *context);

/* Preprocess function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_preProcessBlockProd(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_processBlockProd(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_postProcessBlockProd(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_resetBlockProd(ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_blockProd *context);

/* Shutdown function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_shutdownBlockProd(ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_blockProd *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
