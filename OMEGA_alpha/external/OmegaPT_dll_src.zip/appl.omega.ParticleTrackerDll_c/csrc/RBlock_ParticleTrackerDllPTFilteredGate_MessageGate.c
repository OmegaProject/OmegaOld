/**
 * File: RBlock_ParticleTrackerDllPTFilteredGate_MessageGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#include "MemoryManager.h"

#include "RBlock_ParticleTrackerDllPTFilteredGate_MessageGate.h"

/* AllocateBlockManaged function */
void ParticleTrackerDllPTFilteredGate_MessageGate_allocateBlockManaged(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate *anchor, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		anchor[i] = ParticleTrackerDllPTFilteredGate_MessageGate_allocateValue(context);
	}
}

/* InitBlockManaged function */
void ParticleTrackerDllPTFilteredGate_MessageGate_initBlockManaged(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate *anchor, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllPTFilteredGate_MessageGate_initManaged(context, anchor[i]);
	}
}

/* DisposeBlockManaged function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeBlockManaged(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate *anchor, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllPTFilteredGate_MessageGate_disposeManaged(context, anchor[i]);
	}
}

/* AllocateGroupBlockManaged function */
void ParticleTrackerDllPTFilteredGate_MessageGate_allocateGroupBlockManaged(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate **anchor, size_t size, size_t *gateSize) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllPTFilteredGate_MessageGate_allocateBlockManaged(context, anchor[i], gateSize[i]);
	}
}

/* InitGroupBlockManaged function */
void ParticleTrackerDllPTFilteredGate_MessageGate_initGroupBlockManaged(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate **anchor, size_t size, size_t *gateSize) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllPTFilteredGate_MessageGate_initBlockManaged(context, anchor[i], gateSize[i]);
	}
}

/* DisposeGroupBlockManaged function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeGroupBlockManaged(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate **anchor, size_t size, size_t *gateSize) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllPTFilteredGate_MessageGate_disposeBlockManaged(context, anchor[i], gateSize[i]);
	}
}

/* eventPool initialization function */
ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock* ParticleTrackerDllPTFilteredGate_MessageGate_initPoolBlock(const DSPEOwner *owner, size_t size) {
	DSPEPoolHandler *handler = memoryManager_getPoolHandler(owner);
	ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock *pool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock*) memoryManager_getPoolBlock(handler, &ParticleTrackerDllPTFilteredGate_MessageGate_allocateBlock, size);
	/* lazy initialization */
	if (pool == NULL) {
		pool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock*) memoryManager_allocate(CAST_TO_ELEMENT(owner), sizeof(ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock));
		initDSPEElement((DSPEElement*) pool, (DSPEElement*) handler);
		initDSPEBlockEventsPool((DSPEBlockEventsPool*) pool);
		pool->eventNumElements = 0;
		pool->headEvent = NULL;
		pool->tailEvent = NULL;
		pool->cloneNumElements = 0;
		pool->headClone = NULL;
		pool->tailClone = NULL;
		((DSPEEventsPool*) pool)->gateDefID = &ParticleTrackerDllPTFilteredGate_MessageGate_allocateBlock;
		((DSPEEventsPool*) pool)->preAlloc = ParticleTrackerDllPTFilteredGate_MessageGate_preAllocPoolBlock;
		((DSPEEventsPool*) pool)->reset = ParticleTrackerDllPTFilteredGate_MessageGate_resetPoolBlock;
		((DSPEEventsPool*) pool)->dispose = ParticleTrackerDllPTFilteredGate_MessageGate_disposePoolBlock;
		((DSPEBlockEventsPool*) pool)->size = size;
		memoryManager_addPoolBlock(handler, (DSPEBlockEventsPool*) pool);
	}
	return pool;
}

/* eventPool preAlloc function */
void ParticleTrackerDllPTFilteredGate_MessageGate_preAllocPoolBlock(DSPEEventsPool *pool, size_t size) {
	ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock *concretePool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock*) pool;
	DSPEEventsPool *childPool = NULL;
	register size_t i;
	ParticleTrackerDllPTFilteredGate_MessageGate_event *firstEvent = NULL;
	ParticleTrackerDllPTFilteredGate_MessageGate_event *lastEvent = NULL;
	ParticleTrackerDllPTFilteredGate_MessageGate_event *currEvent = NULL;

	/* PreAlloc blocks children */
	childPool = (DSPEEventsPool*) ((DSPEBlockEventsPool*) pool)->blocksHead;
	for (i = 0; i < ((DSPEBlockEventsPool*) pool)->blocksNumElements; i++) {
		childPool->preAlloc(childPool, size);
		childPool = childPool->next;
	}

	firstEvent = ParticleTrackerDllPTFilteredGate_MessageGate_allocateBlock(concretePool);
	lastEvent = firstEvent;
	ParticleTrackerDllPTFilteredGate_MessageGate_initializeBlock(firstEvent);

	/* size - 1 because of allocation of first */
	for (i = 0; i < size - 1; i++) {
		currEvent = ParticleTrackerDllPTFilteredGate_MessageGate_allocateBlock(concretePool);
		ParticleTrackerDllPTFilteredGate_MessageGate_initializeBlock(currEvent);
		
		((DSPEEvent*) lastEvent)->next = (DSPEEvent*) currEvent;
		lastEvent = currEvent;
	}

	concretePool->headEvent = firstEvent;
	concretePool->tailEvent = lastEvent;
	concretePool->eventNumElements = size;
}

/* eventPool reset function */
void ParticleTrackerDllPTFilteredGate_MessageGate_resetPoolBlock(DSPEEventsPool *pool) {
	ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock *concretePool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock*) pool;
	DSPEEventsPool *childPool = NULL;
	register size_t i;
	ParticleTrackerDllPTFilteredGate_MessageGate_event *event = NULL;
	/* Reset blocks children */
	childPool = (DSPEEventsPool*) ((DSPEBlockEventsPool*) pool)->blocksHead;
	for (i = 0; i < ((DSPEBlockEventsPool*) pool)->blocksNumElements; i++) {
		childPool->reset(childPool);
		childPool = childPool->next;
	}

	event = concretePool->headEvent;
	for (i = 0; i < concretePool->eventNumElements; i++) {
		ParticleTrackerDllPTFilteredGate_MessageGate_initializeBlock(event);
		event = (ParticleTrackerDllPTFilteredGate_MessageGate_event*) ((DSPEEvent*) event)->next;
	}
}

/* Allocate function */
ParticleTrackerDllPTFilteredGate_MessageGate_event* ParticleTrackerDllPTFilteredGate_MessageGate_allocateBlock(ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock *pool) {
	ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock *gatePool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock*) pool;
	ParticleTrackerDllPTFilteredGate_MessageGate_event *event = NULL;

	switch (gatePool->eventNumElements) {
	case 0:
		event = (ParticleTrackerDllPTFilteredGate_MessageGate_event*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllPTFilteredGate_MessageGate_event));
		initDSPEEvent((DSPEEvent*) event);
		((DSPEEvent*) event)->blockSize = ((DSPEBlockEventsPool*) gatePool)->size;
		((DSPEEvent*) event)->pool = (DSPEEventsPool*) pool;
		((DSPEEvent*) event)->dispose = ParticleTrackerDllPTFilteredGate_MessageGate_disposeBlock;
		((DSPEEvent*) event)->clone = ParticleTrackerDllPTFilteredGate_MessageGate_cloneBlock;
		ParticleTrackerDllPTFilteredGate_MessageGate_createBlock(event);
		ParticleTrackerDllPTFilteredGate_MessageGate_initializeBlock(event);
		return event;
	case 1:
		event = (ParticleTrackerDllPTFilteredGate_MessageGate_event*) gatePool->headEvent;
		gatePool->headEvent = NULL;
		gatePool->tailEvent = NULL;
		gatePool->eventNumElements = 0;
		((DSPEEvent*) event)->next = NULL;
		return event;
	default:
		event = (ParticleTrackerDllPTFilteredGate_MessageGate_event*) gatePool->headEvent;
		gatePool->headEvent = (ParticleTrackerDllPTFilteredGate_MessageGate_event*) ((DSPEEvent*) event)->next;
		gatePool->eventNumElements--;
		((DSPEEvent*) event)->next = NULL;
		return event;
	}
}

/* Create function */
void ParticleTrackerDllPTFilteredGate_MessageGate_createBlock(ParticleTrackerDllPTFilteredGate_MessageGate_event *event) {
	register size_t i;
	event->value = (ParticleTrackerDllPTFilteredGate_MessageGate*) memoryManager_allocate((DSPEElement*) ((DSPEEvent*) event)->pool, ((DSPEEvent*) event)->blockSize * sizeof(ParticleTrackerDllPTFilteredGate_MessageGate));
	//TODO da verificare!!
	event->anchor = *event->value;
	for (i = 0; i <  ((DSPEEvent*) event)->blockSize; i++) {
		event->value[i] = ParticleTrackerDllPTFilteredGate_MessageGate_allocateValue((DSPEElement*) ((DSPEEvent*) event)->pool);
		ParticleTrackerDllPTFilteredGate_MessageGate_initValue((DSPEElement*) ((DSPEEvent*) event)->pool, event->value[i]);
	}
}

/* Initialise function */
void ParticleTrackerDllPTFilteredGate_MessageGate_initializeBlock(ParticleTrackerDllPTFilteredGate_MessageGate_event *event) {
	register size_t i;
	for (i = 0; i <  ((DSPEEvent*) event)->blockSize; i++) {
		ParticleTrackerDllPTFilteredGate_MessageGate_initValue((DSPEElement*) ((DSPEEvent*) event)->pool, event->value[i]);
	}
}

/* Clone event function */
DSPEEvent* ParticleTrackerDllPTFilteredGate_MessageGate_cloneBlock(DSPEEvent *event) {
	ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock *gatePool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock*) event->pool;
	ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent *clone = NULL;
	
	switch (gatePool->cloneNumElements) {
	case 0:
		clone = (ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent));
		initDSPEEvent((DSPEEvent*) clone);
		((DSPEEvent*) clone)->dispose = ParticleTrackerDllPTFilteredGate_MessageGate_disposeCloneBlock;
		((DSPEEvent*) clone)->clone = ParticleTrackerDllPTFilteredGate_MessageGate_cloneBlock;
		((DSPEEvent*) clone)->pool = event->pool;
		((DSPEEvent*) clone)->blockSize = event->blockSize;
		break;
	case 1:
		clone = gatePool->headClone;
		gatePool->headClone = NULL;
		gatePool->tailClone = NULL;
		gatePool->cloneNumElements = 0;
		break;
	default:
		clone = gatePool->headClone;
		gatePool->headClone = (ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent*) ((DSPEEvent*) clone)->next;
		gatePool->cloneNumElements--;
		break;
	}

	event->refCount++;
	clone->original = event;

	((DSPEEvent*) clone)->next = NULL;

	((ParticleTrackerDllPTFilteredGate_MessageGate_event*) clone)->value = ((ParticleTrackerDllPTFilteredGate_MessageGate_event*) event)->value;

	return (DSPEEvent*) clone;
}

/* Dispose function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeBlock(DSPEEvent *event) {
	ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock *gatePool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock*) event->pool;
	if (event->refCount == 1) {
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->eventNumElements) {
		case 0:
			gatePool->headEvent = (ParticleTrackerDllPTFilteredGate_MessageGate_event*) event;
			gatePool->tailEvent = (ParticleTrackerDllPTFilteredGate_MessageGate_event*) event;
			gatePool->eventNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailEvent)->next = (DSPEEvent*) event;
			gatePool->tailEvent = (ParticleTrackerDllPTFilteredGate_MessageGate_event*) event;
			gatePool->eventNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* Dispose clone function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeCloneBlock(DSPEEvent *event) {
	ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock *gatePool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock*) event->pool;
	DSPEEvent *original = (DSPEEvent*) ((ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent*) event)->original;
	if (event->refCount == 1) {
		original->dispose(original);
		((ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent*) event)->original = NULL;
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->cloneNumElements) {
		case 0:
			gatePool->headClone = (ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent*) event;
			gatePool->tailClone = (ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent*) event;
			gatePool->cloneNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailClone)->next = (DSPEEvent*) event;
			gatePool->tailClone = (ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent*) event;
			gatePool->cloneNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* Destroy function */
void ParticleTrackerDllPTFilteredGate_MessageGate_destroyBlock(ParticleTrackerDllPTFilteredGate_MessageGate_event *event) {
	register size_t i;
	for (i = 0; i <  ((DSPEEvent*) event)->blockSize; i++) {
		ParticleTrackerDllPTFilteredGate_MessageGate_disposeValue((DSPEElement*) ((DSPEEvent*) event)->pool, event->value[i]);
	}
	memorySupport_dispose(event->value);
}

/* eventPool dispose function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposePoolBlock(DSPEEventsPool *pool) {
	ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock *thisPool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock*) pool;
	register size_t i;
	DSPEEvent *tmp  = NULL;
	
	/* dispose events */
	for (i = 0; i < thisPool->eventNumElements; i++) {
		tmp = (DSPEEvent*) thisPool->headEvent;
		thisPool->headEvent = (ParticleTrackerDllPTFilteredGate_MessageGate_event*) tmp->next;
		tmp->next = NULL;
		ParticleTrackerDllPTFilteredGate_MessageGate_destroyBlock((ParticleTrackerDllPTFilteredGate_MessageGate_event*) tmp);
		memorySupport_dispose(tmp);
	}
	/* dispose clones */
	for (i = 0; i < thisPool->cloneNumElements; i++) {
		tmp = (DSPEEvent*) thisPool->headClone;
		thisPool->headClone = (ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent*) tmp->next;
		tmp->next = NULL;
		((ParticleTrackerDllPTFilteredGate_MessageGate_event*) tmp)->value = NULL;
		memorySupport_dispose(tmp);
	}
	/* dispose pool */
	memorySupport_dispose(thisPool);
}

/* Allocate function */
ParticleTrackerDllPTFilteredGate_MessageGate* ParticleTrackerDllPTFilteredGate_MessageGate_allocateUnlinkedBlock(DSPEElement *context, size_t size) {
	return memoryManager_allocate(context, size * sizeof(ParticleTrackerDllPTFilteredGate_MessageGate));
}

/* Initialise function */
void ParticleTrackerDllPTFilteredGate_MessageGate_initializeUnlinkedBlock(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate *place, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllPTFilteredGate_MessageGate_initializeUnlinked(context, &place[i]);
	}
}

/* Set function */
void ParticleTrackerDllPTFilteredGate_MessageGate_setBlock(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate *place, size_t size, ParticleTrackerDllPTFilteredGate_MessageGate *value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		place[i] = value[i];
	}
}

/* Dispose function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeUnlinkedBlock(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate *place) {
	memorySupport_dispose(place);
}

/* groupEventPool initialization function */
ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock* ParticleTrackerDllPTFilteredGate_MessageGate_initGroupPoolBlock(const DSPEOwner *owner, size_t groupSize, size_t blockSize) {
	DSPEPoolHandler *handler = memoryManager_getPoolHandler(owner);
	ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock *pool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock*) memoryManager_getGroupPoolBlock(handler, &ParticleTrackerDllPTFilteredGate_MessageGate_allocateGroupBlock, groupSize, blockSize);
	/* lazy initialization */
	if (pool == NULL){
		pool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock*) memoryManager_allocate(CAST_TO_ELEMENT(owner), sizeof(ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock));
		initDSPEElement((DSPEElement*) pool, (DSPEElement*) handler);
		initDSPEGroupBlockEventsPool((DSPEGroupBlockEventsPool*) pool);
		pool->eventNumElements = 0;
		pool->headEvent = NULL;
		pool->tailEvent = NULL;
		pool->cloneNumElements = 0;
		pool->headClone = NULL;
		pool->tailClone = NULL;
		pool->containerNumElements = 0;
		pool->headContainer = NULL;
		pool->tailContainer = NULL;
		((DSPEEventsPool*) pool)->gateDefID = &ParticleTrackerDllPTFilteredGate_MessageGate_allocateGroupBlock;
		((DSPEEventsPool*) pool)->preAlloc = ParticleTrackerDllPTFilteredGate_MessageGate_preAllocGroupPoolBlock;
		((DSPEEventsPool*) pool)->reset = ParticleTrackerDllPTFilteredGate_MessageGate_resetGroupPoolBlock;
		((DSPEEventsPool*) pool)->dispose = ParticleTrackerDllPTFilteredGate_MessageGate_disposeGroupPoolBlock;
		((DSPEBlockEventsPool*) pool)->size = blockSize;
		((DSPEGroupBlockEventsPool*) pool)->groupSize = groupSize;
		memoryManager_addGroupPoolBlock(handler, (DSPEGroupBlockEventsPool*) pool);
	}
	return pool;
}

/* eventPool preAlloc function */
void ParticleTrackerDllPTFilteredGate_MessageGate_preAllocGroupPoolBlock(DSPEEventsPool *pool, size_t size) {
	ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock *concretePool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock*) pool;
	DSPEEventsPool *childPool = NULL;
	register size_t i, j;
	ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent *firstEvent = NULL;
	ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent *lastEvent = NULL;
	ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent *currEvent = NULL;
	
	/* PreAlloc blocks children */
	childPool = (DSPEEventsPool*) ((DSPEGroupBlockEventsPool*) pool)->blocksHead;
	for (i = 0; i < ((DSPEGroupBlockEventsPool*) pool)->blocksNumElements; i++) {
		childPool->preAlloc(childPool, size);
		childPool = childPool->next;
	}

	/* PreAlloc groups children */
	childPool = (DSPEEventsPool*) ((DSPEGroupBlockEventsPool*) pool)->groupsHead;
	for (i = 0; i < ((DSPEGroupBlockEventsPool*) pool)->groupsNumElements; i++) {
		childPool->preAlloc(childPool, size);
		childPool = childPool->next;
	}

	firstEvent = ParticleTrackerDllPTFilteredGate_MessageGate_allocateGroupBlock(concretePool);
	lastEvent = firstEvent;
	for (i = 0; i < ((DSPEGroupBlockEventsPool*) pool)->groupSize; i++) {
		ParticleTrackerDllPTFilteredGate_MessageGate_initializeGroupBlock(firstEvent, i);
	}

	/* size - 1 because of allocation of first */
	for (i = 0; i < size - 1; i++) {
		currEvent = ParticleTrackerDllPTFilteredGate_MessageGate_allocateGroupBlock(concretePool);
		for (j = 0; j < ((DSPEGroupBlockEventsPool*) pool)->groupSize; j++) {
			ParticleTrackerDllPTFilteredGate_MessageGate_initializeGroupBlock(currEvent, j);
		}
		
		((DSPEEvent*) lastEvent)->next = (DSPEEvent*) currEvent;
		lastEvent = currEvent;
	}

	concretePool->headEvent = firstEvent;
	concretePool->tailEvent = lastEvent;
	concretePool->eventNumElements = size;
}

/* eventPool reset function */
void ParticleTrackerDllPTFilteredGate_MessageGate_resetGroupPoolBlock(DSPEEventsPool *pool) {
	ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock *concretePool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock*) pool;
	DSPEEventsPool *childPool = NULL;
	register size_t i, j;
	ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent *event = NULL;
	/* PreAlloc blocks children */
	childPool = (DSPEEventsPool*) ((DSPEGroupBlockEventsPool*) pool)->blocksHead;
	for (i = 0; i < ((DSPEGroupBlockEventsPool*) pool)->blocksNumElements; i++) {
		childPool->reset(childPool);
		childPool = childPool->next;
	}

	/* PreAlloc groups children */
	childPool = (DSPEEventsPool*) ((DSPEGroupBlockEventsPool*) pool)->groupsHead;
	for (i = 0; i < ((DSPEGroupBlockEventsPool*) pool)->groupsNumElements; i++) {
		childPool->reset(childPool);
		childPool = childPool->next;
	}
	
	event = concretePool->headEvent;
	for (i = 0; i < concretePool->eventNumElements; i++) {
		for (j = 0; j < ((DSPEGroupBlockEventsPool*) pool)->groupSize; j++) {
			ParticleTrackerDllPTFilteredGate_MessageGate_initializeGroupBlock(event, j);
		}
		event = (ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent*) ((DSPEEvent*) event)->next;
	}
}

/* AllocateGroup function */
ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent* ParticleTrackerDllPTFilteredGate_MessageGate_allocateGroupBlock(ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock *pool) {
	ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock *gatePool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock*) pool;
	register size_t i;
	ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent *event = NULL;

	switch (gatePool->eventNumElements) {
	case 0:
		event = (ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent));
		initDSPEEvent((DSPEEvent*) event);
		initDSPEGroupEvent((DSPEGroupEvent*) event);
		((DSPEGroupEvent*) event)->groupSize = ((DSPEGroupBlockEventsPool*) pool)->groupSize;
		((DSPEEvent*) event)->blockSize = ((DSPEBlockEventsPool*) pool)->size;
		((DSPEEvent*) event)->pool = (DSPEEventsPool*) pool;
		((DSPEEvent*) event)->dispose = ParticleTrackerDllPTFilteredGate_MessageGate_disposeGroupBlock;
		((DSPEEvent*) event)->clone = ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupBlock;
		event->value = (ParticleTrackerDllPTFilteredGate_MessageGate**) memoryManager_allocate((DSPEElement*) gatePool, ((DSPEGroupBlockEventsPool*) pool)->groupSize * sizeof(ParticleTrackerDllPTFilteredGate_MessageGate*));
		for (i = 0; i < ((DSPEGroupBlockEventsPool*) pool)->groupSize; i++) {
			ParticleTrackerDllPTFilteredGate_MessageGate_createGroupBlock(event, i);
			ParticleTrackerDllPTFilteredGate_MessageGate_initializeGroupBlock(event, i);
		}
		return event;
	case 1:
		event = gatePool->headEvent;
		gatePool->headEvent = NULL;
		gatePool->tailEvent = NULL;
		gatePool->eventNumElements = 0;
		((DSPEEvent*) event)->next = NULL;
		return event;
	default:
		event = gatePool->headEvent;
		gatePool->headEvent = (ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent*) ((DSPEEvent*) event)->next;
		gatePool->eventNumElements--;
		((DSPEEvent*) event)->next = NULL;
		return event;
	}
}

/* CreateGroup function */
void ParticleTrackerDllPTFilteredGate_MessageGate_createGroupBlock(ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent *event, size_t index) {
	register size_t i;
	event->value[index] = (ParticleTrackerDllPTFilteredGate_MessageGate*) memoryManager_allocate((DSPEElement*) ((DSPEEvent*) event)->pool, ((DSPEEvent*) event)->blockSize * sizeof(ParticleTrackerDllPTFilteredGate_MessageGate));
	for (i = 0; i <  ((DSPEEvent*) event)->blockSize; i++) {
		event->value[index][i] = ParticleTrackerDllPTFilteredGate_MessageGate_allocateValue((DSPEElement*) ((DSPEEvent*) event)->pool);
		ParticleTrackerDllPTFilteredGate_MessageGate_initValue((DSPEElement*) ((DSPEEvent*) event)->pool, event->value[index][i]);
	}
}

/* InitialiseGroup function */
void ParticleTrackerDllPTFilteredGate_MessageGate_initializeGroupBlock(ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent *event, size_t index) {
	register size_t i;
	for (i = 0; i <  ((DSPEEvent*) event)->blockSize; i++) {
		ParticleTrackerDllPTFilteredGate_MessageGate_initValue((DSPEElement*) ((DSPEEvent*) event)->pool, event->value[index][i]);
	}
}

/* CloneGroup event function */
DSPEEvent* ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupBlock(DSPEEvent *event) {
	register size_t i;
	ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock *gatePool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock*) event->pool;
	ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupEvent *clone = NULL;

	switch (gatePool->cloneNumElements) {
	case 0:
		clone = (ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupEvent*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupEvent));
		((ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent*) clone)->value = (ParticleTrackerDllPTFilteredGate_MessageGate**) memoryManager_allocate((DSPEElement*) gatePool, ((DSPEGroupEvent*) event)->groupSize * sizeof(ParticleTrackerDllPTFilteredGate_MessageGate*));
		initDSPEGroupEvent((DSPEGroupEvent*) clone);
		((DSPEGroupEvent*) clone)->groupSize = ((DSPEGroupEvent*) event)->groupSize;
		((DSPEEvent*) clone)->dispose = ParticleTrackerDllPTFilteredGate_MessageGate_disposeGroupCloneBlock;
		((DSPEEvent*) clone)->clone = ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupBlock;
		((DSPEEvent*) clone)->pool = event->pool;
		((DSPEEvent*) clone)->blockSize = event->blockSize;
		break;
	case 1:
		clone = gatePool->headClone;
		gatePool->headClone = NULL;
		gatePool->tailClone = NULL;
		gatePool->cloneNumElements = 0;
		break;
	default:
		clone = gatePool->headClone;
		gatePool->headClone = (ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupEvent*) ((DSPEEvent*) clone)->next;
		gatePool->cloneNumElements--;
		break;
	}
	((DSPEEvent*) clone)->next = NULL;
	
	event->refCount++;
	clone->original = (DSPEGroupEvent*) event;

	for (i = 0; i < ((DSPEGroupEvent*) event)->groupSize; i++) {
		((ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent*) clone)->value[i] = ((ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent*) event)->value[i];
	}
	
	return (DSPEEvent*) clone;
}

/* SubClone event function */
DSPEEvent* ParticleTrackerDllPTFilteredGate_MessageGate_subCloneBlock(DSPEGroupEvent *event, DSPEEventsPool *pool, size_t index) {
	ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock *gatePool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock*) pool;
	ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent *clone = NULL;

	switch (gatePool->cloneNumElements) {
	case 0:
		clone = (ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent));
		((ParticleTrackerDllPTFilteredGate_MessageGate_event*) clone)->value = NULL;
		initDSPEEvent((DSPEEvent*) clone);
		((DSPEEvent*) clone)->dispose = ParticleTrackerDllPTFilteredGate_MessageGate_disposeCloneBlock;
		((DSPEEvent*) clone)->clone = ParticleTrackerDllPTFilteredGate_MessageGate_cloneBlock;
		((DSPEEvent*) clone)->pool = pool;
		((DSPEEvent*) clone)->blockSize = ((DSPEBlockEventsPool*) pool)->size;
		break;
	case 1:
		clone = gatePool->headClone;
		gatePool->headClone = NULL;
		gatePool->tailClone = NULL;
		gatePool->cloneNumElements = 0;
		break;
	default:
		clone = gatePool->headClone;
		gatePool->headClone = (ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent*) ((DSPEEvent*) clone)->next;
		gatePool->cloneNumElements--;
		break;
	}
	((DSPEEvent*) clone)->next = NULL;
	
	/* Set clones's original and increment original's refCounter */
	((DSPEEvent*) event)->refCount++;
	((ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent*) clone)->original = (DSPEEvent*) event;
	
	((ParticleTrackerDllPTFilteredGate_MessageGate_event*) clone)->value = ((ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent*) event)->value[index];
	return (DSPEEvent*) clone;
}

/**
 * Allocate containerEvent function
 */
ParticleTrackerDllPTFilteredGate_MessageGate_eventContainer* ParticleTrackerDllPTFilteredGate_MessageGate_allocateContainerBlock(ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock *pool) {
	ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock *gatePool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock*) pool;
	ParticleTrackerDllPTFilteredGate_MessageGate_eventContainer *event = NULL;
	register size_t i;
	switch (gatePool->containerNumElements) {
	case 0:
		event = (ParticleTrackerDllPTFilteredGate_MessageGate_eventContainer*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllPTFilteredGate_MessageGate_eventContainer));
		initDSPEGroupEvent((DSPEGroupEvent*) event);
		((DSPEEvent*) event)->pool = (DSPEEventsPool*) pool;
		((DSPEEvent*) event)->dispose = ParticleTrackerDllPTFilteredGate_MessageGate_disposeContainerBlock;
		((DSPEEvent*) event)->clone = ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupBlock;
		((DSPEGroupEvent*) event)->groupSize = ((DSPEGroupBlockEventsPool*) gatePool)->groupSize;
		((ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent*) event)->value = (ParticleTrackerDllPTFilteredGate_MessageGate**) memoryManager_allocate((DSPEElement*) gatePool, ((DSPEGroupEventsPool*) gatePool)->groupSize * sizeof(ParticleTrackerDllPTFilteredGate_MessageGate*));
		event->containedEvents = (DSPEEvent**) memoryManager_allocate((DSPEElement*) gatePool, ((DSPEGroupBlockEventsPool*) gatePool)->groupSize * sizeof(DSPEEvent*));
		for (i = 0; i < ((DSPEGroupBlockEventsPool*) gatePool)->groupSize; i++) {
			event->containedEvents[i] = NULL;
			((ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent*) event)->value[i] = NULL;
		}
		return event;
	case 1:
		event = gatePool->headContainer;
		gatePool->headContainer = NULL;
		gatePool->tailContainer = NULL;
		gatePool->containerNumElements = 0;
		((DSPEEvent*) event)->next = NULL;
		return event;
	default:
		event = gatePool->headContainer;
		gatePool->headContainer = (ParticleTrackerDllPTFilteredGate_MessageGate_eventContainer*) ((DSPEEvent*) event)->next;
		gatePool->containerNumElements--;
		((DSPEEvent*) event)->next = NULL;
		return event;
	}
}

/**
 * Dispose containerEvent function
 */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeContainerBlock(DSPEEvent *event) {
	ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock *gatePool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock*) event->pool;
	register size_t i;
	ParticleTrackerDllPTFilteredGate_MessageGate_eventContainer *container = (ParticleTrackerDllPTFilteredGate_MessageGate_eventContainer*) event;
	DSPEEvent *refEvent = NULL;
	if (event->refCount == 1) {
		for (i = 0; i < ((DSPEGroupBlockEventsPool*) gatePool)->groupSize; i++) {
			refEvent = container->containedEvents[i];
			if (refEvent != NULL) {
				refEvent->dispose(refEvent);
				container->containedEvents[i] = NULL;
			}
			((ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent*) container)->value[i] = NULL;
		}
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->containerNumElements) {
		case 0:
			gatePool->headContainer = (ParticleTrackerDllPTFilteredGate_MessageGate_eventContainer*) event;
			gatePool->tailContainer = (ParticleTrackerDllPTFilteredGate_MessageGate_eventContainer*) event;
			gatePool->containerNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailContainer)->next = event;
			gatePool->tailContainer = (ParticleTrackerDllPTFilteredGate_MessageGate_eventContainer*) event;
			gatePool->containerNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* DisposeGroup function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeGroupBlock(DSPEEvent *event) {
	ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock *gatePool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock*) event->pool;
	if (event->refCount == 1) {
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->eventNumElements) {
		case 0:
			gatePool->headEvent = (ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent*) event;
			gatePool->tailEvent = (ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent*) event;
			gatePool->eventNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailEvent)->next = (DSPEEvent*) event;
			gatePool->tailEvent = (ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent*) event;
			gatePool->eventNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* Dispose GroupClone function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeGroupCloneBlock(DSPEEvent *event) {
	ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock *gatePool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock*) event->pool;
	DSPEEvent *original = (DSPEEvent*) ((ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupEvent*) event)->original;
	if (event->refCount == 1) {
		original->dispose(original);
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->cloneNumElements) {
		case 0:
			gatePool->headClone = (ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupEvent*) event;
			gatePool->tailClone = (ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupEvent*) event;
			gatePool->cloneNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailClone)->next = (DSPEEvent*) event;
			gatePool->tailClone = (ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupEvent*) event;
			gatePool->cloneNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* DestroyGroup function */
void ParticleTrackerDllPTFilteredGate_MessageGate_destroyGroupBlock(ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent *event) {
	register size_t i, j;
	for (i = 0; i < ((DSPEGroupEvent*) event)->groupSize; i++) {
		for (j = 0; j < ((DSPEEvent*) event)->blockSize; j++) {
			ParticleTrackerDllPTFilteredGate_MessageGate_disposeValue((DSPEElement*) ((DSPEEvent*) event)->pool, event->value[i][j]);
		}
	}
	memorySupport_dispose(event->value);
}

/* eventPool dispose function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeGroupPoolBlock(DSPEEventsPool *pool) {
	register size_t i;
	DSPEEvent *tmp = NULL;
	DSPEEventsPool *eventPool = NULL;
	DSPEEventsPool *tmpEventPool = NULL;
	ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock *thisPool = (ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock*) pool;

	/* dispose children */
	eventPool = (DSPEEventsPool*) ((DSPEGroupEventsPool*) thisPool)->groupsHead;
	for (i = 0; i < ((DSPEGroupEventsPool*) thisPool)->groupsNumElements; i++) {
		tmpEventPool = eventPool;
		eventPool = eventPool->next;
		tmpEventPool->next = NULL;
		tmpEventPool->dispose(tmpEventPool);
	}
	/* dispose events */
	for (i = 0; i < thisPool->eventNumElements; i++) {
		tmp = (DSPEEvent*) thisPool->headEvent;
		thisPool->headEvent = (ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent*) tmp->next;
		tmp->next = NULL;
		ParticleTrackerDllPTFilteredGate_MessageGate_destroyGroupBlock((ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent*) tmp);
		memorySupport_dispose(tmp);
	}
	/* dispose clones */
	for (i = 0; i < thisPool->cloneNumElements; i++) {
		tmp = (DSPEEvent*) thisPool->headClone;
		thisPool->headClone = (ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupEvent*) tmp->next;
		tmp->next = NULL;
		((ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent*) tmp)->value = NULL;
		((ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent*) tmp)->anchor = NULL;
		memorySupport_dispose(tmp);
	}
	/* dispose pool */
	memorySupport_dispose(thisPool);
}

