/**
 * File: B_ParticleTrackerDllBoolGate_StandardGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "MemoryManager.h"

#include "B_ParticleTrackerDllBoolGate_StandardGate.h"

/* Allocate function */
ParticleTrackerDllBoolGate_StandardGate* ParticleTrackerDllBoolGate_StandardGate_allocate(DSPEElement *context) {
	return memoryManager_allocate(context, sizeof(ParticleTrackerDllBoolGate_StandardGate));
}

/* Initialise function */
void ParticleTrackerDllBoolGate_StandardGate_initialize(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate *place) {
	*place = PARTICLETRACKERDLLBOOLGATE_STANDARDGATE_DEFAULTVALUE;
}

/* Set function */
void ParticleTrackerDllBoolGate_StandardGate_setOverride(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate *place, ParticleTrackerDllBoolGate_StandardGate value) {
	*place = value;
}

/* Set function */
void ParticleTrackerDllBoolGate_StandardGate_set(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate *place, ParticleTrackerDllBoolGate_StandardGate *value) {
	*place = *value;
}

/* Dispose function */
void ParticleTrackerDllBoolGate_StandardGate_dispose(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate *place) {
	memorySupport_dispose(place);
}

/* AllocateGroup function */
void ParticleTrackerDllBoolGate_StandardGate_allocateGroup(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	place[i] = ParticleTrackerDllBoolGate_StandardGate_allocate(context);
	}
}

/* InitialiseGroup function */
void ParticleTrackerDllBoolGate_StandardGate_initializeGroup(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
	 	ParticleTrackerDllBoolGate_StandardGate_initialize(context, place[i]);
	}
}

/* SetOverrideGroup function */
void ParticleTrackerDllBoolGate_StandardGate_setOverrideGroup(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t size, ParticleTrackerDllBoolGate_StandardGate value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllBoolGate_StandardGate_setOverride(context, place[i], value);
	}
}

/* SetGroup function */
void ParticleTrackerDllBoolGate_StandardGate_setGroup(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t size, ParticleTrackerDllBoolGate_StandardGate **value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllBoolGate_StandardGate_set(context, place[i], value[i]);
	}
}

/* DisposeGroup function */
void ParticleTrackerDllBoolGate_StandardGate_disposeGroup(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	memorySupport_dispose(place[i]);
	}
}

/* CreateNode function */
ParticleTrackerDllBoolGate_StandardGate_node* ParticleTrackerDllBoolGate_StandardGate_createNode(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate *gate, ParticleTrackerDllBoolGate_StandardGate *localVar) {
	ParticleTrackerDllBoolGate_StandardGate_node *node = (ParticleTrackerDllBoolGate_StandardGate_node*) memoryManager_allocate(context, sizeof(ParticleTrackerDllBoolGate_StandardGate_node));
	initDSPEGateNode((DSPEGateNode*) node);
	node->gate = gate;
	node->localVar = localVar;
	((DSPEGateNode*) node)->setValue = ParticleTrackerDllBoolGate_StandardGate_setValue;
	((DSPEGateNode*) node)->disposeNode = ParticleTrackerDllBoolGate_StandardGate_disposeNode;
	return node;
}

/* DisposeNode function */
void ParticleTrackerDllBoolGate_StandardGate_disposeNode(DSPEElement *context, DSPEGateNode *node) {
	node->next = NULL;
	memorySupport_dispose(node);
}

/* SetValue function */
void ParticleTrackerDllBoolGate_StandardGate_setValue(DSPEElement *context, DSPEGateNode *node) {
	ParticleTrackerDllBoolGate_StandardGate_node *tmpNode = (ParticleTrackerDllBoolGate_StandardGate_node*) node;
	if (tmpNode->gate != 0)
		*tmpNode->gate = tmpNode->value;
	if (tmpNode->localVar != 0)
		*tmpNode->localVar = tmpNode->value;
}

