/**
 * File: RBlock_ParticleTrackerDllStatusGate_StringGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "StringManager.h"
#include "MemoryManager.h"

#include "RBlock_ParticleTrackerDllStatusGate_StringGate.h"

/* AllocateBlockManaged function */
void ParticleTrackerDllStatusGate_StringGate_allocateBlockManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *anchor, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		anchor[i] = ParticleTrackerDllStatusGate_StringGate_allocateValue(context);
	}
}

/* InitBlockManaged function */
void ParticleTrackerDllStatusGate_StringGate_initBlockManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *anchor, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllStatusGate_StringGate_initManaged(context, anchor[i]);
	}
}

/* DisposeBlockManaged function */
void ParticleTrackerDllStatusGate_StringGate_disposeBlockManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *anchor, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllStatusGate_StringGate_disposeManaged(context, anchor[i]);
	}
}

/* AllocateGroupBlockManaged function */
void ParticleTrackerDllStatusGate_StringGate_allocateGroupBlockManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **anchor, size_t size, size_t *gateSize) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllStatusGate_StringGate_allocateBlockManaged(context, anchor[i], gateSize[i]);
	}
}

/* InitGroupBlockManaged function */
void ParticleTrackerDllStatusGate_StringGate_initGroupBlockManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **anchor, size_t size, size_t *gateSize) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllStatusGate_StringGate_initBlockManaged(context, anchor[i], gateSize[i]);
	}
}

/* DisposeGroupBlockManaged function */
void ParticleTrackerDllStatusGate_StringGate_disposeGroupBlockManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **anchor, size_t size, size_t *gateSize) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllStatusGate_StringGate_disposeBlockManaged(context, anchor[i], gateSize[i]);
	}
}

/* Allocate function */
ParticleTrackerDllStatusGate_StringGate* ParticleTrackerDllStatusGate_StringGate_allocateBlock(DSPEElement *context, size_t size) {
	return memoryManager_allocate(context, size * sizeof(ParticleTrackerDllStatusGate_StringGate));
}

/* Initialise function */
void ParticleTrackerDllStatusGate_StringGate_initializeBlock(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *place, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllStatusGate_StringGate_initialize(context, &place[i]);
	}
}

/* SetOverride function */
void ParticleTrackerDllStatusGate_StringGate_setOverrideBlock(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *place, size_t size, ParticleTrackerDllStatusGate_StringGate value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllStatusGate_StringGate_setOverride(context, &place[i], value);
	}
}

/* Set function */
void ParticleTrackerDllStatusGate_StringGate_setBlock(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *place, size_t size, ParticleTrackerDllStatusGate_StringGate *value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllStatusGate_StringGate_set(context, &place[i], &value[i]);
	}
}

/* Dispose function */
void ParticleTrackerDllStatusGate_StringGate_disposeBlock(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *place) {
	memorySupport_dispose(place);
}

/* AllocateGroup function */
void ParticleTrackerDllStatusGate_StringGate_allocateGroupBlock(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t groupSize, size_t *gateSize) {
	register size_t i;	
	for (i = 0; i < groupSize; i++) {
	 	place[i] = ParticleTrackerDllStatusGate_StringGate_allocateBlock(context, gateSize[i]);	
	}
}

/* InitialiseGroup function */
void ParticleTrackerDllStatusGate_StringGate_initializeGroupBlock(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t groupSize, size_t *gateSize) {
	register size_t i, j;
	for (i = 0; i < groupSize; i++) {
		for (j = 0; j <  gateSize[i]; j++) {
			ParticleTrackerDllStatusGate_StringGate_initialize(context, &place[i][j]);
		}
	}
}

/* SetOverrideGroupBlock function */
void ParticleTrackerDllStatusGate_StringGate_setOverrideGroupBlock(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllStatusGate_StringGate value) {
	register size_t i;
	for (i = 0; i < groupSize; i++) {
		ParticleTrackerDllStatusGate_StringGate_setOverrideBlock(context, place[i], gateSize[i], value);
	}
}

/* SetGroup function */
void ParticleTrackerDllStatusGate_StringGate_setGroupBlock(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllStatusGate_StringGate **value) {
	register size_t i, j;
	for (i = 0; i < groupSize; i++) {
		for (j = 0; j <  gateSize[i]; j++) {
			ParticleTrackerDllStatusGate_StringGate_set(context, &place[i][j], &value[i][j]);
		}
	}
}

/* DisposeGroup function */
void ParticleTrackerDllStatusGate_StringGate_disposeGroupBlock(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	memorySupport_dispose(place[i]);
	}
}

