/**
 * File: F_ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation.c
 *
 * @author Loris
 * @created Thu May 26 10:23:50 CEST 2011
 */
#include "InfoManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "EngineManager.h"
#include "B_ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation.h"
#include "S_ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation.h"

#include "B_ParticleTrackerDllTracker_Requirement.h"
#include "B_ParticleTrackerDllDebug_Requirement.h"
#include "B_ParticleTrackerDllPendingEvents_Requirement.h"

/**
 * Convenience defines to access unit state variables.
 */
#define currState context->state
/* Input ParameterGates Shortcuts */
#define pIn_stop (*context->paramIn_stop)
#define pIn_Linkrange (*context->paramIn_Linkrange)
#define pIn_Displacement (*context->paramIn_Displacement)

/* Output ParameterGates Shortcuts */
#define pOut_stop (*context->paramOut_stop)
#define pOut_Status (*context->paramOut_Status)
#define pOut_Status_set(str) stringSupport_copy(*context->paramOut_Status, str)

/* Input DataGates Shortcuts */
#define dIn_PTFrame (*context->dataIn_PTFrame)

/* Output DataGates Shortcuts */
#define dOut_PTFrame (*context->dataOut_PTFrame)

/* numLinks shortcuts */
#define dIn_PTFrame_numLinks context->dataIn_PTFrame_numLinks
#define dOut_PTFrame_numLinks context->dataOut_PTFrame_numLinks
#define pIn_next_numLinks context->paramIn_next_numLinks
#define pIn_stop_numLinks context->paramIn_stop_numLinks
#define pIn_Linkrange_numLinks context->paramIn_Linkrange_numLinks
#define pIn_Displacement_numLinks context->paramIn_Displacement_numLinks
#define pOut_next_numLinks context->paramOut_next_numLinks
#define pOut_stop_numLinks context->paramOut_stop_numLinks
#define pOut_Status_numLinks context->paramOut_Status_numLinks

/* AdditionalStateVariables shortcuts */
#define addS_framesToLink context->functionalState.framesToLink
#define addS_linkrangeCounter context->functionalState.linkrangeCounter
#define addS_currentFrame context->functionalState.currentFrame
#define addS_index context->functionalState.index
#define addS_currentState context->functionalState.currentState

/* AdditionalStateVariables default values */
#define ADDS_FRAMESTOLINK_DEFAULTVALUE 0
#define ADDS_LINKRANGECOUNTER_DEFAULTVALUE 0
#define ADDS_CURRENTFRAME_DEFAULTVALUE 0
#define ADDS_INDEX_DEFAULTVALUE 0
#define ADDS_CURRENTSTATE_DEFAULTVALUE 0

/* Input EventGate IDs */
#define pIn_next_event 1000
#define dIn_PTFrame_event 1001

/* Common event shortcuts */
#define event_isAvailable() isEventAvailable(context)
#define event_transit() transitEvent(context)
#define event_getID() getEventID(context)

/* Parameter Output support function shortcuts */
#define pOut_next_sendEvent() sendPE_next(context)

/* Data Input getEvent function shortcuts */
#define dIn_PTFrame_getEvent() getDE_PTFrame(context)

/* Data Input transit support functions */
#define dIn_PTFrame_transitNumElements() getTransitNumElementsDE_PTFrame(context)
#define dIn_PTFrame_getFirstTransit() getFirstTransitDE_PTFrame(context)
#define dIn_PTFrame_currentNumElements() getCurrentNumElementsDE_PTFrame(context)
#define dIn_PTFrame_getCurTransit() getCurTransitDE_PTFrame(context)
#define dIn_PTFrame_dismissEvent() dismissDE_PTFrame(context)

/* Data Output support function shortcuts */
#define dOut_PTFrame_armEvent() armDE_PTFrame(context)
#define dOut_PTFrame_sendEvent() sendDE_PTFrame(context)

/* MemoryManager function shortcuts */
#define memory_allocate(size) memoryManager_allocate((DSPEElement*) context, size)
#define memory_allocateAndInit(blockSize, size) memoryManager_allocateAndInit((DSPEElement*) context, blockSize, size)
#define memory_realloc(pointer, newSize) memorySupport_realloc(pointer, newSize)
#define memory_dispose(pointer) memorySupport_dispose(pointer)
#define memory_copyBlock(destination, source, size) memorySupport_copyBlock(destination, source, size)
#define memory_resetBlock(destination, size) memorySupport_resetBlock(destination, size)

/* StringManager function shortcuts */
#define string_copy(destination, source) stringSupport_copy(destination, source)
#define string_nCopy(destination, source, numChars) stringSupport_nCopy(destination, source, numChars)
#define string_compare(first, second) stringSupport_compare(first, second)
#define string_nCompare(first, second, numChars) stringSupport_nCompare(first, second, numChars)
#define string_compareNoCase(first, second) stringSupport_compareNoCase(first, second)
#define string_nCompareNoCase(first, second, numChars) stringSupport_nCompareNoCase(first, second, numChars)
#define string_length(string) stringSupport_length(string)

/* EngineManager function shortcuts */
#define engine_run() engineManager_run((DSPEElement*) context)
#define engine_stop() engineManager_stop((DSPEElement*) context)
#define engine_pause() engineManager_pause((DSPEElement*) context)
#define engine_skip(cycles) engineManager_skip((DSPEElement*) context, cycles)
#define engine_quit() engineManager_quit((DSPEElement*) context)
#define engine_suspend() engineManager_suspend((DSPEElement*) context)
#define engine_freeze() engineManager_freeze((DSPEElement*) context)
#define engine_resume() engineManager_resume((DSPEElement*) context)

#define engine_isExecuting() engineManager_isExecuting((DSPEElement*) context)
#define engine_isStopping() engineManager_isStopping((DSPEElement*) context)
#define engine_isStopped() engineManager_isStopped((DSPEElement*) context)
#define engine_isPaused() engineManager_isPaused((DSPEElement*) context)
#define engine_isSkipping() engineManager_isSkipping((DSPEElement*) context)
#define engine_isExiting() engineManager_isExiting((DSPEElement*) context)
#define engine_isSuspended() engineManager_isSuspended((DSPEElement*) context)

/* InfoManager function shortcuts */
#if defined(INFOMANAGER_BYPASS_CONSOLE) && (INFOMANAGER_BYPASS_CONSOLE == 1)
#define info_writeInfo(info, ...)
#define info_collectAndWriteInfo(id)
#define info_nCollectAndWriteInfo(id, increment)
#else
#define info_writeInfo(info, ...) infoManager_writeInfo((DSPEElement*) context, info , ##__VA_ARGS__)
#define info_collectAndWriteInfo(id) infoManager_collectAndWriteInfo((DSPEElement*) context, id, 1)
#define info_nCollectAndWriteInfo(id, increment) infoManager_collectAndWriteInfo((DSPEElement*) context, id, increment)
#endif
#if defined(INFOMANAGER_BYPASS_LOG) && (INFOMANAGER_BYPASS_LOG == 1)
#define info_logInfo(info, ...)
#define info_collectAndLogInfo(id)
#define info_nCollectAndLogInfo(id, increment)
#else
#define info_logInfo(info, ...) infoManager_logInfo((DSPEElement*) context, info , ##__VA_ARGS__)
#define info_collectAndLogInfo(id) infoManager_collectAndLogInfo((DSPEElement*) context, id, 1)
#define info_nCollectAndLogInfo(id, increment) infoManager_collectAndLogInfo((DSPEElement*) context, id, increment)
#endif

/**
 * PreProcess algorithm. Process phase initialization should take place here.
 * This function will be called ONCE before the process phase.
 */
void ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation_preProcess(ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *context) {
//Place implementation after this line -- SYD-PREPROCESS-START
	int i;

	pOut_Status_set("Running");

	addS_framesToLink = (PTFrame**) memory_allocate((pIn_Linkrange + 1) * sizeof(PTFrame*));
	for(i = 0; i <= pIn_Linkrange; i++)
		addS_framesToLink[i] = NULL;

#ifdef DEBUG
#ifdef DEBUG_LINK
	DEBUG_initFile(DEBUG_LINK, "w");
#endif
#endif
//SYD-PREPROCESS-END -- Place implementation before this line
}

/**
 * Process algorithm. What the unit really does should take place here.
 * This function will be called at each process cycle.
 */
void ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation_process(ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *context) {
//Place implementation after this line -- SYD-PROCESS-START
	int i, c;
	PTFrame *ptFrameFrom, *ptFrameTo;

	if(dIn_PTFrame_currentNumElements() == 0)
		return;

	if(addS_currentState == 0) {
		dIn_PTFrame_getCurTransit();
		addS_framesToLink[addS_index] = dIn_PTFrame;

		PT_InitParticleNext(addS_framesToLink[addS_index]->pl, pIn_Linkrange);

		addS_currentState++;
	} else if(addS_currentState < pIn_Linkrange) {
		dIn_PTFrame_getCurTransit();
		addS_framesToLink[addS_index] = dIn_PTFrame;

		PT_InitParticleNext(addS_framesToLink[addS_index]->pl, pIn_Linkrange);

		for(i = addS_currentFrame ; i < addS_index; i++) {
			ptFrameFrom = addS_framesToLink[i];
			ptFrameTo = addS_framesToLink[addS_index];
			PT_LinkParticles(ptFrameFrom->pl, ptFrameTo->pl, pIn_Linkrange, pIn_Displacement, addS_index - i - 1);
		}

		addS_currentState++;
	} else if(addS_currentState >= pIn_Linkrange) {
		dIn_PTFrame_getCurTransit();
		addS_framesToLink[addS_index] = dIn_PTFrame;

		PT_InitParticleNext(addS_framesToLink[addS_index]->pl, pIn_Linkrange);

		for(i = 0; i < pIn_Linkrange; i++) {
			c = addS_currentFrame + i;
			if(c > pIn_Linkrange)
				c -= pIn_Linkrange + 1;
			ptFrameFrom = addS_framesToLink[c];
			ptFrameTo = addS_framesToLink[addS_index];
			PT_LinkParticles(ptFrameFrom->pl, ptFrameTo->pl, pIn_Linkrange, pIn_Displacement, pIn_Linkrange - i - 1);
		}

		dOut_PTFrame_armEvent();
		dOut_PTFrame = addS_framesToLink[addS_currentFrame];

#ifdef DEBUG
#ifdef DEBUG_LINK
		DEBUG_printLinkParticles(DEBUG_LINK, dOut_PTFrame, pIn_Linkrange);
#endif
#endif

		dOut_PTFrame_sendEvent();

		addS_framesToLink[addS_currentFrame] =  NULL;
		dIn_PTFrame_dismissEvent();

		addS_currentFrame++;
		if(addS_currentFrame >= pIn_Linkrange + 1) {
			addS_currentFrame = 0;
		}

		if(addS_framesToLink[addS_currentFrame]->isLast) {
			addS_currentState = -1;

			dOut_PTFrame_armEvent();
			dOut_PTFrame = addS_framesToLink[addS_currentFrame];

#ifdef DEBUG
#ifdef DEBUG_LINK
			DEBUG_printLinkParticles(DEBUG_LINK, dOut_PTFrame, pIn_Linkrange);
#endif
#endif

			dOut_PTFrame_sendEvent();

			addS_framesToLink[addS_currentFrame] =  NULL;
			dIn_PTFrame_dismissEvent();

			for(i = 1; i <= pIn_Linkrange; i++) {
				c = addS_currentFrame + i;
				if(c > pIn_Linkrange)
					c = addS_currentFrame + i - (pIn_Linkrange +1);
				if(addS_framesToLink[c] == NULL)
					continue;
				ptFrameFrom = addS_framesToLink[c];
				dOut_PTFrame_armEvent();
				dOut_PTFrame = ptFrameFrom;

#ifdef DEBUG
#ifdef DEBUG_LINK
				DEBUG_printLinkParticles(DEBUG_LINK, dOut_PTFrame, pIn_Linkrange);
#endif
#endif

				dOut_PTFrame_sendEvent();

				addS_framesToLink[c] =  NULL;
				dIn_PTFrame_dismissEvent();

			}
		}
	} else {
		pOut_Status_set("No more frame to link");
	}

	addS_index++;
	if(addS_index > pIn_Linkrange)
		addS_index = 0;
//SYD-PROCESS-END -- Place implementation before this line 
}

/**
 * PostProcess algorithm. Process phase cleanup should take place here.
 * This function will be called ONCE after the process phase.
 */
void ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation_postProcess(ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *context) {
//Place implementation after this line -- SYD-POSTPROCESS-START
	memory_dispose(addS_framesToLink);
//SYD-POSTPROCESS-END -- Place implementation before this line 
}

#undef currState
/* Input ParameterGates Shortcuts */
#undef pIn_stop
#undef pIn_Linkrange
#undef pIn_Displacement

/* Output ParameterGates Shortcuts */
#undef pOut_stop
#undef pOut_Status
#undef pOut_Status_set

/* Input DataGates Shortcuts */
#undef dIn_PTFrame

/* Output DataGates Shortcuts */
#undef dOut_PTFrame

/* numLinks shortcuts */
#undef dIn_PTFrame_numLinks
#undef dOut_PTFrame_numLinks
#undef pIn_next_numLinks
#undef pIn_stop_numLinks
#undef pIn_Linkrange_numLinks
#undef pIn_Displacement_numLinks
#undef pOut_next_numLinks
#undef pOut_stop_numLinks
#undef pOut_Status_numLinks

/* AdditionalStateVariables shortcuts */
#undef addS_framesToLink
#undef addS_linkrangeCounter
#undef addS_currentFrame
#undef addS_index
#undef addS_currentState

#undef ADDS_FRAMESTOLINK_DEFAULTVALUE
#undef ADDS_LINKRANGECOUNTER_DEFAULTVALUE
#undef ADDS_CURRENTFRAME_DEFAULTVALUE
#undef ADDS_INDEX_DEFAULTVALUE
#undef ADDS_CURRENTSTATE_DEFAULTVALUE

#undef pIn_next_event
#undef dIn_PTFrame_event
#undef event_isAvailable
#undef event_getID

#undef event_transit

#undef pOut_next_sendEvent

#undef dIn_PTFrame_getEvent

#undef dIn_PTFrame_transitNumElements
#undef dIn_PTFrame_getFirstTransit
#undef dIn_PTFrame_currentNumElements
#undef dIn_PTFrame_getCurTransit
#undef dIn_PTFrame_dismissEvent

#undef dOut_PTFrame_armEvent
#undef dOut_PTFrame_sendEvent

/* MemoryManager function shortcuts */
#undef memory_allocate
#undef memory_allocateAndInit
#undef memory_realloc
#undef memory_dispose
#undef memory_copyBlock
#undef memory_resetBlock

/* StringManager function shortcuts */
#undef string_copy
#undef string_nCopy
#undef string_compare
#undef string_nCompare
#undef string_compareNoCase
#undef string_nCompareNoCase
#undef string_length

/* EngineManager function shortcuts */
#undef engine_run
#undef engine_stop
#undef engine_pause
#undef engine_skip
#undef engine_quit
#undef engine_suspend
#undef engine_freeze
#undef engine_resume

#undef engine_isExecuting
#undef engine_isStopping
#undef engine_isStopped
#undef engine_isPaused
#undef engine_isSkipping
#undef engine_isExiting
#undef engine_isSuspended

/* InfoManager function shortcuts */
#undef info_writeInfo
#undef info_collectAndWriteInfo
#undef info_nCollectAndWriteInfo
#undef info_logInfo
#undef info_collectAndLogInfo
#undef info_nCollectAndLogInfo

