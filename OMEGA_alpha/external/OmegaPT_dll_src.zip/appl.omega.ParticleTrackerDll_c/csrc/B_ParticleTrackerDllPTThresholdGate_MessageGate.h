/**
 * File: B_ParticleTrackerDllPTThresholdGate_MessageGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef B_ParticleTrackerDllPTThresholdGate_MessageGate_h
#define B_ParticleTrackerDllPTThresholdGate_MessageGate_h

#include "DSPEXTElements.h"
#include "MemoryGround.h"

#include "B_ParticleTrackerDllTracker_Requirement.h"


#define PARTICLETRACKERDLLPTTHRESHOLDGATE_MESSAGEGATE_TYPECATEGORY "Message"
#define PARTICLETRACKERDLLPTTHRESHOLDGATE_MESSAGEGATE_DEFAULTVALUE 0

typedef PTThreshold* ParticleTrackerDllPTThresholdGate_MessageGate;


/* EventGate state type definition */
typedef struct ParticleTrackerDllPTThresholdGate_MessageGate_event ParticleTrackerDllPTThresholdGate_MessageGate_event;

/* EventGate state definition */
struct ParticleTrackerDllPTThresholdGate_MessageGate_event {
	DSPEEvent event;

	ParticleTrackerDllPTThresholdGate_MessageGate *value;
	ParticleTrackerDllPTThresholdGate_MessageGate anchor;
};

/* Event clone state type definition */
typedef struct ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent;

/* Event clone state definition */
struct ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent {
	ParticleTrackerDllPTThresholdGate_MessageGate_event event;

	DSPEEvent *original;
};

/* EventGate pool type definition */
typedef struct ParticleTrackerDllPTThresholdGate_MessageGate_pool ParticleTrackerDllPTThresholdGate_MessageGate_pool;

/* EventGate pool definition */
struct ParticleTrackerDllPTThresholdGate_MessageGate_pool {
	DSPEBaseEventsPool pool;

	// Pool for events
	size_t eventNumElements;
	ParticleTrackerDllPTThresholdGate_MessageGate_event *headEvent;
	ParticleTrackerDllPTThresholdGate_MessageGate_event *tailEvent;

	// Pool for clones
	size_t cloneNumElements;
	ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent *headClone;
	ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent *tailClone;
};


/* GroupEventGate state type definition */
typedef struct ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent;

/* GroupEventGate state definition */
struct ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent {
	DSPEGroupEvent event;

	ParticleTrackerDllPTThresholdGate_MessageGate **value;
	ParticleTrackerDllPTThresholdGate_MessageGate *anchor;
};

/* GroupEvent clone state type definition */
typedef struct ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroupEvent ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroupEvent;

/* GroupEvent clone state definition */
struct ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroupEvent {
	ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent event;

	DSPEGroupEvent *original;
};

/* GroupEvent container state type definition */
typedef struct ParticleTrackerDllPTThresholdGate_MessageGate_eventContainer ParticleTrackerDllPTThresholdGate_MessageGate_eventContainer;

/* GroupEvent container state definition */
struct ParticleTrackerDllPTThresholdGate_MessageGate_eventContainer {
	ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent event;

	DSPEEvent **containedEvents;
};

/* GroupEventGate pool type definition */
typedef struct ParticleTrackerDllPTThresholdGate_MessageGate_groupPool ParticleTrackerDllPTThresholdGate_MessageGate_groupPool;

/* GroupEventGate pool definition */
struct ParticleTrackerDllPTThresholdGate_MessageGate_groupPool {
	DSPEGroupEventsPool pool;

	/* Pool for Events */
	size_t eventNumElements;
	ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *headEvent;
	ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *tailEvent;
	
	/* Pool for Clones */
	size_t cloneNumElements;
	ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroupEvent *headClone;
	ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroupEvent *tailClone;
	
	/* Pool for EventContainers */
	size_t containerNumElements;
	ParticleTrackerDllPTThresholdGate_MessageGate_eventContainer *headContainer;
	ParticleTrackerDllPTThresholdGate_MessageGate_eventContainer *tailContainer;
};

/* EventGate node type definition */
typedef struct ParticleTrackerDllPTThresholdGate_MessageGate_node ParticleTrackerDllPTThresholdGate_MessageGate_node; 

/* EventGate node definition */ 
struct ParticleTrackerDllPTThresholdGate_MessageGate_node {
	DSPEGateNode node;

	ParticleTrackerDllPTThresholdGate_MessageGate *localVar;
	ParticleTrackerDllPTThresholdGate_MessageGate value;
	int sendEvent;
	unsigned int eventID;
	DSPEApplication *application;
	DSPEEventsPool *pool;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Allocate function */
ParticleTrackerDllPTThresholdGate_MessageGate ParticleTrackerDllPTThresholdGate_MessageGate_allocateValue(DSPEElement *context);

/* Initialise function */
void ParticleTrackerDllPTThresholdGate_MessageGate_initValue(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate data);

/* Copy function */
void ParticleTrackerDllPTThresholdGate_MessageGate_copyValue(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate destination, ParticleTrackerDllPTThresholdGate_MessageGate source);

/* Dispose function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeValue(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate data);

/* AllocateManaged function */
void ParticleTrackerDllPTThresholdGate_MessageGate_allocateManaged(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate *anchor);
/* InitManaged function */
void ParticleTrackerDllPTThresholdGate_MessageGate_initManaged(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate anchor);

/* DisposeManaged function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeManaged(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate anchor);

/* AllocateGroupManaged function */
void ParticleTrackerDllPTThresholdGate_MessageGate_allocateGroupManaged(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate **anchor, size_t size);
/* InitGroupManaged function */
void ParticleTrackerDllPTThresholdGate_MessageGate_initGroupManaged(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate **anchor, size_t size);

/* DisposeGroupManaged function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeGroupManaged(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate **anchor, size_t size);

/* eventPool initialization function */
ParticleTrackerDllPTThresholdGate_MessageGate_pool* ParticleTrackerDllPTThresholdGate_MessageGate_initPool(const DSPEOwner *owner);

/* eventPool preAlloc function */
void ParticleTrackerDllPTThresholdGate_MessageGate_preAllocPool(DSPEEventsPool *pool, size_t size);

/* eventPool reset function */
void ParticleTrackerDllPTThresholdGate_MessageGate_resetPool(DSPEEventsPool *pool);

/* Allocate function */
ParticleTrackerDllPTThresholdGate_MessageGate_event* ParticleTrackerDllPTThresholdGate_MessageGate_allocate(ParticleTrackerDllPTThresholdGate_MessageGate_pool *pool);

/* Create function */
void ParticleTrackerDllPTThresholdGate_MessageGate_create(ParticleTrackerDllPTThresholdGate_MessageGate_event *event);

/* Initialise function */
void ParticleTrackerDllPTThresholdGate_MessageGate_initialize(ParticleTrackerDllPTThresholdGate_MessageGate_event *event);

/**
 * Copy function
 */
void ParticleTrackerDllPTThresholdGate_MessageGate_copy(ParticleTrackerDllPTThresholdGate_MessageGate_event *event, ParticleTrackerDllPTThresholdGate_MessageGate value);

/* Clone event function */
DSPEEvent* ParticleTrackerDllPTThresholdGate_MessageGate_clone(DSPEEvent *event);

/* Dispose function */
void ParticleTrackerDllPTThresholdGate_MessageGate_dispose(DSPEEvent *event);

/* Dispose clone function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeClone(DSPEEvent *event);

/* Destroy function */
void ParticleTrackerDllPTThresholdGate_MessageGate_destroy(ParticleTrackerDllPTThresholdGate_MessageGate_event *event);

/* eventPool dispose function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposePool(DSPEEventsPool *pool);

/* Allocate function */
ParticleTrackerDllPTThresholdGate_MessageGate* ParticleTrackerDllPTThresholdGate_MessageGate_allocateUnlinked(DSPEElement *context);

/* Initialise function */
void ParticleTrackerDllPTThresholdGate_MessageGate_initializeUnlinked(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate *place);

/* Set function */
void ParticleTrackerDllPTThresholdGate_MessageGate_set(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate *place, ParticleTrackerDllPTThresholdGate_MessageGate *value);

/* Dispose function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeUnlinked(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate *place);

/* groupEventPool initialization function */
ParticleTrackerDllPTThresholdGate_MessageGate_groupPool* ParticleTrackerDllPTThresholdGate_MessageGate_initGroupPool(const DSPEOwner *owner, size_t groupSize);

/* eventPool preAlloc function */
void ParticleTrackerDllPTThresholdGate_MessageGate_preAllocGroupPool(DSPEEventsPool *pool, size_t size);

/* eventPool reset function */
void ParticleTrackerDllPTThresholdGate_MessageGate_resetGroupPool(DSPEEventsPool *pool);

/* AllocateGroup function */
ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent* ParticleTrackerDllPTThresholdGate_MessageGate_allocateGroup(ParticleTrackerDllPTThresholdGate_MessageGate_groupPool *grpPool);

/* CreateGroup function */
void ParticleTrackerDllPTThresholdGate_MessageGate_createGroup(ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *event, size_t index);

/* InitialiseGroup function */
void ParticleTrackerDllPTThresholdGate_MessageGate_initializeGroup(ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *event, size_t index);

/**
 * Copy function
 */
void ParticleTrackerDllPTThresholdGate_MessageGate_copyGroup(ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *event, ParticleTrackerDllPTThresholdGate_MessageGate value, size_t index);

/* CloneGroup event function */
DSPEEvent* ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroup(DSPEEvent *event);

/* SubClone event function */
DSPEEvent* ParticleTrackerDllPTThresholdGate_MessageGate_subClone(DSPEGroupEvent *event, DSPEEventsPool *pool, size_t index);

/**
 * Allocate containerEvent function
 */
ParticleTrackerDllPTThresholdGate_MessageGate_eventContainer* ParticleTrackerDllPTThresholdGate_MessageGate_allocateContainer(ParticleTrackerDllPTThresholdGate_MessageGate_groupPool *grpPool);

/**
 * Dispose containerEvent function
 */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeContainer(DSPEEvent *event);

/* DisposeGroup function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeGroup(DSPEEvent *event);

/* Dispose GroupClone function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeGroupClone(DSPEEvent *event);

/* DestroyGroup function */
void ParticleTrackerDllPTThresholdGate_MessageGate_destroyGroup(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *event);

/* eventPool dispose function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeGroupPool(DSPEEventsPool *pool);

/* CreateNode function */
ParticleTrackerDllPTThresholdGate_MessageGate_node* ParticleTrackerDllPTThresholdGate_MessageGate_createNode(ParticleTrackerDllPTThresholdGate_MessageGate *localVar, DSPEApplication *application, DSPEEventsPool *pool, unsigned int eventID);

/* DisposeNode function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeNode(DSPEElement *context, DSPEGateNode *node);

/* SetValue function */
void ParticleTrackerDllPTThresholdGate_MessageGate_setValue(DSPEElement *context, DSPEGateNode *node);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
