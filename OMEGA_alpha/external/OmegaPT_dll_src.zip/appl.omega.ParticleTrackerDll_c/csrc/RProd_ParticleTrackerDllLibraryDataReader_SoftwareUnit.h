/**
 * File: RProd_ParticleTrackerDllLibraryDataReader_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef RProd_ParticleTrackerDllLibraryDataReader_SoftwareUnit_h
#define RProd_ParticleTrackerDllLibraryDataReader_SoftwareUnit_h

#include "B_ParticleTrackerDllLibraryDataReader_StateImplementation.h"
#include "B_ParticleTrackerDllLibraryDataReader_SoftwareUnit.h"
#include "B_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "B_ParticleTrackerDllPTFrameGate_MessageGate.h"

/* Real SoftwareUnit state type definition */
typedef struct ParticleTrackerDllLibraryDataReader_SoftwareUnit_realProd ParticleTrackerDllLibraryDataReader_SoftwareUnit_realProd;

/* Real SoftwareUnit state definition */
struct ParticleTrackerDllLibraryDataReader_SoftwareUnit_realProd {

	/* Base unit state */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllLibraryDataReader_StateImplementation implState;
	
	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;
	DSPEEvent *dataOut_PTFrame_place;
	DSPEEvent *dataOut_PTFrame_armMarker;

	/* Data pending events support */
	size_t dataOut_PTFrame_pendingEvents;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;

	/* EventPools */
	ParticleTrackerDllPTFrameGate_MessageGate_pool *dataOut_PTFrame_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame_unlinked;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataOut_SequenceValues;


	/* Output data places */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataOut_SequenceValues_place;

};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllLibraryDataReader_SoftwareUnit_armEventRealProd(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllLibraryDataReader_SoftwareUnit_postEventRealProd(DSPEEventsUnit *unit, unsigned int ID);

/* Earlyalloc function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_earlyAllocRealProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realProd *context);

/* Alloc function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_allocRealProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realProd *context);

/* Earlyconnect function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_earlyConnectRealProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realProd *context);

/* Connect function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_connectRealProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realProd *context);

/* Startup function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_startupRealProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realProd *context);

/* Preprocess function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_preProcessRealProd(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_processRealProd(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_postProcessRealProd(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_resetRealProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realProd *context);

/* Shutdown function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_shutdownRealProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realProd *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
