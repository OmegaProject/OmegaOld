/**
 * File: RSim_ParticleTrackerDllLibraryDataReader_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef RSim_ParticleTrackerDllLibraryDataReader_SoftwareUnit_h
#define RSim_ParticleTrackerDllLibraryDataReader_SoftwareUnit_h

#include "B_ParticleTrackerDllLibraryDataReader_StateImplementation.h"
#include "B_ParticleTrackerDllLibraryDataReader_SoftwareUnit.h"
#include "B_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "B_ParticleTrackerDllPTFrameGate_MessageGate.h"

/* Real SoftwareUnit state type definition */
typedef struct ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim;

/* Real SoftwareUnit state definition */
struct ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim {

	/* Base unit state */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllLibraryDataReader_StateImplementation implState;
	
	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;
	DSPEEvent *dataOut_PTFrame_place;
	DSPEEvent *dataOut_PTFrame_armMarker;

	/* Data pending events support */
	size_t dataOut_PTFrame_pendingEvents;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;

	/* EventPools */
	ParticleTrackerDllPTFrameGate_MessageGate_pool *dataOut_PTFrame_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame_unlinked;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataOut_SequenceValues;


	/* Output data places */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataOut_SequenceValues_place;

};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllLibraryDataReader_SoftwareUnit_armEventRealSim(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllLibraryDataReader_SoftwareUnit_postEventRealSim(DSPEEventsUnit *unit, unsigned int ID);

/* Earlyalloc function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_earlyAllocRealSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context);

/* Alloc function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_allocRealSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context);

/* Earlyconnect function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_earlyConnectRealSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context);

/* Connect function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_connectRealSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context);

/* Startup function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_startupRealSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context);

/* Preprocess function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_preProcessRealSim(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_processRealSim(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_postProcessRealSim(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_resetRealSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context);

/* Shutdown function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_shutdownRealSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
