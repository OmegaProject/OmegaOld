/**
 * File: RSim_ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "PlatformManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "EngineManager.h"
#include "ProfileManager.h"
#include "CoprocManager.h"
#include "ErrorManager.h"

#include "RSim_ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit.h"

#include "S_ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation.h"

#define PENDING_EVENTS_MAX 10

/* NoEvent ID */
#define NOEVENT 10

#define pIn_next_event 1000
#define dIn_PTFrame_event 1001

#define pOut_next_event 1000
#define dOut_PTFrame_event 1001

/* CoprocEvent ID */
#define pIn_Coproc_event 100

/******************************************************************************
 * PENDING EVENTS SUPPORT FUNCTIONS
 ******************************************************************************/

/* hasPendingEvents function */
static INLINE int hasPendingEvents(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context) {
	if (context->implState.dataOut_PTFrame_numLinks > 0 &&
		context->dataOut_PTFrame_pendingEvents == 0)
		return 0;
	return 1;
}

/* pendingEvents_aboveMaxThreshold function
 * Returns true if at least one pendingEvents counter is found that passes PENDING_EVENTS_MAX value
 */
static INLINE int pendingEvents_aboveMaxThreshold(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context) {
	return 	context->dataOut_PTFrame_pendingEvents > PENDING_EVENTS_MAX;
}

// TODO
// gate_sendEvent functions are generated only if pendingEvents support is needed.
// Consider refactoring postEvent and eventually armEvent functions so that the send functionality 
// is always available to the user enabling the soCalled 'immediate send' which may override the postEvent
// function call and send the event immediately through gate_sendEvent.
// This refactoring should also consider possible enhancements to gates like installing function pointers
// on gates to arm/post or sendImmediate events. ((DSPEEventGate*) gate)->armEvent((DSPEEventGate*) gate);

static INLINE void dataOut_PTFrame_sendEvent(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context) {
	unsigned int ID = 0;
	DSPEEventsUnit *unit = (DSPEEventsUnit*) context;
	DSPEEvent *event = NULL;

		/* Decrement pendingEvents counter for gate */
		if (context->dataOut_PTFrame_pendingEvents > 0)
			context->dataOut_PTFrame_pendingEvents--;
		/* Set ID for current gate */
		ID = dOut_PTFrame_event;
		event = context->dataOut_PTFrame_place;
		if (event == NULL)
			return;
		context->dataOut_PTFrame_place = event->next;
		if (context->dataOut_PTFrame_armMarker == event || context->dataOut_PTFrame_place == NULL)
			context->dataOut_PTFrame_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
}

/******************************************************************************
 * NEXT EVENT SUPPORT FUNCTIONS
 ******************************************************************************/

/* output next handler function */
static INLINE void handleOutgoingNextRequest(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context) {
	((DSPEEventsUnit*) context)->armEvent((DSPEEventsUnit*) context, pOut_next_event);
	((DSPEEventsUnit*) context)->postEvent((DSPEEventsUnit*) context, pOut_next_event);
}

/* input next handler function */
static INLINE void handleIncomingNextRequest(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context) {
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState = &context->implState;
	/* If not stop requested */
	if (*((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->paramIn_stop == 0) {
		/* Unlock stop and send next to notify */
		if (implState->stopOutNext &&
			!coprocManager_isAboveMaxThreshold(implState->opQueue)) {
			
			implState->stopOutNext = 0;
			
			/* Request data if pending requests */
			if (implState->waitingOutNext > 0) {
				implState->waitingOutNext--;
				handleOutgoingNextRequest(context);
			}
		} else if (!coprocManager_isAboveMaxThreshold(implState->opQueue) &&
			implState->waitingOutNext > 0) {
			/* Forward next */
			implState->waitingOutNext--;
			handleOutgoingNextRequest(context);
		}
		/* Send all available results */
		while (hasPendingEvents(context)) {
			dataOut_PTFrame_sendEvent(context);
		}
	}
	//REMARK:
	// else ignore next request. There will be sent at least one more next request
	// as soon as receiving unit unlocks the stop.
}

/******************************************************************************
 * GATE AUTOMATION SUPPORT FUNCTIONS
 ******************************************************************************/

/**
 * loadAllTransitEvents function
 */
static INLINE void loadAllTransitEvents(ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) implState)->container;

	unit->getCurrentTransitEvent(unit, dIn_PTFrame_event);
}

/**
 * armAllTransferEvents function
 */
static INLINE void armAllTransferEvents(ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState) {
	DSPEEventsUnit *unit = (DSPEEventsUnit*) ((DSPEElement*) implState)->container;

	unit->armEvent(unit, dOut_PTFrame_event);
}

/* Handle incoming event */
static INLINE void handleInputEvent(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context) {
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState = &context->implState;
	/* If coprocessor's inputQueue is full increment waiting requests for coproc */
	if (coprocManager_isAboveMaxThreshold(implState->opQueue) || 
		implState->stopOutNext) {
		implState->waitingOutNext++;
	} else {
		handleOutgoingNextRequest(context);
	}
	/* Set currentOp by getting op from pool */
	implState->curOp = getEmptyOp(implState);
	loadAllTransitEvents(implState);
	armAllTransferEvents(implState);
	transferAllGatesOnOp(implState);
}

/**
 * dismissOp function
 */
static INLINE void dismissOp(ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState) {
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context = (ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim*) ((DSPEElement*) implState)->container;
	/* Call dismissOp */
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_dismissOp(implState);

	/* Merge profile info */
	profileManager_mergeQueue((DSPEElement*) implState, ((DSPEProfileCoprocOp*) implState->curOp)->profileQueue);


	/* Dismiss input events */
	((DSPEQueueUnit*) context)->dismissEvent((DSPEQueueUnit*) context, dIn_PTFrame_event);

	/* AutomaticSend data events */
	((DSPEEventsUnit*) context)->postEvent((DSPEEventsUnit*) context, dOut_PTFrame_event);

	/* input next push support */
	if (*((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->paramIn_stop == 1) {
		if (pendingEvents_aboveMaxThreshold(context))
			implState->stopOutNext = 1;
	}
}

/******************************************************************************
 * OP BUFFER SUPPORT
 ******************************************************************************/

/**
 * Initialize opBuffer function
 */
static INLINE void initOpBuffer(ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState) {
	implState->opPoolHead = NULL;
	implState->opPoolTail = NULL;
	implState->opPoolNumElements = 0;
	implState->opBufferHead = NULL;
	implState->opBufferTail = NULL;
	implState->opBufferNumElements = 0;
}

/**
 * Dispose opBuffer function
 */
static INLINE void disposeOpBuffer(ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState) {
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_op *currentOp = NULL;
	while (implState->opPoolNumElements > 0) {
		currentOp = implState->opPoolHead;
		implState->opPoolHead = currentOp->next;
		implState->opPoolNumElements--;
		currentOp->next = NULL;
		destroyOp(currentOp);
	}
	implState->opPoolHead = NULL;
	implState->opPoolTail = NULL;
	implState->opPoolNumElements = 0;
}

/**
 * Handle coproc event function
 */
static INLINE void handleCoprocEvent(ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState) {
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_op *currentOp = (ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_op*) getProcessedOp(implState);
	currentOp->processed = 1;

	/* Remove processed coprocOp from buffer */
	currentOp = getBufferedOp(implState);
	while (currentOp != NULL) {
		/* Set current op */
		implState->curOp = currentOp;
		/* Call unit's dismissOp function */
		dismissOp(implState);
		releaseOp(implState, currentOp);
		currentOp = getBufferedOp(implState);
	}

	/* Restore unitBehaviour's currentOp to NULL */
	implState->curOp = NULL;
}

/**
 * Release opBuffer function
 */
static INLINE void releaseOpBuffer(ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState) {
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_op *currentOp = getNextOp(implState);
	while (currentOp != NULL) {
		implState->curOp = currentOp;
		ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_dismissOp(implState);
		releaseOp(implState, currentOp);
		currentOp = getNextOp(implState);
	}
}

/******************************************************************************
 * EVENT SUPPORT FUNCTIONS
 ******************************************************************************/

static INLINE void resetEventPlaces(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context) {
	DSPEEvent *event = NULL;
	context->paramOut_next_armMarker = NULL;
	
	while (context->paramOut_next_place != NULL) {
		event = (DSPEEvent*) context->paramOut_next_place;
		context->paramOut_next_place = event->next;
		/* force disposal */
		event->refCount = 1;
		event->dispose(event);
	}
	context->dataOut_PTFrame_armMarker = NULL;
	
	while (context->dataOut_PTFrame_place != NULL) {
		event = (DSPEEvent*) context->dataOut_PTFrame_place;
		context->dataOut_PTFrame_place = event->next;
		/* force disposal */
		event->refCount = 1;
		event->dispose(event);
	}
}

static INLINE void initQueue(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *unit) {
	/* Data transit queues */
	unit->dataIn_PTFrame_transitNumElements = 0;
	unit->dataIn_PTFrame_transitHead = NULL;
	unit->dataIn_PTFrame_transitTail = NULL;
	unit->dataIn_PTFrame_curTransit = NULL;
	unit->dataIn_PTFrame_curTransitIndex = 0;
	
}

static INLINE void resetQueue(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *unit) {
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_dismissAllEventsRealSim((DSPEQueueUnit*) unit, dIn_PTFrame_event);
}

/**
 * Transit input event function
 */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_transitEventRealSim(DSPEQueueUnit *unit) {
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context = (ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim*) unit;
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_queueNode *node = ((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->queueHead;
	
	/* Prevent multiple transits */
	if (node->inTransit == 1)
		return;

	switch (node->ID) {
	case dIn_PTFrame_event:
		if (context->dataIn_PTFrame_transitNumElements == 0) {
			context->dataIn_PTFrame_transitHead = node;
			context->dataIn_PTFrame_transitTail = node;
			context->dataIn_PTFrame_transitNumElements = 1;
		} else {
			context->dataIn_PTFrame_transitTail->nextInTransit = node;
			context->dataIn_PTFrame_transitTail = node;
			context->dataIn_PTFrame_transitNumElements++;
		}
		/* set curTransit if needed */
		if (context->dataIn_PTFrame_curTransit == NULL) {
			context->dataIn_PTFrame_curTransit = node;
			context->dataIn_PTFrame_curTransitIndex = 0;
		}
		context->dataIn_PTFrame_curTransitIndex++;
		node->inTransit = 1;
		break;
	}
}

size_t ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getTransitNumElementsRealSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context = (ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim*) unit;
	
	switch (ID) {
	case dIn_PTFrame_event:
		return context->dataIn_PTFrame_transitNumElements;
	}
	return 0;
}

size_t ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getCurrentNumElementsRealSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context = (ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim*) unit;
	
	switch (ID) {
	case dIn_PTFrame_event:
		return context->dataIn_PTFrame_curTransitIndex;
	}
	return 0;
}

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getFirstTransitRealSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context = (ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim*) unit;
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState = &context->implState;
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_queueNode *node = NULL;
	
	switch (ID) {
	case dIn_PTFrame_event:
		node = context->dataIn_PTFrame_transitHead;
		if (node == NULL)
			return;
		/* Set UnitBehaviour input gate pointer */
		implState->dataIn_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) node->event)->value;
		break;
	}
}

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getCurTransitRealSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context = (ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim*) unit;
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState = &context->implState;
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_queueNode *node = NULL;
	
	switch (ID) {
	case dIn_PTFrame_event:
		node = context->dataIn_PTFrame_curTransit;
		if (node == NULL)
			return;
		context->dataIn_PTFrame_curTransit = node->nextInTransit;
		if (node->nextInTransit == NULL)
			context->dataIn_PTFrame_curTransitIndex = 0;
		else
			context->dataIn_PTFrame_curTransitIndex--;
		/* set implementation's gate pointer */
		implState->dataIn_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) node->event)->value;
		break;
	}
}

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_dismissEventRealSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context = (ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim*) unit;
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState = (ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation*) &context->implState;
	DSPEEvent *event = NULL;
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_queueNode *node = NULL;

	switch (ID) {
	case dIn_PTFrame_event:
		node = context->dataIn_PTFrame_transitHead;
		if (context->dataIn_PTFrame_transitNumElements == 1) {
			context->dataIn_PTFrame_transitHead = NULL;
			context->dataIn_PTFrame_transitTail = NULL;
			context->dataIn_PTFrame_transitNumElements = 0;
		} else {
			context->dataIn_PTFrame_transitHead = node->nextInTransit;
			context->dataIn_PTFrame_transitNumElements--;
		}
		/* Set implementation pointer to secure unlinked place */
		implState->dataIn_PTFrame = context->dataIn_PTFrame_unlinked;
		break;

	}
	node->inTransit = 0;
	node->nextInTransit = NULL;
	
	// If node is the headNode within the queue let unitReleaseEvent do the disposal!
	if (node == ((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->queueHead)
		return;
	
	event = node->event;
	event->dispose(event);
	node->event = NULL;
	node->ID = 0;
	
	/* Move node to pool */
	if (((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->poolNumNodes == 0) {
		((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->poolHead = node;
		((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->poolTail = node;
		((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->poolNumNodes = 1;
	} else {
		((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->poolTail->next = node;
		((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->poolTail = node;
		((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->poolNumNodes++;
	}
}

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_dismissAllEventsRealSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context = (ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim*) unit;

	switch (ID) {
	case dIn_PTFrame_event:
		while (context->dataIn_PTFrame_transitNumElements != 0)
			ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_dismissEventRealSim(unit, ID);
		/* Reset curTransit */
		context->dataIn_PTFrame_curTransit = NULL;
		context->dataIn_PTFrame_curTransitIndex = 0;
		break;
	}
}

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_armEventRealSim(DSPEEventsUnit *unit, unsigned int ID) {
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context = (ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim*) unit;
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState = &context->implState;

	DSPEEvent *event = NULL;
	DSPEEvent *insert = NULL;

	switch (ID) {
	case pOut_next_event:
		insert = context->paramOut_next_armMarker;
		event = (DSPEEvent*) ParticleTrackerDllNextGate_SignalGate_allocate(context->paramOut_next_pool);
		event->refCount = 1;
		if (insert == NULL)
			context->paramOut_next_place = event;
		else
			insert->next = event;
		context->paramOut_next_armMarker = event;
		break;
	case dOut_PTFrame_event:
		insert = context->dataOut_PTFrame_armMarker;
		event = (DSPEEvent*) ParticleTrackerDllPTFrameGate_MessageGate_allocate(context->dataOut_PTFrame_pool);
		event->refCount = 1;
		if (insert == NULL)
			context->dataOut_PTFrame_place = event;
		else
			insert->next = event;
		context->dataOut_PTFrame_armMarker = event;
		/* Set implementation pointer */
		implState->dataOut_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value;
		break;
	}
}

/* RealUnit Post Function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_postEventRealSim(DSPEEventsUnit *unit, unsigned int ID) {
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context = (ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim*) unit;
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState = &context->implState;
	DSPEEvent *event = NULL;

	switch (ID) {
	case pOut_next_event:
		event = context->paramOut_next_place;
		if (event == NULL)
			return;
		context->paramOut_next_place = event->next;
		if (context->paramOut_next_place == NULL)
			context->paramOut_next_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
		break;
	case dOut_PTFrame_event:
		/* Restore save place to write */
		implState->dataOut_PTFrame = context->dataOut_PTFrame_unlinked;
		// Push pendingEvents support. If stop requested start collecting events instead of sending them
		// if pendingEvents available: we cannot send current data because there is other data to be sent before. Wait inputNext request to empty pending events
		// if stop requested: unit will send next to request all collected data!
		if (hasPendingEvents(context) ||
			*((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->paramIn_stop == 1) {
			// Start collecting events. Incrementing pendingEvents counter and returning.
			// Event will be sent when inputEvent arrives
			context->dataOut_PTFrame_pendingEvents++;
			return;
		}
		event = context->dataOut_PTFrame_place;
		if (event == NULL)
			return;
		context->dataOut_PTFrame_place = event->next;
		if (context->dataOut_PTFrame_armMarker == event || context->dataOut_PTFrame_place == NULL)
			context->dataOut_PTFrame_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
		break;
	}

}

/**
 * InitOp function
 */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_initOpRealSim(DSPECoprocUnit *unit, DSPEOp *op) {
	((ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_op*) op)->blockSize = 1;
}

/* Initialize gate values */
static INLINE void initValues(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState = &context->implState;
	ParticleTrackerDllPTFrameGate_MessageGate_initializeUnlinked((DSPEElement*) context, context->dataIn_PTFrame_unlinked);
	implState->dataIn_PTFrame = context->dataIn_PTFrame_unlinked;
	ParticleTrackerDllPTFrameGate_MessageGate_initializeUnlinked((DSPEElement*) context, context->dataOut_PTFrame_unlinked);
	implState->dataOut_PTFrame = context->dataOut_PTFrame_unlinked;

}

/******************************************************************************
 * COMMON UNIT FUNCTIONS
 ******************************************************************************/

/* Earlyalloc function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_earlyAllocRealSim(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context) {
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState = &context->implState;

	initDSPEElement((DSPEElement*) &context->implState, (DSPEElement*) context);
	initDSPECoprocUnit((DSPECoprocUnit*) context);
	((DSPEComponent*) context)->preprocess = ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_preProcessRealSim;
	((DSPEComponent*) context)->process = ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_processRealSim;
	((DSPEComponent*) context)->postprocess = ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_postProcessRealSim;
	implState->curOp = NULL;
	implState->waitingOutNext = 0;
	implState->stopOutNext = 0;
	implState->opsBusy = 0;
	/* Data pendingEvents initialization */
	context->dataOut_PTFrame_pendingEvents = 0;

	/* Implementation LocalStateVariables initialization */
	implState->functionalState.particleCounter = 0;
	/* Allocate permanent state */
	implState->persistent = (ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_persistent*) memoryManager_allocate((DSPEElement*) context, sizeof(ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_persistent));

	/* Op PermanentStateVariables initialization */
	(*implState->persistent).kernelWidth = 0;
	/* Unit profile ID initialization */
	context->unitProfileID = (int) profileSupport_getUnitProfileID(((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->ID);
}

/* Alloc function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_allocRealSim(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context) {
	const DSPEOwner *owner = ((DSPEElement*) context)->owner;

	/* Base alloc() function call */
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_alloc(&context->baseState);

	((DSPEEventsUnit*) context)->armEvent = ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_armEventRealSim;
	((DSPEEventsUnit*) context)->postEvent = ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_postEventRealSim;
	initQueue(context);
	((DSPEQueueUnit*) context)->transitEvent = ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_transitEventRealSim;
	((DSPEQueueUnit*) context)->getTransitNumElements = ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getTransitNumElementsRealSim;
	((DSPEQueueUnit*) context)->getCurrentNumElements = ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getCurrentNumElementsRealSim;
	((DSPEQueueUnit*) context)->dismissEvent = ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_dismissEventRealSim;
	((DSPEQueueUnit*) context)->getFirstTransitEvent = ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getFirstTransitRealSim;
	((DSPEQueueUnit*) context)->getCurrentTransitEvent = ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getCurTransitRealSim;
	((DSPECoprocUnit*) context)->initOp = ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_initOpRealSim;
	/* Initializing event Hooks and Inserts */
	context->paramOut_next_place = NULL;
	context->paramOut_next_armMarker = NULL;

	/* Initialize eventPools for parameter gates */
	context->paramOut_next_pool = ParticleTrackerDllNextGate_SignalGate_initPool(owner);

	/* Initializing event Hooks and Inserts */
	context->dataOut_PTFrame_place = NULL;
	context->dataOut_PTFrame_armMarker = NULL;

	/* Initialize eventPools for data gates */
	context->dataOut_PTFrame_pool = ParticleTrackerDllPTFrameGate_MessageGate_initPool(owner);

	/* Allocate unlinked places for input event gates */
	context->dataIn_PTFrame_unlinked = ParticleTrackerDllPTFrameGate_MessageGate_allocateUnlinked((DSPEElement*) context);
	context->dataOut_PTFrame_unlinked = ParticleTrackerDllPTFrameGate_MessageGate_allocateUnlinked((DSPEElement*) context);

}

/* Earlyconnect function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_earlyConnectRealSim(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState = &context->implState;

	/* Implementation output parameters gates initialization */
	implState->paramOut_stop = ((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->paramOut_stop_place;
	implState->paramOut_Status = ((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->paramOut_Status_place;


	/* Base earlyconnect() function call */
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_earlyConnect(&context->baseState);

}

/* Connect function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_connectRealSim(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState = &context->implState;

	/* Implementation input parameters gates initialization */
	implState->paramIn_stop = ((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->paramIn_stop;
	implState->paramIn_Radius = ((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->paramIn_Radius;

	/* Implementation data gates initialization */
	implState->dataIn_Mask = context->dataIn_Mask;
	implState->dataIn_SequenceValues = context->dataIn_SequenceValues;

	/* Implementation gates numLinks initialization */
	implState->dataIn_Mask_numLinks = ((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->dataIn_Mask_numLinks;
	implState->dataIn_SequenceValues_numLinks = ((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->dataIn_SequenceValues_numLinks;
	implState->dataIn_PTFrame_numLinks = ((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->dataIn_PTFrame_numLinks;
	implState->dataOut_PTFrame_numLinks = ((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->dataOut_PTFrame_numLinks;
	implState->paramIn_next_numLinks = ((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->paramIn_next_numLinks;
	implState->paramIn_stop_numLinks = ((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->paramIn_stop_numLinks;
	implState->paramIn_Radius_numLinks = ((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->paramIn_Radius_numLinks;
	implState->paramOut_next_numLinks = ((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->paramOut_next_numLinks;
	implState->paramOut_stop_numLinks = ((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->paramOut_stop_numLinks;
	implState->paramOut_Status_numLinks = ((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->paramOut_Status_numLinks;

}

/* Startup function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_startupRealSim(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context) {
	/* Initialize gate values */
	initValues(context);

	context->implState.opQueue = coprocManager_initCoprocInQueue((DSPEElement*) context, NULL);

	initOpBuffer(&context->implState);
}

/* Preprocess function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_preProcessRealSim(DSPEComponent *component) {
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context = (ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim*) component;

	/* Implementation preprocess() call */
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_preProcess(&context->implState);

}

/* Process function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_processRealSim(DSPEComponent *component) {
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context = (ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim*) component;
	/* Implementation state local variable initialization */
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState = &context->implState;
	const unsigned int ID = (((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->queueNumNodes == 0) ? NOEVENT : ((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->queueHead->ID;

	/* Push support: send all pending events if available */
	if (*((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context)->paramIn_stop == 0) {
		while (hasPendingEvents(context)) {		
			dataOut_PTFrame_sendEvent(context);
		}
	}
	/* Switch input event ID */
	switch (ID) {
	case dIn_PTFrame_event:
		/* AutoTransit inputEvents */
		((DSPEQueueUnit*) context)->transitEvent((DSPEQueueUnit*) context);
		/* Handle incoming event */
		handleInputEvent(context);
		break;
	case pIn_Coproc_event:
		//REMARK added after pendingEvents refactor because source (PUSH-autoPull) went idle
		/* Unlock stop */
		if (implState->stopOutNext &&
			!pendingEvents_aboveMaxThreshold(context) &&
			!coprocManager_isAboveMaxThreshold(implState->opQueue)) {
			implState->stopOutNext = 0;
		}
		handleCoprocEvent(&context->implState);
		/* Send waitingOut request if opInQueue has place for more events */
		if (implState->waitingOutNext > 0 &&
			!coprocManager_isAboveMaxThreshold(implState->opQueue) &&
			implState->stopOutNext == 0) {
			implState->waitingOutNext--;
			handleOutgoingNextRequest(context);
			/* Send one more if there are more waitingOut requests than opsBusy */
			if (implState->waitingOutNext > implState->opsBusy) {
				implState->waitingOutNext--;
				handleOutgoingNextRequest(context);
			}
		}

		break;
	case pIn_next_event:
		handleIncomingNextRequest(context);
		break;
	}
	// Automatic Execute support : curOp will be set only if there is at least
    // one event that has not been requested (by getCurTransit) in transit for each inputEventGate excluding omitted gates
	if (implState->curOp != NULL) {

	/* Implementation armOp() call */
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_armOp(implState);
	} /* End of automaticExecute support */

	/* AutoBuffer Support - if curOp has been set put curOp to coproc input queue */
	if (implState->curOp != NULL) {
		queueOp(implState, (DSPEOp*) implState->curOp);
	}
	implState->curOp = NULL;

	/* Restore unlinked pointers on unitBehaviour */
	if (implState->dataIn_PTFrame != context->dataIn_PTFrame_unlinked)
		implState->dataIn_PTFrame = context->dataIn_PTFrame_unlinked;

	/* send remaining waitingOut requests if no more output will be produced */
	if (implState->waitingOutNext > 0 &&
		implState->opsBusy == 0 &&
		!hasPendingEvents(context)) {
		while (implState->waitingOutNext > 0) {
			implState->waitingOutNext--;
			handleOutgoingNextRequest(context);
		}
	}
	/* Release event */
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_releaseEvent((ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit*) context);
}

/* Postprocess function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_postProcessRealSim(DSPEComponent *component) {
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context = (ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim*) component;

	/* Release opBuffer. Puts all ops that haven't been processed back to opPool */
	releaseOpBuffer(&context->implState);

	/* Move all output events that have been armed but not sent to their related pool */
	resetEventPlaces(context);

	/* Move all events from transitQueue back to their related pool */
	resetQueue(context);
	/* Reset unit's opInputQueue */
	context->implState.opQueue->reset(context->implState.opQueue);


	/* Base postprocess() function call */
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_postProcess(&context->baseState);
}

/* Reset function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_resetRealSim(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context) {
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *implState = &context->implState;

	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_op *currentOp = implState->opPoolHead;

	/* Base reset() function call */
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_reset(&context->baseState);

	/* Initialize gate values */
	initValues(context);
	implState->curOp = NULL;
	implState->waitingOutNext = 0;
	implState->stopOutNext = 0;
	implState->opsBusy = 0;
	/* Data pendingEvents initialization */
	context->dataOut_PTFrame_pendingEvents = 0;

	/* Implementation LocalStateVariables initialization */
	implState->functionalState.particleCounter = 0;

	/* Coproc PersistentStateVariables initialization */
	(*implState->persistent).kernelWidth = 0;

	/* Reset temporary states on ops in pool*/
	while (currentOp != NULL) {
		/* Merge profile info */
		profileManager_mergeQueue((DSPEElement*) implState, ((DSPEProfileCoprocOp*) currentOp)->profileQueue);
	
		currentOp = currentOp->next;
	}
}

/* Shutdown function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_shutdownRealSim(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_realSim *context) {
	disposeOpBuffer(&context->implState);

	context->implState.opQueue->dispose(context->implState.opQueue);

	/* Base shutdown() function call */
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_shutdown(&context->baseState);

	/* Dispose unlinked places for input event gates */
	ParticleTrackerDllPTFrameGate_MessageGate_disposeUnlinked((DSPEElement*) context, context->dataIn_PTFrame_unlinked);
	ParticleTrackerDllPTFrameGate_MessageGate_disposeUnlinked((DSPEElement*) context, context->dataOut_PTFrame_unlinked);

	/* Dispose permanent state */
	memorySupport_dispose(context->implState.persistent);
}

