/**
 * File: RBlock_ParticleTrackerDllPTFrameGate_MessageGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef RBlock_ParticleTrackerDllPTFrameGate_MessageGate_h
#define RBlock_ParticleTrackerDllPTFrameGate_MessageGate_h

#include "B_ParticleTrackerDllPTFrameGate_MessageGate.h"

/* EventGate pool type definition */
typedef struct ParticleTrackerDllPTFrameGate_MessageGate_poolBlock ParticleTrackerDllPTFrameGate_MessageGate_poolBlock;

/* EventGate pool definition */
struct ParticleTrackerDllPTFrameGate_MessageGate_poolBlock {
	DSPEBlockEventsPool pool;

	// Pool for Events
	size_t eventNumElements;
	ParticleTrackerDllPTFrameGate_MessageGate_event *headEvent;
	ParticleTrackerDllPTFrameGate_MessageGate_event *tailEvent;

	// Pool for Clones
	size_t cloneNumElements;
	ParticleTrackerDllPTFrameGate_MessageGate_cloneEvent *headClone;
	ParticleTrackerDllPTFrameGate_MessageGate_cloneEvent *tailClone;
};

/* BlockEventGroupGate pool type definition */
typedef struct ParticleTrackerDllPTFrameGate_MessageGate_poolGroupBlock ParticleTrackerDllPTFrameGate_MessageGate_poolGroupBlock;

/* BlockEventGroupGate pool definition */
struct ParticleTrackerDllPTFrameGate_MessageGate_poolGroupBlock {
	DSPEGroupBlockEventsPool pool;

	/* Pool for Events */
	size_t eventNumElements;
	ParticleTrackerDllPTFrameGate_MessageGate_groupEvent *headEvent;
	ParticleTrackerDllPTFrameGate_MessageGate_groupEvent *tailEvent;
	
	/* Pool for Clones */
	size_t cloneNumElements;
	ParticleTrackerDllPTFrameGate_MessageGate_cloneGroupEvent *headClone;
	ParticleTrackerDllPTFrameGate_MessageGate_cloneGroupEvent *tailClone;
	
	/* Pool for EventContainers */
	size_t containerNumElements;
	ParticleTrackerDllPTFrameGate_MessageGate_eventContainer *headContainer;
	ParticleTrackerDllPTFrameGate_MessageGate_eventContainer *tailContainer;
};

#ifdef __cplusplus
extern "C" {
#endif

/* eventPool initialization function */
ParticleTrackerDllPTFrameGate_MessageGate_poolBlock* ParticleTrackerDllPTFrameGate_MessageGate_initPoolBlock(const DSPEOwner *owner, size_t size);

/* eventPool preAlloc function */
void ParticleTrackerDllPTFrameGate_MessageGate_preAllocPoolBlock(DSPEEventsPool *pool, size_t size);

/* eventPool reset function */
void ParticleTrackerDllPTFrameGate_MessageGate_resetPoolBlock(DSPEEventsPool *pool);

/* Allocate function */
ParticleTrackerDllPTFrameGate_MessageGate_event* ParticleTrackerDllPTFrameGate_MessageGate_allocateBlock(ParticleTrackerDllPTFrameGate_MessageGate_poolBlock *pool);

/* Initialise function */
void ParticleTrackerDllPTFrameGate_MessageGate_initializeBlock(ParticleTrackerDllPTFrameGate_MessageGate_event *event);

/* Clone event function */
DSPEEvent* ParticleTrackerDllPTFrameGate_MessageGate_cloneBlock(DSPEEvent *event);

/* Dispose function */
void ParticleTrackerDllPTFrameGate_MessageGate_disposeBlock(DSPEEvent *event);

/* Dispose clone function */
void ParticleTrackerDllPTFrameGate_MessageGate_disposeCloneBlock(DSPEEvent *event);

/* eventPool dispose function */
void ParticleTrackerDllPTFrameGate_MessageGate_disposePoolBlock(DSPEEventsPool *pool);

/* Allocate function */
ParticleTrackerDllPTFrameGate_MessageGate* ParticleTrackerDllPTFrameGate_MessageGate_allocateUnlinkedBlock(DSPEElement *context, size_t size);

/* Initialise function */
void ParticleTrackerDllPTFrameGate_MessageGate_initializeUnlinkedBlock(DSPEElement *context, ParticleTrackerDllPTFrameGate_MessageGate *place, size_t size);

/* Dispose function */
void ParticleTrackerDllPTFrameGate_MessageGate_disposeUnlinkedBlock(DSPEElement *context, ParticleTrackerDllPTFrameGate_MessageGate *place);

/* groupEventPool initialization function */
ParticleTrackerDllPTFrameGate_MessageGate_poolGroupBlock* ParticleTrackerDllPTFrameGate_MessageGate_initGroupPoolBlock(const DSPEOwner *owner, size_t groupSize, size_t blockSize);

/* eventPool preAlloc function */
void ParticleTrackerDllPTFrameGate_MessageGate_preAllocGroupPoolBlock(DSPEEventsPool *pool, size_t size);

/* eventPool reset function */
void ParticleTrackerDllPTFrameGate_MessageGate_resetGroupPoolBlock(DSPEEventsPool *pool);

/* AllocateGroup function */
ParticleTrackerDllPTFrameGate_MessageGate_groupEvent* ParticleTrackerDllPTFrameGate_MessageGate_allocateGroupBlock(ParticleTrackerDllPTFrameGate_MessageGate_poolGroupBlock *pool);

/* CreateGroup function */
void ParticleTrackerDllPTFrameGate_MessageGate_createGroupBlock(ParticleTrackerDllPTFrameGate_MessageGate_groupEvent *event, size_t index);

/* InitialiseGroup function */
void ParticleTrackerDllPTFrameGate_MessageGate_initializeGroupBlock(ParticleTrackerDllPTFrameGate_MessageGate_groupEvent *event, size_t index);

/* CloneGroup event function */
DSPEEvent* ParticleTrackerDllPTFrameGate_MessageGate_cloneGroupBlock(DSPEEvent *event);

/* SubClone event function */
DSPEEvent* ParticleTrackerDllPTFrameGate_MessageGate_subCloneBlock(DSPEGroupEvent *event, DSPEEventsPool *pool, size_t index);

/**
 * Allocate containerEvent function
 */
ParticleTrackerDllPTFrameGate_MessageGate_eventContainer* ParticleTrackerDllPTFrameGate_MessageGate_allocateContainerBlock(ParticleTrackerDllPTFrameGate_MessageGate_poolGroupBlock *pool);

/**
 * Dispose containerEvent function
 */
void ParticleTrackerDllPTFrameGate_MessageGate_disposeContainerBlock(DSPEEvent *event);

/* DisposeGroup function */
void ParticleTrackerDllPTFrameGate_MessageGate_disposeGroupBlock(DSPEEvent *event);

/* Dispose GroupClone function */
void ParticleTrackerDllPTFrameGate_MessageGate_disposeGroupCloneBlock(DSPEEvent *event);

/* eventPool dispose function */
void ParticleTrackerDllPTFrameGate_MessageGate_disposeGroupPoolBlock(DSPEEventsPool *pool);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
