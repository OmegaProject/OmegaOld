/**
 * File: RBlock_ParticleTrackerDllRealGate_CustomGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#include "MemoryManager.h"

#include "RBlock_ParticleTrackerDllRealGate_CustomGate.h"

/* Allocate function */
ParticleTrackerDllRealGate_CustomGate* ParticleTrackerDllRealGate_CustomGate_allocateBlock(DSPEElement *context, size_t size) {
	return memoryManager_allocate(context, size * sizeof(ParticleTrackerDllRealGate_CustomGate));
}

/* Initialise function */
void ParticleTrackerDllRealGate_CustomGate_initializeBlock(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate *place, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllRealGate_CustomGate_initialize(context, &place[i]);
	}
}

/* SetOverrideBlock function */
void ParticleTrackerDllRealGate_CustomGate_setOverrideBlock(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate *place, size_t size, ParticleTrackerDllRealGate_CustomGate value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllRealGate_CustomGate_setOverride(context, &place[i], value);
	}
}

/* SetBlock function */
void ParticleTrackerDllRealGate_CustomGate_setBlock(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate *place, size_t size, ParticleTrackerDllRealGate_CustomGate *value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		place[i] = value[i]; 
	}
}

/* Dispose function */
void ParticleTrackerDllRealGate_CustomGate_disposeBlock(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate *place) {
	memorySupport_dispose(place);
}

/* AllocateGroup function */
void ParticleTrackerDllRealGate_CustomGate_allocateGroupBlock(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t groupSize, size_t *gateSize) {
	register size_t i;	
	for (i = 0; i < groupSize; i++) {
	 	place[i] = ParticleTrackerDllRealGate_CustomGate_allocateBlock(context, gateSize[i]);	
	}
}

/* InitialiseGroup function */
void ParticleTrackerDllRealGate_CustomGate_initializeGroupBlock(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t groupSize, size_t *gateSize) {
	register size_t i;
	for (i = 0; i < groupSize; i++) {
		ParticleTrackerDllRealGate_CustomGate_initializeBlock(context, place[i], gateSize[i]);
	}
}

/* SetOverrideGroupBlock function */
void ParticleTrackerDllRealGate_CustomGate_setOverrideGroupBlock(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllRealGate_CustomGate value) {
	register size_t i;
	for (i = 0; i < groupSize; i++) {
		ParticleTrackerDllRealGate_CustomGate_setOverrideBlock(context, place[i], gateSize[i], value);
	}
}

/* SetGroupBlock function */
void ParticleTrackerDllRealGate_CustomGate_setGroupBlock(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllRealGate_CustomGate **value) {
	register size_t i;
	for (i = 0; i < groupSize; i++) {
		ParticleTrackerDllRealGate_CustomGate_setBlock(context, place[i], gateSize[i], value[i]);
	}
}

/* DisposeGroup function */
void ParticleTrackerDllRealGate_CustomGate_disposeGroupBlock(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	memorySupport_dispose(place[i]);
	}
}

