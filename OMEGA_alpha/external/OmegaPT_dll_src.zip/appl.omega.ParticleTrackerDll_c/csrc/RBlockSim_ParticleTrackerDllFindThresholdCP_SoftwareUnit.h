/**
 * File: RBlockSim_ParticleTrackerDllFindThresholdCP_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef RBlockSim_ParticleTrackerDllFindThresholdCP_SoftwareUnit_h
#define RBlockSim_ParticleTrackerDllFindThresholdCP_SoftwareUnit_h

#include "B_ParticleTrackerDllFindThreshold_CoprocImplementation.h"
#include "B_ParticleTrackerDllFindThresholdCP_SoftwareUnit.h"
#include "RBlock_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "RBlock_ParticleTrackerDllPTFilteredGate_MessageGate.h"
#include "RBlock_ParticleTrackerDllPTThresholdGate_MessageGate.h"

/* Block SoftwareUnit state type definition */
typedef struct ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim;

/* Block SoftwareUnit state definition */
struct ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim {

	/* Base unit state */
	ParticleTrackerDllFindThresholdCP_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllFindThreshold_CoprocImplementation implState;
	
	/* Block size */
	size_t blockSize;

	/* Samples to process */
	size_t samplesToProcess;

	/* Data transit queues */
	size_t dataIn_PTFiltered_transitNumElements;
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode *dataIn_PTFiltered_transitHead;
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode *dataIn_PTFiltered_transitTail;
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode *dataIn_PTFiltered_curTransit;
	unsigned int dataIn_PTFiltered_curTransitIndex;

	DSPEEvent *dataOut_PTThreshold_place;
	DSPEEvent *dataOut_PTThreshold_armMarker;

	/* EventPools */
	ParticleTrackerDllPTThresholdGate_MessageGate_poolBlock *dataOut_PTThreshold_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFilteredGate_MessageGate *dataIn_PTFiltered_unlinked;
	ParticleTrackerDllPTFilteredGate_MessageGate *dataIn_PTFiltered_unlinkedAnchor;
	ParticleTrackerDllPTThresholdGate_MessageGate *dataOut_PTThreshold_unlinked;
	ParticleTrackerDllPTThresholdGate_MessageGate *dataOut_PTThreshold_unlinkedAnchor;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;


	/* Data gates sizes */
	size_t dataIn_SequenceValues_size;
	size_t dataOut_PTThreshold_size;


	/* Data gates factors */
	size_t dataIn_SequenceValues_factor;
	size_t dataOut_PTThreshold_factor;


	/* Data gates counters */
	size_t dataIn_SequenceValues_counter;
	size_t dataOut_PTThreshold_counter;


	/* Data gates counters */
	size_t dataOut_PTThreshold_samplesCounter;

	/* Unit profile ID */
	int unitProfileID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_transitEventBlockSim(DSPEQueueUnit *unit);

size_t ParticleTrackerDllFindThresholdCP_SoftwareUnit_getTransitNumElementsBlockSim(DSPEQueueUnit *unit, unsigned int ID);

size_t ParticleTrackerDllFindThresholdCP_SoftwareUnit_getTransitNumElementsBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_getFirstTransitBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_getCurTransitBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_dismissEventBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_dismissAllEventsBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_armEventBlockSim(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_postEventBlockSim(DSPEEventsUnit *unit, unsigned int ID);

/**
 * initOp function
 */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_initOpBlockSim(DSPECoprocUnit *unit, DSPEOp *op);

/* Earlyalloc function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_earlyAllocBlockSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context);

/* Alloc function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_allocBlockSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context);

/* Earlyconnect function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_earlyConnectBlockSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context);

/* Connect function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_connectBlockSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context);

/* Startup function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_startupBlockSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context);

/* Preprocess function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_preProcessBlockSim(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_processBlockSim(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_postProcessBlockSim(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_resetBlockSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context);

/* Shutdown function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_shutdownBlockSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockSim *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
