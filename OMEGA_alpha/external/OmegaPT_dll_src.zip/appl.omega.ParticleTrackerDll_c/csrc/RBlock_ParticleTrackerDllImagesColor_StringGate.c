/**
 * File: RBlock_ParticleTrackerDllImagesColor_StringGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "StringManager.h"
#include "MemoryManager.h"

#include "RBlock_ParticleTrackerDllImagesColor_StringGate.h"

/* AllocateBlockManaged function */
void ParticleTrackerDllImagesColor_StringGate_allocateBlockManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *anchor, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		anchor[i] = ParticleTrackerDllImagesColor_StringGate_allocateValue(context);
	}
}

/* InitBlockManaged function */
void ParticleTrackerDllImagesColor_StringGate_initBlockManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *anchor, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllImagesColor_StringGate_initManaged(context, anchor[i]);
	}
}

/* DisposeBlockManaged function */
void ParticleTrackerDllImagesColor_StringGate_disposeBlockManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *anchor, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllImagesColor_StringGate_disposeManaged(context, anchor[i]);
	}
}

/* AllocateGroupBlockManaged function */
void ParticleTrackerDllImagesColor_StringGate_allocateGroupBlockManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **anchor, size_t size, size_t *gateSize) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllImagesColor_StringGate_allocateBlockManaged(context, anchor[i], gateSize[i]);
	}
}

/* InitGroupBlockManaged function */
void ParticleTrackerDllImagesColor_StringGate_initGroupBlockManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **anchor, size_t size, size_t *gateSize) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllImagesColor_StringGate_initBlockManaged(context, anchor[i], gateSize[i]);
	}
}

/* DisposeGroupBlockManaged function */
void ParticleTrackerDllImagesColor_StringGate_disposeGroupBlockManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **anchor, size_t size, size_t *gateSize) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllImagesColor_StringGate_disposeBlockManaged(context, anchor[i], gateSize[i]);
	}
}

/* Allocate function */
ParticleTrackerDllImagesColor_StringGate* ParticleTrackerDllImagesColor_StringGate_allocateBlock(DSPEElement *context, size_t size) {
	return memoryManager_allocate(context, size * sizeof(ParticleTrackerDllImagesColor_StringGate));
}

/* Initialise function */
void ParticleTrackerDllImagesColor_StringGate_initializeBlock(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *place, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllImagesColor_StringGate_initialize(context, &place[i]);
	}
}

/* SetOverride function */
void ParticleTrackerDllImagesColor_StringGate_setOverrideBlock(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *place, size_t size, ParticleTrackerDllImagesColor_StringGate value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllImagesColor_StringGate_setOverride(context, &place[i], value);
	}
}

/* Set function */
void ParticleTrackerDllImagesColor_StringGate_setBlock(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *place, size_t size, ParticleTrackerDllImagesColor_StringGate *value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllImagesColor_StringGate_set(context, &place[i], &value[i]);
	}
}

/* Dispose function */
void ParticleTrackerDllImagesColor_StringGate_disposeBlock(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *place) {
	memorySupport_dispose(place);
}

/* AllocateGroup function */
void ParticleTrackerDllImagesColor_StringGate_allocateGroupBlock(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t groupSize, size_t *gateSize) {
	register size_t i;	
	for (i = 0; i < groupSize; i++) {
	 	place[i] = ParticleTrackerDllImagesColor_StringGate_allocateBlock(context, gateSize[i]);	
	}
}

/* InitialiseGroup function */
void ParticleTrackerDllImagesColor_StringGate_initializeGroupBlock(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t groupSize, size_t *gateSize) {
	register size_t i, j;
	for (i = 0; i < groupSize; i++) {
		for (j = 0; j <  gateSize[i]; j++) {
			ParticleTrackerDllImagesColor_StringGate_initialize(context, &place[i][j]);
		}
	}
}

/* SetOverrideGroupBlock function */
void ParticleTrackerDllImagesColor_StringGate_setOverrideGroupBlock(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllImagesColor_StringGate value) {
	register size_t i;
	for (i = 0; i < groupSize; i++) {
		ParticleTrackerDllImagesColor_StringGate_setOverrideBlock(context, place[i], gateSize[i], value);
	}
}

/* SetGroup function */
void ParticleTrackerDllImagesColor_StringGate_setGroupBlock(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllImagesColor_StringGate **value) {
	register size_t i, j;
	for (i = 0; i < groupSize; i++) {
		for (j = 0; j <  gateSize[i]; j++) {
			ParticleTrackerDllImagesColor_StringGate_set(context, &place[i][j], &value[i][j]);
		}
	}
}

/* DisposeGroup function */
void ParticleTrackerDllImagesColor_StringGate_disposeGroupBlock(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	memorySupport_dispose(place[i]);
	}
}

