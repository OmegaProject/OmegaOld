/**
 * File: B_ParticleTrackerDllFindThreshold_CoprocImplementation.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef B_ParticleTrackerDllFindThreshold_CoprocImplementation_h
#define B_ParticleTrackerDllFindThreshold_CoprocImplementation_h

#include "CoprocGround.h"
#include "DSPEXTElements.h"

#include "B_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "B_ParticleTrackerDllPTFilteredGate_MessageGate.h"
#include "B_ParticleTrackerDllPTThresholdGate_MessageGate.h"
#include "B_ParticleTrackerDllRealGate_CustomGate.h"
#include "B_ParticleTrackerDllStatusGate_StringGate.h"

/* Coproc persistent state type definition */
typedef struct ParticleTrackerDllFindThreshold_CoprocImplementation_persistent ParticleTrackerDllFindThreshold_CoprocImplementation_persistent;

/* This struct may contain user defined persistent state variables */
struct ParticleTrackerDllFindThreshold_CoprocImplementation_persistent {
	//Place persistent state variables after this line -- SYD-PERSISTENT-STATE-START
	real percentile;
	//SYD-PERSISTENT-STATE-END  -- Place persistent state variables before this line
};

/* Coproc Operation type definition */
typedef struct ParticleTrackerDllFindThreshold_CoprocImplementation_op ParticleTrackerDllFindThreshold_CoprocImplementation_op;

/* This struct may contain user defined additional state variables */
struct ParticleTrackerDllFindThreshold_CoprocImplementation_op {

	DSPEProfileCoprocOp coprocOp;

	/* BlockSize */
	size_t blockSize;

	/* CoprocOp Buffer support */
	ParticleTrackerDllFindThreshold_CoprocImplementation_op *next;
	unsigned int processed;

	/* Coproc persistent state */
	ParticleTrackerDllFindThreshold_CoprocImplementation_persistent *persistent;

	//Place additional state variables after this line -- SYD-ADDITIONAL-STATE-START
	//SYD-ADDITIONAL-STATE-END  -- Place additional state variables before this line


	/* Transfered Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;
	ParticleTrackerDllPTFilteredGate_MessageGate *dataIn_PTFiltered;
	ParticleTrackerDllPTThresholdGate_MessageGate *dataOut_PTThreshold;


	/* Transfered Parameter gates */
	ParticleTrackerDllRealGate_CustomGate *paramIn_Percentile;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status;

};



/* Functional implementation state type definition */
typedef struct ParticleTrackerDllFindThreshold_CoprocImplementation_func ParticleTrackerDllFindThreshold_CoprocImplementation_func;

/* This struct may contain user defined additional state variables for the unit */
struct ParticleTrackerDllFindThreshold_CoprocImplementation_func {

	DSPECoprocImplementation coprocImplementation;

	//Place local state variables after this line -- SYD-LOCAL-STATE-START
	//SYD-LOCAL-STATE-END  -- Place local state variables before this line
};

/******************************************************************************
 * FOLLOWING CODE IS NOT INTENDED TO BE MODIFIED BY USERS                     *
 ******************************************************************************/

/* State type definition */
typedef struct ParticleTrackerDllFindThreshold_CoprocImplementation ParticleTrackerDllFindThreshold_CoprocImplementation;

/* State definition */ 
struct ParticleTrackerDllFindThreshold_CoprocImplementation {

	/* Functional implementation state */
	ParticleTrackerDllFindThreshold_CoprocImplementation_func functionalState;

	/* Current working op state var */
	ParticleTrackerDllFindThreshold_CoprocImplementation_op *curOp;

	DSPEOpInQueue *opQueue;

	/* Coproc permanent state */
	ParticleTrackerDllFindThreshold_CoprocImplementation_persistent* persistent;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;
	ParticleTrackerDllPTFilteredGate_MessageGate *dataIn_PTFiltered;
	ParticleTrackerDllPTThresholdGate_MessageGate *dataOut_PTThreshold;

	/* Parameter gates */
	ParticleTrackerDllRealGate_CustomGate *paramIn_Percentile;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status;


	/* numLinks flags */
	unsigned int dataIn_SequenceValues_numLinks;
	unsigned int dataIn_PTFiltered_numLinks;
	unsigned int dataOut_PTThreshold_numLinks;
	unsigned int paramIn_Percentile_numLinks;
	unsigned int paramOut_Status_numLinks;

	/* State */
	unsigned int state;

	/* opBuffer support */
	ParticleTrackerDllFindThreshold_CoprocImplementation_op *opPoolHead;
	ParticleTrackerDllFindThreshold_CoprocImplementation_op *opPoolTail;
	size_t opPoolNumElements;
	ParticleTrackerDllFindThreshold_CoprocImplementation_op *opBufferHead;
	ParticleTrackerDllFindThreshold_CoprocImplementation_op *opBufferTail;
	size_t opBufferNumElements;

	unsigned int opsBusy;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

/* Preprocess function */
void ParticleTrackerDllFindThreshold_CoprocImplementation_preProcess(ParticleTrackerDllFindThreshold_CoprocImplementation *context);

/* Process function */
void ParticleTrackerDllFindThreshold_CoprocImplementation_process(ParticleTrackerDllFindThreshold_CoprocImplementation_op *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
