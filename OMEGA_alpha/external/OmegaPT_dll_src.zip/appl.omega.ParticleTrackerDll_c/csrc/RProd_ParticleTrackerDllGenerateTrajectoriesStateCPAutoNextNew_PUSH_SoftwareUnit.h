/**
 * File: RProd_ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef RProd_ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_h
#define RProd_ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_h

#include "B_ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation.h"
#include "B_ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit.h"
#include "B_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "B_ParticleTrackerDllPTFrameGate_MessageGate.h"
#include "B_ParticleTrackerDllTrajectory_MessageGate.h"

/* Real SoftwareUnit state type definition */
typedef struct ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_realProd ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_realProd;

/* Real SoftwareUnit state definition */
struct ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_realProd {

	/* Base unit state */
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation implState;
	
	/* Data transit queues */
	size_t dataIn_PTFrame_transitNumElements;
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_transitHead;
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_transitTail;
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_curTransit;
	unsigned int dataIn_PTFrame_curTransitIndex;

	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;
	DSPEEvent *paramOut_LastFrameProcessed_place;
	DSPEEvent *paramOut_LastFrameProcessed_armMarker;
	DSPEEvent *dataOut_Trajectory_place;
	DSPEEvent *dataOut_Trajectory_armMarker;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_LastFrameProcessed_pool;

	/* EventPools */
	ParticleTrackerDllTrajectory_MessageGate_pool *dataOut_Trajectory_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame_unlinked;
	ParticleTrackerDllTrajectory_MessageGate *dataOut_Trajectory_unlinked;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;

	/* Unit profile ID */
	int unitProfileID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_transitEventRealProd(DSPEQueueUnit *unit);

size_t ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_getTransitNumElementsRealProd(DSPEQueueUnit *unit, unsigned int ID);

size_t ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_getCurrentNumElementsRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_getFirstTransitRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_getCurTransitRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_dismissEventRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_dismissAllEventsRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_armEventRealProd(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_postEventRealProd(DSPEEventsUnit *unit, unsigned int ID);

/* Earlyalloc function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_earlyAllocRealProd(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_realProd *context);

/* Alloc function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_allocRealProd(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_realProd *context);

/* Earlyconnect function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_earlyConnectRealProd(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_realProd *context);

/* Connect function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_connectRealProd(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_realProd *context);

/* Startup function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_startupRealProd(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_realProd *context);

/* Preprocess function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_preProcessRealProd(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_processRealProd(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_postProcessRealProd(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_resetRealProd(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_realProd *context);

/* Shutdown function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_shutdownRealProd(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_realProd *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
