/**
 * File: RBlockSim_ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit.c
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#include "PlatformManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "EngineManager.h"
#include "ProfileManager.h"
#include "CoprocManager.h"
#include "ErrorManager.h"

#include "RBlockSim_ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit.h"

#include "S_ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation.h"

#define PENDING_EVENTS_MAX 10

/* NoEvent ID */
#define NOEVENT 10

#define pIn_next_event 1000
#define dIn_PTFrame_event 1001

#define pOut_next_event 1000
#define dOut_PTFrame_event 1001

/* CoprocEvent ID */
#define pIn_Coproc_event 100

/******************************************************************************
 * PENDING EVENTS SUPPORT FUNCTIONS
 ******************************************************************************/

/* hasPendingEvents function */
static INLINE int hasPendingEvents(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context) {
	if (context->implState.dataOut_PTFrame_numLinks > 0 &&
		context->dataOut_PTFrame_pendingEvents == 0)
		return 0;
	return 1;
}

/* pendingEvents_aboveMaxThreshold function
 * Returns true if at least one pendingEvents counter is found that passes PENDING_EVENTS_MAX value
 */
static INLINE int pendingEvents_aboveMaxThreshold(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context) {
	return 	context->dataOut_PTFrame_pendingEvents > PENDING_EVENTS_MAX;
}

// TODO
// gate_sendEvent functions are generated only if pendingEvents support is needed.
// Consider refactoring postEvent and eventually armEvent functions so that the send functionality 
// is always available to the user enabling the soCalled 'immediate send' which may override the postEvent
// function call and send the event immediately through gate_sendEvent.
// This refactoring should also consider possible enhancements to gates like installing function pointers
// on gates to arm/post or sendImmediate events. ((DSPEEventGate*) gate)->armEvent((DSPEEventGate*) gate);

static INLINE void dataOut_PTFrame_sendEvent(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context) {
	unsigned int ID = 0;
	DSPEEventsUnit *unit = (DSPEEventsUnit*) context;
	DSPEEvent *event = NULL;

		/* Decrement pendingEvents counter for gate */
		if (context->dataOut_PTFrame_pendingEvents > 0)
			context->dataOut_PTFrame_pendingEvents--;
		/* Set ID for current gate */
		ID = dOut_PTFrame_event;
		event = context->dataOut_PTFrame_place;
		if (event == NULL)
			return;
		context->dataOut_PTFrame_place = event->next;
		if (context->dataOut_PTFrame_armMarker == event || context->dataOut_PTFrame_place == NULL)
			context->dataOut_PTFrame_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
}

/******************************************************************************
 * NEXT EVENT SUPPORT FUNCTIONS
 ******************************************************************************/

/* output next handler function */
static INLINE void handleOutgoingNextRequest(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context) {
	((DSPEEventsUnit*) context)->armEvent((DSPEEventsUnit*) context, pOut_next_event);
	((DSPEEventsUnit*) context)->postEvent((DSPEEventsUnit*) context, pOut_next_event);
}

/* input next handler function */
static INLINE void handleIncomingNextRequest(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context) {
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState = &context->implState;
	/* If not stop requested */
	if (*((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramIn_stop == 0) {
		if (*((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramOut_stop &&
			!coprocManager_isAboveMaxThreshold(implState->opQueue)) {

			/* Unlock stop and send next to notify */
			*((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramOut_stop = 0;
			handleOutgoingNextRequest(context);
		} else if (!coprocManager_isAboveMaxThreshold(implState->opQueue)) {
			/* Forward next */
			handleOutgoingNextRequest(context);
		}
		/* Send all available results */
		while (hasPendingEvents(context)) {
			dataOut_PTFrame_sendEvent(context);
		}
	}
	//REMARK:
	// else ignore next request. There will be sent at least one more next request
	// as soon as receiving unit unlocks the stop.
}

/******************************************************************************
 * GATE AUTOMATION SUPPORT FUNCTIONS
 ******************************************************************************/

/**
 * loadAllTransitEvents function
 */
static INLINE void loadAllTransitEvents(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) implState)->container;

	unit->getCurrentTransitEvent(unit, dIn_PTFrame_event);
}

/**
 * armAllTransferEvents function
 */
static INLINE void armAllTransferEvents(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState) {
	DSPEEventsUnit *unit = (DSPEEventsUnit*) ((DSPEElement*) implState)->container;

	unit->armEvent(unit, dOut_PTFrame_event);
}

/* Handle incoming event */
static INLINE void handleInputEvent(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context) {
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState = &context->implState;
	if (*((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramOut_stop) {
		/* Unlock if possible */
		if (!pendingEvents_aboveMaxThreshold(context) && 
			!coprocManager_isAboveMaxThreshold(implState->opQueue)) {
			*((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramOut_stop = 0;
			handleOutgoingNextRequest(context);
		}
	} else {
		/* Lock if needed */
		if (coprocManager_isAboveMaxThreshold(implState->opQueue))
			*((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramOut_stop = 1;
	}
	/* Set currentOp by getting op from pool */
	implState->curOp = getEmptyOp(implState);
	loadAllTransitEvents(implState);
	armAllTransferEvents(implState);
	transferAllGatesOnOp(implState);
}

/**
 * dismissOp function
 */
static INLINE void dismissOp(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState) {
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim*) ((DSPEElement*) implState)->container;
	/* Copy returning ops parameter value to implementation pointer */
	memorySupport_copyBlock(implState->paramIn_Radius, implState->curOp->paramIn_Radius, sizeof(ParticleTrackerDllIntGate_StandardGate));
	memorySupport_copyBlock(implState->paramOut_Status, implState->curOp->paramOut_Status, sizeof(ParticleTrackerDllStatusGate_StringGate));
	/* Copy returning ops data block to implementation pointer */
	memorySupport_copyBlock(implState->dataIn_SequenceValues, implState->curOp->dataIn_SequenceValues, implState->curOp->blockSize * sizeof(ParticleTrackerDllSequenceValuesGate_PointerGate));
	memorySupport_copyBlock(implState->dataOut_Mask, implState->curOp->dataOut_Mask, implState->curOp->blockSize * sizeof(ParticleTrackerDllMaskGate_PointerGate));

	/* Merge profile info */
	profileManager_mergeQueue((DSPEElement*) implState, ((DSPEProfileCoprocOp*) implState->curOp)->profileQueue);


	/* Dismiss input events */
	((DSPEQueueUnit*) context)->dismissEvent((DSPEQueueUnit*) context, dIn_PTFrame_event);

	/* AutomaticSend data events */
	((DSPEEventsUnit*) context)->postEvent((DSPEEventsUnit*) context, dOut_PTFrame_event);

	/* input next push support */
	if (*((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramIn_stop == 1) {
		if (pendingEvents_aboveMaxThreshold(context))
			*((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramOut_stop = 1;
	}
}

/******************************************************************************
 * OP BUFFER SUPPORT
 ******************************************************************************/

/**
 * Initialize opBuffer function
 */
static INLINE void initOpBuffer(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState) {
	implState->opPoolHead = NULL;
	implState->opPoolTail = NULL;
	implState->opPoolNumElements = 0;
	implState->opBufferHead = NULL;
	implState->opBufferTail = NULL;
	implState->opBufferNumElements = 0;
}

/**
 * Dispose opBuffer function
 */
static INLINE void disposeOpBuffer(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState) {
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op *currentOp = NULL;
	while (implState->opPoolNumElements > 0) {
		currentOp = implState->opPoolHead;
		implState->opPoolHead = currentOp->next;
		implState->opPoolNumElements--;
		currentOp->next = NULL;
		destroyOp(currentOp);
	}
	implState->opPoolHead = NULL;
	implState->opPoolTail = NULL;
	implState->opPoolNumElements = 0;
}

/**
 * Handle coproc event function
 */
static INLINE void handleCoprocEvent(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState) {
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op *currentOp = (ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op*) getProcessedOp(implState);
	currentOp->processed = 1;

	/* Remove processed coprocOp from buffer */
	currentOp = getBufferedOp(implState);
	while (currentOp != NULL) {
		/* Set current op */
		implState->curOp = currentOp;
		/* Call unit's dismissOp function */
		dismissOp(implState);
		releaseOp(implState, currentOp);
		currentOp = getBufferedOp(implState);
	}

	/* Restore unitBehaviour's currentOp to NULL */
	implState->curOp = NULL;
}

/**
 * Release opBuffer function
 */
static INLINE void releaseOpBuffer(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState) {
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op *currentOp = getNextOp(implState);
	while (currentOp != NULL) {
		implState->curOp = currentOp;
		releaseOp(implState, currentOp);
		currentOp = getNextOp(implState);
	}
}

/******************************************************************************
 * EVENT SUPPORT FUNCTIONS
 ******************************************************************************/

static INLINE void resetEventPlaces(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context) {
	DSPEEvent *event = NULL;
	context->paramOut_next_armMarker = NULL;
	
	while (context->paramOut_next_place != NULL) {
		event = (DSPEEvent*) context->paramOut_next_place;
		context->paramOut_next_place = event->next;
		/* force disposal */
		event->refCount = 1;
		event->dispose(event);
	}
	context->dataOut_PTFrame_armMarker = NULL;
	
	while (context->dataOut_PTFrame_place != NULL) {
		event = (DSPEEvent*) context->dataOut_PTFrame_place;
		context->dataOut_PTFrame_place = event->next;
		/* force disposal */
		event->refCount = 1;
		event->dispose(event);
	}
}

static INLINE void initQueue(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *unit) {
	/* Data transit queues */
	unit->dataIn_PTFrame_transitNumElements = 0;
	unit->dataIn_PTFrame_transitHead = NULL;
	unit->dataIn_PTFrame_transitTail = NULL;
	unit->dataIn_PTFrame_curTransit = NULL;
	unit->dataIn_PTFrame_curTransitIndex = 0;
	
}

static INLINE void resetQueue(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *unit) {
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_dismissAllEventsBlockSim((DSPEQueueUnit*) unit, dIn_PTFrame_event);
}

/**
 * Transit input event function
 */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_transitEventBlockSim(DSPEQueueUnit *unit) {
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim*) unit;
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_queueNode *node = ((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->queueHead;
	
	/* Prevent multiple transits */
	if (node->inTransit == 1)
		return;

	switch (node->ID) {
	case dIn_PTFrame_event:
		if (context->dataIn_PTFrame_transitNumElements == 0) {
			context->dataIn_PTFrame_transitHead = node;
			context->dataIn_PTFrame_transitTail = node;
			context->dataIn_PTFrame_transitNumElements = 1;
		} else {
			context->dataIn_PTFrame_transitTail->nextInTransit = node;
			context->dataIn_PTFrame_transitTail = node;
			context->dataIn_PTFrame_transitNumElements++;
		}
		/* set curTransit if needed */
		if (context->dataIn_PTFrame_curTransit == NULL) {
			context->dataIn_PTFrame_curTransit = node;
			context->dataIn_PTFrame_curTransitIndex = 0;
		}
		context->dataIn_PTFrame_curTransitIndex++;
		node->inTransit = 1;
		break;
	}
}

size_t ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getTransitNumElementsBlockSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim*) unit;

	switch (ID) {
	case dIn_PTFrame_event:
		return context->dataIn_PTFrame_transitNumElements;
	}
	return 0;
}

size_t ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getCurrentNumElementsBlockSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim*) unit;

	switch (ID) {
	case dIn_PTFrame_event:
		return context->dataIn_PTFrame_curTransitIndex;
	}
	return 0;
}

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getFirstTransitBlockSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim*) unit;
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState = &context->implState;
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_queueNode *node = NULL;
	
	switch (ID) {
	case dIn_PTFrame_event:
		node = context->dataIn_PTFrame_transitHead;
		if (node == NULL)
			return;
		/* Set UnitBehaviour input gate pointer */
		implState->dataIn_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) node->event)->value;
		break;
	}
}

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getCurTransitBlockSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim*) unit;
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState = &context->implState;
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_queueNode *node = NULL;
	
	switch (ID) {
	case dIn_PTFrame_event:
		node = context->dataIn_PTFrame_curTransit;
		if (node == NULL)
			return;
		context->dataIn_PTFrame_curTransit = node->nextInTransit;
		if (node->nextInTransit == NULL)
			context->dataIn_PTFrame_curTransitIndex = 0;
		else
			context->dataIn_PTFrame_curTransitIndex--;
		/* set implementation's gate pointer */
		implState->dataIn_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) node->event)->value;
		break;
	}
}

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_dismissEventBlockSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim*) unit;
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState = (ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation*) &context->implState;
	DSPEEvent *event = NULL;
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_queueNode *node = NULL;

	switch (ID) {
	case dIn_PTFrame_event:
		node = context->dataIn_PTFrame_transitHead;
		if (context->dataIn_PTFrame_transitNumElements == 1) {
			context->dataIn_PTFrame_transitHead = NULL;
			context->dataIn_PTFrame_transitTail = NULL;
			context->dataIn_PTFrame_transitNumElements = 0;
		} else {
			context->dataIn_PTFrame_transitHead = node->nextInTransit;
			context->dataIn_PTFrame_transitNumElements--;
		}
		/* Set implementation pointer to secure unlinked place */
		implState->dataIn_PTFrame = context->dataIn_PTFrame_unlinked;
		break;
	}
	node->inTransit = 0;
	node->nextInTransit = NULL;
	
	// If node is the headNode within the queue let unitReleaseEvent do the disposal!
	if (node == ((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->queueHead)
		return;
	
	event = node->event;
	event->dispose(event);
	node->event = NULL;
	node->ID = 0;
	
	/* Move node to pool */
	if (((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->poolNumNodes == 0) {
		((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->poolHead = node;
		((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->poolTail = node;
		((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->poolNumNodes = 1;
	} else {
		((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->poolTail->next = node;
		((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->poolTail = node;
		((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->poolNumNodes++;
	}
}

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_dismissAllEventsBlockSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim*) unit;

	switch (ID) {
	case dIn_PTFrame_event:
		while (context->dataIn_PTFrame_transitNumElements != 0)
			ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_dismissEventBlockSim(unit, ID);
		/* Reset curTransit */
		context->dataIn_PTFrame_curTransit = NULL;
		context->dataIn_PTFrame_curTransitIndex = 0;
		break;
	}
}

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_armEventBlockSim(DSPEEventsUnit *unit, unsigned int ID) {
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim*) unit;
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState = &context->implState;

	register size_t i;
	DSPEEvent *event = NULL;
	DSPEEvent *insert = NULL;

	switch (ID) {
	case pOut_next_event:
		insert = context->paramOut_next_armMarker;
		event = (DSPEEvent*) ParticleTrackerDllNextGate_SignalGate_allocate(context->paramOut_next_pool);
		event->refCount = 1;
		if (insert == NULL)
			context->paramOut_next_place = event;
		else
			insert->next = event;
		context->paramOut_next_armMarker = event;
		break;
	case dOut_PTFrame_event:
		insert = context->dataOut_PTFrame_armMarker;
		if (insert == NULL) {
			if (context->dataOut_PTFrame_place == NULL) {
				event = (DSPEEvent*) ParticleTrackerDllPTFrameGate_MessageGate_allocateBlock(context->dataOut_PTFrame_pool);
				event->refCount = 1;
				context->dataOut_PTFrame_place = event;
				context->dataOut_PTFrame_armMarker = event;
				implState->dataOut_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value;
				/* create clones if needed */
				for (i = 0; i < context->dataOut_PTFrame_factor - 1; i++) {
					insert = event;
					event = insert->clone(insert);
					event->refCount = 1;
					((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value += context->blockSize;
					/* append clone */
					insert->next = event;
				}
			} else {
				event = context->dataOut_PTFrame_place;
				context->dataOut_PTFrame_armMarker = event;
				implState->dataOut_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value;
			}
		} else if (insert->next == NULL) {
			event = (DSPEEvent*) ParticleTrackerDllPTFrameGate_MessageGate_allocateBlock(context->dataOut_PTFrame_pool);
			event->refCount = 1;
			context->dataOut_PTFrame_armMarker->next = event;
			context->dataOut_PTFrame_armMarker = event;
			implState->dataOut_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value;
			/* create clones if needed */
			for (i = 0; i < context->dataOut_PTFrame_factor - 1; i++) {
				insert = event;
				event = insert->clone(insert);
				event->refCount = 1;
				((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value += context->blockSize;
				/* append clone */
				insert->next = event;
			}
		} else {
			/* use insert->next*/
			event = insert->next;
			context->dataOut_PTFrame_armMarker = event;
			implState->dataOut_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value;
		}
		break;
	}
}

/* BlockUnit Post Function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_postEventBlockSim(DSPEEventsUnit *unit, unsigned int ID) {
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim*) unit;
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState = &context->implState;
	DSPEEvent *event = NULL;
	switch (ID) {
	case pOut_next_event:
		event = context->paramOut_next_place;
		if (event == NULL)
			return;
		context->paramOut_next_place = event->next;
		if (context->paramOut_next_place == NULL)
			context->paramOut_next_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
		break;
	case dOut_PTFrame_event:
		/* Restore save place to write */
		implState->dataOut_PTFrame = context->dataOut_PTFrame_unlinked;
		// Push pendingEvents support. If stop requested start collecting events instead of sending them
		// if pendingEvents available: we cannot send current data because there is other data to be sent before. Wait inputNext request to empty pending events
		// if stop requested: unit will send next to request all collected data!
		if (hasPendingEvents(context) ||
			*((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramIn_stop == 1) {
			// Start collecting events. Incrementing pendingEvents counter and returning.
			// Event will be sent when inputEvent arrives
			context->dataOut_PTFrame_pendingEvents++;
			return;
		}
		event = context->dataOut_PTFrame_place;
		if (event == NULL)
			return;
		context->dataOut_PTFrame_place = event->next;
		if (context->dataOut_PTFrame_armMarker == event || context->dataOut_PTFrame_place == NULL)
			context->dataOut_PTFrame_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
		break;
	}

}

/**
 * InitOp function
 */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_initOpBlockSim(DSPECoprocUnit *unit, DSPEOp *op) {
	((ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op*) op)->blockSize = ((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim*) unit)->samplesToProcess;
}

/* Initialize gate values */
static INLINE void initValues(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState = &context->implState;
	/* Data output places initializazion */
	ParticleTrackerDllMaskGate_PointerGate_initializeBlock((DSPEElement*) context, context->dataOut_Mask_place, context->dataOut_Mask_size);

	ParticleTrackerDllPTFrameGate_MessageGate_initializeUnlinkedBlock((DSPEElement*) context, context->dataIn_PTFrame_unlinked, context->blockSize);
	implState->dataIn_PTFrame = context->dataIn_PTFrame_unlinked;
	ParticleTrackerDllPTFrameGate_MessageGate_initializeUnlinkedBlock((DSPEElement*) context, context->dataOut_PTFrame_unlinked, context->blockSize);
	implState->dataOut_PTFrame = context->dataOut_PTFrame_unlinked;

}

/******************************************************************************
 * COMMON UNIT FUNCTIONS
 ******************************************************************************/

/* Earlyalloc function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_earlyAllocBlockSim(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context) {
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState = &context->implState;

	initDSPEElement((DSPEElement*) &context->implState, (DSPEElement*) context);
	initDSPECoprocUnit((DSPECoprocUnit*) context);
	((DSPEComponent*) context)->preprocess = ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_preProcessBlockSim;
	((DSPEComponent*) context)->process = ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_processBlockSim;
	((DSPEComponent*) context)->postprocess = ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_postProcessBlockSim;
	/* Data gates size initialization */
	context->dataIn_SequenceValues_size = context->blockSize;
	context->dataOut_Mask_size = context->blockSize;
	context->dataOut_PTFrame_size = context->blockSize;

	implState->curOp = NULL;
	implState->opsBusy = 0;
	/* Data pendingEvents initialization */
	context->dataOut_PTFrame_pendingEvents = 0;
	/* Allocate permanent state */
	implState->persistent = (ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_persistent*) memoryManager_allocate((DSPEElement*) context, sizeof(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_persistent));

	/* Op PermanentStateVariables initialization */
	(*implState->persistent).kernelWidth = 0;
	(*implState->persistent).mask = 0;
	/* Unit profile ID initialization */
	context->unitProfileID = (int) profileSupport_getUnitProfileID(((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->ID);
}

/* Alloc function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_allocBlockSim(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context) {
	const DSPEOwner *owner = ((DSPEElement*) context)->owner;

	/* Base alloc() function call */
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_alloc(&context->baseState);

	initQueue(context);
	((DSPEQueueUnit*) context)->transitEvent = ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_transitEventBlockSim;
	((DSPEQueueUnit*) context)->getTransitNumElements = ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getTransitNumElementsBlockSim;
	((DSPEQueueUnit*) context)->getCurrentNumElements = ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getCurrentNumElementsBlockSim;
	((DSPEQueueUnit*) context)->dismissEvent = ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_dismissEventBlockSim;
	((DSPEQueueUnit*) context)->getFirstTransitEvent = ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getFirstTransitBlockSim;
	((DSPEQueueUnit*) context)->getCurrentTransitEvent = ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getCurTransitBlockSim;
	((DSPECoprocUnit*) context)->initOp = ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_initOpBlockSim;
	((DSPEEventsUnit*) context)->armEvent = ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_armEventBlockSim;
	((DSPEEventsUnit*) context)->postEvent = ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_postEventBlockSim;

	/* Initializing event Hooks and Inserts */
	context->paramOut_next_place = NULL;
	context->paramOut_next_armMarker = NULL;

	/* Allocate unlinked places for input event gates */
	context->dataIn_PTFrame_unlinked = ParticleTrackerDllPTFrameGate_MessageGate_allocateUnlinkedBlock((DSPEElement*) context, context->blockSize);
	context->dataOut_PTFrame_unlinked = ParticleTrackerDllPTFrameGate_MessageGate_allocateUnlinkedBlock((DSPEElement*) context, context->blockSize);


	/* Data output gates factor and counter initialization */
	context->dataOut_Mask_factor = context->dataOut_Mask_size / context->blockSize;
	context->dataOut_PTFrame_factor = context->dataOut_PTFrame_size / context->blockSize;

	/* Data output gates factor and counter initialization */
	context->dataOut_Mask_counter = context->dataOut_Mask_factor;


	/* Output data places memory allocation */
	context->dataOut_Mask_place = ParticleTrackerDllMaskGate_PointerGate_allocateBlock((DSPEElement*) context, context->dataOut_Mask_size);

	/* Initialize eventPools for parameter gates */
	context->paramOut_next_pool = ParticleTrackerDllNextGate_SignalGate_initPool(owner);

	context->dataOut_PTFrame_place = NULL;
	context->dataOut_PTFrame_armMarker = NULL;

	/* Initialize eventPools for data gates */
	context->dataOut_PTFrame_pool = ParticleTrackerDllPTFrameGate_MessageGate_initPoolBlock(owner, context->dataOut_PTFrame_size);

}

/* Earlyconnect function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_earlyConnectBlockSim(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState = &context->implState;

	/* Implementation output parameters gates initialization */
	implState->paramOut_stop = ((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramOut_stop_place;
	implState->paramOut_Status = ((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramOut_Status_place;


	/* Base earlyconnect() function call */
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_earlyConnect(&context->baseState);

	/* Input data gates factor and counter initialization */
	context->dataIn_SequenceValues_factor = context->dataIn_SequenceValues_size / context->blockSize;

	/* Input data gates factor and counter initialization */
	context->dataIn_SequenceValues_counter = context->dataIn_SequenceValues_factor;


	/* Output data gates initialization */
	context->dataOut_Mask = context->dataOut_Mask_place;

}

/* Connect function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_connectBlockSim(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState = &context->implState;

	/* Implementation input parameters gates initialization */
	implState->paramIn_stop = ((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramIn_stop;
	implState->paramIn_Radius = ((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramIn_Radius;

	/* Implementation data gates initialization */
	implState->dataIn_SequenceValues = context->dataIn_SequenceValues;
	implState->dataOut_Mask = context->dataOut_Mask;

	/* Implementation gates numLinks initialization */
	implState->dataIn_SequenceValues_numLinks = ((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->dataIn_SequenceValues_numLinks;
	implState->dataIn_PTFrame_numLinks = ((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->dataIn_PTFrame_numLinks;
	implState->dataOut_Mask_numLinks = ((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->dataOut_Mask_numLinks;
	implState->dataOut_PTFrame_numLinks = ((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->dataOut_PTFrame_numLinks;
	implState->paramIn_next_numLinks = ((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramIn_next_numLinks;
	implState->paramIn_stop_numLinks = ((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramIn_stop_numLinks;
	implState->paramIn_Radius_numLinks = ((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramIn_Radius_numLinks;
	implState->paramOut_next_numLinks = ((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramOut_next_numLinks;
	implState->paramOut_stop_numLinks = ((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramOut_stop_numLinks;
	implState->paramOut_Status_numLinks = ((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramOut_Status_numLinks;

}

/* Startup function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_startupBlockSim(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context) {
	/* Initialize gate values */
	initValues(context);

	context->implState.opQueue = coprocManager_initCoprocInQueue((DSPEElement*) context, NULL);

	initOpBuffer(&context->implState);
}

/* Preprocess function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_preProcessBlockSim(DSPEComponent *component) {
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim*) component;
	/* Implementation preprocess() call */
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_preProcess(&context->implState);
}

/* Process function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_processBlockSim(DSPEComponent *component) {
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim*) component;
	/* Implementation state local variable initialization */
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState = &context->implState;
	const unsigned int ID = (((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->queueNumNodes == 0) ? NOEVENT : ((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->queueHead->ID;

	/* Implementation data gates and counters update */
	if (context->dataIn_SequenceValues_counter == context->dataIn_SequenceValues_factor) {
		implState->dataIn_SequenceValues = context->dataIn_SequenceValues;
		context->dataIn_SequenceValues_counter = 0;
	} else {
		implState->dataIn_SequenceValues++;
	}
	if (context->dataOut_Mask_counter == context->dataOut_Mask_factor) {
		implState->dataOut_Mask = context->dataOut_Mask;
		context->dataOut_Mask_counter = 0;
	} else {
		implState->dataOut_Mask++;
	}

	/* Push support: send all pending events if available */
	if (*((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramIn_stop == 0) {
		while (hasPendingEvents(context)) {		
			dataOut_PTFrame_sendEvent(context);
		}
	}
	/* Switch input event ID */
	switch (ID) {
	case dIn_PTFrame_event:
		/* AutoTransit inputEvents */
		((DSPEQueueUnit*) context)->transitEvent((DSPEQueueUnit*) context);
		/* Unlock stop if possible and send next to notify */
		if (*((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramOut_stop &&
			!pendingEvents_aboveMaxThreshold(context) && 
			!coprocManager_isAboveMaxThreshold(implState->opQueue)) {
			*((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramOut_stop = 0;
			handleOutgoingNextRequest(context);
		}
		/* Handle incoming event */
		handleInputEvent(context);
		break;
	case pIn_Coproc_event:
		handleCoprocEvent(&context->implState);
		/* Unlock data stop */
		if (!coprocManager_isAboveMaxThreshold(implState->opQueue) &&
			!pendingEvents_aboveMaxThreshold(context) &&
			*((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramOut_stop == 1) {
			*((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramOut_stop = 0;
			handleOutgoingNextRequest(context);
		}

		break;
	case pIn_next_event:
		handleIncomingNextRequest(context);
		break;
	}


	/* AutoBuffer Support - if curOp has been set put curOp to coproc input queue */
	if (implState->curOp != NULL) {
		queueOp(implState, (DSPEOp*) implState->curOp);
		/* Lock if needed */
		if (*((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramOut_stop == 0 &&
			coprocManager_isAboveMaxThreshold(implState->opQueue)) {
			*((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context)->paramOut_stop = 1;
		}
	}
	implState->curOp = NULL;
	/* Block counters increment */
	context->dataIn_SequenceValues_counter++;
	context->dataOut_Mask_counter++;


	/* Restore unlinked pointers on unitBehaviour */
	if (implState->dataIn_PTFrame != context->dataIn_PTFrame_unlinked)
		implState->dataIn_PTFrame = context->dataIn_PTFrame_unlinked;
	/* Release event */
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_releaseEvent((ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit*) context);
}

/* Postprocess function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_postProcessBlockSim(DSPEComponent *component) {
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim*) component;

	/* Release opBuffer. Puts all ops that haven't been processed back to opPool */
	releaseOpBuffer(&context->implState);

	/* Implementation postprocess() call */
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_postProcess(&context->implState);

	/* Move all output events that have been armed but not sent to their related pool */
	resetEventPlaces(context);

	/* Move all events from transitQueue back to their related pool */
	resetQueue(context);
	/* Reset unit's opInputQueue */
	context->implState.opQueue->reset(context->implState.opQueue);


	/* Base postprocess() function call */
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_postProcess(&context->baseState);
}

/* Reset function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_resetBlockSim(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context) {
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *implState = &context->implState;

	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op *currentOp = implState->opPoolHead;

	/* Base reset() function call */
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_reset(&context->baseState);

	/* Initialize gate values */
	initValues(context);
	implState->curOp = NULL;
	implState->opsBusy = 0;
	/* Data pendingEvents initialization */
	context->dataOut_PTFrame_pendingEvents = 0;

	/* Coproc PersistentStateVariables initialization */
	(*implState->persistent).kernelWidth = 0;
	(*implState->persistent).mask = 0;

	/* Reset temporary states on ops in pool*/
	while (currentOp != NULL) {
		/* Merge profile info */
		profileManager_mergeQueue((DSPEElement*) implState, ((DSPEProfileCoprocOp*) currentOp)->profileQueue);
	
		currentOp = currentOp->next;
	}
}

/* Shutdown function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_shutdownBlockSim(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context) {

	disposeOpBuffer(&context->implState);
	context->implState.opQueue->dispose(context->implState.opQueue);

	/* Base shutdown() function call */
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_shutdown(&context->baseState);


	/* Output data places dispose */
	ParticleTrackerDllMaskGate_PointerGate_disposeBlock((DSPEElement*) context, context->dataOut_Mask_place);

	/* Dispose unlinked places for input event gates */
	ParticleTrackerDllPTFrameGate_MessageGate_disposeUnlinkedBlock((DSPEElement*) context, context->dataIn_PTFrame_unlinked);
	ParticleTrackerDllPTFrameGate_MessageGate_disposeUnlinkedBlock((DSPEElement*) context, context->dataOut_PTFrame_unlinked);

	/* Dispose permanent state */
	memorySupport_dispose(context->implState.persistent);
}

