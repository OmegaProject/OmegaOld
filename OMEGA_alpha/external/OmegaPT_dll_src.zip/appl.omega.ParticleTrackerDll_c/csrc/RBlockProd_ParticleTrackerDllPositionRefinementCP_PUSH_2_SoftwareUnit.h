/**
 * File: RBlockProd_ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef RBlockProd_ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_h
#define RBlockProd_ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_h

#include "B_ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation.h"
#include "B_ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit.h"
#include "RBlock_ParticleTrackerDllMaskGate_PointerGate.h"
#include "RBlock_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "RBlock_ParticleTrackerDllPTFrameGate_MessageGate.h"

/* Block SoftwareUnit state type definition */
typedef struct ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockProd ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockProd;

/* Block SoftwareUnit state definition */
struct ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockProd {

	/* Base unit state */
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation implState;
	
	/* Block size */
	size_t blockSize;

	/* Samples to process */
	size_t samplesToProcess;

	/* Data transit queues */
	size_t dataIn_PTFrame_transitNumElements;
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_queueNode *dataIn_PTFrame_transitHead;
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_queueNode *dataIn_PTFrame_transitTail;
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_queueNode *dataIn_PTFrame_curTransit;
	unsigned int dataIn_PTFrame_curTransitIndex;

	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;
	DSPEEvent *dataOut_PTFrame_place;
	DSPEEvent *dataOut_PTFrame_armMarker;

	/* Data pending events support */
	size_t dataOut_PTFrame_pendingEvents;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;

	/* EventPools */
	ParticleTrackerDllPTFrameGate_MessageGate_poolBlock *dataOut_PTFrame_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame_unlinked;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame_unlinked;


	/* Data gates */
	ParticleTrackerDllMaskGate_PointerGate *dataIn_Mask;
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;


	/* Data gates sizes */
	size_t dataIn_Mask_size;
	size_t dataIn_SequenceValues_size;
	size_t dataOut_PTFrame_size;


	/* Data gates factors */
	size_t dataIn_Mask_factor;
	size_t dataIn_SequenceValues_factor;
	size_t dataOut_PTFrame_factor;


	/* Data gates counters */
	size_t dataIn_Mask_counter;
	size_t dataIn_SequenceValues_counter;
	size_t dataOut_PTFrame_counter;


	/* Data gates counters */
	size_t dataOut_PTFrame_samplesCounter;

	/* Unit profile ID */
	int unitProfileID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_transitEventBlockProd(DSPEQueueUnit *unit);

size_t ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getTransitNumElementsBlockProd(DSPEQueueUnit *unit, unsigned int ID);

size_t ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getTransitNumElementsBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getFirstTransitBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_getCurTransitBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_dismissEventBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_dismissAllEventsBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_armEventBlockProd(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_postEventBlockProd(DSPEEventsUnit *unit, unsigned int ID);

/**
 * initOp function
 */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_initOpBlockProd(DSPECoprocUnit *unit, DSPEOp *op);

/* Earlyalloc function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_earlyAllocBlockProd(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockProd *context);

/* Alloc function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_allocBlockProd(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockProd *context);

/* Earlyconnect function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_earlyConnectBlockProd(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockProd *context);

/* Connect function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_connectBlockProd(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockProd *context);

/* Startup function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_startupBlockProd(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockProd *context);

/* Preprocess function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_preProcessBlockProd(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_processBlockProd(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_postProcessBlockProd(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_resetBlockProd(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockProd *context);

/* Shutdown function */
void ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_shutdownBlockProd(ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_blockProd *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
