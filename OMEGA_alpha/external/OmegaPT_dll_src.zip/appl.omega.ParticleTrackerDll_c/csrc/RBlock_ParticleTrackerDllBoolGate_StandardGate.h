/**
 * File: RBlock_ParticleTrackerDllBoolGate_StandardGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef RBlock_ParticleTrackerDllBoolGate_StandardGate_h
#define RBlock_ParticleTrackerDllBoolGate_StandardGate_h

#include "B_ParticleTrackerDllBoolGate_StandardGate.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Allocate function */
ParticleTrackerDllBoolGate_StandardGate* ParticleTrackerDllBoolGate_StandardGate_allocateBlock(DSPEElement *context, size_t size);

/* Initialise function */
void ParticleTrackerDllBoolGate_StandardGate_initializeBlock(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate *place, size_t size);

/* SetOverrideBlock function */
void ParticleTrackerDllBoolGate_StandardGate_setOverrideBlock(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate *place, size_t size, ParticleTrackerDllBoolGate_StandardGate value);

/* SetBlock function */
void ParticleTrackerDllBoolGate_StandardGate_setBlock(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate *place, size_t size, ParticleTrackerDllBoolGate_StandardGate *value);

/* Dispose function */
void ParticleTrackerDllBoolGate_StandardGate_disposeBlock(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate *place);

/* AllocateGroup function */
void ParticleTrackerDllBoolGate_StandardGate_allocateGroupBlock(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t groupSize, size_t *gateSize);

/* InitialiseGroup function */
void ParticleTrackerDllBoolGate_StandardGate_initializeGroupBlock(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t groupSize, size_t *gateSize);

/* SetOverrideGroupBlock function */
void ParticleTrackerDllBoolGate_StandardGate_setOverrideGroupBlock(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllBoolGate_StandardGate value);

/* SetGroupBlock function */
void ParticleTrackerDllBoolGate_StandardGate_setGroupBlock(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllBoolGate_StandardGate **value);

/* DisposeGroup function */
void ParticleTrackerDllBoolGate_StandardGate_disposeGroupBlock(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t size);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
