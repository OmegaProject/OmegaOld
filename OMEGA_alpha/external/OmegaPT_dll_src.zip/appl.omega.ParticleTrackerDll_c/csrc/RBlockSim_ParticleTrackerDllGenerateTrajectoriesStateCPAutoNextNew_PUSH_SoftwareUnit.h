/**
 * File: RBlockSim_ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef RBlockSim_ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_h
#define RBlockSim_ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_h

#include "B_ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation.h"
#include "B_ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit.h"
#include "RBlock_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "RBlock_ParticleTrackerDllPTFrameGate_MessageGate.h"
#include "RBlock_ParticleTrackerDllTrajectory_MessageGate.h"

/* Block SoftwareUnit state type definition */
typedef struct ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockSim ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockSim;

/* Block SoftwareUnit state definition */
struct ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockSim {

	/* Base unit state */
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllGenerateTrajectoriesCPAutoNextNew_PUSH_StateImplementation implState;
	
	/* Block size */
	size_t blockSize;

	/* Samples to process */
	size_t samplesToProcess;

	/* Data transit queues */
	size_t dataIn_PTFrame_transitNumElements;
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_transitHead;
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_transitTail;
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_curTransit;
	unsigned int dataIn_PTFrame_curTransitIndex;

	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;
	DSPEEvent *paramOut_LastFrameProcessed_place;
	DSPEEvent *paramOut_LastFrameProcessed_armMarker;
	DSPEEvent *dataOut_Trajectory_place;
	DSPEEvent *dataOut_Trajectory_armMarker;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_LastFrameProcessed_pool;

	/* EventPools */
	ParticleTrackerDllTrajectory_MessageGate_poolBlock *dataOut_Trajectory_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame_unlinked;
	ParticleTrackerDllTrajectory_MessageGate *dataOut_Trajectory_unlinked;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;


	/* Data gates sizes */
	size_t dataIn_SequenceValues_size;
	size_t dataOut_Trajectory_size;


	/* Data gates factors */
	size_t dataIn_SequenceValues_factor;
	size_t dataOut_Trajectory_factor;


	/* Data gates counters */
	size_t dataIn_SequenceValues_counter;
	size_t dataOut_Trajectory_counter;


	/* Data gates counters */
	size_t dataOut_Trajectory_samplesCounter;

	/* Unit profile ID */
	int unitProfileID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_transitEventBlockSim(DSPEQueueUnit *unit);

size_t ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_getTransitNumElementsBlockSim(DSPEQueueUnit *unit, unsigned int ID);

size_t ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_getTransitNumElementsBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_getFirstTransitBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_getCurTransitBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_dismissEventBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_dismissAllEventsBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_armEventBlockSim(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_postEventBlockSim(DSPEEventsUnit *unit, unsigned int ID);

/* Earlyalloc function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_earlyAllocBlockSim(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockSim *context);

/* Alloc function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_allocBlockSim(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockSim *context);

/* Earlyconnect function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_earlyConnectBlockSim(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockSim *context);

/* Connect function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_connectBlockSim(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockSim *context);

/* Startup function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_startupBlockSim(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockSim *context);

/* Preprocess function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_preProcessBlockSim(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_processBlockSim(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_postProcessBlockSim(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_resetBlockSim(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockSim *context);

/* Shutdown function */
void ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_shutdownBlockSim(ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_blockSim *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
