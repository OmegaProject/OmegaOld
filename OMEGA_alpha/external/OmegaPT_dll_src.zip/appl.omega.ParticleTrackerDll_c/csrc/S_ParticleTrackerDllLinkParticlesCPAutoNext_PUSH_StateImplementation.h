/**
 * File: S_ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation.h
 *
 * @author Loris
 * @created Thu May 26 10:23:50 CEST 2011
 */
#ifndef S_ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation_h
#define S_ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation_h

#include "PlatformManager.h"

#include "B_ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation.h"

/* Input EventGate IDs */
#define pIn_next_event 1000
#define dIn_PTFrame_event 1001

#define pOut_next_event 1000
#define dOut_PTFrame_event 1001

#ifdef __cplusplus
extern "C" {
#endif

static INLINE int isEventAvailable(ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *context) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	return unit->isEventAvailable(unit);
}

static INLINE unsigned int getEventID(ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *context) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	return unit->getEventID(unit);
}

/* Move inputEvent to specific transitQueue */
static INLINE void transitEvent(ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *context) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	unit->transitEvent(unit);
}

static INLINE void getDE_PTFrame(ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *context) {
	// TODO utilizzare l'ID della gate, rispettivamente l'index per le GroupGates per verificare che il valore rischiesto sia quello dell'evento in coda
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	DSPEEvent *event = unit->getEvent(unit);
	if (event == NULL)
		return; /* notify error here */
	context->dataIn_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value;
}

static INLINE size_t getTransitNumElementsDE_PTFrame(ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *context) {
	// TODO utilizzare l'ID della gate, rispettivamente l'index per le GroupGates per verificare che il valore richiesto sia quello dell'evento in coda
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	return unit->getTransitNumElements(unit, dIn_PTFrame_event);
}

static INLINE void getFirstTransitDE_PTFrame(ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *context) {
	// TODO utilizzare l'ID della gate, rispettivamente l'index per le GroupGates per verificare che il valore richiesto sia quello dell'evento in coda
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	unit->getFirstTransitEvent(unit, dIn_PTFrame_event );
}

static INLINE size_t getCurrentNumElementsDE_PTFrame(ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *context) {
	// TODO utilizzare l'ID della gate, rispettivamente l'index per le GroupGates per verificare che il valore richiesto sia quello dell'evento in coda
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	return unit->getCurrentNumElements(unit, dIn_PTFrame_event);
}

static INLINE void getCurTransitDE_PTFrame(ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *context) {
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	unit->getCurrentTransitEvent(unit, dIn_PTFrame_event);
}

static INLINE void dismissDE_PTFrame(ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *context) {
	//TODO valutare possibilita' di un unico dismiss
	DSPEQueueUnit *unit = (DSPEQueueUnit*) ((DSPEElement*) context)->container;
	unit->dismissEvent(unit, dIn_PTFrame_event);
}

/* SignalGate send advanced */
static INLINE void sendPE_next(ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *context) {
	DSPEEventsUnit *unit = (DSPEEventsUnit*) ((DSPEElement*) context)->container;
	if (unit->sendEvent == NULL)
		return;
	unit->armEvent(unit, pOut_next_event);
	unit->postEvent(unit, pOut_next_event);
}
static INLINE void armDE_PTFrame(ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *context) {
	DSPEEventsUnit *unit = (DSPEEventsUnit*) ((DSPEElement*) context)->container;
	if (unit->armEvent == 0)
		return;
	unit->armEvent(unit, dOut_PTFrame_event);
}

/* Forward send request to unit */
static INLINE void sendDE_PTFrame(ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *context) {
	DSPEEventsUnit *unit = (DSPEEventsUnit*) ((DSPEElement*) context)->container;
	if (unit->sendEvent == NULL)
		return;
	unit->postEvent(unit, dOut_PTFrame_event);
}

#ifdef __cplusplus
} /* extern "C" */
#endif

#undef pIn_next_event
#undef dIn_PTFrame_event
#undef pOut_next_event
#undef dOut_PTFrame_event

#endif
