/**
 * File: RBlock_ParticleTrackerDllRealGate_CustomGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef RBlock_ParticleTrackerDllRealGate_CustomGate_h
#define RBlock_ParticleTrackerDllRealGate_CustomGate_h

#include "B_ParticleTrackerDllRealGate_CustomGate.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Allocate function */
ParticleTrackerDllRealGate_CustomGate* ParticleTrackerDllRealGate_CustomGate_allocateBlock(DSPEElement *context, size_t size);

/* Initialise function */
void ParticleTrackerDllRealGate_CustomGate_initializeBlock(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate *place, size_t size);

/* SetOverrideBlock function */
void ParticleTrackerDllRealGate_CustomGate_setOverrideBlock(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate *place, size_t size, ParticleTrackerDllRealGate_CustomGate value);

/* SetBlock function */
void ParticleTrackerDllRealGate_CustomGate_setBlock(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate *place, size_t size, ParticleTrackerDllRealGate_CustomGate *value);

/* Dispose function */
void ParticleTrackerDllRealGate_CustomGate_disposeBlock(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate *place);

/* AllocateGroup function */
void ParticleTrackerDllRealGate_CustomGate_allocateGroupBlock(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t groupSize, size_t *gateSize);

/* InitialiseGroup function */
void ParticleTrackerDllRealGate_CustomGate_initializeGroupBlock(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t groupSize, size_t *gateSize);

/* SetOverrideGroupBlock function */
void ParticleTrackerDllRealGate_CustomGate_setOverrideGroupBlock(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllRealGate_CustomGate value);

/* SetGroupBlock function */
void ParticleTrackerDllRealGate_CustomGate_setGroupBlock(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllRealGate_CustomGate **value);

/* DisposeGroup function */
void ParticleTrackerDllRealGate_CustomGate_disposeGroupBlock(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t size);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
