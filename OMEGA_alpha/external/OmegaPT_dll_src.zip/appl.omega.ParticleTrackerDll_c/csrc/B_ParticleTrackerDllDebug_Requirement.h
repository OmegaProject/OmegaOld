/**
 * File: B_ParticleTrackerDllDebug_Requirement.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef B_ParticleTrackerDllDebug_Requirement_h
#define B_ParticleTrackerDllDebug_Requirement_h

//Place include directives after this line -- SYD-INCLUDES-START
#include "debug.h"
//SYD-INCLUDES-END -- Place include directives before this line

//Place define directives after this line -- SYD-DEFINES-START
#ifndef DEBUG_LINK
#define DEBUG_LINK "link21.txt"
#endif

#ifndef DEBUG_DISCRI
#define DEBUG_DISCRI "particles2.txt"
#endif

#ifndef DEBUG_FIND
#define DEBUG_FIND "particles2.txt"
#endif

#ifndef DEBUG_POSREF
#define DEBUG_POSREF "particles2.txt"
#endif

#ifndef DEBUG_TRAJ
#define DEBUG_TRAJ "traj2.txt"
#endif

//SYD-DEFINES-END -- Place define directives before this line
#endif
