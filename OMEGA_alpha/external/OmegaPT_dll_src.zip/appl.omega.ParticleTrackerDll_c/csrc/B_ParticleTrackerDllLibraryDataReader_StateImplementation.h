/**
 * File: B_ParticleTrackerDllLibraryDataReader_StateImplementation.h
 *
 * @author Loris
 * @created Thu May 26 10:23:50 CEST 2011
 */
#ifndef B_ParticleTrackerDllLibraryDataReader_StateImplementation_h
#define B_ParticleTrackerDllLibraryDataReader_StateImplementation_h

#include "DSPEXTElements.h"

#include "B_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "B_ParticleTrackerDllPTFrameGate_MessageGate.h"
#include "B_ParticleTrackerDllNextGate_SignalGate.h"
#include "B_ParticleTrackerDllIntGate_StandardGate.h"
#include "B_ParticleTrackerDllRealGate_CustomGate.h"
#include "B_ParticleTrackerDllStatusGate_StringGate.h"

#include "B_ParticleTrackerDllStructPTFrameQueue_Requirement.h"

/* Functional implementation state type definition */
typedef struct ParticleTrackerDllLibraryDataReader_StateImplementation_func ParticleTrackerDllLibraryDataReader_StateImplementation_func;

/* This struct may contain user defined additional state variables for the unit */
struct ParticleTrackerDllLibraryDataReader_StateImplementation_func {

	DSPEStateImplementation stateImplementation;

	//Place additional state variables after this line -- SYD-ADDITIONAL-STATE-START
	PTFrameQueue* queue;
	unsigned int remainingImgs;
	unsigned int id;
	//SYD-ADDITIONAL-STATE-END  -- Place additional state variables before this line

};

/******************************************************************************
 * FOLLOWING CODE IS NOT INTENDED TO BE MODIFIED BY USERS                     *
 ******************************************************************************/

/* State type definition */
typedef struct ParticleTrackerDllLibraryDataReader_StateImplementation ParticleTrackerDllLibraryDataReader_StateImplementation;

/* State definition */ 
struct ParticleTrackerDllLibraryDataReader_StateImplementation {

	/* Functional implementation state */
	ParticleTrackerDllLibraryDataReader_StateImplementation_func functionalState;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataOut_SequenceValues;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame;

	/* Parameter gates */
	ParticleTrackerDllIntGate_StandardGate *paramIn_stop;
	ParticleTrackerDllIntGate_StandardGate *paramIn_LinkRange;
	ParticleTrackerDllIntGate_StandardGate *paramIn_ImgsNum;
	ParticleTrackerDllIntGate_StandardGate *paramIn_ImgWidth;
	ParticleTrackerDllIntGate_StandardGate *paramIn_ImgHeight;
	ParticleTrackerDllRealGate_CustomGate *paramIn_ImgMin;
	ParticleTrackerDllRealGate_CustomGate *paramIn_ImgMax;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status;


	/* numLinks flags */
	unsigned int dataOut_SequenceValues_numLinks;
	unsigned int dataOut_PTFrame_numLinks;
	unsigned int paramIn_sourceNext_numLinks;
	unsigned int paramIn_next_numLinks;
	unsigned int paramIn_stop_numLinks;
	unsigned int paramIn_LinkRange_numLinks;
	unsigned int paramIn_ImgsNum_numLinks;
	unsigned int paramIn_ImgWidth_numLinks;
	unsigned int paramIn_ImgHeight_numLinks;
	unsigned int paramIn_ImgMin_numLinks;
	unsigned int paramIn_ImgMax_numLinks;
	unsigned int paramOut_next_numLinks;
	unsigned int paramOut_Status_numLinks;

	/* State */
	unsigned int state;

	unsigned int waitingInNext;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

/* Startup function */
void ParticleTrackerDllLibraryDataReader_StateImplementation_startup(ParticleTrackerDllLibraryDataReader_StateImplementation *context);

/* Preprocess function */
void ParticleTrackerDllLibraryDataReader_StateImplementation_preProcess(ParticleTrackerDllLibraryDataReader_StateImplementation *context);

/* Process function */
void ParticleTrackerDllLibraryDataReader_StateImplementation_process(ParticleTrackerDllLibraryDataReader_StateImplementation *context);

/* Postprocess function */
void ParticleTrackerDllLibraryDataReader_StateImplementation_postProcess(ParticleTrackerDllLibraryDataReader_StateImplementation *context);

/* Shutdown function */
void ParticleTrackerDllLibraryDataReader_StateImplementation_shutdown(ParticleTrackerDllLibraryDataReader_StateImplementation *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
