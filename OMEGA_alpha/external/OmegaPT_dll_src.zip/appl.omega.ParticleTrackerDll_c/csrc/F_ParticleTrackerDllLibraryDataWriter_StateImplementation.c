/**
 * File: F_ParticleTrackerDllLibraryDataWriter_StateImplementation.c
 *
 * @author Loris
 * @created Thu May 26 10:23:50 CEST 2011
 */
#include "EngineManager.h"
#include "B_ParticleTrackerDllLibraryDataWriter_StateImplementation.h"
#include "S_ParticleTrackerDllLibraryDataWriter_StateImplementation.h"

#include "B_ParticleTrackerDllLibraryDataWriter_Requirement.h"

/**
 * Convenience defines to access unit state variables.
 */
#define currState context->state
/* Input ParameterGates Shortcuts */
#define pIn_FoundTrajectories (*context->paramIn_FoundTrajectories)

/* Output ParameterGates Shortcuts */
#define pOut_stop (*context->paramOut_stop)

/* Input DataGates Shortcuts */
#define dIn_Trajectory (*context->dataIn_Trajectory)

/* numLinks shortcuts */
#define dIn_Trajectory_numLinks context->dataIn_Trajectory_numLinks
#define pIn_LastFrameProcessed_numLinks context->paramIn_LastFrameProcessed_numLinks
#define pIn_FoundTrajectories_numLinks context->paramIn_FoundTrajectories_numLinks
#define pOut_next_numLinks context->paramOut_next_numLinks
#define pOut_stop_numLinks context->paramOut_stop_numLinks

/* AdditionalStateVariables shortcuts */
#define addS_receivedTrajectories context->functionalState.receivedTrajectories
#define addS_lastFrameProcessed context->functionalState.lastFrameProcessed

/* AdditionalStateVariables default values */
#define ADDS_RECEIVEDTRAJECTORIES_DEFAULTVALUE 0
#define ADDS_LASTFRAMEPROCESSED_DEFAULTVALUE 0

/* Input EventGate IDs */
#define pIn_LastFrameProcessed_event 1000
#define dIn_Trajectory_event 1001

/* Common event shortcuts */
#define event_isAvailable() isEventAvailable(context)
#define event_transit() transitEvent(context)
#define event_getID() getEventID(context)

/* Parameter Output support function shortcuts */
#define pOut_next_sendEvent() sendPE_next(context)

/* Data Input getEvent function shortcuts */
#define dIn_Trajectory_getEvent() getDE_Trajectory(context)

/* Data Input transit support functions */
#define dIn_Trajectory_transitNumElements() getTransitNumElementsDE_Trajectory(context)
#define dIn_Trajectory_getFirstTransit() getFirstTransitDE_Trajectory(context)
#define dIn_Trajectory_currentNumElements() getCurrentNumElementsDE_Trajectory(context)
#define dIn_Trajectory_getCurTransit() getCurTransitDE_Trajectory(context)
#define dIn_Trajectory_dismissEvent() dismissDE_Trajectory(context)

/* EngineManager function shortcuts */
#define engine_run() engineManager_run((DSPEElement*) context)
#define engine_stop() engineManager_stop((DSPEElement*) context)
#define engine_pause() engineManager_pause((DSPEElement*) context)
#define engine_skip(cycles) engineManager_skip((DSPEElement*) context, cycles)
#define engine_quit() engineManager_quit((DSPEElement*) context)
#define engine_suspend() engineManager_suspend((DSPEElement*) context)
#define engine_freeze() engineManager_freeze((DSPEElement*) context)
#define engine_resume() engineManager_resume((DSPEElement*) context)

#define engine_isExecuting() engineManager_isExecuting((DSPEElement*) context)
#define engine_isStopping() engineManager_isStopping((DSPEElement*) context)
#define engine_isStopped() engineManager_isStopped((DSPEElement*) context)
#define engine_isPaused() engineManager_isPaused((DSPEElement*) context)
#define engine_isSkipping() engineManager_isSkipping((DSPEElement*) context)
#define engine_isExiting() engineManager_isExiting((DSPEElement*) context)
#define engine_isSuspended() engineManager_isSuspended((DSPEElement*) context)

/**
 * Startup algorithm. Unit initialization should take place here.
 * This function will be called ONCE at application startup.
 */
void ParticleTrackerDllLibraryDataWriter_StateImplementation_startup(ParticleTrackerDllLibraryDataWriter_StateImplementation *context) {
//Place implementation after this line -- SYD-STARTUP-START
	// REMARK: spostato qui per rendere disponibili i dati in uscita
	// anche quando l'applicazione � ferma!!

	// FIXME Rimpiazzare la dimensione massima del buffer con un parametro in entrata!!
	initOutputBuffers((void*) ((DSPEElement*) context)->application, 20);
//SYD-STARTUP-END -- Place implementation before this line
}

/**
 * PreProcess algorithm. Process phase initialization should take place here.
 * This function will be called ONCE before the process phase.
 */
void ParticleTrackerDllLibraryDataWriter_StateImplementation_preProcess(ParticleTrackerDllLibraryDataWriter_StateImplementation *context) {
//Place implementation after this line -- SYD-PREPROCESS-START
	resetOutputBuffers((void*) ((DSPEElement*) context)->application);
//SYD-PREPROCESS-END -- Place implementation before this line
}

/**
 * Process algorithm. What the unit really does should take place here.
 * This function will be called at each process cycle.
 */
void ParticleTrackerDllLibraryDataWriter_StateImplementation_process(ParticleTrackerDllLibraryDataWriter_StateImplementation *context) {
//Place implementation after this line -- SYD-PROCESS-START
	int i = 0;
	track* trk;
	ParticleNode* node;

	if (event_getID() == pIn_LastFrameProcessed_event) {
		addS_lastFrameProcessed = 1;
		if (addS_receivedTrajectories == pIn_FoundTrajectories)
			// All trajectories have been processed - stop the application
			engine_stop();
		return;
	}

	addS_receivedTrajectories++;

	dIn_Trajectory_getEvent();
	trk = getOutputDataPtr((void*) ((DSPEElement*) context)->application, dIn_Trajectory->numberOfParticle);
	node = dIn_Trajectory->head;

	while (node != NULL) {
		trk->frameNo[i] = node->p->frameId;
		trk->x[i] = node->p->x;
		trk->y[i] = node->p->y;

		node = node->next;
		i++;
	}

	// Add processed data to output buffer
	if (setOutputData((void*) ((DSPEElement*) context)->application, trk) && pOut_stop == 0)
		// Output buffer is full, stop receiving input events
		pOut_stop = 1;

	if (addS_lastFrameProcessed == 1 && pIn_FoundTrajectories == addS_receivedTrajectories)
		// All trajectories have been processed - stop the application
		engine_stop();
//SYD-PROCESS-END -- Place implementation before this line 
}

/**
 * Shutdown algorithm. Unit cleanup should take place here.
 * This function will be called ONCE at application shutdown.
 */
void ParticleTrackerDllLibraryDataWriter_StateImplementation_shutdown(ParticleTrackerDllLibraryDataWriter_StateImplementation *context) {
//Place implementation after this line -- SYD-SHUTDOWN-START
	// REMARK: spostato qui per rendere disponibili i dati in uscita
	// anche quando l'applicazione � ferma!!
	disposeOutputBuffers((void*) ((DSPEElement*) context)->application);
//SYD-SHUTDOWN-END -- Place implementation before this line
}

#undef currState
/* Input ParameterGates Shortcuts */
#undef pIn_FoundTrajectories

/* Output ParameterGates Shortcuts */
#undef pOut_stop

/* Input DataGates Shortcuts */
#undef dIn_Trajectory

/* numLinks shortcuts */
#undef dIn_Trajectory_numLinks
#undef pIn_LastFrameProcessed_numLinks
#undef pIn_FoundTrajectories_numLinks
#undef pOut_next_numLinks
#undef pOut_stop_numLinks

/* AdditionalStateVariables shortcuts */
#undef addS_receivedTrajectories
#undef addS_lastFrameProcessed

#undef ADDS_RECEIVEDTRAJECTORIES_DEFAULTVALUE
#undef ADDS_LASTFRAMEPROCESSED_DEFAULTVALUE

#undef pIn_LastFrameProcessed_event
#undef dIn_Trajectory_event
#undef event_isAvailable
#undef event_getID

#undef event_transit

#undef pOut_next_sendEvent

#undef dIn_Trajectory_getEvent

#undef dIn_Trajectory_transitNumElements
#undef dIn_Trajectory_getFirstTransit
#undef dIn_Trajectory_currentNumElements
#undef dIn_Trajectory_getCurTransit
#undef dIn_Trajectory_dismissEvent

/* EngineManager function shortcuts */
#undef engine_run
#undef engine_stop
#undef engine_pause
#undef engine_skip
#undef engine_quit
#undef engine_suspend
#undef engine_freeze
#undef engine_resume

#undef engine_isExecuting
#undef engine_isStopping
#undef engine_isStopped
#undef engine_isPaused
#undef engine_isSkipping
#undef engine_isExiting
#undef engine_isSuspended

