/**
 * File: RSim_ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef RSim_ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_h
#define RSim_ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_h

#include "B_ParticleTrackerDllConvolveAllCase_PUSH_CoprocImplementation.h"
#include "B_ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit.h"
#include "B_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "B_ParticleTrackerDllPTFrameGate_MessageGate.h"
#include "B_ParticleTrackerDllPTFilteredGate_MessageGate.h"

/* Real SoftwareUnit state type definition */
typedef struct ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_realSim ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_realSim;

/* Real SoftwareUnit state definition */
struct ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_realSim {

	/* Base unit state */
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllConvolveAllCase_PUSH_CoprocImplementation implState;
	
	/* Data transit queues */
	size_t dataIn_PTFrame_transitNumElements;
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_transitHead;
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_transitTail;
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_curTransit;
	unsigned int dataIn_PTFrame_curTransitIndex;

	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;
	DSPEEvent *dataOut_PTFrame_place;
	DSPEEvent *dataOut_PTFrame_armMarker;
	DSPEEvent *dataOut_PTFiltered_place;
	DSPEEvent *dataOut_PTFiltered_armMarker;

	/* Data pending events support */
	size_t dataOut_PTFrame_pendingEvents;
	size_t dataOut_PTFiltered_pendingEvents;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;

	/* EventPools */
	ParticleTrackerDllPTFrameGate_MessageGate_pool *dataOut_PTFrame_pool;
	ParticleTrackerDllPTFilteredGate_MessageGate_pool *dataOut_PTFiltered_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame_unlinked;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame_unlinked;
	ParticleTrackerDllPTFilteredGate_MessageGate *dataOut_PTFiltered_unlinked;
	ParticleTrackerDllPTFilteredGate_MessageGate *dataOut_PTFiltered_unlinkedAnchor;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;

	/* Unit profile ID */
	int unitProfileID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_transitEventRealSim(DSPEQueueUnit *unit);

size_t ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_getTransitNumElementsRealSim(DSPEQueueUnit *unit, unsigned int ID);

size_t ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_getCurrentNumElementsRealSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_getFirstTransitRealSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_getCurTransitRealSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_dismissEventRealSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_dismissAllEventsRealSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_armEventRealSim(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_postEventRealSim(DSPEEventsUnit *unit, unsigned int ID);

/**
 * initOp function
 */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_initOpRealSim(DSPECoprocUnit *unit, DSPEOp *op);

/* Earlyalloc function */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_earlyAllocRealSim(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_realSim *context);

/* Alloc function */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_allocRealSim(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_realSim *context);

/* Earlyconnect function */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_earlyConnectRealSim(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_realSim *context);

/* Connect function */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_connectRealSim(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_realSim *context);

/* Startup function */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_startupRealSim(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_realSim *context);

/* Preprocess function */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_preProcessRealSim(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_processRealSim(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_postProcessRealSim(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_resetRealSim(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_realSim *context);

/* Shutdown function */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_shutdownRealSim(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_realSim *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
