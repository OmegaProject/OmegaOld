/**
 * File: RBlockSim_ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "PlatformManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "EngineManager.h"
#include "ProfileManager.h"
#include "ErrorManager.h"

#include "RBlockSim_ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit.h"

#define PENDING_EVENTS_MAX 10

/* NoEvent ID */
#define NOEVENT 10

#define pIn_next_event 1000
#define dIn_PTFrame_event 1001

#define pOut_next_event 1000
#define dOut_PTFrame_event 1001

/******************************************************************************
 * PENDING EVENTS SUPPORT FUNCTIONS
 ******************************************************************************/

/* hasPendingEvents function */
static INLINE int hasPendingEvents(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context) {
	if (context->implState.dataOut_PTFrame_numLinks > 0 &&
		context->dataOut_PTFrame_pendingEvents == 0)
		return 0;
	return 1;
}

/* pendingEvents_aboveMaxThreshold function
 * Returns true if at least one pendingEvents counter is found that passes PENDING_EVENTS_MAX value
 */
static INLINE int pendingEvents_aboveMaxThreshold(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context) {
	return 	context->dataOut_PTFrame_pendingEvents > PENDING_EVENTS_MAX;
}

// TODO
// gate_sendEvent functions are generated only if pendingEvents support is needed.
// Consider refactoring postEvent and eventually armEvent functions so that the send functionality 
// is always available to the user enabling the soCalled 'immediate send' which may override the postEvent
// function call and send the event immediately through gate_sendEvent.
// This refactoring should also consider possible enhancements to gates like installing function pointers
// on gates to arm/post or sendImmediate events. ((DSPEEventGate*) gate)->armEvent((DSPEEventGate*) gate);

static INLINE void dataOut_PTFrame_sendEvent(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context) {
	unsigned int ID = 0;
	DSPEEventsUnit *unit = (DSPEEventsUnit*) context;
	DSPEEvent *event = NULL;

		/* Decrement pendingEvents counter for gate */
		if (context->dataOut_PTFrame_pendingEvents > 0)
			context->dataOut_PTFrame_pendingEvents--;
		/* Set ID for current gate */
		ID = dOut_PTFrame_event;
		event = context->dataOut_PTFrame_place;
		if (event == NULL)
			return;
		context->dataOut_PTFrame_place = event->next;
		if (context->dataOut_PTFrame_armMarker == event || context->dataOut_PTFrame_place == NULL)
			context->dataOut_PTFrame_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
}

/******************************************************************************
 * NEXT EVENT SUPPORT FUNCTIONS
 ******************************************************************************/

/* output next handler function */
static INLINE void handleOutgoingNextRequest(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context) {
	((DSPEEventsUnit*) context)->armEvent((DSPEEventsUnit*) context, pOut_next_event);
	((DSPEEventsUnit*) context)->postEvent((DSPEEventsUnit*) context, pOut_next_event);
}

/* input next handler function */
static INLINE void handleIncomingNextRequest(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context) {
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *implState = &context->implState;
	/* If not stop requested */
	if (*((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramIn_stop == 0) {
		// REMARK: no need to check if pendingEvents < MAX because we are sending them all!
		if (*((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramOut_stop) {

			/* Unlock stop and send next to notify */
			*((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramOut_stop = 0;
			handleOutgoingNextRequest(context);
		} else {
			/* Forward next */
			handleOutgoingNextRequest(context);
		}
		/* Send all available results */
		while (hasPendingEvents(context)) {
			dataOut_PTFrame_sendEvent(context);
		}
	}
	//REMARK:
	// else ignore next request. There will be sent at least one more next request
	// as soon as receiving unit unlocks the stop.
}

/******************************************************************************
 * GATE AUTOMATION SUPPORT FUNCTIONS
 ******************************************************************************/

/* Handle incoming event */
static INLINE void handleInputEvent(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context) {
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *implState = &context->implState;
	if (*((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramOut_stop) {
		/* Unlock if possible */
		if (!pendingEvents_aboveMaxThreshold(context)) {
			*((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramOut_stop = 0;
			handleOutgoingNextRequest(context);
		}
	} else {
		/* Lock if needed */
		if (pendingEvents_aboveMaxThreshold(context))
			*((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramOut_stop = 1;
	}
	implState->isReadyToExecute = 1;
}

/******************************************************************************
 * EVENT SUPPORT FUNCTIONS
 ******************************************************************************/

static INLINE void resetEventPlaces(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context) {
	DSPEEvent *event = NULL;
	context->paramOut_next_armMarker = NULL;
	
	while (context->paramOut_next_place != NULL) {
		event = (DSPEEvent*) context->paramOut_next_place;
		context->paramOut_next_place = event->next;
		/* force disposal */
		event->refCount = 1;
		event->dispose(event);
	}
	context->dataOut_PTFrame_armMarker = NULL;
	
	while (context->dataOut_PTFrame_place != NULL) {
		event = (DSPEEvent*) context->dataOut_PTFrame_place;
		context->dataOut_PTFrame_place = event->next;
		/* force disposal */
		event->refCount = 1;
		event->dispose(event);
	}
}

static INLINE void initQueue(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *unit) {
	/* Data transit queues */
	unit->dataIn_PTFrame_transitNumElements = 0;
	unit->dataIn_PTFrame_transitHead = NULL;
	unit->dataIn_PTFrame_transitTail = NULL;
	unit->dataIn_PTFrame_curTransit = NULL;
	unit->dataIn_PTFrame_curTransitIndex = 0;
	
}

static INLINE void resetQueue(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *unit) {
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_dismissAllEventsBlockSim((DSPEQueueUnit*) unit, dIn_PTFrame_event);
}

/**
 * Transit input event function
 */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_transitEventBlockSim(DSPEQueueUnit *unit) {
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim*) unit;
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_queueNode *node = ((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->queueHead;
	
	/* Prevent multiple transits */
	if (node->inTransit == 1)
		return;

	switch (node->ID) {
	case dIn_PTFrame_event:
		if (context->dataIn_PTFrame_transitNumElements == 0) {
			context->dataIn_PTFrame_transitHead = node;
			context->dataIn_PTFrame_transitTail = node;
			context->dataIn_PTFrame_transitNumElements = 1;
		} else {
			context->dataIn_PTFrame_transitTail->nextInTransit = node;
			context->dataIn_PTFrame_transitTail = node;
			context->dataIn_PTFrame_transitNumElements++;
		}
		/* set curTransit if needed */
		if (context->dataIn_PTFrame_curTransit == NULL) {
			context->dataIn_PTFrame_curTransit = node;
			context->dataIn_PTFrame_curTransitIndex = 0;
		}
		context->dataIn_PTFrame_curTransitIndex++;
		node->inTransit = 1;
		break;
	}
}

size_t ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getTransitNumElementsBlockSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim*) unit;

	switch (ID) {
	case dIn_PTFrame_event:
		return context->dataIn_PTFrame_transitNumElements;
	}
	return 0;
}

size_t ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getCurrentNumElementsBlockSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim*) unit;

	switch (ID) {
	case dIn_PTFrame_event:
		return context->dataIn_PTFrame_curTransitIndex;
	}
	return 0;
}

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getFirstTransitBlockSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim*) unit;
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *implState = &context->implState;
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_queueNode *node = NULL;
	
	switch (ID) {
	case dIn_PTFrame_event:
		node = context->dataIn_PTFrame_transitHead;
		if (node == NULL)
			return;
		/* Set UnitBehaviour input gate pointer */
		implState->dataIn_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) node->event)->value;
		break;
	}
}

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getCurTransitBlockSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim*) unit;
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *implState = &context->implState;
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_queueNode *node = NULL;
	
	switch (ID) {
	case dIn_PTFrame_event:
		node = context->dataIn_PTFrame_curTransit;
		if (node == NULL)
			return;
		context->dataIn_PTFrame_curTransit = node->nextInTransit;
		if (node->nextInTransit == NULL)
			context->dataIn_PTFrame_curTransitIndex = 0;
		else
			context->dataIn_PTFrame_curTransitIndex--;
		/* set implementation's gate pointer */
		implState->dataIn_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) node->event)->value;
		break;
	}
}

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_dismissEventBlockSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim*) unit;
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *implState = (ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation*) &context->implState;
	DSPEEvent *event = NULL;
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_queueNode *node = NULL;

	switch (ID) {
	case dIn_PTFrame_event:
		node = context->dataIn_PTFrame_transitHead;
		if (context->dataIn_PTFrame_transitNumElements == 1) {
			context->dataIn_PTFrame_transitHead = NULL;
			context->dataIn_PTFrame_transitTail = NULL;
			context->dataIn_PTFrame_transitNumElements = 0;
		} else {
			context->dataIn_PTFrame_transitHead = node->nextInTransit;
			context->dataIn_PTFrame_transitNumElements--;
		}
		/* Set implementation pointer to secure unlinked place */
		implState->dataIn_PTFrame = context->dataIn_PTFrame_unlinked;
		break;
	}
	node->inTransit = 0;
	node->nextInTransit = NULL;
	
	// If node is the headNode within the queue let unitReleaseEvent do the disposal!
	if (node == ((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->queueHead)
		return;
	
	event = node->event;
	event->dispose(event);
	node->event = NULL;
	node->ID = 0;
	
	/* Move node to pool */
	if (((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->poolNumNodes == 0) {
		((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->poolHead = node;
		((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->poolTail = node;
		((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->poolNumNodes = 1;
	} else {
		((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->poolTail->next = node;
		((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->poolTail = node;
		((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->poolNumNodes++;
	}
}

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_dismissAllEventsBlockSim(DSPEQueueUnit *unit, unsigned int ID) {
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim*) unit;

	switch (ID) {
	case dIn_PTFrame_event:
		while (context->dataIn_PTFrame_transitNumElements != 0)
			ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_dismissEventBlockSim(unit, ID);
		/* Reset curTransit */
		context->dataIn_PTFrame_curTransit = NULL;
		context->dataIn_PTFrame_curTransitIndex = 0;
		break;
	}
}

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_armEventBlockSim(DSPEEventsUnit *unit, unsigned int ID) {
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim*) unit;
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *implState = &context->implState;

	register size_t i;
	DSPEEvent *event = NULL;
	DSPEEvent *insert = NULL;

	switch (ID) {
	case pOut_next_event:
		/* If gate is unlinked no event will be sent. Avoid creating event */
		if (implState->paramOut_next_numLinks == 0)
			return;
		insert = context->paramOut_next_armMarker;
		event = (DSPEEvent*) ParticleTrackerDllNextGate_SignalGate_allocate(context->paramOut_next_pool);
		event->refCount = 1;
		if (insert == NULL)
			context->paramOut_next_place = event;
		else
			insert->next = event;
		context->paramOut_next_armMarker = event;
		break;
	case dOut_PTFrame_event:
		/* If gate is unlinked no event will be sent. Avoid creating event */
		if (implState->dataOut_PTFrame_numLinks == 0)
			return;
		insert = context->dataOut_PTFrame_armMarker;
		if (insert == NULL) {
			if (context->dataOut_PTFrame_place == NULL) {
				event = (DSPEEvent*) ParticleTrackerDllPTFrameGate_MessageGate_allocateBlock(context->dataOut_PTFrame_pool);
				event->refCount = 1;
				context->dataOut_PTFrame_place = event;
				context->dataOut_PTFrame_armMarker = event;
				implState->dataOut_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value;
				/* create clones if needed */
				for (i = 0; i < context->dataOut_PTFrame_factor - 1; i++) {
					insert = event;
					event = insert->clone(insert);
					event->refCount = 1;
					((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value += context->blockSize;
					/* append clone */
					insert->next = event;
				}
			} else {
				event = context->dataOut_PTFrame_place;
				context->dataOut_PTFrame_armMarker = event;
				implState->dataOut_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value;
			}
		} else if (insert->next == NULL) {
			event = (DSPEEvent*) ParticleTrackerDllPTFrameGate_MessageGate_allocateBlock(context->dataOut_PTFrame_pool);
			event->refCount = 1;
			context->dataOut_PTFrame_armMarker->next = event;
			context->dataOut_PTFrame_armMarker = event;
			implState->dataOut_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value;
			/* create clones if needed */
			for (i = 0; i < context->dataOut_PTFrame_factor - 1; i++) {
				insert = event;
				event = insert->clone(insert);
				event->refCount = 1;
				((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value += context->blockSize;
				/* append clone */
				insert->next = event;
			}
		} else {
			/* use insert->next*/
			event = insert->next;
			context->dataOut_PTFrame_armMarker = event;
			implState->dataOut_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value;
		}
		break;
	}
}

/* BlockUnit Post Function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_postEventBlockSim(DSPEEventsUnit *unit, unsigned int ID) {
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim*) unit;
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *implState = &context->implState;
	DSPEEvent *event = NULL;
	switch (ID) {
	case pOut_next_event:
		/* If gate is unlinked no event will be sent */
		if (implState->paramOut_next_numLinks == 0)
			return;
		event = context->paramOut_next_place;
		if (event == NULL)
			return;
		context->paramOut_next_place = event->next;
		if (context->paramOut_next_place == NULL)
			context->paramOut_next_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
		break;
	case dOut_PTFrame_event:
		/* If gate is unlinked no event will be sent */
		if (implState->dataOut_PTFrame_numLinks == 0)
			return;
		/* Restore save place to write */
		implState->dataOut_PTFrame = context->dataOut_PTFrame_unlinked;
		// Push pendingEvents support. If stop requested start collecting events instead of sending them
		// if pendingEvents available: we cannot send current data because there is other data to be sent before. Wait inputNext request to empty pending events
		// if stop requested: unit will send next to request all collected data!
		if (hasPendingEvents(context) ||
			*((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramIn_stop == 1) {
			// Start collecting events. Incrementing pendingEvents counter and returning.
			// Event will be sent when inputEvent arrives
			context->dataOut_PTFrame_pendingEvents++;
			return;
		}
		event = context->dataOut_PTFrame_place;
		if (event == NULL)
			return;
		context->dataOut_PTFrame_place = event->next;
		if (context->dataOut_PTFrame_armMarker == event || context->dataOut_PTFrame_place == NULL)
			context->dataOut_PTFrame_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
		break;
	}

}

/* Initialize gate values */
static INLINE void initValues(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *implState = &context->implState;
	ParticleTrackerDllPTFrameGate_MessageGate_initializeUnlinkedBlock((DSPEElement*) context, context->dataIn_PTFrame_unlinked, context->blockSize);
	implState->dataIn_PTFrame = context->dataIn_PTFrame_unlinked;
	ParticleTrackerDllPTFrameGate_MessageGate_initializeUnlinkedBlock((DSPEElement*) context, context->dataOut_PTFrame_unlinked, context->blockSize);
	implState->dataOut_PTFrame = context->dataOut_PTFrame_unlinked;

}

/******************************************************************************
 * COMMON UNIT FUNCTIONS
 ******************************************************************************/

/* Earlyalloc function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_earlyAllocBlockSim(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context) {
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *implState = &context->implState;

	initDSPEElement((DSPEElement*) &context->implState, (DSPEElement*) context);
	initDSPEQueueUnit((DSPEQueueUnit*) context);
	((DSPEComponent*) context)->preprocess = ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_preProcessBlockSim;
	((DSPEComponent*) context)->process = ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_processBlockSim;
	((DSPEComponent*) context)->postprocess = ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_postProcessBlockSim;
	/* Data gates size initialization */
	context->dataOut_PTFrame_size = context->blockSize;

	implState->isReadyToExecute = 0;
	/* Data pendingEvents initialization */
	context->dataOut_PTFrame_pendingEvents = 0;

	/* Implementation AdditionalStateVariables initialization */
	implState->functionalState.framesToLink = 0;
	implState->functionalState.linkrangeCounter = 0;
	implState->functionalState.currentFrame = 0;
	implState->functionalState.index = 0;
	implState->functionalState.currentState = 0;
	/* Unit profile ID initialization */
	context->unitProfileID = (int) profileSupport_getUnitProfileID(((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->ID);
}

/* Alloc function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_allocBlockSim(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context) {
	const DSPEOwner *owner = ((DSPEElement*) context)->owner;

	/* Base alloc() function call */
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_alloc(&context->baseState);

	initQueue(context);
	((DSPEQueueUnit*) context)->transitEvent = ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_transitEventBlockSim;
	((DSPEQueueUnit*) context)->getTransitNumElements = ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getTransitNumElementsBlockSim;
	((DSPEQueueUnit*) context)->getCurrentNumElements = ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getCurrentNumElementsBlockSim;
	((DSPEQueueUnit*) context)->dismissEvent = ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_dismissEventBlockSim;
	((DSPEQueueUnit*) context)->getFirstTransitEvent = ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getFirstTransitBlockSim;
	((DSPEQueueUnit*) context)->getCurrentTransitEvent = ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getCurTransitBlockSim;
	((DSPEEventsUnit*) context)->armEvent = ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_armEventBlockSim;
	((DSPEEventsUnit*) context)->postEvent = ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_postEventBlockSim;

	/* Initializing event Hooks and Inserts */
	context->paramOut_next_place = NULL;
	context->paramOut_next_armMarker = NULL;

	/* Allocate unlinked places for input event gates */
	context->dataIn_PTFrame_unlinked = ParticleTrackerDllPTFrameGate_MessageGate_allocateUnlinkedBlock((DSPEElement*) context, context->blockSize);
	context->dataOut_PTFrame_unlinked = ParticleTrackerDllPTFrameGate_MessageGate_allocateUnlinkedBlock((DSPEElement*) context, context->blockSize);


	/* Data output gates factor and counter initialization */
	context->dataOut_PTFrame_factor = context->dataOut_PTFrame_size / context->blockSize;

	/* Initialize eventPools for parameter gates */
	context->paramOut_next_pool = ParticleTrackerDllNextGate_SignalGate_initPool(owner);

	context->dataOut_PTFrame_place = NULL;
	context->dataOut_PTFrame_armMarker = NULL;

	/* Initialize eventPools for data gates */
	context->dataOut_PTFrame_pool = ParticleTrackerDllPTFrameGate_MessageGate_initPoolBlock(owner, context->dataOut_PTFrame_size);

}

/* Earlyconnect function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_earlyConnectBlockSim(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *implState = &context->implState;

	/* Implementation output parameters gates initialization */
	implState->paramOut_stop = ((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramOut_stop_place;
	implState->paramOut_Status = ((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramOut_Status_place;


	/* Base earlyconnect() function call */
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_earlyConnect(&context->baseState);

}

/* Connect function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_connectBlockSim(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *implState = &context->implState;

	/* Implementation input parameters gates initialization */
	implState->paramIn_stop = ((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramIn_stop;
	implState->paramIn_Linkrange = ((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramIn_Linkrange;
	implState->paramIn_Displacement = ((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramIn_Displacement;

	/* Implementation gates numLinks initialization */
	implState->dataIn_PTFrame_numLinks = ((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->dataIn_PTFrame_numLinks;
	implState->dataOut_PTFrame_numLinks = ((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->dataOut_PTFrame_numLinks;
	implState->paramIn_next_numLinks = ((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramIn_next_numLinks;
	implState->paramIn_stop_numLinks = ((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramIn_stop_numLinks;
	implState->paramIn_Linkrange_numLinks = ((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramIn_Linkrange_numLinks;
	implState->paramIn_Displacement_numLinks = ((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramIn_Displacement_numLinks;
	implState->paramOut_next_numLinks = ((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramOut_next_numLinks;
	implState->paramOut_stop_numLinks = ((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramOut_stop_numLinks;
	implState->paramOut_Status_numLinks = ((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramOut_Status_numLinks;

}

/* Startup function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_startupBlockSim(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context) {
	/* Initialize gate values */
	initValues(context);


}

/* Preprocess function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_preProcessBlockSim(DSPEComponent *component) {
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim*) component;
	/* Implementation preprocess() call */
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation_preProcess(&context->implState);
}

/* Process function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_processBlockSim(DSPEComponent *component) {
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim*) component;
	/* Implementation state local variable initialization */
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *implState = &context->implState;
	const unsigned int ID = (((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->queueNumNodes == 0) ? NOEVENT : ((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->queueHead->ID;
	/* Loop counter */
	register size_t i;

	/* Push support: send all pending events if available */
	if (*((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramIn_stop == 0) {
		while (hasPendingEvents(context)) {		
			dataOut_PTFrame_sendEvent(context);
		}
	}
	/* Switch input event ID */
	switch (ID) {
	case dIn_PTFrame_event:
		/* AutoTransit inputEvents */
		((DSPEQueueUnit*) context)->transitEvent((DSPEQueueUnit*) context);
		/* Unlock stop if possible and send next to notify */
		if (*((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramOut_stop &&
			!pendingEvents_aboveMaxThreshold(context)) {
			*((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramOut_stop = 0;
			handleOutgoingNextRequest(context);
		}
		/* Handle incoming event */
		handleInputEvent(context);
		break;
	case pIn_next_event:
		handleIncomingNextRequest(context);
		break;
	}
	/* Automatic execute support */
	if (implState->isReadyToExecute) {
		implState->isReadyToExecute = 0;

	/* Capture unit process start time */
	profileManager_captureStartTime((DSPEElement*) context, (profileID) context->unitProfileID);


	/* Blocksize loop */
	for (i = 0; i < context->samplesToProcess - 1; i++) {

		/* Implementation process() call */
		ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation_process(implState);


		/* Block loop event Input pointers increment */
		if (implState->dataIn_PTFrame != context->dataIn_PTFrame_unlinked)
			implState->dataIn_PTFrame++;

		/* For Implementation having Advanced EventSupport also pointers for data output events have to be incremented */
		if (implState->dataOut_PTFrame != NULL)
			implState->dataOut_PTFrame++;

	}

	/* Implementation process() call */
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation_process(implState);

	/* Capture unit process end time */
	profileManager_captureEndTime((DSPEElement*) context, (profileID) context->unitProfileID);

		/* input next push support */
		if (*((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramIn_stop == 1) {
			if (pendingEvents_aboveMaxThreshold(context))
				*((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context)->paramOut_stop = 1;
		}
	} /* End of automaticExecute support */

	/* Restore unlinked pointers on unitBehaviour */
	if (implState->dataIn_PTFrame != context->dataIn_PTFrame_unlinked)
		implState->dataIn_PTFrame = context->dataIn_PTFrame_unlinked;
	/* Release event */
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_releaseEvent((ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit*) context);
}

/* Postprocess function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_postProcessBlockSim(DSPEComponent *component) {
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context = (ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim*) component;

	/* Implementation postprocess() call */
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation_postProcess(&context->implState);

	/* Move all output events that have been armed but not sent to their related pool */
	resetEventPlaces(context);

	/* Move all events from transitQueue back to their related pool */
	resetQueue(context);

	/* Base postprocess() function call */
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_postProcess(&context->baseState);
}

/* Reset function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_resetBlockSim(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context) {
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *implState = &context->implState;

	/* Base reset() function call */
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_reset(&context->baseState);

	/* Initialize gate values */
	initValues(context);
	implState->isReadyToExecute = 0;
	/* Data pendingEvents initialization */
	context->dataOut_PTFrame_pendingEvents = 0;

	/* Implementation AdditionalStateVariables initialization */
	implState->functionalState.framesToLink = 0;
	implState->functionalState.linkrangeCounter = 0;
	implState->functionalState.currentFrame = 0;
	implState->functionalState.index = 0;
	implState->functionalState.currentState = 0;
}

/* Shutdown function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_shutdownBlockSim(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context) {


	/* Base shutdown() function call */
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_shutdown(&context->baseState);

	/* Dispose unlinked places for input event gates */
	ParticleTrackerDllPTFrameGate_MessageGate_disposeUnlinkedBlock((DSPEElement*) context, context->dataIn_PTFrame_unlinked);
	ParticleTrackerDllPTFrameGate_MessageGate_disposeUnlinkedBlock((DSPEElement*) context, context->dataOut_PTFrame_unlinked);

}

