/**
 * File: B_ParticleTrackerDllIntGate_StandardGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef B_ParticleTrackerDllIntGate_StandardGate_h
#define B_ParticleTrackerDllIntGate_StandardGate_h

#include "DSPEElements.h"

#define PARTICLETRACKERDLLINTGATE_STANDARDGATE_TYPECATEGORY "Standard"
#define PARTICLETRACKERDLLINTGATE_STANDARDGATE_DEFAULTVALUE 0
typedef int ParticleTrackerDllIntGate_StandardGate;

/* StandardGate node type definition */
typedef struct ParticleTrackerDllIntGate_StandardGate_node ParticleTrackerDllIntGate_StandardGate_node; 

/* StandardGate node definition */ 
struct ParticleTrackerDllIntGate_StandardGate_node {
	DSPEGateNode node;
	
	ParticleTrackerDllIntGate_StandardGate *gate;
	ParticleTrackerDllIntGate_StandardGate *localVar;
	ParticleTrackerDllIntGate_StandardGate value;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Allocate function */
ParticleTrackerDllIntGate_StandardGate* ParticleTrackerDllIntGate_StandardGate_allocate(DSPEElement *context);

/* Initialise function */
void ParticleTrackerDllIntGate_StandardGate_initialize(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate *place);

/* SetOverride function */
void ParticleTrackerDllIntGate_StandardGate_setOverride(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate *place, ParticleTrackerDllIntGate_StandardGate value);

/* Set function */
void ParticleTrackerDllIntGate_StandardGate_set(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate *place, ParticleTrackerDllIntGate_StandardGate *value);

/* Dispose function */
void ParticleTrackerDllIntGate_StandardGate_dispose(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate *place);

/* AllocateGroup function */
void ParticleTrackerDllIntGate_StandardGate_allocateGroup(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t size);

/* InitialiseGroup function */
void ParticleTrackerDllIntGate_StandardGate_initializeGroup(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t size);

/* SetOverrideGroup function */
void ParticleTrackerDllIntGate_StandardGate_setOverrideGroup(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t size, ParticleTrackerDllIntGate_StandardGate value);

/* SetGroup function */
void ParticleTrackerDllIntGate_StandardGate_setGroup(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t size, ParticleTrackerDllIntGate_StandardGate **value);

/* DisposeGroup function */
void ParticleTrackerDllIntGate_StandardGate_disposeGroup(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t size);

/* CreateNode function */
ParticleTrackerDllIntGate_StandardGate_node* ParticleTrackerDllIntGate_StandardGate_createNode(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate *gate, ParticleTrackerDllIntGate_StandardGate *localVar);

/* DisposeNode function */
void ParticleTrackerDllIntGate_StandardGate_disposeNode(DSPEElement *context, DSPEGateNode *node);

/* SetValue function */
void ParticleTrackerDllIntGate_StandardGate_setValue(DSPEElement *context, DSPEGateNode *node);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
