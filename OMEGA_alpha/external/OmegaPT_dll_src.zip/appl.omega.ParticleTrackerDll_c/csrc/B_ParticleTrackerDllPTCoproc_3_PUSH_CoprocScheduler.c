/**
 * File: B_ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler.c
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#include "PlatformManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "CoprocManager.h"
#include "EngineManager.h"

#include "B_ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler.h"

#define LibraryDataReader_pIn_sourceNext_event 1000
#define LibraryDataReader_pIn_next_event 1001
#define LibraryDataReader_pOut_next_event 1000
#define LibraryDataReader_dOut_PTFrame_event 1001

#define ConvolveAllCaseCP_PUSH_pIn_next_event 1000
#define ConvolveAllCaseCP_PUSH_dIn_PTFrame_event 1001
#define ConvolveAllCaseCP_PUSH_pOut_next_event 1000
#define ConvolveAllCaseCP_PUSH_dOut_PTFrame_event 1001
#define ConvolveAllCaseCP_PUSH_dOut_PTFiltered_event 1002

#define DilateAllCaseCP_PUSH_pIn_next_event 1000
#define DilateAllCaseCP_PUSH_dIn_PTFrame_event 1001
#define DilateAllCaseCP_PUSH_pOut_next_event 1000
#define DilateAllCaseCP_PUSH_dOut_PTFrame_event 1001

#define FindThresholdCP_dIn_PTFiltered_event 1000
#define FindThresholdCP_dOut_PTThreshold_event 1000

#define FindParticlesCPNewAutoNext_PUSH_2_pIn_next_event 1000
#define FindParticlesCPNewAutoNext_PUSH_2_dIn_PTFrame_event 1001
#define FindParticlesCPNewAutoNext_PUSH_2_dIn_PTThreshold_event 1002
#define FindParticlesCPNewAutoNext_PUSH_2_pOut_next_event 1000
#define FindParticlesCPNewAutoNext_PUSH_2_dOut_PTFrame_event 1001

#define PositionRefinementCP_PUSH_2_pIn_next_event 1000
#define PositionRefinementCP_PUSH_2_dIn_PTFrame_event 1001
#define PositionRefinementCP_PUSH_2_pOut_next_event 1000
#define PositionRefinementCP_PUSH_2_dOut_PTFrame_event 1001

#define ParticlesDiscriminationStateCP_PUSH_pIn_next_event 1000
#define ParticlesDiscriminationStateCP_PUSH_dIn_PTFrame_event 1001
#define ParticlesDiscriminationStateCP_PUSH_pOut_next_event 1000
#define ParticlesDiscriminationStateCP_PUSH_dOut_PTFrame_event 1001

#define LinkParticlesStateCPAutoNext_PUSH_pIn_next_event 1000
#define LinkParticlesStateCPAutoNext_PUSH_dIn_PTFrame_event 1001
#define LinkParticlesStateCPAutoNext_PUSH_pOut_next_event 1000
#define LinkParticlesStateCPAutoNext_PUSH_dOut_PTFrame_event 1001

#define GenerateTrajectoriesStateCPAutoNextNew_PUSH_pIn_next_event 1000
#define GenerateTrajectoriesStateCPAutoNextNew_PUSH_dIn_PTFrame_event 1001
#define GenerateTrajectoriesStateCPAutoNextNew_PUSH_pOut_next_event 1000
#define GenerateTrajectoriesStateCPAutoNextNew_PUSH_pOut_LastFrameProcessed_event 1001
#define GenerateTrajectoriesStateCPAutoNextNew_PUSH_dOut_Trajectory_event 1002

#define LibraryDataWriter_pIn_LastFrameProcessed_event 1000
#define LibraryDataWriter_dIn_Trajectory_event 1001
#define LibraryDataWriter_pOut_next_event 1000


/* Unit declaration id defines */
#define LibraryDataReader_ID "LibraryDataReader"
#define ConvolveAllCaseCP_PUSH_ID "ConvolveAllCaseCP_PUSH"
#define DilateAllCaseCP_PUSH_ID "DilateAllCaseCP_PUSH"
#define FindThresholdCP_ID "FindThresholdCP"
#define FindParticlesCPNewAutoNext_PUSH_2_ID "FindParticlesCPNewAutoNext_PUSH_2"
#define PositionRefinementCP_PUSH_2_ID "PositionRefinementCP_PUSH_2"
#define ParticlesDiscriminationStateCP_PUSH_ID "ParticlesDiscriminationStateCP_PUSH"
#define LinkParticlesStateCPAutoNext_PUSH_ID "LinkParticlesStateCPAutoNext_PUSH"
#define GenerateTrajectoriesStateCPAutoNextNew_PUSH_ID "GenerateTrajectoriesStateCPAutoNextNew_PUSH"
#define LibraryDataWriter_ID "LibraryDataWriter"

static INLINE void queueComponent(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *scheduler, DSPEComponent *component) {
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_queueNode *node = NULL;
	
	switch (scheduler->poolNumNodes) {
	case 0:
		node = (ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_queueNode*) memoryManager_allocate((DSPEElement*) scheduler, sizeof(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_queueNode));
		break;
	case 1:
		node = scheduler->poolHead;
		scheduler->poolHead = NULL;
		scheduler->poolTail = NULL;
		scheduler->poolNumNodes = 0;
		break;
	default:
		node = scheduler->poolHead;
		scheduler->poolHead = node->next;
		scheduler->poolNumNodes--;
		break;
	}

	node->next = NULL;
	node->component = component;
	
	if (scheduler->queueNumNodes == 0) {
		scheduler->queueHead = node;
		scheduler->queueTail = node;
		scheduler->queueNumNodes = 1;
	} else {
		scheduler->queueTail->next = node;
		scheduler->queueTail = node;
		scheduler->queueNumNodes++;
	}
}

static INLINE DSPEComponent* releaseComponent(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *scheduler) {
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_queueNode *node = scheduler->queueHead;
	DSPEComponent *component = NULL;
	
	if (scheduler->queueNumNodes == 1) {
		scheduler->queueHead = NULL;
		scheduler->queueTail = NULL;
		scheduler->queueNumNodes = 0;
	} else {
		scheduler->queueHead = node->next;
		scheduler->queueNumNodes--;
	}

	node->next = NULL;
	component = node->component;
	node->component = NULL;

	if (scheduler->poolNumNodes == 0) {
		scheduler->poolHead = node;
		scheduler->poolTail = node;
		scheduler->poolNumNodes = 1;
	} else {
		scheduler->poolTail->next = node;
		scheduler->poolTail = node;
		scheduler->poolNumNodes++;
	}
	return component;
}

static INLINE void initQueue(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *scheduler) {
	scheduler->poolNumNodes = 0;
	scheduler->poolHead = NULL;
	scheduler->poolTail = NULL;
		
	scheduler->queueNumNodes = 0;
	scheduler->queueHead = NULL;
	scheduler->queueTail = NULL;
	
	scheduler->resumeContainer = 0;
}

static INLINE void resetQueue(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *scheduler) {
	while (scheduler->queueNumNodes != 0)
		releaseComponent(scheduler);
	
	scheduler->resumeContainer = 0;
}

static INLINE void disposeQueue(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *scheduler) {
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_queueNode *node = scheduler->poolHead;
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_queueNode *tmp = NULL;
	
	/* Dispose queueNodes in pool */
	while (node != NULL) {
		tmp = node->next;
		node->next = NULL;
		memorySupport_dispose(node);
		node = tmp;
	}
}

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendDilateAllCaseCP_PUSHEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID) {
	DSPEElement *element = (DSPEElement*) unit;
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context = (ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler*) element->container;

	switch (ID) {
	case DilateAllCaseCP_PUSH_dOut_PTFrame_event:
		ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->FindParticlesCPNewAutoNext_PUSH_2, event, FindParticlesCPNewAutoNext_PUSH_2_dIn_PTFrame_event);
		queueComponent(context, (DSPEComponent*) &context->FindParticlesCPNewAutoNext_PUSH_2);
		break;
	case DilateAllCaseCP_PUSH_pOut_next_event:
		ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->ConvolveAllCaseCP_PUSH, event, ConvolveAllCaseCP_PUSH_pIn_next_event);
		queueComponent(context, (DSPEComponent*) &context->ConvolveAllCaseCP_PUSH);
		break;
	}
}

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendConvolveAllCaseCP_PUSHEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID) {
	DSPEElement *element = (DSPEElement*) unit;
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context = (ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler*) element->container;

	switch (ID) {
	case ConvolveAllCaseCP_PUSH_dOut_PTFrame_event:
		ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->DilateAllCaseCP_PUSH, event, DilateAllCaseCP_PUSH_dIn_PTFrame_event);
		queueComponent(context, (DSPEComponent*) &context->DilateAllCaseCP_PUSH);
		break;
	case ConvolveAllCaseCP_PUSH_pOut_next_event:
		ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->LibraryDataReader, event, LibraryDataReader_pIn_next_event);
		queueComponent(context, (DSPEComponent*) &context->LibraryDataReader);
		break;
	case ConvolveAllCaseCP_PUSH_dOut_PTFiltered_event:
		ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->FindThresholdCP, event, FindThresholdCP_dIn_PTFiltered_event);
		queueComponent(context, (DSPEComponent*) &context->FindThresholdCP);
		break;
	}
}

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendLinkParticlesStateCPAutoNext_PUSHEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID) {
	DSPEElement *element = (DSPEElement*) unit;
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context = (ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler*) element->container;

	switch (ID) {
	case LinkParticlesStateCPAutoNext_PUSH_pOut_next_event:
		ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->ParticlesDiscriminationStateCP_PUSH, event, ParticlesDiscriminationStateCP_PUSH_pIn_next_event);
		queueComponent(context, (DSPEComponent*) &context->ParticlesDiscriminationStateCP_PUSH);
		break;
	case LinkParticlesStateCPAutoNext_PUSH_dOut_PTFrame_event:
		ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->GenerateTrajectoriesStateCPAutoNextNew_PUSH, event, GenerateTrajectoriesStateCPAutoNextNew_PUSH_dIn_PTFrame_event);
		queueComponent(context, (DSPEComponent*) &context->GenerateTrajectoriesStateCPAutoNextNew_PUSH);
		break;
	}
}

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendGenerateTrajectoriesStateCPAutoNextNew_PUSHEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID) {
	DSPEElement *element = (DSPEElement*) unit;
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context = (ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler*) element->container;

	switch (ID) {
	case GenerateTrajectoriesStateCPAutoNextNew_PUSH_pOut_LastFrameProcessed_event:
		ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->LibraryDataWriter, event, LibraryDataWriter_pIn_LastFrameProcessed_event);
		queueComponent(context, (DSPEComponent*) &context->LibraryDataWriter);
		break;
	case GenerateTrajectoriesStateCPAutoNextNew_PUSH_dOut_Trajectory_event:
		ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->LibraryDataWriter, event, LibraryDataWriter_dIn_Trajectory_event);
		queueComponent(context, (DSPEComponent*) &context->LibraryDataWriter);
		break;
	case GenerateTrajectoriesStateCPAutoNextNew_PUSH_pOut_next_event:
		ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->LinkParticlesStateCPAutoNext_PUSH, event, LinkParticlesStateCPAutoNext_PUSH_pIn_next_event);
		queueComponent(context, (DSPEComponent*) &context->LinkParticlesStateCPAutoNext_PUSH);
		break;
	}
}

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendFindParticlesCPNewAutoNext_PUSH_2Event(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID) {
	DSPEElement *element = (DSPEElement*) unit;
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context = (ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler*) element->container;

	switch (ID) {
	case FindParticlesCPNewAutoNext_PUSH_2_pOut_next_event:
		ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->DilateAllCaseCP_PUSH, event, DilateAllCaseCP_PUSH_pIn_next_event);
		queueComponent(context, (DSPEComponent*) &context->DilateAllCaseCP_PUSH);
		break;
	case FindParticlesCPNewAutoNext_PUSH_2_dOut_PTFrame_event:
		ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->PositionRefinementCP_PUSH_2, event, PositionRefinementCP_PUSH_2_dIn_PTFrame_event);
		queueComponent(context, (DSPEComponent*) &context->PositionRefinementCP_PUSH_2);
		break;
	}
}

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendPositionRefinementCP_PUSH_2Event(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID) {
	DSPEElement *element = (DSPEElement*) unit;
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context = (ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler*) element->container;

	switch (ID) {
	case PositionRefinementCP_PUSH_2_dOut_PTFrame_event:
		ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->ParticlesDiscriminationStateCP_PUSH, event, ParticlesDiscriminationStateCP_PUSH_dIn_PTFrame_event);
		queueComponent(context, (DSPEComponent*) &context->ParticlesDiscriminationStateCP_PUSH);
		break;
	case PositionRefinementCP_PUSH_2_pOut_next_event:
		ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->FindParticlesCPNewAutoNext_PUSH_2, event, FindParticlesCPNewAutoNext_PUSH_2_pIn_next_event);
		queueComponent(context, (DSPEComponent*) &context->FindParticlesCPNewAutoNext_PUSH_2);
		break;
	}
}

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendParticlesDiscriminationStateCP_PUSHEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID) {
	DSPEElement *element = (DSPEElement*) unit;
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context = (ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler*) element->container;

	switch (ID) {
	case ParticlesDiscriminationStateCP_PUSH_dOut_PTFrame_event:
		ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->LinkParticlesStateCPAutoNext_PUSH, event, LinkParticlesStateCPAutoNext_PUSH_dIn_PTFrame_event);
		queueComponent(context, (DSPEComponent*) &context->LinkParticlesStateCPAutoNext_PUSH);
		break;
	case ParticlesDiscriminationStateCP_PUSH_pOut_next_event:
		ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->PositionRefinementCP_PUSH_2, event, PositionRefinementCP_PUSH_2_pIn_next_event);
		queueComponent(context, (DSPEComponent*) &context->PositionRefinementCP_PUSH_2);
		break;
	}
}

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendLibraryDataWriterEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID) {
	DSPEElement *element = (DSPEElement*) unit;
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context = (ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler*) element->container;

	switch (ID) {
	case LibraryDataWriter_pOut_next_event:
		ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->GenerateTrajectoriesStateCPAutoNextNew_PUSH, event, GenerateTrajectoriesStateCPAutoNextNew_PUSH_pIn_next_event);
		queueComponent(context, (DSPEComponent*) &context->GenerateTrajectoriesStateCPAutoNextNew_PUSH);
		break;
	}
}

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendLibraryDataReaderEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID) {
	DSPEElement *element = (DSPEElement*) unit;
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context = (ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler*) element->container;

	switch (ID) {
	case LibraryDataReader_dOut_PTFrame_event:
		ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->ConvolveAllCaseCP_PUSH, event, ConvolveAllCaseCP_PUSH_dIn_PTFrame_event);
		queueComponent(context, (DSPEComponent*) &context->ConvolveAllCaseCP_PUSH);
		break;
	case LibraryDataReader_pOut_next_event:
		ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->LibraryDataReader, event, LibraryDataReader_pIn_sourceNext_event);
		queueComponent(context, (DSPEComponent*) &context->LibraryDataReader);
		break;
	}
}

void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendFindThresholdCPEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID) {
	DSPEElement *element = (DSPEElement*) unit;
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context = (ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler*) element->container;

	switch (ID) {
	case FindThresholdCP_dOut_PTThreshold_event:
		ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_queueEvent((DSPEEventsUnit*) &context->FindParticlesCPNewAutoNext_PUSH_2, event, FindParticlesCPNewAutoNext_PUSH_2_dIn_PTThreshold_event);
		queueComponent(context, (DSPEComponent*) &context->FindParticlesCPNewAutoNext_PUSH_2);
		break;
	}
}

DSPEOpOutQueue* ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_getOutQueue(const DSPECoprocScheduler *scheduler) {
	return ((ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler*) scheduler)->outQueue;
}

/**
 * GetExternalEventsQueue function
 */
DSPEExternalEventsQueue* ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_getExternalEventsQueue(const DSPEScheduler *scheduler) {
	return ((ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler*) scheduler)->externalEventsQueue;
}

/**
 * GetExternalEventsPool function
 */
DSPEExternalEventsQueue* ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_getExternalEventsPool(const DSPEScheduler *scheduler) {
	return ((ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler*) scheduler)->externalEventsPool;
}

/* Dispose CoprocEvent function */
static void CoprocEvent_dispose(DSPEEvent *event) {
	DSPECoprocEventsPool *pool = (DSPECoprocEventsPool*) event->pool;
	if (event->refCount == 1) {
		event->refCount = 0;
		switch (pool->eventsNumElements) {
		case 0:
			pool->eventsHead = (DSPECoprocEvent*) event;
			pool->eventsTail = (DSPECoprocEvent*) event;
			pool->eventsNumElements = 1;
			break;
		default:
			((DSPEEvent*) pool->eventsTail)->next = event;
			pool->eventsTail = (DSPECoprocEvent*) event;
			pool->eventsNumElements++;
			break;
		}	
	} else
		event->refCount--;
}

/* Send CoprocEvent function */
static INLINE void sendCoprocEvent(DSPEOp *op) {
	DSPEEventsUnit *unit = (DSPEEventsUnit*) ((DSPEElement*) op)->container;
	DSPECoprocEvent *event = NULL;
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context = (ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler*) ((DSPEElement*) unit)->container;
	DSPECoprocEventsPool *pool = context->coprocEventsPool;
	
	switch (pool->eventsNumElements) {
	case 0:
		event = (DSPECoprocEvent*) memoryManager_allocate((DSPEElement*) pool, sizeof(DSPECoprocEvent));
		initDSPEEvent((DSPEEvent*) event);
		((DSPEEvent*) event)->dispose = CoprocEvent_dispose;
		((DSPEEvent*) event)->pool = (DSPEEventsPool*) context->coprocEventsPool;
		break;
	case 1:
		event = pool->eventsHead;
		pool->eventsHead = NULL;
		pool->eventsTail = NULL;
		pool->eventsNumElements = 0;
		break;
	default:
		event = pool->eventsHead;
		pool->eventsHead = (DSPECoprocEvent*) ((DSPEEvent*) event)->next;
		pool->eventsNumElements--;
		break;
	}
	
	/* Set event */
	((DSPEEvent*) event)->next = NULL;
	event->op = op;
	unit->queueEvent(unit, (DSPEEvent*) event, 100);
	queueComponent(context, (DSPEComponent*) unit);
}

/* INIT EVENT SUPPORT */

typedef struct InitEvent InitEvent;
struct InitEvent {
	DSPEEvent superEvent;
};

/* Dispose function */
static void InitEvent_dispose(DSPEEvent *event) {
	if (event->refCount == 1)
		memorySupport_dispose(event);
	else
		event->refCount--;
}

/* Send InitEvent function */
static INLINE void sendInitEvent(DSPEEventsUnit *unit, int queueOnly) {
	DSPEEvent *event = NULL;

	/* If unit does not accept initEvent only queue unit */
	if (queueOnly == 0) {
		event = (DSPEEvent*) memoryManager_allocate((DSPEElement*) unit, sizeof(InitEvent));
		event->dispose = InitEvent_dispose;
		event->refCount = 1;
		unit->queueEvent(unit, event, 0);
		event->dispose(event);
	}
	queueComponent((ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler*) ((DSPEElement*) unit)->container, (DSPEComponent*) unit);
}

/**
 * SendExternalEvents function
 */
static INLINE void sendExternalEvents(const ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *scheduler) {
	DSPEExternalEvent *currentEvt;
	DSPEEventsUnit* unit;

	/* Send external events */
	currentEvt = memoryManager_getExternalEventFromQueue((DSPEScheduler*) scheduler);
	while (currentEvt != NULL) {
		switch (currentEvt->id) {
		case 0:
			// InitEvent
			sendInitEvent((DSPEEventsUnit*) &scheduler->LibraryDataReader, 0);
			break;
		case 1:
			if (*(scheduler->LibraryDataWriter.baseState.paramOut_stop) == 0)
				// Stop has not been set => don't need to send a next event!
				break;

			unit = (DSPEEventsUnit*) &scheduler->LibraryDataWriter;
			// Next external event
			if (unit->sendEvent == NULL) {
				memoryManager_addExternalEventToPool((DSPEScheduler*) scheduler, currentEvt);
				return;
			}
			unit->armEvent(unit, LibraryDataWriter_pOut_next_event);
			unit->postEvent(unit, LibraryDataWriter_pOut_next_event);

			// FIXME Trovare una soluzione migliore!!
			// Set stop to 0
			*(scheduler->LibraryDataWriter.baseState.paramOut_stop) = 0;
			break;
		default:
			break;
		}

		memoryManager_addExternalEventToPool((DSPEScheduler*) scheduler, currentEvt);
		currentEvt = memoryManager_getExternalEventFromQueue((DSPEScheduler*) scheduler);
	}
}

/* CoprocScheduler isLocalIdle Function */
static INLINE int isLocalIdle(const ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *scheduler) {
	DSPEOp *currentOp = NULL;
	DSPEOpOutQueue *resultQueue = (DSPEOpOutQueue*) scheduler->outQueue;
	
	/* Send returning OPs to unit's input queue */
	currentOp = coprocManager_getOpFromOutQueue(resultQueue);
	while (currentOp != NULL) {
		sendCoprocEvent(currentOp);
		currentOp = coprocManager_getOpFromOutQueue(resultQueue);
	}

	/* Send external events */
	sendExternalEvents(scheduler);

	/* Not Idle if units in queue */
	return scheduler->queueNumNodes ==  0;
}

int ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_isIdle(const DSPEScheduler *scheduler) {
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context = (ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler*) scheduler;

	/* If not local idle*/
	if (isLocalIdle(context) == 0)
		return 0;
	return 1;
}

/* Earlyalloc function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_earlyAlloc(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context) {
	initDSPECoprocScheduler((DSPECoprocScheduler*) context);
	initQueue(context);

	context->outQueue = coprocManager_initCoprocOutQueue((DSPECoprocScheduler*) context);
	((DSPECoprocScheduler*) context)->getOutQueue = ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_getOutQueue;	

	/* Init external events pool and queue */
	context->externalEventsPool = memoryManager_initExternalEventsQueue((DSPEScheduler*) context);
	((DSPEScheduler*) context)->getExternalEventsPool = ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_getExternalEventsPool;

	context->externalEventsQueue = memoryManager_initExternalEventsQueue((DSPEScheduler*) context);
	((DSPEScheduler*) context)->getExternalEventsQueue = ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_getExternalEventsQueue;

	/* CoprocEvents Pool initialization */
	context->coprocEventsPool = memoryManager_initCoprocPool((DSPECoprocScheduler*) context);

	initDSPEElement((DSPEElement*) &context->LibraryDataReader, (DSPEElement*) context);
	initDSPEElement((DSPEElement*) &context->ConvolveAllCaseCP_PUSH, (DSPEElement*) context);
	initDSPEElement((DSPEElement*) &context->DilateAllCaseCP_PUSH, (DSPEElement*) context);
	initDSPEElement((DSPEElement*) &context->FindThresholdCP, (DSPEElement*) context);
	initDSPEElement((DSPEElement*) &context->FindParticlesCPNewAutoNext_PUSH_2, (DSPEElement*) context);
	initDSPEElement((DSPEElement*) &context->PositionRefinementCP_PUSH_2, (DSPEElement*) context);
	initDSPEElement((DSPEElement*) &context->ParticlesDiscriminationStateCP_PUSH, (DSPEElement*) context);
	initDSPEElement((DSPEElement*) &context->LinkParticlesStateCPAutoNext_PUSH, (DSPEElement*) context);
	initDSPEElement((DSPEElement*) &context->GenerateTrajectoriesStateCPAutoNextNew_PUSH, (DSPEElement*) context);
	initDSPEElement((DSPEElement*) &context->LibraryDataWriter, (DSPEElement*) context);


	context->LibraryDataReader.baseState.ID = stringSupport_generateID(context->namePrefix, LibraryDataReader_ID);
	context->ConvolveAllCaseCP_PUSH.baseState.ID = stringSupport_generateID(context->namePrefix, ConvolveAllCaseCP_PUSH_ID);
	context->DilateAllCaseCP_PUSH.baseState.ID = stringSupport_generateID(context->namePrefix, DilateAllCaseCP_PUSH_ID);
	context->FindThresholdCP.baseState.ID = stringSupport_generateID(context->namePrefix, FindThresholdCP_ID);
	context->FindParticlesCPNewAutoNext_PUSH_2.baseState.ID = stringSupport_generateID(context->namePrefix, FindParticlesCPNewAutoNext_PUSH_2_ID);
	context->PositionRefinementCP_PUSH_2.baseState.ID = stringSupport_generateID(context->namePrefix, PositionRefinementCP_PUSH_2_ID);
	context->ParticlesDiscriminationStateCP_PUSH.baseState.ID = stringSupport_generateID(context->namePrefix, ParticlesDiscriminationStateCP_PUSH_ID);
	context->LinkParticlesStateCPAutoNext_PUSH.baseState.ID = stringSupport_generateID(context->namePrefix, LinkParticlesStateCPAutoNext_PUSH_ID);
	context->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.ID = stringSupport_generateID(context->namePrefix, GenerateTrajectoriesStateCPAutoNextNew_PUSH_ID);
	context->LibraryDataWriter.baseState.ID = stringSupport_generateID(context->namePrefix, LibraryDataWriter_ID);


	/* Contained units earlyalloc() calls sequence */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_earlyAllocRealProd(&context->LibraryDataReader);
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_earlyAllocRealProd(&context->ConvolveAllCaseCP_PUSH);
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_earlyAllocRealProd(&context->DilateAllCaseCP_PUSH);
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_earlyAllocRealProd(&context->FindThresholdCP);
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_earlyAllocRealProd(&context->FindParticlesCPNewAutoNext_PUSH_2);
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_earlyAllocRealProd(&context->PositionRefinementCP_PUSH_2);
	ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_earlyAllocRealProd(&context->ParticlesDiscriminationStateCP_PUSH);
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_earlyAllocRealProd(&context->LinkParticlesStateCPAutoNext_PUSH);
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_earlyAllocRealProd(&context->GenerateTrajectoriesStateCPAutoNextNew_PUSH);
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_earlyAllocRealProd(&context->LibraryDataWriter);

}

/* Alloc function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_alloc(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context) {

	/* Contained units alloc() calls sequence */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_allocRealProd(&context->LibraryDataReader);
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_allocRealProd(&context->ConvolveAllCaseCP_PUSH);
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_allocRealProd(&context->DilateAllCaseCP_PUSH);
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_allocRealProd(&context->FindThresholdCP);
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_allocRealProd(&context->FindParticlesCPNewAutoNext_PUSH_2);
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_allocRealProd(&context->PositionRefinementCP_PUSH_2);
	ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_allocRealProd(&context->ParticlesDiscriminationStateCP_PUSH);
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_allocRealProd(&context->LinkParticlesStateCPAutoNext_PUSH);
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_allocRealProd(&context->GenerateTrajectoriesStateCPAutoNextNew_PUSH);
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_allocRealProd(&context->LibraryDataWriter);

	/* Initializes sendEvent functions for units, by substituting units
	 * initialization done during their alloc phase
	 */
	((DSPEEventsUnit*) &context->DilateAllCaseCP_PUSH)->sendEvent = ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendDilateAllCaseCP_PUSHEvent;
	((DSPEEventsUnit*) &context->ConvolveAllCaseCP_PUSH)->sendEvent = ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendConvolveAllCaseCP_PUSHEvent;
	((DSPEEventsUnit*) &context->LinkParticlesStateCPAutoNext_PUSH)->sendEvent = ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendLinkParticlesStateCPAutoNext_PUSHEvent;
	((DSPEEventsUnit*) &context->GenerateTrajectoriesStateCPAutoNextNew_PUSH)->sendEvent = ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendGenerateTrajectoriesStateCPAutoNextNew_PUSHEvent;
	((DSPEEventsUnit*) &context->FindParticlesCPNewAutoNext_PUSH_2)->sendEvent = ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendFindParticlesCPNewAutoNext_PUSH_2Event;
	((DSPEEventsUnit*) &context->PositionRefinementCP_PUSH_2)->sendEvent = ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendPositionRefinementCP_PUSH_2Event;
	((DSPEEventsUnit*) &context->ParticlesDiscriminationStateCP_PUSH)->sendEvent = ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendParticlesDiscriminationStateCP_PUSHEvent;
	((DSPEEventsUnit*) &context->LibraryDataWriter)->sendEvent = ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendLibraryDataWriterEvent;
	((DSPEEventsUnit*) &context->LibraryDataReader)->sendEvent = ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendLibraryDataReaderEvent;
	((DSPEEventsUnit*) &context->FindThresholdCP)->sendEvent = ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_sendFindThresholdCPEvent;

}

/* Earlyconnect function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_earlyConnect(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context) {

	/* Contained units earlyconnect() calls sequence */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_earlyConnectRealProd(&context->LibraryDataReader);
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_earlyConnectRealProd(&context->ConvolveAllCaseCP_PUSH);
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_earlyConnectRealProd(&context->DilateAllCaseCP_PUSH);
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_earlyConnectRealProd(&context->FindThresholdCP);
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_earlyConnectRealProd(&context->FindParticlesCPNewAutoNext_PUSH_2);
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_earlyConnectRealProd(&context->PositionRefinementCP_PUSH_2);
	ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_earlyConnectRealProd(&context->ParticlesDiscriminationStateCP_PUSH);
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_earlyConnectRealProd(&context->LinkParticlesStateCPAutoNext_PUSH);
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_earlyConnectRealProd(&context->GenerateTrajectoriesStateCPAutoNextNew_PUSH);
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_earlyConnectRealProd(&context->LibraryDataWriter);

}

/* Connect function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_connect(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context) {

	/* Contained units data gates connection */
	context->ConvolveAllCaseCP_PUSH.dataIn_SequenceValues = context->LibraryDataReader.dataOut_SequenceValues;
	context->FindThresholdCP.dataIn_SequenceValues = context->LibraryDataReader.dataOut_SequenceValues;
	context->DilateAllCaseCP_PUSH.dataIn_SequenceValues = context->LibraryDataReader.dataOut_SequenceValues;
	context->FindParticlesCPNewAutoNext_PUSH_2.dataIn_SequenceValues = context->LibraryDataReader.dataOut_SequenceValues;
	context->PositionRefinementCP_PUSH_2.dataIn_Mask = context->DilateAllCaseCP_PUSH.dataOut_Mask;
	context->PositionRefinementCP_PUSH_2.dataIn_SequenceValues = context->LibraryDataReader.dataOut_SequenceValues;
	context->GenerateTrajectoriesStateCPAutoNextNew_PUSH.dataIn_SequenceValues = context->LibraryDataReader.dataOut_SequenceValues;


	/* Contained units parameter gates connection */
	context->ConvolveAllCaseCP_PUSH.baseState.paramIn_stop = context->DilateAllCaseCP_PUSH.baseState.paramOut_stop;
	context->LibraryDataReader.baseState.paramIn_stop = context->ConvolveAllCaseCP_PUSH.baseState.paramOut_stop;
	context->ParticlesDiscriminationStateCP_PUSH.baseState.paramIn_stop = context->LinkParticlesStateCPAutoNext_PUSH.baseState.paramOut_stop;
	context->LinkParticlesStateCPAutoNext_PUSH.baseState.paramIn_stop = context->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramOut_stop;
	context->DilateAllCaseCP_PUSH.baseState.paramIn_stop = context->FindParticlesCPNewAutoNext_PUSH_2.baseState.paramOut_stop;
	context->FindParticlesCPNewAutoNext_PUSH_2.baseState.paramIn_stop = context->PositionRefinementCP_PUSH_2.baseState.paramOut_stop;
	context->PositionRefinementCP_PUSH_2.baseState.paramIn_stop = context->ParticlesDiscriminationStateCP_PUSH.baseState.paramOut_stop;
	context->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramIn_stop = context->LibraryDataWriter.baseState.paramOut_stop;
	context->LibraryDataWriter.baseState.paramIn_FoundTrajectories = context->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramOut_FoundTrajectories;

	context->PositionRefinementCP_PUSH_2.baseState.paramIn_next_numLinks += 1;
	context->PositionRefinementCP_PUSH_2.baseState.paramIn_stop_numLinks += 1;
	context->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.dataIn_SequenceValues_numLinks += 1;
	context->LinkParticlesStateCPAutoNext_PUSH.baseState.paramIn_stop_numLinks += 1;
	context->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramIn_next_numLinks += 1;
	context->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramIn_stop_numLinks += 1;
	context->LibraryDataReader.baseState.paramIn_stop_numLinks += 1;
	context->ParticlesDiscriminationStateCP_PUSH.baseState.paramIn_stop_numLinks += 1;
	context->PositionRefinementCP_PUSH_2.baseState.dataIn_PTFrame_numLinks += 1;
	context->DilateAllCaseCP_PUSH.baseState.paramIn_next_numLinks += 1;
	context->LibraryDataWriter.baseState.dataIn_Trajectory_numLinks += 1;
	context->LibraryDataWriter.baseState.paramIn_FoundTrajectories_numLinks += 1;
	context->LibraryDataReader.baseState.paramIn_next_numLinks += 1;
	context->FindThresholdCP.baseState.dataIn_SequenceValues_numLinks += 1;
	context->FindParticlesCPNewAutoNext_PUSH_2.baseState.paramIn_stop_numLinks += 1;
	context->ConvolveAllCaseCP_PUSH.baseState.paramIn_stop_numLinks += 1;
	context->FindThresholdCP.baseState.dataIn_PTFiltered_numLinks += 1;
	context->PositionRefinementCP_PUSH_2.baseState.dataIn_SequenceValues_numLinks += 1;
	context->LibraryDataWriter.baseState.paramIn_LastFrameProcessed_numLinks += 1;
	context->ConvolveAllCaseCP_PUSH.baseState.dataIn_PTFrame_numLinks += 1;
	context->DilateAllCaseCP_PUSH.baseState.dataIn_SequenceValues_numLinks += 1;
	context->PositionRefinementCP_PUSH_2.baseState.dataIn_Mask_numLinks += 1;
	context->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.dataIn_PTFrame_numLinks += 1;
	context->LinkParticlesStateCPAutoNext_PUSH.baseState.paramIn_next_numLinks += 1;
	context->ConvolveAllCaseCP_PUSH.baseState.paramIn_next_numLinks += 1;
	context->FindParticlesCPNewAutoNext_PUSH_2.baseState.dataIn_PTFrame_numLinks += 1;
	context->ParticlesDiscriminationStateCP_PUSH.baseState.paramIn_next_numLinks += 1;
	context->FindParticlesCPNewAutoNext_PUSH_2.baseState.dataIn_SequenceValues_numLinks += 1;
	context->LinkParticlesStateCPAutoNext_PUSH.baseState.dataIn_PTFrame_numLinks += 1;
	context->LibraryDataReader.baseState.paramIn_sourceNext_numLinks += 1;
	context->ParticlesDiscriminationStateCP_PUSH.baseState.dataIn_PTFrame_numLinks += 1;
	context->ConvolveAllCaseCP_PUSH.baseState.dataIn_SequenceValues_numLinks += 1;
	context->DilateAllCaseCP_PUSH.baseState.dataIn_PTFrame_numLinks += 1;
	context->DilateAllCaseCP_PUSH.baseState.paramIn_stop_numLinks += 1;
	context->FindParticlesCPNewAutoNext_PUSH_2.baseState.paramIn_next_numLinks += 1;
	context->FindParticlesCPNewAutoNext_PUSH_2.baseState.dataIn_PTThreshold_numLinks += 1;
	context->ConvolveAllCaseCP_PUSH.baseState.paramOut_next_numLinks += 1;
	context->FindThresholdCP.baseState.dataOut_PTThreshold_numLinks += 1;
	context->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramOut_next_numLinks += 1;
	context->ParticlesDiscriminationStateCP_PUSH.baseState.paramOut_next_numLinks += 1;
	context->LibraryDataReader.baseState.dataOut_SequenceValues_numLinks += 6;
	context->LinkParticlesStateCPAutoNext_PUSH.baseState.dataOut_PTFrame_numLinks += 1;
	context->LibraryDataWriter.baseState.paramOut_stop_numLinks += 1;
	context->PositionRefinementCP_PUSH_2.baseState.dataOut_PTFrame_numLinks += 1;
	context->ConvolveAllCaseCP_PUSH.baseState.paramOut_stop_numLinks += 1;
	context->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramOut_stop_numLinks += 1;
	context->DilateAllCaseCP_PUSH.baseState.dataOut_Mask_numLinks += 1;
	context->LinkParticlesStateCPAutoNext_PUSH.baseState.paramOut_stop_numLinks += 1;
	context->FindParticlesCPNewAutoNext_PUSH_2.baseState.paramOut_stop_numLinks += 1;
	context->DilateAllCaseCP_PUSH.baseState.paramOut_stop_numLinks += 1;
	context->LibraryDataWriter.baseState.paramOut_next_numLinks += 1;
	context->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramOut_FoundTrajectories_numLinks += 1;
	context->LibraryDataReader.baseState.dataOut_PTFrame_numLinks += 1;
	context->PositionRefinementCP_PUSH_2.baseState.paramOut_next_numLinks += 1;
	context->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramOut_LastFrameProcessed_numLinks += 1;
	context->DilateAllCaseCP_PUSH.baseState.paramOut_next_numLinks += 1;
	context->LinkParticlesStateCPAutoNext_PUSH.baseState.paramOut_next_numLinks += 1;
	context->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.dataOut_Trajectory_numLinks += 1;
	context->LibraryDataReader.baseState.paramOut_next_numLinks += 1;
	context->ConvolveAllCaseCP_PUSH.baseState.dataOut_PTFiltered_numLinks += 1;
	context->ParticlesDiscriminationStateCP_PUSH.baseState.dataOut_PTFrame_numLinks += 1;
	context->ConvolveAllCaseCP_PUSH.baseState.dataOut_PTFrame_numLinks += 1;
	context->ParticlesDiscriminationStateCP_PUSH.baseState.paramOut_stop_numLinks += 1;
	context->DilateAllCaseCP_PUSH.baseState.dataOut_PTFrame_numLinks += 1;
	context->PositionRefinementCP_PUSH_2.baseState.paramOut_stop_numLinks += 1;
	context->FindParticlesCPNewAutoNext_PUSH_2.baseState.paramOut_next_numLinks += 1;
	context->FindParticlesCPNewAutoNext_PUSH_2.baseState.dataOut_PTFrame_numLinks += 1;

	/* Contained units connect() calls sequence */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_connectRealProd(&context->LibraryDataReader);
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_connectRealProd(&context->ConvolveAllCaseCP_PUSH);
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_connectRealProd(&context->DilateAllCaseCP_PUSH);
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_connectRealProd(&context->FindThresholdCP);
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_connectRealProd(&context->FindParticlesCPNewAutoNext_PUSH_2);
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_connectRealProd(&context->PositionRefinementCP_PUSH_2);
	ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_connectRealProd(&context->ParticlesDiscriminationStateCP_PUSH);
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_connectRealProd(&context->LinkParticlesStateCPAutoNext_PUSH);
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_connectRealProd(&context->GenerateTrajectoriesStateCPAutoNextNew_PUSH);
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_connectRealProd(&context->LibraryDataWriter);

}

/* Startup function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_startup(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context) {

	/* Contained units startup() calls sequence */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_startupRealProd(&context->LibraryDataReader);
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_startupRealProd(&context->ConvolveAllCaseCP_PUSH);
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_startupRealProd(&context->DilateAllCaseCP_PUSH);
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_startupRealProd(&context->FindThresholdCP);
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_startupRealProd(&context->FindParticlesCPNewAutoNext_PUSH_2);
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_startupRealProd(&context->PositionRefinementCP_PUSH_2);
	ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_startupRealProd(&context->ParticlesDiscriminationStateCP_PUSH);
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_startupRealProd(&context->LinkParticlesStateCPAutoNext_PUSH);
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_startupRealProd(&context->GenerateTrajectoriesStateCPAutoNextNew_PUSH);
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_startupRealProd(&context->LibraryDataWriter);

}

/* Preprocess function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_preProcess(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context) {

	/* Contained units preprocess() calls sequence */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_preProcessRealProd((DSPEComponent*) &context->LibraryDataReader);
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_preProcessRealProd((DSPEComponent*) &context->ConvolveAllCaseCP_PUSH);
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_preProcessRealProd((DSPEComponent*) &context->DilateAllCaseCP_PUSH);
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_preProcessRealProd((DSPEComponent*) &context->FindThresholdCP);
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_preProcessRealProd((DSPEComponent*) &context->FindParticlesCPNewAutoNext_PUSH_2);
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_preProcessRealProd((DSPEComponent*) &context->PositionRefinementCP_PUSH_2);
	ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_preProcessRealProd((DSPEComponent*) &context->ParticlesDiscriminationStateCP_PUSH);
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_preProcessRealProd((DSPEComponent*) &context->LinkParticlesStateCPAutoNext_PUSH);
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_preProcessRealProd((DSPEComponent*) &context->GenerateTrajectoriesStateCPAutoNextNew_PUSH);
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_preProcessRealProd((DSPEComponent*) &context->LibraryDataWriter);

}

/* Process function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_process(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context) {
	const DSPEElement *container = ((DSPEElement*) context)->container;
	DSPEApplication *application = ((DSPEElement*) context)->application;
	DSPEComponent *currentComponent = NULL;
	DSPEOp *currentOp = NULL;
	// TODO supporto force critical section: updatare la critical section per ogni unit puo'
	// risultare in updates troppo frequenti, cercare alternativa
	
	// TODO stabilire bene dove devono andare i force critical section e i check stopped in modo che
	// nella cascata di chiamate vengano eseguiti con regolarita'

	for (;;) {
		if (engineManager_forceCriticalSection((DSPEElement*) application)) {
			break;
		}
		/* Post events for returning OPs */
		currentOp = coprocManager_getOpFromOutQueue((DSPEOpOutQueue*) context->outQueue);
		while (currentOp != NULL) {
			sendCoprocEvent(currentOp);
			currentOp = coprocManager_getOpFromOutQueue((DSPEOpOutQueue*) context->outQueue);
		}
	
		/* Send external events */
		sendExternalEvents(context);

		/* Idle Time */
		while (isLocalIdle(context)) {
			/* exit on application stop request */		
			if (engineManager_forceCriticalSection((DSPEElement*) application))
				break;
			/* Coproc contribution is done at idle time to maximize cpu time usage! */
			engineManager_performIdleTime((DSPEElement*) application);
			/* Post events for returning OPs */
			currentOp = coprocManager_getOpFromOutQueue((DSPEOpOutQueue*) context->outQueue);
			while (currentOp != NULL) {
				sendCoprocEvent(currentOp);
				currentOp = coprocManager_getOpFromOutQueue((DSPEOpOutQueue*) context->outQueue);
			}
			/* Send external events */
			sendExternalEvents(context);


		} /* End of Idle Time Handling */

		/* Needed to forward the break done in the idle time loop */
		if (engineManager_isStopped((DSPEElement*) application) || engineManager_isStopping((DSPEElement*) application)) {
			break;
		}

		
		currentComponent = releaseComponent(context);
		if ((DSPEElement*) currentComponent == container) {
			context->resumeContainer = 0;
			break;
		}

		// need to check if process function has been installed because units may miss it
		// (not installed if process function not present)
		if (currentComponent->process != NULL)
			currentComponent->process(currentComponent);
	}
}

/* Postprocess function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_postProcess(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context) {
	DSPEOpOutQueue *outQueue = NULL;

	/* Contained units postprocess() calls sequence */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_postProcessRealProd((DSPEComponent*) &context->LibraryDataReader);
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_postProcessRealProd((DSPEComponent*) &context->ConvolveAllCaseCP_PUSH);
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_postProcessRealProd((DSPEComponent*) &context->DilateAllCaseCP_PUSH);
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_postProcessRealProd((DSPEComponent*) &context->FindThresholdCP);
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_postProcessRealProd((DSPEComponent*) &context->FindParticlesCPNewAutoNext_PUSH_2);
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_postProcessRealProd((DSPEComponent*) &context->PositionRefinementCP_PUSH_2);
	ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_postProcessRealProd((DSPEComponent*) &context->ParticlesDiscriminationStateCP_PUSH);
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_postProcessRealProd((DSPEComponent*) &context->LinkParticlesStateCPAutoNext_PUSH);
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_postProcessRealProd((DSPEComponent*) &context->GenerateTrajectoriesStateCPAutoNextNew_PUSH);
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_postProcessRealProd((DSPEComponent*) &context->LibraryDataWriter);

	resetQueue(context);

	outQueue = context->outQueue;
	outQueue->reset(outQueue);
	/* Reset externalEventsQueue. Move all external events from queue to pool */
	memoryManager_resetExternalEventsQueue((DSPEScheduler*) context);

}

/* Reset function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_reset(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context) {
	/* Contained units reset() call sequence */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_resetRealProd(&context->LibraryDataReader);
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_resetRealProd(&context->ConvolveAllCaseCP_PUSH);
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_resetRealProd(&context->DilateAllCaseCP_PUSH);
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_resetRealProd(&context->FindThresholdCP);
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_resetRealProd(&context->FindParticlesCPNewAutoNext_PUSH_2);
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_resetRealProd(&context->PositionRefinementCP_PUSH_2);
	ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_resetRealProd(&context->ParticlesDiscriminationStateCP_PUSH);
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_resetRealProd(&context->LinkParticlesStateCPAutoNext_PUSH);
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_resetRealProd(&context->GenerateTrajectoriesStateCPAutoNextNew_PUSH);
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_resetRealProd(&context->LibraryDataWriter);

}

/* Shutdown function */
void ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_shutdown(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *context) {
	DSPEOpOutQueue *outQueue = NULL;
	disposeQueue(context);

	/* Contained units shutdown() calls sequence */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_shutdownRealProd(&context->LibraryDataReader);
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_shutdownRealProd(&context->ConvolveAllCaseCP_PUSH);
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_shutdownRealProd(&context->DilateAllCaseCP_PUSH);
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_shutdownRealProd(&context->FindThresholdCP);
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_shutdownRealProd(&context->FindParticlesCPNewAutoNext_PUSH_2);
	ParticleTrackerDllPositionRefinementCP_PUSH_2_SoftwareUnit_shutdownRealProd(&context->PositionRefinementCP_PUSH_2);
	ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_shutdownRealProd(&context->ParticlesDiscriminationStateCP_PUSH);
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_shutdownRealProd(&context->LinkParticlesStateCPAutoNext_PUSH);
	ParticleTrackerDllGenerateTrajectoriesStateCPAutoNextNew_PUSH_SoftwareUnit_shutdownRealProd(&context->GenerateTrajectoriesStateCPAutoNextNew_PUSH);
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_shutdownRealProd(&context->LibraryDataWriter);

	outQueue = context->outQueue;
	outQueue->dispose(outQueue);
	/* Dispose externalEvents pool and queue */
	memoryManager_disposeExternalEventsQueue((DSPEScheduler*) context, context->externalEventsQueue);
	memoryManager_disposeExternalEventsQueue((DSPEScheduler*) context, context->externalEventsPool);

}

