/**
 * File: RBlockProd_ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef RBlockProd_ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_h
#define RBlockProd_ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_h

#include "B_ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation.h"
#include "B_ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit.h"
#include "RBlock_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "RBlock_ParticleTrackerDllPTFrameGate_MessageGate.h"
#include "RBlock_ParticleTrackerDllMaskGate_PointerGate.h"

/* Block SoftwareUnit state type definition */
typedef struct ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockProd ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockProd;

/* Block SoftwareUnit state definition */
struct ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockProd {

	/* Base unit state */
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation implState;
	
	/* Block size */
	size_t blockSize;

	/* Samples to process */
	size_t samplesToProcess;

	/* Data transit queues */
	size_t dataIn_PTFrame_transitNumElements;
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_transitHead;
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_transitTail;
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_curTransit;
	unsigned int dataIn_PTFrame_curTransitIndex;

	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;
	DSPEEvent *dataOut_PTFrame_place;
	DSPEEvent *dataOut_PTFrame_armMarker;

	/* Data pending events support */
	size_t dataOut_PTFrame_pendingEvents;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;

	/* EventPools */
	ParticleTrackerDllPTFrameGate_MessageGate_poolBlock *dataOut_PTFrame_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame_unlinked;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame_unlinked;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;
	ParticleTrackerDllMaskGate_PointerGate *dataOut_Mask;


	/* Data gates sizes */
	size_t dataIn_SequenceValues_size;
	size_t dataOut_Mask_size;
	size_t dataOut_PTFrame_size;


	/* Data gates factors */
	size_t dataIn_SequenceValues_factor;
	size_t dataOut_Mask_factor;
	size_t dataOut_PTFrame_factor;


	/* Data gates counters */
	size_t dataIn_SequenceValues_counter;
	size_t dataOut_Mask_counter;
	size_t dataOut_PTFrame_counter;


	/* Output data places */
	ParticleTrackerDllMaskGate_PointerGate *dataOut_Mask_place;


	/* Data gates counters */
	size_t dataOut_PTFrame_samplesCounter;

	/* Unit profile ID */
	int unitProfileID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_transitEventBlockProd(DSPEQueueUnit *unit);

size_t ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getTransitNumElementsBlockProd(DSPEQueueUnit *unit, unsigned int ID);

size_t ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getTransitNumElementsBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getFirstTransitBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getCurTransitBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_dismissEventBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_dismissAllEventsBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_armEventBlockProd(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_postEventBlockProd(DSPEEventsUnit *unit, unsigned int ID);

/**
 * initOp function
 */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_initOpBlockProd(DSPECoprocUnit *unit, DSPEOp *op);

/* Earlyalloc function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_earlyAllocBlockProd(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockProd *context);

/* Alloc function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_allocBlockProd(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockProd *context);

/* Earlyconnect function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_earlyConnectBlockProd(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockProd *context);

/* Connect function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_connectBlockProd(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockProd *context);

/* Startup function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_startupBlockProd(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockProd *context);

/* Preprocess function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_preProcessBlockProd(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_processBlockProd(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_postProcessBlockProd(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_resetBlockProd(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockProd *context);

/* Shutdown function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_shutdownBlockProd(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockProd *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
