/**
 * File: RBlock_ParticleTrackerDllBoolGate_StandardGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "MemoryManager.h"

#include "RBlock_ParticleTrackerDllBoolGate_StandardGate.h"

/* Allocate function */
ParticleTrackerDllBoolGate_StandardGate* ParticleTrackerDllBoolGate_StandardGate_allocateBlock(DSPEElement *context, size_t size) {
	return memoryManager_allocate(context, size * sizeof(ParticleTrackerDllBoolGate_StandardGate));
}

/* Initialise function */
void ParticleTrackerDllBoolGate_StandardGate_initializeBlock(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate *place, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllBoolGate_StandardGate_initialize(context, &place[i]);
	}
}

/* SetOverrideBlock function */
void ParticleTrackerDllBoolGate_StandardGate_setOverrideBlock(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate *place, size_t size, ParticleTrackerDllBoolGate_StandardGate value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllBoolGate_StandardGate_setOverride(context, &place[i], value);
	}
}

/* SetBlock function */
void ParticleTrackerDllBoolGate_StandardGate_setBlock(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate *place, size_t size, ParticleTrackerDllBoolGate_StandardGate *value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		place[i] = value[i]; 
	}
}

/* Dispose function */
void ParticleTrackerDllBoolGate_StandardGate_disposeBlock(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate *place) {
	memorySupport_dispose(place);
}

/* AllocateGroup function */
void ParticleTrackerDllBoolGate_StandardGate_allocateGroupBlock(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t groupSize, size_t *gateSize) {
	register size_t i;	
	for (i = 0; i < groupSize; i++) {
	 	place[i] = ParticleTrackerDllBoolGate_StandardGate_allocateBlock(context, gateSize[i]);	
	}
}

/* InitialiseGroup function */
void ParticleTrackerDllBoolGate_StandardGate_initializeGroupBlock(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t groupSize, size_t *gateSize) {
	register size_t i;
	for (i = 0; i < groupSize; i++) {
		ParticleTrackerDllBoolGate_StandardGate_initializeBlock(context, place[i], gateSize[i]);
	}
}

/* SetOverrideGroupBlock function */
void ParticleTrackerDllBoolGate_StandardGate_setOverrideGroupBlock(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllBoolGate_StandardGate value) {
	register size_t i;
	for (i = 0; i < groupSize; i++) {
		ParticleTrackerDllBoolGate_StandardGate_setOverrideBlock(context, place[i], gateSize[i], value);
	}
}

/* SetGroupBlock function */
void ParticleTrackerDllBoolGate_StandardGate_setGroupBlock(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllBoolGate_StandardGate **value) {
	register size_t i;
	for (i = 0; i < groupSize; i++) {
		ParticleTrackerDllBoolGate_StandardGate_setBlock(context, place[i], gateSize[i], value[i]);
	}
}

/* DisposeGroup function */
void ParticleTrackerDllBoolGate_StandardGate_disposeGroupBlock(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	memorySupport_dispose(place[i]);
	}
}

