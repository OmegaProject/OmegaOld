/**
 * File: RBlockProd_ParticleTrackerDllFindThresholdCP_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef RBlockProd_ParticleTrackerDllFindThresholdCP_SoftwareUnit_h
#define RBlockProd_ParticleTrackerDllFindThresholdCP_SoftwareUnit_h

#include "B_ParticleTrackerDllFindThreshold_CoprocImplementation.h"
#include "B_ParticleTrackerDllFindThresholdCP_SoftwareUnit.h"
#include "RBlock_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "RBlock_ParticleTrackerDllPTFilteredGate_MessageGate.h"
#include "RBlock_ParticleTrackerDllPTThresholdGate_MessageGate.h"

/* Block SoftwareUnit state type definition */
typedef struct ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockProd ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockProd;

/* Block SoftwareUnit state definition */
struct ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockProd {

	/* Base unit state */
	ParticleTrackerDllFindThresholdCP_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllFindThreshold_CoprocImplementation implState;
	
	/* Block size */
	size_t blockSize;

	/* Samples to process */
	size_t samplesToProcess;

	/* Data transit queues */
	size_t dataIn_PTFiltered_transitNumElements;
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode *dataIn_PTFiltered_transitHead;
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode *dataIn_PTFiltered_transitTail;
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode *dataIn_PTFiltered_curTransit;
	unsigned int dataIn_PTFiltered_curTransitIndex;

	DSPEEvent *dataOut_PTThreshold_place;
	DSPEEvent *dataOut_PTThreshold_armMarker;

	/* EventPools */
	ParticleTrackerDllPTThresholdGate_MessageGate_poolBlock *dataOut_PTThreshold_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFilteredGate_MessageGate *dataIn_PTFiltered_unlinked;
	ParticleTrackerDllPTFilteredGate_MessageGate *dataIn_PTFiltered_unlinkedAnchor;
	ParticleTrackerDllPTThresholdGate_MessageGate *dataOut_PTThreshold_unlinked;
	ParticleTrackerDllPTThresholdGate_MessageGate *dataOut_PTThreshold_unlinkedAnchor;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;


	/* Data gates sizes */
	size_t dataIn_SequenceValues_size;
	size_t dataOut_PTThreshold_size;


	/* Data gates factors */
	size_t dataIn_SequenceValues_factor;
	size_t dataOut_PTThreshold_factor;


	/* Data gates counters */
	size_t dataIn_SequenceValues_counter;
	size_t dataOut_PTThreshold_counter;


	/* Data gates counters */
	size_t dataOut_PTThreshold_samplesCounter;

	/* Unit profile ID */
	int unitProfileID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_transitEventBlockProd(DSPEQueueUnit *unit);

size_t ParticleTrackerDllFindThresholdCP_SoftwareUnit_getTransitNumElementsBlockProd(DSPEQueueUnit *unit, unsigned int ID);

size_t ParticleTrackerDllFindThresholdCP_SoftwareUnit_getTransitNumElementsBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_getFirstTransitBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_getCurTransitBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_dismissEventBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_dismissAllEventsBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_armEventBlockProd(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_postEventBlockProd(DSPEEventsUnit *unit, unsigned int ID);

/**
 * initOp function
 */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_initOpBlockProd(DSPECoprocUnit *unit, DSPEOp *op);

/* Earlyalloc function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_earlyAllocBlockProd(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockProd *context);

/* Alloc function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_allocBlockProd(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockProd *context);

/* Earlyconnect function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_earlyConnectBlockProd(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockProd *context);

/* Connect function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_connectBlockProd(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockProd *context);

/* Startup function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_startupBlockProd(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockProd *context);

/* Preprocess function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_preProcessBlockProd(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_processBlockProd(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_postProcessBlockProd(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_resetBlockProd(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockProd *context);

/* Shutdown function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_shutdownBlockProd(ParticleTrackerDllFindThresholdCP_SoftwareUnit_blockProd *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
