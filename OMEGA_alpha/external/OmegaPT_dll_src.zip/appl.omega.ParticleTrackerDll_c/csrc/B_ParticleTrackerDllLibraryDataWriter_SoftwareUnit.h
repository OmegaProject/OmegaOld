/**
 * File: B_ParticleTrackerDllLibraryDataWriter_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef B_ParticleTrackerDllLibraryDataWriter_SoftwareUnit_h
#define B_ParticleTrackerDllLibraryDataWriter_SoftwareUnit_h

#include "DSPEElements.h"

#include "B_ParticleTrackerDllNextGate_SignalGate.h"
#include "B_ParticleTrackerDllIntGate_StandardGate.h"

/* Queue node type definition */
typedef struct ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode;

/* Queue node type definition */
struct ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode {
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *next;
	unsigned int ID;
	DSPEEvent *event;
	/* Transit node support */
	short inTransit;
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *nextInTransit;
};

/* State type definition */
typedef struct ParticleTrackerDllLibraryDataWriter_SoftwareUnit ParticleTrackerDllLibraryDataWriter_SoftwareUnit;

/* State definition */ 
struct ParticleTrackerDllLibraryDataWriter_SoftwareUnit {

	DSPEQueueUnit queueUnit;

	unsigned int poolNumNodes;
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *poolHead;
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *poolTail;

	unsigned int queueNumNodes;
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *queueHead;
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *queueTail;

	/* Parameter gates */
	ParticleTrackerDllIntGate_StandardGate *paramIn_FoundTrajectories;
	ParticleTrackerDllIntGate_StandardGate *paramOut_stop;


	/* Output parameters places */
	ParticleTrackerDllIntGate_StandardGate *paramOut_stop_place;

	/* Gates numLinks */
	unsigned int dataIn_Trajectory_numLinks;
	unsigned int paramIn_LastFrameProcessed_numLinks;
	unsigned int paramIn_FoundTrajectories_numLinks;
	unsigned int paramOut_next_numLinks;
	unsigned int paramOut_stop_numLinks;

	/* unit ID */
	char *ID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID);

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_releaseEvent(ParticleTrackerDllLibraryDataWriter_SoftwareUnit *context);

int ParticleTrackerDllLibraryDataWriter_SoftwareUnit_isEventAvailable(const DSPEQueueUnit *unit);

DSPEEvent* ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getEvent(const DSPEQueueUnit *unit);

unsigned int ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getEventID(const DSPEQueueUnit *unit);

/* getID function */
char* ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getID(const DSPEElement *element);

/* Alloc function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_alloc(ParticleTrackerDllLibraryDataWriter_SoftwareUnit *context);

/* Earlyconnect function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_earlyConnect(ParticleTrackerDllLibraryDataWriter_SoftwareUnit *context);

/* Postprocess function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_postProcess(ParticleTrackerDllLibraryDataWriter_SoftwareUnit *context);

/* Reset function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_reset(ParticleTrackerDllLibraryDataWriter_SoftwareUnit *context);

/* Shutdown function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_shutdown(ParticleTrackerDllLibraryDataWriter_SoftwareUnit *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
