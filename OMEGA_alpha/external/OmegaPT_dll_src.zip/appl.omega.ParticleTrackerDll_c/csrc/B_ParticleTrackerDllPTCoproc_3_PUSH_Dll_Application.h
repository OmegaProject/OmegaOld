/**
 * File: B_ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef B_ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_h
#define B_ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_h

#include "DSPEElements.h"

#include "B_ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler.h"
#include "B_ParticleTrackerDllIntGate_StandardGate.h"
#include "B_ParticleTrackerDllRealGate_CustomGate.h"
#include "B_ParticleTrackerDllStatusGate_StringGate.h"
#include "B_ParticleTrackerDllBoolGate_StandardGate.h"

/* Parameter rates */
#define PARTICLETRACKERDLLPTCOPROC_3_PUSH_DLL_APPLICATION_PARAMETERSINPUTRATE 1
#define PARTICLETRACKERDLLPTCOPROC_3_PUSH_DLL_APPLICATION_PARAMETERSOUTPUTRATE 1

/* Update rate */
#define PARTICLETRACKERDLLPTCOPROC_3_PUSH_DLL_APPLICATION_UPDATERATE 1

/* State type definition */
typedef struct ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application;

/* State definition */ 
struct ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application {

	DSPEApplication application;

	/* Contained configuration */
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler configuration;

	/* Parameter gates */
	ParticleTrackerDllIntGate_StandardGate *paramIn_Radius;
	ParticleTrackerDllRealGate_CustomGate *paramIn_Cutoff;
	ParticleTrackerDllRealGate_CustomGate *paramIn_Percentile;
	ParticleTrackerDllRealGate_CustomGate *paramIn_Displacement;
	ParticleTrackerDllIntGate_StandardGate *paramIn_Linkrange;
	ParticleTrackerDllIntGate_StandardGate *paramIn_ImgsNum;
	ParticleTrackerDllIntGate_StandardGate *paramIn_ImgWidth;
	ParticleTrackerDllIntGate_StandardGate *paramIn_ImgHeight;
	ParticleTrackerDllRealGate_CustomGate *paramIn_ImgMin;
	ParticleTrackerDllRealGate_CustomGate *paramIn_ImgMax;
	ParticleTrackerDllStatusGate_StringGate *paramOut_DataReader_status;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Convolve_status;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Dilate_status;
	ParticleTrackerDllStatusGate_StringGate *paramOut_FindThreshold_status;
	ParticleTrackerDllStatusGate_StringGate *paramOut_FindParticles_status;
	ParticleTrackerDllStatusGate_StringGate *paramOut_PositionRefinement_status;
	ParticleTrackerDllStatusGate_StringGate *paramOut_ParticlesDiscrimination_status;
	ParticleTrackerDllStatusGate_StringGate *paramOut_LinkParticles_status;
	ParticleTrackerDllStatusGate_StringGate *paramOut_GenerateTrajectories_status;


	/* Contained configuration unlinked input parameter gates initialization */
	ParticleTrackerDllBoolGate_StandardGate *GenerateTrajectoriesStateCPAutoNextNew_PUSH_paramIn_Verbose_unlinked;


	/* Application input parameter gates places */
	ParticleTrackerDllIntGate_StandardGate *paramIn_Radius_place;
	ParticleTrackerDllRealGate_CustomGate *paramIn_Cutoff_place;
	ParticleTrackerDllRealGate_CustomGate *paramIn_Percentile_place;
	ParticleTrackerDllRealGate_CustomGate *paramIn_Displacement_place;
	ParticleTrackerDllIntGate_StandardGate *paramIn_Linkrange_place;
	ParticleTrackerDllIntGate_StandardGate *paramIn_ImgsNum_place;
	ParticleTrackerDllIntGate_StandardGate *paramIn_ImgWidth_place;
	ParticleTrackerDllIntGate_StandardGate *paramIn_ImgHeight_place;
	ParticleTrackerDllRealGate_CustomGate *paramIn_ImgMin_place;
	ParticleTrackerDllRealGate_CustomGate *paramIn_ImgMax_place;

	/* unit ID */
	char *ID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

/* getID function */
char* ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_getID(const DSPEElement *element);

/* Earlyalloc function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_earlyAlloc(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *context);

/* Alloc function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_alloc(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *context);

/* Earlyconnect function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_earlyConnect(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *context);

/* Connect function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_connect(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *context);

/* Startup function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_startup(DSPEApplication *application);

/* Preprocess function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_preProcess(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_process(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_postProcess(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_reset(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *context);

/* Shutdown function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_shutdown(DSPEApplication *application);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
