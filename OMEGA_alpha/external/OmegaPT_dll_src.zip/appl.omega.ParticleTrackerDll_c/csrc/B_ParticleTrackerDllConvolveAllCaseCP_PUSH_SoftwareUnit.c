/**
 * File: B_ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit.c
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#include "PlatformManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "EngineManager.h"

#include "B_ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit.h"

#define pIn_next_event 1000
#define dIn_PTFrame_event 1001

#define pOut_next_event 1000
#define dOut_PTFrame_event 1001
#define dOut_PTFiltered_event 1002

static INLINE void initQueue(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *unit) {
	unit->poolNumNodes = 0;
	unit->poolHead = NULL;
	unit->poolTail = NULL;

	unit->queueNumNodes = 0;
	unit->queueHead = NULL;
	unit->queueTail = NULL;

}

static INLINE void resetQueue(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *unit) {
	// REMARK: avoid calling the installed release function because of possible
	// overriding implementations. Just need to release the event here.
	// TODO non esistono piu versioni sovrascritte!!
	while (unit->queueNumNodes != 0)
		ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_releaseEvent(unit);
}

static INLINE void disposeQueue(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *unit) {
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueNode *node = unit->poolHead;
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueNode *tmp = NULL;

	/* Dispose queueNodes in pool */
	while (node != NULL) {
		tmp = node->next;
		node->next = NULL;
		memorySupport_dispose(node);
		node = tmp;
	}
}

void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID) {
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *context = (ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit*) unit;
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueNode *node = NULL;
	
	switch (context->poolNumNodes) {
	case 0:
		node = (ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueNode*) memoryManager_allocate((DSPEElement*) context, sizeof(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueNode));
		node->nextInTransit = NULL;
		break;
	case 1:
		node = context->poolHead;
		context->poolHead = NULL;
		context->poolTail = NULL;
		context->poolNumNodes = 0;
		break;
	default:
		node = context->poolHead;
		context->poolHead = node->next;
		context->poolNumNodes--;
		break;
	}

	node->next = NULL;
	node->ID = ID;
	node->event = event;
	event->refCount++;

	if (context->queueNumNodes == 0) {
		context->queueHead = node;
		context->queueTail = node;
		context->queueNumNodes = 1;
	} else {
		context->queueTail->next = node;
		context->queueTail = node;
		context->queueNumNodes++;
	}
	node->inTransit = 0;
}

void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_releaseEvent(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *context) {
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueNode *node = context->queueHead;
	DSPEEvent *event = NULL;
	
	switch (context->queueNumNodes) {
	case 0:
		/* No events in queue */
		// REMARK: this could happen if we have idleTimeSequence and we want to re-schedule a unit
		return;
	case 1:
		context->queueHead = NULL;
		context->queueTail = NULL;
		context->queueNumNodes = 0;
		break;
	default:
		context->queueHead = node->next;
		context->queueNumNodes--;
		break;
	}

	node->next = NULL;

	/* REMARK:
	 * If node is in transit avoid disposing event and putting the node 
	 * back to pool. This will happen when user calls dismiss function 
	 */
	if (node->inTransit == 1)
		return;
	
	event = node->event;
	event->dispose(event);
	node->event = NULL;
	node->ID = 0;

	if (context->poolNumNodes == 0) {
		context->poolHead = node;
		context->poolTail = node;
		context->poolNumNodes = 1;
	} else {
		context->poolTail->next = node;
		context->poolTail = node;
		context->poolNumNodes++;
	}
}

int ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_isEventAvailable(const DSPEQueueUnit *unit) {
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *context = (ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit*) unit;
	return context->queueNumNodes != 0;
}

DSPEEvent* ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_getEvent(const DSPEQueueUnit *unit) {
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *context = (ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit*) unit;
	return context->queueHead->event;
}

unsigned int ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_getEventID(const DSPEQueueUnit *unit) {
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *context = (ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit*) unit;
	return context->queueHead->ID;
}

/* getID function */
char* ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_getID(const DSPEElement *element) {
	return ((const ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit*) element)->ID;
}

/* Initialize gate values */
static INLINE void initValues(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *context) {
	/* Parameter Output gates initializazion */
	ParticleTrackerDllIntGate_StandardGate_initialize((DSPEElement*) context, context->paramOut_stop_place);
	ParticleTrackerDllStatusGate_StringGate_initManaged((DSPEElement*) context, *context->paramOut_Status_placeAnchor);
	ParticleTrackerDllStatusGate_StringGate_set((DSPEElement*) context, context->paramOut_Status_place, context->paramOut_Status_placeAnchor);
}

/* Alloc function */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_alloc(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *context) {
	((DSPEElement*) context)->getID = ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_getID;
	initQueue(context);

	((DSPEEventsUnit*) context)->queueEvent = ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueEvent;
	((DSPEQueueUnit*) context)->isEventAvailable = ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_isEventAvailable;
	((DSPEQueueUnit*) context)->getEventID = ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_getEventID;
	((DSPEQueueUnit*) context)->getEvent = ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_getEvent;

	/* Output parameters places allocation */
	context->paramOut_stop_place = ParticleTrackerDllIntGate_StandardGate_allocate((DSPEElement*) context);
	context->paramOut_Status_place = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);

	/* Places anchors allocation */
	context->paramOut_Status_placeAnchor = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);

	/* Places anchors allocation */
	ParticleTrackerDllStatusGate_StringGate_allocateManaged((DSPEElement*) context, context->paramOut_Status_placeAnchor);

	/* Initialize gate values */
	initValues(context);
}

/* Earlyconnect function */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_earlyConnect(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *context) {
	/* Gates numLinks initialization */
	context->dataIn_SequenceValues_numLinks = 0;
	context->dataIn_PTFrame_numLinks = 0;
	context->dataOut_PTFrame_numLinks = 0;
	context->dataOut_PTFiltered_numLinks = 0;
	context->paramIn_next_numLinks = 0;
	context->paramIn_stop_numLinks = 0;
	context->paramIn_Radius_numLinks = 0;
	context->paramOut_next_numLinks = 0;
	context->paramOut_stop_numLinks = 0;
	context->paramOut_Status_numLinks = 0;


	/* Output parameters gates initialization */
	context->paramOut_stop = context->paramOut_stop_place;
	context->paramOut_Status = context->paramOut_Status_place;

}


/* Postprocess function
 * Remark: this function is not installed as pointer to function because it will be called
 * from either RealUnit's postProcess or BlockUnit's postProcess function.
 */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_postProcess(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *context) {
	resetQueue(context);

}

/* Reset function */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_reset(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *context) {
	/* Initialize gate values */
	initValues(context);
}

/* Shutdown function */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_shutdown(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *context) {
	disposeQueue(context);

	/* Output parameters places dispose */
	ParticleTrackerDllIntGate_StandardGate_dispose((DSPEElement*) context, context->paramOut_stop_place);
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_Status_place);


	/* Places anchors memory dispose */
	ParticleTrackerDllStatusGate_StringGate_disposeManaged((DSPEElement*) context, *context->paramOut_Status_placeAnchor);


	/* Places anchors memory dispose */
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_Status_placeAnchor);

	/* UnitID dispose */
	memorySupport_dispose(context->ID);
}

