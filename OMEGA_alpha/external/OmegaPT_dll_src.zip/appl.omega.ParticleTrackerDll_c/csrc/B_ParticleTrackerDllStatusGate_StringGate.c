/**
 * File: B_ParticleTrackerDllStatusGate_StringGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "StringManager.h"
#include "MemoryManager.h"

#include "B_ParticleTrackerDllStatusGate_StringGate.h"

/* AllocateValue function */
ParticleTrackerDllStatusGate_StringGate ParticleTrackerDllStatusGate_StringGate_allocateValue(DSPEElement *context) {
	return memoryManager_allocate(context, PARTICLETRACKERDLLSTATUSGATE_STRINGGATE_MAXIMUMSIZE + 1);
}
/* InitValue function */
void ParticleTrackerDllStatusGate_StringGate_initValue(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate anchor) {
	stringSupport_copy(anchor, PARTICLETRACKERDLLSTATUSGATE_STRINGGATE_DEFAULTVALUE);
}

/* CopyValue function */
void ParticleTrackerDllStatusGate_StringGate_copyValue(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate destination, ParticleTrackerDllStatusGate_StringGate source) {
	stringSupport_copy(destination, source);
}

/* CompareValue function */
int ParticleTrackerDllStatusGate_StringGate_compareValue(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate first, ParticleTrackerDllStatusGate_StringGate second) {
	return stringSupport_compare(first, second);
}

/* DisposeValue function */
void ParticleTrackerDllStatusGate_StringGate_disposeValue(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate anchor) {
	memorySupport_dispose(anchor);
}

/* AllocateManaged function */
void ParticleTrackerDllStatusGate_StringGate_allocateManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *anchor) {
	*anchor = ParticleTrackerDllStatusGate_StringGate_allocateValue(context);
}
/* InitManaged function */
void ParticleTrackerDllStatusGate_StringGate_initManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate anchor) {
	ParticleTrackerDllStatusGate_StringGate_initValue(context, anchor);
}

/* DisposeManaged function */
void ParticleTrackerDllStatusGate_StringGate_disposeManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate anchor) {
	ParticleTrackerDllStatusGate_StringGate_disposeValue(context, anchor);
}

/* AllocateGroupManaged function */
void ParticleTrackerDllStatusGate_StringGate_allocateGroupManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **anchor, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllStatusGate_StringGate_allocateManaged(context, anchor[i]);
	}
}
/* InitGroupManaged function */
void ParticleTrackerDllStatusGate_StringGate_initGroupManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **anchor, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllStatusGate_StringGate_initValue(context, *anchor[i]);
	}
}

/* DisposeGroupManaged function */
void ParticleTrackerDllStatusGate_StringGate_disposeGroupManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **anchor, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllStatusGate_StringGate_disposeValue(context, *anchor[i]);
	}
}

/* Allocate function */
ParticleTrackerDllStatusGate_StringGate* ParticleTrackerDllStatusGate_StringGate_allocate(DSPEElement *context) {
	return memoryManager_allocate(context, sizeof(ParticleTrackerDllStatusGate_StringGate));
}

/* Initialise function */
void ParticleTrackerDllStatusGate_StringGate_initialize(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *place) {
	stringSupport_copy(*place, PARTICLETRACKERDLLSTATUSGATE_STRINGGATE_DEFAULTVALUE);
}

/* SetOverride function */
void ParticleTrackerDllStatusGate_StringGate_setOverride(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *place, ParticleTrackerDllStatusGate_StringGate value) {
	stringSupport_copy(*place, value);
}

/* Set function */
void ParticleTrackerDllStatusGate_StringGate_set(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *place, ParticleTrackerDllStatusGate_StringGate *value) {
	*place = *value;
}

/* Dispose function */
void ParticleTrackerDllStatusGate_StringGate_dispose(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *place) {
	memorySupport_dispose(place);
}

/* AllocateGroup function */
void ParticleTrackerDllStatusGate_StringGate_allocateGroup(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	place[i] = ParticleTrackerDllStatusGate_StringGate_allocate(context);
	}
}

/* InitialiseGroup function */
void ParticleTrackerDllStatusGate_StringGate_initializeGroup(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
	 	ParticleTrackerDllStatusGate_StringGate_initialize(context, place[i]);
	}
}

/* SetOverrideGroup function */
void ParticleTrackerDllStatusGate_StringGate_setOverrideGroup(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t size, ParticleTrackerDllStatusGate_StringGate value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllStatusGate_StringGate_setOverride(context, place[i], value);
	}
}

/* SetGroup function */
void ParticleTrackerDllStatusGate_StringGate_setGroup(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t size, ParticleTrackerDllStatusGate_StringGate **value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllStatusGate_StringGate_set(context, place[i], value[i]);
	}
}

/* DisposeGroup function */
void ParticleTrackerDllStatusGate_StringGate_disposeGroup(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	memorySupport_dispose(place[i]);
	}
}

/* CreateNode function */
ParticleTrackerDllStatusGate_StringGate_node* ParticleTrackerDllStatusGate_StringGate_createNode(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *gate, ParticleTrackerDllStatusGate_StringGate *localVar) {
	ParticleTrackerDllStatusGate_StringGate_node *node = (ParticleTrackerDllStatusGate_StringGate_node*) memoryManager_allocate(context, sizeof(ParticleTrackerDllStatusGate_StringGate_node));
	initDSPEGateNode((DSPEGateNode*) node);
	node->gate = gate;
	if (gate != 0)
		node->gateAnchor = *node->gate;
	else
		node->gateAnchor = 0;
	node->localVar = localVar;
	if (localVar != 0)
		node->localVarAnchor = *node->localVar;
	else
		node->localVarAnchor = 0;
	node->value = ParticleTrackerDllStatusGate_StringGate_allocate(context);
	ParticleTrackerDllStatusGate_StringGate_allocateManaged(context, node->value);
	ParticleTrackerDllStatusGate_StringGate_initialize(context, node->value);
	node->valueAnchor = *node->value;
	((DSPEGateNode*) node)->setValue = ParticleTrackerDllStatusGate_StringGate_setValue;
	((DSPEGateNode*) node)->disposeNode = ParticleTrackerDllStatusGate_StringGate_disposeNode;
	return node;
}

/* DisposeNode function */
void ParticleTrackerDllStatusGate_StringGate_disposeNode(DSPEElement *context, DSPEGateNode *node) {
	ParticleTrackerDllStatusGate_StringGate_node *tmpNode = (ParticleTrackerDllStatusGate_StringGate_node*) node;
	node->next = NULL;
	//ParticleTrackerDllStatusGate_StringGate_destroy(tmpNode->valueAnchor);
	ParticleTrackerDllStatusGate_StringGate_disposeManaged(context, *tmpNode->value);
	ParticleTrackerDllStatusGate_StringGate_dispose(context, tmpNode->value);
	memorySupport_dispose(tmpNode);
}

/* SetValue function */
void ParticleTrackerDllStatusGate_StringGate_setValue(DSPEElement *context, DSPEGateNode *node) {
	ParticleTrackerDllStatusGate_StringGate_node *tmpNode = (ParticleTrackerDllStatusGate_StringGate_node*) node;
	if (tmpNode->gate != 0) {
		if (*tmpNode->value != 0) {
			*tmpNode->gate = tmpNode->gateAnchor;
			stringSupport_copy(*tmpNode->gate, *tmpNode->value);
		} else
			*tmpNode->gate = 0;
	}
	if (tmpNode->localVar != 0) {
		if (*tmpNode->value != 0) {
			*tmpNode->localVar = tmpNode->localVarAnchor;
			stringSupport_copy(*tmpNode->localVar, *tmpNode->value);
		} else
			*tmpNode->localVar = 0;
	}
}

