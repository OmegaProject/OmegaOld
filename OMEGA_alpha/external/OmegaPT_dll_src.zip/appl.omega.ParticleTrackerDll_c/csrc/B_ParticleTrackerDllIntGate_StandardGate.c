/**
 * File: B_ParticleTrackerDllIntGate_StandardGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "MemoryManager.h"

#include "B_ParticleTrackerDllIntGate_StandardGate.h"

/* Allocate function */
ParticleTrackerDllIntGate_StandardGate* ParticleTrackerDllIntGate_StandardGate_allocate(DSPEElement *context) {
	return memoryManager_allocate(context, sizeof(ParticleTrackerDllIntGate_StandardGate));
}

/* Initialise function */
void ParticleTrackerDllIntGate_StandardGate_initialize(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate *place) {
	*place = PARTICLETRACKERDLLINTGATE_STANDARDGATE_DEFAULTVALUE;
}

/* Set function */
void ParticleTrackerDllIntGate_StandardGate_setOverride(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate *place, ParticleTrackerDllIntGate_StandardGate value) {
	*place = value;
}

/* Set function */
void ParticleTrackerDllIntGate_StandardGate_set(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate *place, ParticleTrackerDllIntGate_StandardGate *value) {
	*place = *value;
}

/* Dispose function */
void ParticleTrackerDllIntGate_StandardGate_dispose(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate *place) {
	memorySupport_dispose(place);
}

/* AllocateGroup function */
void ParticleTrackerDllIntGate_StandardGate_allocateGroup(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	place[i] = ParticleTrackerDllIntGate_StandardGate_allocate(context);
	}
}

/* InitialiseGroup function */
void ParticleTrackerDllIntGate_StandardGate_initializeGroup(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
	 	ParticleTrackerDllIntGate_StandardGate_initialize(context, place[i]);
	}
}

/* SetOverrideGroup function */
void ParticleTrackerDllIntGate_StandardGate_setOverrideGroup(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t size, ParticleTrackerDllIntGate_StandardGate value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllIntGate_StandardGate_setOverride(context, place[i], value);
	}
}

/* SetGroup function */
void ParticleTrackerDllIntGate_StandardGate_setGroup(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t size, ParticleTrackerDllIntGate_StandardGate **value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllIntGate_StandardGate_set(context, place[i], value[i]);
	}
}

/* DisposeGroup function */
void ParticleTrackerDllIntGate_StandardGate_disposeGroup(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	memorySupport_dispose(place[i]);
	}
}

/* CreateNode function */
ParticleTrackerDllIntGate_StandardGate_node* ParticleTrackerDllIntGate_StandardGate_createNode(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate *gate, ParticleTrackerDllIntGate_StandardGate *localVar) {
	ParticleTrackerDllIntGate_StandardGate_node *node = (ParticleTrackerDllIntGate_StandardGate_node*) memoryManager_allocate(context, sizeof(ParticleTrackerDllIntGate_StandardGate_node));
	initDSPEGateNode((DSPEGateNode*) node);
	node->gate = gate;
	node->localVar = localVar;
	((DSPEGateNode*) node)->setValue = ParticleTrackerDllIntGate_StandardGate_setValue;
	((DSPEGateNode*) node)->disposeNode = ParticleTrackerDllIntGate_StandardGate_disposeNode;
	return node;
}

/* DisposeNode function */
void ParticleTrackerDllIntGate_StandardGate_disposeNode(DSPEElement *context, DSPEGateNode *node) {
	node->next = NULL;
	memorySupport_dispose(node);
}

/* SetValue function */
void ParticleTrackerDllIntGate_StandardGate_setValue(DSPEElement *context, DSPEGateNode *node) {
	ParticleTrackerDllIntGate_StandardGate_node *tmpNode = (ParticleTrackerDllIntGate_StandardGate_node*) node;
	if (tmpNode->gate != 0)
		*tmpNode->gate = tmpNode->value;
	if (tmpNode->localVar != 0)
		*tmpNode->localVar = tmpNode->value;
}

