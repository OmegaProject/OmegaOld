/**
 * File: B_ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef B_ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_h
#define B_ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_h

#include "CoprocGround.h"
#include "DSPEXTElements.h"

#include "B_ParticleTrackerDllMaskGate_PointerGate.h"
#include "B_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "B_ParticleTrackerDllPTFrameGate_MessageGate.h"
#include "B_ParticleTrackerDllNextGate_SignalGate.h"
#include "B_ParticleTrackerDllIntGate_StandardGate.h"
#include "B_ParticleTrackerDllStatusGate_StringGate.h"

/* Coproc persistent state type definition */
typedef struct ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_persistent ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_persistent;

/* This struct may contain user defined persistent state variables */
struct ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_persistent {
	//Place persistent state variables after this line -- SYD-PERSISTENT-STATE-START
	int kernelWidth;
	//SYD-PERSISTENT-STATE-END  -- Place persistent state variables before this line
};

/* Coproc Operation type definition */
typedef struct ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_op ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_op;

/* This struct may contain user defined additional state variables */
struct ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_op {

	DSPEProfileCoprocOp coprocOp;

	/* BlockSize */
	size_t blockSize;

	/* CoprocOp Buffer support */
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_op *next;
	unsigned int processed;

	/* Coproc persistent state */
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_persistent *persistent;

	//Place additional state variables after this line -- SYD-ADDITIONAL-STATE-START
	//SYD-ADDITIONAL-STATE-END  -- Place additional state variables before this line


	/* Transfered Data gates */
	ParticleTrackerDllMaskGate_PointerGate *dataIn_Mask;
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame;


	/* Transfered Parameter gates */
	ParticleTrackerDllIntGate_StandardGate *paramIn_Radius;
	ParticleTrackerDllIntGate_StandardGate *paramOut_stop;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status;

};



/* Functional implementation state type definition */
typedef struct ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_func ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_func;

/* This struct may contain user defined additional state variables for the unit */
struct ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_func {

	DSPECoprocImplementation coprocImplementation;

	//Place local state variables after this line -- SYD-LOCAL-STATE-START
	int particleCounter;
	//SYD-LOCAL-STATE-END  -- Place local state variables before this line
};

/******************************************************************************
 * FOLLOWING CODE IS NOT INTENDED TO BE MODIFIED BY USERS                     *
 ******************************************************************************/

/* State type definition */
typedef struct ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation;

/* State definition */ 
struct ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation {

	/* Functional implementation state */
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_func functionalState;

	/* Current working op state var */
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_op *curOp;

	DSPEOpInQueue *opQueue;

	/* Coproc permanent state */
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_persistent* persistent;


	/* Data gates */
	ParticleTrackerDllMaskGate_PointerGate *dataIn_Mask;
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame;

	/* Parameter gates */
	ParticleTrackerDllIntGate_StandardGate *paramIn_stop;
	ParticleTrackerDllIntGate_StandardGate *paramIn_Radius;
	ParticleTrackerDllIntGate_StandardGate *paramOut_stop;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status;


	/* numLinks flags */
	unsigned int dataIn_Mask_numLinks;
	unsigned int dataIn_SequenceValues_numLinks;
	unsigned int dataIn_PTFrame_numLinks;
	unsigned int dataOut_PTFrame_numLinks;
	unsigned int paramIn_next_numLinks;
	unsigned int paramIn_stop_numLinks;
	unsigned int paramIn_Radius_numLinks;
	unsigned int paramOut_next_numLinks;
	unsigned int paramOut_stop_numLinks;
	unsigned int paramOut_Status_numLinks;

	/* State */
	unsigned int state;

	/* opBuffer support */
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_op *opPoolHead;
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_op *opPoolTail;
	size_t opPoolNumElements;
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_op *opBufferHead;
	ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_op *opBufferTail;
	size_t opBufferNumElements;

	unsigned int waitingOutNext;
	unsigned int stopOutNext;
	unsigned int opsBusy;
	unsigned int waitingInNext;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

/* Preprocess function */
void ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_preProcess(ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *context);

/**
 * ArmOp function
 */
void ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_armOp(ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *context);

/* Process function */
void ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_process(ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_op *context);

/**
 * DismissOp function
 */
void ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation_dismissOp(ParticleTrackerDllPositionRefinment_PUSH_2_CoprocImplementation *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
