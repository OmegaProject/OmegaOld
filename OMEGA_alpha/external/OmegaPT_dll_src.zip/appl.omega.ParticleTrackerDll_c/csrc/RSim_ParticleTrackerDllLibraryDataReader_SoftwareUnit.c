/**
 * File: RSim_ParticleTrackerDllLibraryDataReader_SoftwareUnit.c
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#include "PlatformManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "EngineManager.h"
#include "ErrorManager.h"

#include "RSim_ParticleTrackerDllLibraryDataReader_SoftwareUnit.h"

#define PENDING_EVENTS_MAX 10

/* NoEvent ID */
#define NOEVENT 10

#define pIn_sourceNext_event 1000
#define pIn_next_event 1001

#define pOut_next_event 1000
#define dOut_PTFrame_event 1001

/******************************************************************************
 * PENDING EVENTS SUPPORT FUNCTIONS
 ******************************************************************************/

/* hasPendingEvents function */
static INLINE int hasPendingEvents(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context) {
	if (context->implState.dataOut_PTFrame_numLinks > 0 &&
		context->dataOut_PTFrame_pendingEvents == 0)
		return 0;
	return 1;
}

/* pendingEvents_aboveMaxThreshold function
 * Returns true if at least one pendingEvents counter is found that passes PENDING_EVENTS_MAX value
 */
static INLINE int pendingEvents_aboveMaxThreshold(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context) {
	return 	context->dataOut_PTFrame_pendingEvents > PENDING_EVENTS_MAX;
}

// TODO
// gate_sendEvent functions are generated only if pendingEvents support is needed.
// Consider refactoring postEvent and eventually armEvent functions so that the send functionality 
// is always available to the user enabling the soCalled 'immediate send' which may override the postEvent
// function call and send the event immediately through gate_sendEvent.
// This refactoring should also consider possible enhancements to gates like installing function pointers
// on gates to arm/post or sendImmediate events. ((DSPEEventGate*) gate)->armEvent((DSPEEventGate*) gate);

static INLINE void dataOut_PTFrame_sendEvent(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context) {
	unsigned int ID = 0;
	DSPEEventsUnit *unit = (DSPEEventsUnit*) context;
	DSPEEvent *event = NULL;

		/* Decrement pendingEvents counter for gate */
		if (context->dataOut_PTFrame_pendingEvents > 0)
			context->dataOut_PTFrame_pendingEvents--;
		/* Set ID for current gate */
		ID = dOut_PTFrame_event;
		event = context->dataOut_PTFrame_place;
		if (event == NULL)
			return;
		context->dataOut_PTFrame_place = event->next;
		if (context->dataOut_PTFrame_armMarker == event || context->dataOut_PTFrame_place == NULL)
			context->dataOut_PTFrame_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
}

/******************************************************************************
 * NEXT EVENT SUPPORT FUNCTIONS
 ******************************************************************************/

/* input next handler function */
static INLINE void handleIncomingNextRequest(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context) {
	ParticleTrackerDllLibraryDataReader_StateImplementation *implState = &context->implState;
	/* If not stop requested */
	if (*((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_stop == 0) {
		/* Send all available results */
		while (hasPendingEvents(context)) {
			dataOut_PTFrame_sendEvent(context);
		}
	}
	//REMARK:
	// else ignore next request. There will be sent at least one more next request
	// as soon as receiving unit unlocks the stop.
}

/******************************************************************************
 * GATE AUTOMATION SUPPORT FUNCTIONS
 ******************************************************************************/

/******************************************************************************
 * EVENT SUPPORT FUNCTIONS
 ******************************************************************************/

static INLINE void resetEventPlaces(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context) {
	DSPEEvent *event = NULL;
	context->paramOut_next_armMarker = NULL;
	
	while (context->paramOut_next_place != NULL) {
		event = (DSPEEvent*) context->paramOut_next_place;
		context->paramOut_next_place = event->next;
		/* force disposal */
		event->refCount = 1;
		event->dispose(event);
	}
	context->dataOut_PTFrame_armMarker = NULL;
	
	while (context->dataOut_PTFrame_place != NULL) {
		event = (DSPEEvent*) context->dataOut_PTFrame_place;
		context->dataOut_PTFrame_place = event->next;
		/* force disposal */
		event->refCount = 1;
		event->dispose(event);
	}
}

void ParticleTrackerDllLibraryDataReader_SoftwareUnit_armEventRealSim(DSPEEventsUnit *unit, unsigned int ID) {
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context = (ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim*) unit;
	ParticleTrackerDllLibraryDataReader_StateImplementation *implState = &context->implState;

	DSPEEvent *event = NULL;
	DSPEEvent *insert = NULL;

	switch (ID) {
	case pOut_next_event:
		/* If gate is unlinked no event will be sent. Avoid creating event */
		if (implState->paramOut_next_numLinks == 0)
			return;
		insert = context->paramOut_next_armMarker;
		event = (DSPEEvent*) ParticleTrackerDllNextGate_SignalGate_allocate(context->paramOut_next_pool);
		event->refCount = 1;
		if (insert == NULL)
			context->paramOut_next_place = event;
		else
			insert->next = event;
		context->paramOut_next_armMarker = event;
		break;
	case dOut_PTFrame_event:
		/* If gate is unlinked no event will be sent. Avoid creating event */
		if (implState->dataOut_PTFrame_numLinks == 0)
			return;
		insert = context->dataOut_PTFrame_armMarker;
		event = (DSPEEvent*) ParticleTrackerDllPTFrameGate_MessageGate_allocate(context->dataOut_PTFrame_pool);
		event->refCount = 1;
		if (insert == NULL)
			context->dataOut_PTFrame_place = event;
		else
			insert->next = event;
		context->dataOut_PTFrame_armMarker = event;
		/* Set implementation pointer */
		implState->dataOut_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value;
		break;
	}
}

/* RealUnit Post Function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_postEventRealSim(DSPEEventsUnit *unit, unsigned int ID) {
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context = (ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim*) unit;
	ParticleTrackerDllLibraryDataReader_StateImplementation *implState = &context->implState;
	DSPEEvent *event = NULL;

	switch (ID) {
	case pOut_next_event:
		/* If gate is unlinked no event will be sent */
		if (implState->paramOut_next_numLinks == 0)
			return;
		event = context->paramOut_next_place;
		if (event == NULL)
			return;
		context->paramOut_next_place = event->next;
		if (context->paramOut_next_place == NULL)
			context->paramOut_next_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
		break;
	case dOut_PTFrame_event:
		/* If gate is unlinked no event will be sent */
		if (implState->dataOut_PTFrame_numLinks == 0)
			return;
		/* Restore save place to write */
		implState->dataOut_PTFrame = context->dataOut_PTFrame_unlinked;
		// Push pendingEvents support. If stop requested start collecting events instead of sending them
		// if pendingEvents available: we cannot send current data because there is other data to be sent before. Wait inputNext request to empty pending events
		// if stop requested: unit will send next to request all collected data!
		if (hasPendingEvents(context) ||
			*((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_stop == 1) {
			// Start collecting events. Incrementing pendingEvents counter and returning.
			// Event will be sent when inputEvent arrives
			context->dataOut_PTFrame_pendingEvents++;
			return;
		}
		event = context->dataOut_PTFrame_place;
		if (event == NULL)
			return;
		context->dataOut_PTFrame_place = event->next;
		if (context->dataOut_PTFrame_armMarker == event || context->dataOut_PTFrame_place == NULL)
			context->dataOut_PTFrame_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
		break;
	}

}

/* Initialize gate values */
static INLINE void initValues(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllLibraryDataReader_StateImplementation *implState = &context->implState;
	/* Data output places initialization */
	ParticleTrackerDllSequenceValuesGate_PointerGate_initialize((DSPEElement*) context, context->dataOut_SequenceValues_place);

	ParticleTrackerDllPTFrameGate_MessageGate_initializeUnlinked((DSPEElement*) context, context->dataOut_PTFrame_unlinked);
	implState->dataOut_PTFrame = context->dataOut_PTFrame_unlinked;

}

/******************************************************************************
 * COMMON UNIT FUNCTIONS
 ******************************************************************************/

/* Earlyalloc function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_earlyAllocRealSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context) {
	ParticleTrackerDllLibraryDataReader_StateImplementation *implState = &context->implState;

	initDSPEElement((DSPEElement*) &context->implState, (DSPEElement*) context);
	initDSPEQueueUnit((DSPEQueueUnit*) context);
	((DSPEComponent*) context)->preprocess = ParticleTrackerDllLibraryDataReader_SoftwareUnit_preProcessRealSim;
	((DSPEComponent*) context)->process = ParticleTrackerDllLibraryDataReader_SoftwareUnit_processRealSim;
	((DSPEComponent*) context)->postprocess = ParticleTrackerDllLibraryDataReader_SoftwareUnit_postProcessRealSim;
	/* Data pendingEvents initialization */
	context->dataOut_PTFrame_pendingEvents = 0;

	/* Implementation AdditionalStateVariables initialization */
	implState->functionalState.queue = 0;
	implState->functionalState.remainingImgs = 0;
	implState->functionalState.id = 0;
}

/* Alloc function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_allocRealSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context) {
	const DSPEOwner *owner = ((DSPEElement*) context)->owner;

	/* Base alloc() function call */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_alloc(&context->baseState);

	((DSPEEventsUnit*) context)->armEvent = ParticleTrackerDllLibraryDataReader_SoftwareUnit_armEventRealSim;
	((DSPEEventsUnit*) context)->postEvent = ParticleTrackerDllLibraryDataReader_SoftwareUnit_postEventRealSim;
	/* Initializing event Hooks and Inserts */
	context->paramOut_next_place = NULL;
	context->paramOut_next_armMarker = NULL;

	/* Initialize eventPools for parameter gates */
	context->paramOut_next_pool = ParticleTrackerDllNextGate_SignalGate_initPool(owner);

	/* Initializing event Hooks and Inserts */
	context->dataOut_PTFrame_place = NULL;
	context->dataOut_PTFrame_armMarker = NULL;

	/* Initialize eventPools for data gates */
	context->dataOut_PTFrame_pool = ParticleTrackerDllPTFrameGate_MessageGate_initPool(owner);

	/* Allocate unlinked places for input event gates */
	context->dataOut_PTFrame_unlinked = ParticleTrackerDllPTFrameGate_MessageGate_allocateUnlinked((DSPEElement*) context);


	/* Output data places allocation */
	context->dataOut_SequenceValues_place = ParticleTrackerDllSequenceValuesGate_PointerGate_allocate((DSPEElement*) context);

}

/* Earlyconnect function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_earlyConnectRealSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllLibraryDataReader_StateImplementation *implState = &context->implState;

	/* Implementation output parameters gates initialization */
	implState->paramOut_Status = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramOut_Status_place;


	/* Base earlyconnect() function call */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_earlyConnect(&context->baseState);


	/* Output data gates initialization */
	context->dataOut_SequenceValues = context->dataOut_SequenceValues_place;

}

/* Connect function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_connectRealSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllLibraryDataReader_StateImplementation *implState = &context->implState;

	/* Implementation input parameters gates initialization */
	implState->paramIn_stop = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_stop;
	implState->paramIn_LinkRange = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_LinkRange;
	implState->paramIn_ImgsNum = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgsNum;
	implState->paramIn_ImgWidth = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgWidth;
	implState->paramIn_ImgHeight = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgHeight;
	implState->paramIn_ImgMin = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgMin;
	implState->paramIn_ImgMax = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgMax;

	/* Implementation data gates initialization */
	implState->dataOut_SequenceValues = context->dataOut_SequenceValues;

	/* Implementation gates numLinks initialization */
	implState->dataOut_SequenceValues_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->dataOut_SequenceValues_numLinks;
	implState->dataOut_PTFrame_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->dataOut_PTFrame_numLinks;
	implState->paramIn_sourceNext_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_sourceNext_numLinks;
	implState->paramIn_next_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_next_numLinks;
	implState->paramIn_stop_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_stop_numLinks;
	implState->paramIn_LinkRange_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_LinkRange_numLinks;
	implState->paramIn_ImgsNum_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgsNum_numLinks;
	implState->paramIn_ImgWidth_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgWidth_numLinks;
	implState->paramIn_ImgHeight_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgHeight_numLinks;
	implState->paramIn_ImgMin_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgMin_numLinks;
	implState->paramIn_ImgMax_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgMax_numLinks;
	implState->paramOut_next_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramOut_next_numLinks;
	implState->paramOut_Status_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramOut_Status_numLinks;

}

/* Startup function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_startupRealSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context) {
	/* Initialize gate values */
	initValues(context);



	/* Implementation startup() call */
	ParticleTrackerDllLibraryDataReader_StateImplementation_startup(&context->implState);

}

/* Preprocess function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_preProcessRealSim(DSPEComponent *component) {
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context = (ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim*) component;

	/* Implementation preprocess() call */
	ParticleTrackerDllLibraryDataReader_StateImplementation_preProcess(&context->implState);

}

/* Process function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_processRealSim(DSPEComponent *component) {
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context = (ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim*) component;
	/* Implementation state local variable initialization */
	ParticleTrackerDllLibraryDataReader_StateImplementation *implState = &context->implState;
	const unsigned int ID = (((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->queueNumNodes == 0) ? NOEVENT : ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->queueHead->ID;

	/* Push support: send all pending events if available */
	if (*((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_stop == 0) {
		while (hasPendingEvents(context)) {		
			dataOut_PTFrame_sendEvent(context);
		}
	}
	/* Switch input event ID */
	switch (ID) {
	case pIn_next_event:
		handleIncomingNextRequest(context);
		break;
	}
	/* Implementation process() call */
	ParticleTrackerDllLibraryDataReader_StateImplementation_process(implState);

	/* input next push support */
	if (*((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_stop == 1) {
	}
	/* Release event */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_releaseEvent((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context);
}

/* Postprocess function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_postProcessRealSim(DSPEComponent *component) {
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context = (ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim*) component;
	/* Implementation postprocess() call */
	ParticleTrackerDllLibraryDataReader_StateImplementation_postProcess(&context->implState);


	/* Move all output events that have been armed but not sent to their related pool */
	resetEventPlaces(context);

	/* Base postprocess() function call */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_postProcess(&context->baseState);
}

/* Reset function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_resetRealSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context) {
	ParticleTrackerDllLibraryDataReader_StateImplementation *implState = &context->implState;

	/* Base reset() function call */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_reset(&context->baseState);

	/* Initialize gate values */
	initValues(context);
	/* Data pendingEvents initialization */
	context->dataOut_PTFrame_pendingEvents = 0;

	/* Implementation AdditionalStateVariables initialization */
	implState->functionalState.remainingImgs = 0;
	implState->functionalState.id = 0;
}

/* Shutdown function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_shutdownRealSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_realSim *context) {
	/* Implementation shutdown() call */
	ParticleTrackerDllLibraryDataReader_StateImplementation_shutdown(&context->implState);

	/* Base shutdown() function call */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_shutdown(&context->baseState);


	/* Output data places dispose */
	ParticleTrackerDllSequenceValuesGate_PointerGate_dispose((DSPEElement*) context, context->dataOut_SequenceValues_place);

	/* Dispose unlinked places for input event gates */
	ParticleTrackerDllPTFrameGate_MessageGate_disposeUnlinked((DSPEElement*) context, context->dataOut_PTFrame_unlinked);

}

