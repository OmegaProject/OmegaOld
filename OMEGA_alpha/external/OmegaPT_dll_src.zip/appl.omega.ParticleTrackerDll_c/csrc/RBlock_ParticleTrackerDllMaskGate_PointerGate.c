/**
 * File: RBlock_ParticleTrackerDllMaskGate_PointerGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#include "MemoryManager.h"

#include "RBlock_ParticleTrackerDllMaskGate_PointerGate.h"

/* Allocate function */
ParticleTrackerDllMaskGate_PointerGate* ParticleTrackerDllMaskGate_PointerGate_allocateBlock(DSPEElement *context, size_t size) {
	return memoryManager_allocate(context, size * sizeof(ParticleTrackerDllMaskGate_PointerGate));
}

/* Initialise function */
void ParticleTrackerDllMaskGate_PointerGate_initializeBlock(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate *place, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllMaskGate_PointerGate_initialize(context, &place[i]);
	}
}

/* SetOverrideBlock function */
void ParticleTrackerDllMaskGate_PointerGate_setOverrideBlock(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate *place, size_t size, ParticleTrackerDllMaskGate_PointerGate value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllMaskGate_PointerGate_setOverride(context, &place[i], value);
	}
}

/* Set function */
void ParticleTrackerDllMaskGate_PointerGate_setBlock(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate *place, size_t size, ParticleTrackerDllMaskGate_PointerGate *value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		place[i] = value[i]; 
	}
}

/* Dispose function */
void ParticleTrackerDllMaskGate_PointerGate_disposeBlock(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate *place) {
	memorySupport_dispose(place);
}

/* AllocateGroup function */
void ParticleTrackerDllMaskGate_PointerGate_allocateGroupBlock(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t groupSize, size_t *gateSize) {
	register size_t i;	
	for (i = 0; i < groupSize; i++) {
	 	place[i] = ParticleTrackerDllMaskGate_PointerGate_allocateBlock(context, gateSize[i]);	
	}
}

/* InitialiseGroup function */
void ParticleTrackerDllMaskGate_PointerGate_initializeGroupBlock(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t groupSize, size_t *gateSize) {
	register size_t i;
	for (i = 0; i < groupSize; i++) {
		ParticleTrackerDllMaskGate_PointerGate_initializeBlock(context, place[i], gateSize[i]);
	}
}

/* SetOverrideGroupBlock function */
void ParticleTrackerDllMaskGate_PointerGate_setOverrideGroupBlock(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllMaskGate_PointerGate value) {
	register size_t i;
	for (i = 0; i < groupSize; i++) {
		ParticleTrackerDllMaskGate_PointerGate_setOverrideBlock(context, place[i], gateSize[i], value);
	}
}

/* SetGroupBlock function */
void ParticleTrackerDllMaskGate_PointerGate_setGroupBlock(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllMaskGate_PointerGate **value) {
	register size_t i;
	for (i = 0; i < groupSize; i++) {
		ParticleTrackerDllMaskGate_PointerGate_setBlock(context, place[i], gateSize[i], value[i]);
	}
}

/* DisposeGroup function */
void ParticleTrackerDllMaskGate_PointerGate_disposeGroupBlock(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	memorySupport_dispose(place[i]);
	}
}

