/**
 * File: F_ParticleTrackerDllFindThreshold_CoprocImplementation.c
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#include "InfoManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "EngineManager.h"
#include "CoprocManager.h"

#include "B_ParticleTrackerDllFindThreshold_CoprocImplementation.h"
#include "S_ParticleTrackerDllFindThreshold_CoprocImplementation.h"

#include "B_ParticleTrackerDllTracker_Requirement.h"

/**
 * Convenience defines to access unit state variables.
 */
#define currState context->state
#define currentOp context->curOp
/* Input ParameterGates Shortcuts */
#define pIn_Percentile (*context->paramIn_Percentile)

/* Output ParameterGates Shortcuts */
#define pOut_Status (*context->paramOut_Status)
#define pOut_Status_set(str) stringSupport_copy(*context->paramOut_Status, str)

/* Input DataGates Shortcuts */
#define dIn_SequenceValues (*context->dataIn_SequenceValues)
#define dIn_PTFiltered (*context->dataIn_PTFiltered)

/* Output DataGates Shortcuts */
#define dOut_PTThreshold (*context->dataOut_PTThreshold)

/* numLinks shortcuts */
#define dIn_SequenceValues_numLinks context->dataIn_SequenceValues_numLinks
#define dIn_PTFiltered_numLinks context->dataIn_PTFiltered_numLinks
#define dOut_PTThreshold_numLinks context->dataOut_PTThreshold_numLinks
#define pIn_Percentile_numLinks context->paramIn_Percentile_numLinks
#define pOut_Status_numLinks context->paramOut_Status_numLinks

/* AdditionalStateVariables default values */
#define ADDS_PERCENTILE_DEFAULTVALUE 0


/* CoprocEvent ID */
#define pIn_Coproc_event 100

/* Input EventGate IDs */
#define dIn_PTFiltered_event 1000

/* MemoryManager function shortcuts */
#define memory_allocate(size) memoryManager_allocate((DSPEElement*) context, size)
#define memory_allocateAndInit(blockSize, size) memoryManager_allocateAndInit((DSPEElement*) context, blockSize, size)
#define memory_realloc(pointer, newSize) memorySupport_realloc(pointer, newSize)
#define memory_dispose(pointer) memorySupport_dispose(pointer)
#define memory_copyBlock(destination, source, size) memorySupport_copyBlock(destination, source, size)
#define memory_resetBlock(destination, size) memorySupport_resetBlock(destination, size)

/* StringManager function shortcuts */
#define string_copy(destination, source) stringSupport_copy(destination, source)
#define string_nCopy(destination, source, numChars) stringSupport_nCopy(destination, source, numChars)
#define string_compare(first, second) stringSupport_compare(first, second)
#define string_nCompare(first, second, numChars) stringSupport_nCompare(first, second, numChars)
#define string_compareNoCase(first, second) stringSupport_compareNoCase(first, second)
#define string_nCompareNoCase(first, second, numChars) stringSupport_nCompareNoCase(first, second, numChars)
#define string_length(string) stringSupport_length(string)

/* EngineManager function shortcuts */
#define engine_run() engineManager_run((DSPEElement*) context)
#define engine_stop() engineManager_stop((DSPEElement*) context)
#define engine_pause() engineManager_pause((DSPEElement*) context)
#define engine_skip(cycles) engineManager_skip((DSPEElement*) context, cycles)
#define engine_quit() engineManager_quit((DSPEElement*) context)
#define engine_suspend() engineManager_suspend((DSPEElement*) context)
#define engine_freeze() engineManager_freeze((DSPEElement*) context)
#define engine_resume() engineManager_resume((DSPEElement*) context)

#define engine_isExecuting() engineManager_isExecuting((DSPEElement*) context)
#define engine_isStopping() engineManager_isStopping((DSPEElement*) context)
#define engine_isStopped() engineManager_isStopped((DSPEElement*) context)
#define engine_isPaused() engineManager_isPaused((DSPEElement*) context)
#define engine_isSkipping() engineManager_isSkipping((DSPEElement*) context)
#define engine_isExiting() engineManager_isExiting((DSPEElement*) context)
#define engine_isSuspended() engineManager_isSuspended((DSPEElement*) context)

/* InfoManager function shortcuts */
#if defined(INFOMANAGER_BYPASS_CONSOLE) && (INFOMANAGER_BYPASS_CONSOLE == 1)
#define info_writeInfo(info, ...)
#define info_collectAndWriteInfo(id)
#define info_nCollectAndWriteInfo(id, increment)
#else
#define info_writeInfo(info, ...) infoManager_writeInfo((DSPEElement*) context, info , ##__VA_ARGS__)
#define info_collectAndWriteInfo(id) infoManager_collectAndWriteInfo((DSPEElement*) context, id, 1)
#define info_nCollectAndWriteInfo(id, increment) infoManager_collectAndWriteInfo((DSPEElement*) context, id, increment)
#endif
#if defined(INFOMANAGER_BYPASS_LOG) && (INFOMANAGER_BYPASS_LOG == 1)
#define info_logInfo(info, ...)
#define info_collectAndLogInfo(id)
#define info_nCollectAndLogInfo(id, increment)
#else
#define info_logInfo(info, ...) infoManager_logInfo((DSPEElement*) context, info , ##__VA_ARGS__)
#define info_collectAndLogInfo(id) infoManager_collectAndLogInfo((DSPEElement*) context, id, 1)
#define info_nCollectAndLogInfo(id, increment) infoManager_collectAndLogInfo((DSPEElement*) context, id, increment)
#endif

/* Op readOnly AdditionalStateVariables shortcuts */
#define addS_percentile context->persistent->percentile

/* Common event shortcuts */
#define event_isAvailable() isEventAvailable(context)
#define event_transit() transitEvent(context)
#define event_getID() getEventID(context)

/* Data Input getEvent function shortcuts */
#define dIn_PTFiltered_getEvent() getDE_PTFiltered(context)

/* Data Input transit support functions */
#define dIn_PTFiltered_transitNumElements() getTransitNumElementsDE_PTFiltered(context)
#define dIn_PTFiltered_getFirstTransit() getFirstTransitDE_PTFiltered(context)
#define dIn_PTFiltered_currentNumElements() getCurrentNumElementsDE_PTFiltered(context)
#define dIn_PTFiltered_getCurTransit() getCurTransitDE_PTFiltered(context)
#define dIn_PTFiltered_dismissEvent() dismissDE_PTFiltered(context)

/* Data Output support function shortcuts */
#define dOut_PTThreshold_armEvent() armDE_PTThreshold(context)
#define dOut_PTThreshold_sendEvent() sendDE_PTThreshold(context)

/* Coproc support function shortcuts */
#define coproc_isCoprocQueueFull() isCoprocFull(context)
#define coproc_queueOp(coprocOp) queueOp(context, (DSPEOp*) coprocOp)
#define coproc_getProcessedOp() getProcessedOp(context)
#define coproc_createOp() createOp(context)
#define coproc_initOp(coprocOp) initOp(context, coprocOp)
#define coproc_destroyOp(coprocOp) destroyOp(coprocOp)

/* CoprocBuffer support function shortcuts */
#define coproc_getEmptyOp() getEmptyOp(context)
#define coproc_getBufferedOp() getBufferedOp(context)
#define coproc_getNextOp() getNextOp(context)
#define coproc_releaseOp(coprocOp) releaseOp(context, coprocOp)

/**
 * PreProcess algorithm. Process phase initialization should take place here.
 * This function will be called ONCE before the process phase.
 */
void ParticleTrackerDllFindThreshold_CoprocImplementation_preProcess(ParticleTrackerDllFindThreshold_CoprocImplementation *context) {
//Place implementation after this line -- SYD-PREPROCESS-START
	addS_percentile = pIn_Percentile / 100;

	pOut_Status_set("Running");
//SYD-PREPROCESS-END -- Place implementation before this line
}

/* Op readOnly AdditionalStateVariables shortcuts */
#undef addS_percentile

/* Op readOnly AdditionalStateVariables shortcuts */
#define addS_percentile ((const ParticleTrackerDllFindThreshold_CoprocImplementation_persistent*) context->persistent)->percentile

#undef event_isAvailable
#undef event_getID

#undef event_transit

#undef dIn_PTFiltered_getEvent

#undef dIn_PTFiltered_transitNumElements
#undef dIn_PTFiltered_getFirstTransit
#undef dIn_PTFiltered_currentNumElements
#undef dIn_PTFiltered_getCurTransit
#undef dIn_PTFiltered_dismissEvent

#undef dOut_PTThreshold_armEvent
#undef dOut_PTThreshold_sendEvent

/* Coproc support function shortcuts */
#undef coproc_isCoprocQueueFull
#undef coproc_queueOp
#undef coproc_getProcessedOp
#undef coproc_createOp
#undef coproc_initOp
#undef coproc_destroyOp
#undef coproc_getEmptyOp
#undef coproc_getBufferedOp
#undef coproc_getNextOp
#undef coproc_releaseOp

/**
 * Process algorithm. What the unit really does should take place here.
 * This function will be called at each process cycle.
 */
void ParticleTrackerDllFindThreshold_CoprocImplementation_process(ParticleTrackerDllFindThreshold_CoprocImplementation_op *context) {
//Place implementation after this line -- SYD-PROCESS-START
	dOut_PTThreshold->id = dIn_PTFiltered->id;

	dOut_PTThreshold->threshold = PT_FindThreshold(dIn_SequenceValues->width, dIn_SequenceValues->height, addS_percentile, dIn_PTFiltered->filtered);
//SYD-PROCESS-END -- Place implementation before this line 
}

/* Op readOnly AdditionalStateVariables shortcuts */
#undef addS_percentile

#undef currState
/* Input ParameterGates Shortcuts */
#undef pIn_Percentile

/* Output ParameterGates Shortcuts */
#undef pOut_Status
#undef pOut_Status_set

/* Input DataGates Shortcuts */
#undef dIn_SequenceValues
#undef dIn_PTFiltered

/* Output DataGates Shortcuts */
#undef dOut_PTThreshold

/* numLinks shortcuts */
#undef dIn_SequenceValues_numLinks
#undef dIn_PTFiltered_numLinks
#undef dOut_PTThreshold_numLinks
#undef pIn_Percentile_numLinks
#undef pOut_Status_numLinks

#undef ADDS_PERCENTILE_DEFAULTVALUE

#undef currentOp
#undef pIn_Coproc_event

#undef dIn_PTFiltered_event
/* MemoryManager function shortcuts */
#undef memory_allocate
#undef memory_allocateAndInit
#undef memory_realloc
#undef memory_dispose
#undef memory_copyBlock
#undef memory_resetBlock

/* StringManager function shortcuts */
#undef string_copy
#undef string_nCopy
#undef string_compare
#undef string_nCompare
#undef string_compareNoCase
#undef string_nCompareNoCase
#undef string_length

/* EngineManager function shortcuts */
#undef engine_run
#undef engine_stop
#undef engine_pause
#undef engine_skip
#undef engine_quit
#undef engine_suspend
#undef engine_freeze
#undef engine_resume

#undef engine_isExecuting
#undef engine_isStopping
#undef engine_isStopped
#undef engine_isPaused
#undef engine_isSkipping
#undef engine_isExiting
#undef engine_isSuspended

/* InfoManager function shortcuts */
#undef info_writeInfo
#undef info_collectAndWriteInfo
#undef info_nCollectAndWriteInfo
#undef info_logInfo
#undef info_collectAndLogInfo
#undef info_nCollectAndLogInfo

