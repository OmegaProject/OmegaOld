/**
 * File: RBlock_ParticleTrackerDllImagesColor_StringGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef RBlock_ParticleTrackerDllImagesColor_StringGate_h
#define RBlock_ParticleTrackerDllImagesColor_StringGate_h

#include "B_ParticleTrackerDllImagesColor_StringGate.h"

#ifdef __cplusplus
extern "C" {
#endif

/* AllocateBlockManaged function */
void ParticleTrackerDllImagesColor_StringGate_allocateBlockManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *anchor, size_t size);

/* InitBlockManaged function */
void ParticleTrackerDllImagesColor_StringGate_initBlockManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *anchor, size_t size);

/* DisposeBlockManaged function */
void ParticleTrackerDllImagesColor_StringGate_disposeBlockManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *anchor, size_t size);

/* AllocateGroupBlockManaged function */
void ParticleTrackerDllImagesColor_StringGate_allocateGroupBlockManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **anchor, size_t size, size_t *gateSize);

/* InitGroupBlockManaged function */
void ParticleTrackerDllImagesColor_StringGate_initGroupBlockManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **anchor, size_t size, size_t *gateSize);

/* DisposeGroupBlockManaged function */
void ParticleTrackerDllImagesColor_StringGate_disposeGroupBlockManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **anchor, size_t size, size_t *gateSize);

/* Allocate function */
ParticleTrackerDllImagesColor_StringGate* ParticleTrackerDllImagesColor_StringGate_allocateBlock(DSPEElement *context, size_t size);

/* Initialise function */
void ParticleTrackerDllImagesColor_StringGate_initializeBlock(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *place, size_t size);

/* SetOverrideBlock function */
void ParticleTrackerDllImagesColor_StringGate_setOverrideBlock(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *place, size_t size, ParticleTrackerDllImagesColor_StringGate value);

/* Set function */
void ParticleTrackerDllImagesColor_StringGate_setBlock(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *place, size_t size, ParticleTrackerDllImagesColor_StringGate *value);

/* Dispose function */
void ParticleTrackerDllImagesColor_StringGate_disposeBlock(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *place);

/* AllocateGroup function */
void ParticleTrackerDllImagesColor_StringGate_allocateGroupBlock(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t groupSize, size_t *gateSize);

/* InitialiseGroup function */
void ParticleTrackerDllImagesColor_StringGate_initializeGroupBlock(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t groupSize, size_t *gateSize);

/* SetOverrideGroupBlock function */
void ParticleTrackerDllImagesColor_StringGate_setOverrideGroupBlock(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllImagesColor_StringGate value);

/* SetGroup function */
void ParticleTrackerDllImagesColor_StringGate_setGroupBlock(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllImagesColor_StringGate **value);

/* DisposeGroup function */
void ParticleTrackerDllImagesColor_StringGate_disposeGroupBlock(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t size);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
