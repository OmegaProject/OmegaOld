/**
 * File: B_ParticleTrackerDllStatusGate_StringGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef B_ParticleTrackerDllStatusGate_StringGate_h
#define B_ParticleTrackerDllStatusGate_StringGate_h

#include "DSPEElements.h"

#define PARTICLETRACKERDLLSTATUSGATE_STRINGGATE_TYPECATEGORY "String"
#define PARTICLETRACKERDLLSTATUSGATE_STRINGGATE_DEFAULTVALUE ""
#define PARTICLETRACKERDLLSTATUSGATE_STRINGGATE_MAXIMUMSIZE 128

typedef char* ParticleTrackerDllStatusGate_StringGate;

/* StringGate node type definition */
typedef struct ParticleTrackerDllStatusGate_StringGate_node ParticleTrackerDllStatusGate_StringGate_node; 

/* StringGate node definition */ 
struct ParticleTrackerDllStatusGate_StringGate_node {
	DSPEGateNode node;
	
	ParticleTrackerDllStatusGate_StringGate *gate;
	ParticleTrackerDllStatusGate_StringGate gateAnchor;
	ParticleTrackerDllStatusGate_StringGate *localVar;
	ParticleTrackerDllStatusGate_StringGate localVarAnchor;	
	ParticleTrackerDllStatusGate_StringGate *value;
	ParticleTrackerDllStatusGate_StringGate valueAnchor;
};

#ifdef __cplusplus
extern "C" {
#endif

/* AllocateValue function */
ParticleTrackerDllStatusGate_StringGate ParticleTrackerDllStatusGate_StringGate_allocateValue(DSPEElement *context);
/* InitValue function */
void ParticleTrackerDllStatusGate_StringGate_initValue(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate anchor);

/* CopyValue function */
void ParticleTrackerDllStatusGate_StringGate_copyValue(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate destination, ParticleTrackerDllStatusGate_StringGate source);

/* CompareValue function */
int ParticleTrackerDllStatusGate_StringGate_compareValue(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate first, ParticleTrackerDllStatusGate_StringGate second);

/* DisposeValue function */
void ParticleTrackerDllStatusGate_StringGate_disposeValue(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate anchor);

/* AllocateManaged function */
void ParticleTrackerDllStatusGate_StringGate_allocateManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *anchor);
/* InitManaged function */
void ParticleTrackerDllStatusGate_StringGate_initManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate anchor);

/* DisposeManaged function */
void ParticleTrackerDllStatusGate_StringGate_disposeManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate anchor);

/* AllocateGroupManaged function */
void ParticleTrackerDllStatusGate_StringGate_allocateGroupManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **anchor, size_t size);
/* InitGroupManaged function */
void ParticleTrackerDllStatusGate_StringGate_initGroupManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **anchor, size_t size);

/* DisposeGroupManaged function */
void ParticleTrackerDllStatusGate_StringGate_disposeGroupManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **anchor, size_t size);

/* Allocate function */
ParticleTrackerDllStatusGate_StringGate* ParticleTrackerDllStatusGate_StringGate_allocate(DSPEElement *context);

/* Initialise function */
void ParticleTrackerDllStatusGate_StringGate_initialize(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *place);

/* SetOverride function */
void ParticleTrackerDllStatusGate_StringGate_setOverride(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *place, ParticleTrackerDllStatusGate_StringGate value);

/* Set function */
void ParticleTrackerDllStatusGate_StringGate_set(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *place, ParticleTrackerDllStatusGate_StringGate *value);

/* Dispose function */
void ParticleTrackerDllStatusGate_StringGate_dispose(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *place);

/* AllocateGroup function */
void ParticleTrackerDllStatusGate_StringGate_allocateGroup(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t size);

/* InitialiseGroup function */
void ParticleTrackerDllStatusGate_StringGate_initializeGroup(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t size);

/* SetOverrideGroup function */
void ParticleTrackerDllStatusGate_StringGate_setOverrideGroup(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t size, ParticleTrackerDllStatusGate_StringGate value);

/* SetGroup function */
void ParticleTrackerDllStatusGate_StringGate_setGroup(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t size, ParticleTrackerDllStatusGate_StringGate **value);

/* DisposeGroup function */
void ParticleTrackerDllStatusGate_StringGate_disposeGroup(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t size);

/* CreateNode function */
ParticleTrackerDllStatusGate_StringGate_node* ParticleTrackerDllStatusGate_StringGate_createNode(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *gate, ParticleTrackerDllStatusGate_StringGate *localVar);

/* DisposeNode function */
void ParticleTrackerDllStatusGate_StringGate_disposeNode(DSPEElement *context, DSPEGateNode *node);

/* SetValue function */
void ParticleTrackerDllStatusGate_StringGate_setValue(DSPEElement *context, DSPEGateNode *node);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
