/**
 * File: B_ParticleTrackerDllNextGate_SignalGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#include "MemoryManager.h"

#include "B_ParticleTrackerDllNextGate_SignalGate.h"

/* eventPool initialization function */
ParticleTrackerDllNextGate_SignalGate_pool* ParticleTrackerDllNextGate_SignalGate_initPool(const DSPEOwner *owner) {
	DSPEPoolHandler *handler = memoryManager_getPoolHandler(owner);
	ParticleTrackerDllNextGate_SignalGate_pool *pool = (ParticleTrackerDllNextGate_SignalGate_pool*) memoryManager_getPool(handler, &ParticleTrackerDllNextGate_SignalGate_allocate);
	/* lazy initialization */
	if (pool == NULL) {
		pool = (ParticleTrackerDllNextGate_SignalGate_pool*) memoryManager_allocate(CAST_TO_ELEMENT(owner), sizeof(ParticleTrackerDllNextGate_SignalGate_pool));
		initDSPEElement((DSPEElement*) pool, (DSPEElement*) handler);
		initDSPEBaseEventsPool((DSPEBaseEventsPool*) pool);
		pool->eventNumElements = 0;
		pool->headEvent = NULL;
		pool->tailEvent = NULL;
		pool->cloneNumElements = 0;
		pool->headClone = NULL;
		pool->tailClone = NULL;
		((DSPEEventsPool*) pool)->gateDefID = &ParticleTrackerDllNextGate_SignalGate_allocate;
		((DSPEEventsPool*) pool)->preAlloc = ParticleTrackerDllNextGate_SignalGate_preAllocPool;
		 /* No need to reset signals as they don't have value ! */
		((DSPEEventsPool*) pool)->reset = NULL;
		((DSPEEventsPool*) pool)->dispose = ParticleTrackerDllNextGate_SignalGate_disposePool;
		memoryManager_addPool(handler, (DSPEBaseEventsPool*) pool);
	}
	return pool;
}

/* eventPool preAlloc function */
void ParticleTrackerDllNextGate_SignalGate_preAllocPool(DSPEEventsPool *pool, size_t size) {
	ParticleTrackerDllNextGate_SignalGate_pool *concretePool = (ParticleTrackerDllNextGate_SignalGate_pool*) pool;
	register size_t i;
	ParticleTrackerDllNextGate_SignalGate_event *firstEvent = NULL;
	ParticleTrackerDllNextGate_SignalGate_event *lastEvent = NULL;
	ParticleTrackerDllNextGate_SignalGate_event *currEvent = NULL;
	
	firstEvent = ParticleTrackerDllNextGate_SignalGate_allocate(concretePool);
	lastEvent = firstEvent;
	
	/* size - 1 because of allocation of first */
	for (i = 0; i < size - 1; i++) {
		currEvent = ParticleTrackerDllNextGate_SignalGate_allocate(concretePool);
	
		((DSPEEvent*) lastEvent)->next = (DSPEEvent*) currEvent;
		lastEvent = currEvent;
	}

	concretePool->headEvent = firstEvent;
	concretePool->tailEvent = lastEvent;
	concretePool->eventNumElements = size;
}

/* Allocate function */
ParticleTrackerDllNextGate_SignalGate_event* ParticleTrackerDllNextGate_SignalGate_allocate(ParticleTrackerDllNextGate_SignalGate_pool *pool) {
	ParticleTrackerDllNextGate_SignalGate_pool *gatePool = (ParticleTrackerDllNextGate_SignalGate_pool*) pool;
	ParticleTrackerDllNextGate_SignalGate_event *event = NULL;

	switch (gatePool->eventNumElements) {
	case 0:
		event = (ParticleTrackerDllNextGate_SignalGate_event*) memorySupport_allocate(sizeof(ParticleTrackerDllNextGate_SignalGate_event));
		initDSPEEvent((DSPEEvent*) event);
		((DSPEEvent*) event)->pool = (DSPEEventsPool*) pool;
		((DSPEEvent*) event)->dispose = ParticleTrackerDllNextGate_SignalGate_dispose;
		((DSPEEvent*) event)->clone = ParticleTrackerDllNextGate_SignalGate_clone;
		return event;
	case 1:
		event = gatePool->headEvent;
		gatePool->headEvent = NULL;
		gatePool->tailEvent = NULL;
		gatePool->eventNumElements = 0;
		((DSPEEvent*) event)->next = NULL;
		return event;
	default:
		event = gatePool->headEvent;
		gatePool->headEvent = (ParticleTrackerDllNextGate_SignalGate_event*) ((DSPEEvent*) event)->next;
		gatePool->eventNumElements--;
		((DSPEEvent*) event)->next = NULL;
		return event;
	}
}

DSPEEvent* ParticleTrackerDllNextGate_SignalGate_clone(DSPEEvent *event) {
	ParticleTrackerDllNextGate_SignalGate_event *clone = ParticleTrackerDllNextGate_SignalGate_allocate((ParticleTrackerDllNextGate_SignalGate_pool*) event->pool);
	return (DSPEEvent*) clone;
}

/* Dispose function */
void ParticleTrackerDllNextGate_SignalGate_dispose(DSPEEvent *event) {
	ParticleTrackerDllNextGate_SignalGate_pool *gatePool = (ParticleTrackerDllNextGate_SignalGate_pool*) event->pool;
	if (event->refCount == 1) {
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->eventNumElements) {
		case 0:
			gatePool->headEvent = (ParticleTrackerDllNextGate_SignalGate_event*) event;
			gatePool->tailEvent = (ParticleTrackerDllNextGate_SignalGate_event*) event;
			gatePool->eventNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailEvent)->next = (DSPEEvent*) event;
			gatePool->tailEvent = (ParticleTrackerDllNextGate_SignalGate_event*) event;
			gatePool->eventNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* eventPool initialization function */
void ParticleTrackerDllNextGate_SignalGate_disposePool(DSPEEventsPool *pool) {
	ParticleTrackerDllNextGate_SignalGate_pool *thisPool = (ParticleTrackerDllNextGate_SignalGate_pool*) pool;
	register size_t i;
	DSPEEvent *tmp  = NULL;
	/* Dispose events */
	for (i = 0; i < thisPool->eventNumElements; i++) {
		tmp = (DSPEEvent*) thisPool->headEvent;
		thisPool->headEvent = (ParticleTrackerDllNextGate_SignalGate_event*) tmp->next;
		tmp->next = NULL;
		memorySupport_dispose(tmp);
	}
	/* Dispose clones */
	for (i = 0; i < thisPool->cloneNumElements; i++) {
		tmp = (DSPEEvent*) thisPool->headClone;
		thisPool->headClone = (ParticleTrackerDllNextGate_SignalGate_cloneEvent*) tmp->next;
		tmp->next = NULL;
		memorySupport_dispose(tmp);
	}
	/* dispose pool */
	memorySupport_dispose(thisPool);
}

/* groupEventPool initialization function */
ParticleTrackerDllNextGate_SignalGate_groupPool* ParticleTrackerDllNextGate_SignalGate_initGroupPool(const DSPEOwner *owner, size_t groupSize) {
	DSPEPoolHandler *handler = memoryManager_getPoolHandler(owner);
	ParticleTrackerDllNextGate_SignalGate_groupPool *pool = (ParticleTrackerDllNextGate_SignalGate_groupPool*) memoryManager_getGroupPool(handler, &ParticleTrackerDllNextGate_SignalGate_allocateGroup, groupSize);
	/* lazy initialization */
	if (pool == NULL) {
		pool = (ParticleTrackerDllNextGate_SignalGate_groupPool*) memoryManager_allocate(CAST_TO_ELEMENT(owner), sizeof(ParticleTrackerDllNextGate_SignalGate_groupPool));
		initDSPEElement((DSPEElement*) pool, (DSPEElement*) handler);
		initDSPEGroupEventsPool((DSPEGroupEventsPool*) pool);
		pool->eventNumElements = 0;
		pool->headEvent = NULL;
		pool->tailEvent = NULL;
		pool->cloneNumElements = 0;
		pool->headClone = NULL;
		pool->tailClone = NULL;
		((DSPEEventsPool*) pool)->gateDefID = &ParticleTrackerDllNextGate_SignalGate_allocateGroup;
		((DSPEEventsPool*) pool)->preAlloc = ParticleTrackerDllNextGate_SignalGate_preAllocGroupPool;
		 /* No need to reset signals as they don't have value ! */
		((DSPEEventsPool*) pool)->reset = NULL;
		((DSPEEventsPool*) pool)->dispose = ParticleTrackerDllNextGate_SignalGate_disposeGroupPool;
		((DSPEGroupEventsPool*) pool)->groupSize = groupSize;
		memoryManager_addGroupPool(handler, (DSPEGroupEventsPool*) pool);
	}
	return pool;
}

/* eventPool preAlloc function */
void ParticleTrackerDllNextGate_SignalGate_preAllocGroupPool(DSPEEventsPool *pool, size_t size) {
	ParticleTrackerDllNextGate_SignalGate_groupPool *concretePool = (ParticleTrackerDllNextGate_SignalGate_groupPool*) pool;
	DSPEEventsPool *childPool = NULL;
	register size_t i;
	ParticleTrackerDllNextGate_SignalGate_groupEvent *firstEvent = NULL;
	ParticleTrackerDllNextGate_SignalGate_groupEvent *lastEvent = NULL;
	ParticleTrackerDllNextGate_SignalGate_groupEvent *currEvent = NULL;
	
	/* preAlloc children */
	childPool = (DSPEEventsPool*) ((DSPEGroupEventsPool*) pool)->groupsHead;
	for (i = 0; i < ((DSPEGroupEventsPool*) pool)->groupsNumElements; i++) {
		childPool->preAlloc(childPool, size);
		childPool = childPool->next;
	}

	firstEvent = ParticleTrackerDllNextGate_SignalGate_allocateGroup(concretePool);
	lastEvent = firstEvent;
	
	/* size - 1 because of allocation of first */
	for (i = 0; i < size - 1; i++) {
		currEvent = ParticleTrackerDllNextGate_SignalGate_allocateGroup(concretePool);
	
		((DSPEEvent*) lastEvent)->next = (DSPEEvent*) currEvent;
		lastEvent = currEvent;
	}

	concretePool->headEvent = firstEvent;
	concretePool->tailEvent = lastEvent;
	concretePool->eventNumElements = size;
}

/* AllocateGroup function */
ParticleTrackerDllNextGate_SignalGate_groupEvent* ParticleTrackerDllNextGate_SignalGate_allocateGroup(ParticleTrackerDllNextGate_SignalGate_groupPool *grpPool) {
	ParticleTrackerDllNextGate_SignalGate_groupPool *gatePool = (ParticleTrackerDllNextGate_SignalGate_groupPool*) grpPool;
	ParticleTrackerDllNextGate_SignalGate_groupEvent *event = NULL;
	switch (gatePool->eventNumElements) {
	case 0:
		event = (ParticleTrackerDllNextGate_SignalGate_groupEvent*) memorySupport_allocate(sizeof(ParticleTrackerDllNextGate_SignalGate_groupEvent));
		initDSPEGroupEvent((DSPEGroupEvent*) event);
		((DSPEGroupEvent*) event)->groupSize = ((DSPEGroupEventsPool*) gatePool)->groupSize;
		((DSPEEvent*) event)->pool = (DSPEEventsPool*) grpPool;
		((DSPEEvent*) event)->dispose = ParticleTrackerDllNextGate_SignalGate_disposeGroup;
		((DSPEEvent*) event)->clone = ParticleTrackerDllNextGate_SignalGate_cloneGroup;
		return event;
	case 1:
		event = gatePool->headEvent;
		gatePool->headEvent = NULL;
		gatePool->tailEvent = NULL;
		gatePool->eventNumElements = 0;
		((DSPEEvent*) event)->next = NULL;
		return event;
	default:
		event = gatePool->headEvent;
		gatePool->headEvent = (ParticleTrackerDllNextGate_SignalGate_groupEvent*) ((DSPEEvent*) event)->next;
		gatePool->eventNumElements--;
		((DSPEEvent*) event)->next = NULL;
		return event;
	}
}

/* SubClone event function */
DSPEEvent* ParticleTrackerDllNextGate_SignalGate_subClone(DSPEGroupEvent *event, DSPEEventsPool *pool, size_t index) {
	ParticleTrackerDllNextGate_SignalGate_pool *gatePool = (ParticleTrackerDllNextGate_SignalGate_pool*) pool;
	ParticleTrackerDllNextGate_SignalGate_event *clone = NULL;
	/* Remark signal events don't have value! no need to create clones */
	switch (gatePool->eventNumElements) {
	case 0:
		clone = (ParticleTrackerDllNextGate_SignalGate_event*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllNextGate_SignalGate_event));
		((DSPEEvent*) clone)->refCount = 0;
		((DSPEEvent*) clone)->dispose = ParticleTrackerDllNextGate_SignalGate_dispose;
		((DSPEEvent*) clone)->clone = ParticleTrackerDllNextGate_SignalGate_clone;
		((DSPEEvent*) clone)->pool = pool;
		((DSPEEvent*) clone)->blockSize = ((DSPEEvent*) event)->blockSize;
		break;
	case 1:
		clone = gatePool->headEvent;
		gatePool->headEvent = NULL;
		gatePool->tailEvent = NULL;
		gatePool->eventNumElements = 0;
		break;
	default:
		clone = gatePool->headEvent;
		gatePool->headEvent = (ParticleTrackerDllNextGate_SignalGate_event*) ((DSPEEvent*) clone)->next;
		gatePool->eventNumElements--;
		break;
	}
	((DSPEEvent*) clone)->next = NULL;
	return (DSPEEvent*) clone;
}

/* CloneGroup event function */
DSPEEvent* ParticleTrackerDllNextGate_SignalGate_cloneGroup(DSPEEvent *event) {
	ParticleTrackerDllNextGate_SignalGate_groupEvent *clone = ParticleTrackerDllNextGate_SignalGate_allocateGroup((ParticleTrackerDllNextGate_SignalGate_groupPool*) event->pool);
	return (DSPEEvent*) clone;
}

/* DisposeGroup function */
void ParticleTrackerDllNextGate_SignalGate_disposeGroup(DSPEEvent *event) {
	ParticleTrackerDllNextGate_SignalGate_groupPool *gatePool = (ParticleTrackerDllNextGate_SignalGate_groupPool*) event->pool;
	if (event->refCount == 1) {
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->eventNumElements) {
		case 0:
			gatePool->headEvent = (ParticleTrackerDllNextGate_SignalGate_groupEvent*) event;
			gatePool->tailEvent = (ParticleTrackerDllNextGate_SignalGate_groupEvent*) event;
			gatePool->eventNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailEvent)->next = event;
			gatePool->tailEvent = (ParticleTrackerDllNextGate_SignalGate_groupEvent*) event;
			gatePool->eventNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* eventPool dispose function */
void ParticleTrackerDllNextGate_SignalGate_disposeGroupPool(DSPEEventsPool *pool) {
	ParticleTrackerDllNextGate_SignalGate_groupPool *thisPool = (ParticleTrackerDllNextGate_SignalGate_groupPool*) pool;
	register size_t i;
	DSPEEvent *tmp  = NULL;
	DSPEEventsPool *eventPool = NULL;
	DSPEEventsPool *tmpEventPool = NULL;

	/* dispose children */
	eventPool = (DSPEEventsPool*) ((DSPEGroupEventsPool*) thisPool)->groupsHead;
	for (i = 0; i < ((DSPEGroupEventsPool*) thisPool)->groupsNumElements; i++) {
		tmpEventPool = eventPool;
		eventPool = eventPool->next;
		tmpEventPool->next = NULL;
		tmpEventPool->dispose(tmpEventPool);
	}
	/* dispose events */
	for (i = 0; i < thisPool->eventNumElements; i++) {
		tmp = (DSPEEvent*) thisPool->headEvent;
		thisPool->headEvent = (ParticleTrackerDllNextGate_SignalGate_groupEvent*) tmp->next;
		tmp->next = NULL;
		memorySupport_dispose(tmp);
	}
	/* dispose clones */
	for (i = 0; i < thisPool->cloneNumElements; i++) {
		tmp = (DSPEEvent*) thisPool->headClone;
		thisPool->headClone = (ParticleTrackerDllNextGate_SignalGate_cloneGroupEvent*) tmp->next;
		tmp->next = NULL;
		memorySupport_dispose(tmp);
	}
	/* dispose pool */
	memorySupport_dispose(thisPool);
}

/**
 * Allocate containerEvent function
 */
ParticleTrackerDllNextGate_SignalGate_eventContainer* ParticleTrackerDllNextGate_SignalGate_allocateContainer(ParticleTrackerDllNextGate_SignalGate_groupPool *grpPool) {
	ParticleTrackerDllNextGate_SignalGate_groupPool *gatePool = (ParticleTrackerDllNextGate_SignalGate_groupPool*) grpPool;
	ParticleTrackerDllNextGate_SignalGate_eventContainer *event = NULL;
	register size_t i;
	switch (gatePool->containerNumElements) {
	case 0:
		event = (ParticleTrackerDllNextGate_SignalGate_eventContainer*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllNextGate_SignalGate_eventContainer));
		initDSPEGroupEvent((DSPEGroupEvent*) event);
		((DSPEEvent*) event)->pool = (DSPEEventsPool*) grpPool;
		((DSPEEvent*) event)->dispose = ParticleTrackerDllNextGate_SignalGate_disposeContainer;
		((DSPEEvent*) event)->clone = ParticleTrackerDllNextGate_SignalGate_cloneGroup;
		((DSPEGroupEvent*) event)->groupSize = ((DSPEGroupEventsPool*) gatePool)->groupSize;
		event->containedEvents = (DSPEEvent**) memoryManager_allocate((DSPEElement*) gatePool, ((DSPEGroupEventsPool*) gatePool)->groupSize * sizeof(DSPEEvent*));
		for (i = 0; i < ((DSPEGroupEventsPool*) gatePool)->groupSize; i++) {
			event->containedEvents[i] = NULL;
		}
		return event;
	case 1:
		event = gatePool->headContainer;
		gatePool->headContainer = NULL;
		gatePool->tailContainer = NULL;
		gatePool->containerNumElements = 0;
		((DSPEEvent*) event)->next = NULL;
		return event;
	default:
		event = gatePool->headContainer;
		gatePool->headContainer = (ParticleTrackerDllNextGate_SignalGate_eventContainer*) ((DSPEEvent*) event)->next;
		gatePool->containerNumElements--;
		((DSPEEvent*) event)->next = NULL;
		return event;
	}
}

/**
 * Dispose containerEvent function
 */
void ParticleTrackerDllNextGate_SignalGate_disposeContainer(DSPEEvent *event) {
	ParticleTrackerDllNextGate_SignalGate_groupPool *gatePool = (ParticleTrackerDllNextGate_SignalGate_groupPool*) event->pool;
	register size_t i;
	ParticleTrackerDllNextGate_SignalGate_eventContainer *container = (ParticleTrackerDllNextGate_SignalGate_eventContainer*) event;
	DSPEEvent *refEvent = NULL;
	if (event->refCount == 1) {
		for (i = 0; i < ((DSPEGroupEventsPool*) gatePool)->groupSize; i++) {
			refEvent = container->containedEvents[i];
			if (refEvent != NULL) {
				refEvent->dispose(refEvent);
				container->containedEvents[i] = NULL;
			}
		}
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->containerNumElements) {
		case 0:
			gatePool->headContainer = (ParticleTrackerDllNextGate_SignalGate_eventContainer*) event;
			gatePool->tailContainer = (ParticleTrackerDllNextGate_SignalGate_eventContainer*) event;
			gatePool->containerNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailContainer)->next = event;
			gatePool->tailContainer = (ParticleTrackerDllNextGate_SignalGate_eventContainer*) event;
			gatePool->containerNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* CreateNode function */
ParticleTrackerDllNextGate_SignalGate_node* ParticleTrackerDllNextGate_SignalGate_createNode(DSPEApplication *application, DSPEEventsPool *pool, unsigned int eventID) {
	ParticleTrackerDllNextGate_SignalGate_node *node = (ParticleTrackerDllNextGate_SignalGate_node*) memoryManager_allocate((DSPEElement*) application, sizeof(ParticleTrackerDllNextGate_SignalGate_node));
	initDSPEGateNode((DSPEGateNode*) node);
	node->eventID = eventID;
	node->application = application;
	node->pool = pool;
	node->sendEvent = 0;
	((DSPEGateNode*) node)->setValue = ParticleTrackerDllNextGate_SignalGate_setValue;
	((DSPEGateNode*) node)->disposeNode = ParticleTrackerDllNextGate_SignalGate_disposeNode;
	return node;
}

/* DisposeNode function */
void ParticleTrackerDllNextGate_SignalGate_disposeNode(DSPEElement *context, DSPEGateNode *node) {
	node->next = NULL;
	memorySupport_dispose(node);
}

/* SetValue function */
void ParticleTrackerDllNextGate_SignalGate_setValue(DSPEElement *context, DSPEGateNode *node) {
	ParticleTrackerDllNextGate_SignalGate_node *tmpNode = (ParticleTrackerDllNextGate_SignalGate_node*) node;
	ParticleTrackerDllNextGate_SignalGate_event *event = NULL;
	if (tmpNode->sendEvent) {
		tmpNode->sendEvent = 0;
		event = ParticleTrackerDllNextGate_SignalGate_allocate((ParticleTrackerDllNextGate_SignalGate_pool*) tmpNode->pool);
		((DSPEEvent*) event)->refCount = 1;
		if (((DSPEEventsApplication*) tmpNode->application)->queueEvent != NULL)
			((DSPEEventsApplication*) tmpNode->application)->queueEvent((DSPEEventsApplication*) tmpNode->application, (DSPEEvent*) event, tmpNode->eventID);
		ParticleTrackerDllNextGate_SignalGate_dispose((DSPEEvent*) event);
	}
}

