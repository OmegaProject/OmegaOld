/**
 * File: B_ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application.c
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#include "PlatformManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "ThreadManager.h"
#include "CoprocManager.h"

#include "B_ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application.h"

#define PTCoproc_3_PUSH_Dll_ID "PTCoproc_3_PUSH_Dll"

#define LibraryDataReader_pIn_sourceNext_event 1000
#define LibraryDataReader_pIn_next_event 1001
#define LibraryDataReader_pOut_next_event 1000
#define LibraryDataReader_dOut_PTFrame_event 1001

#define ConvolveAllCaseCP_PUSH_pIn_next_event 1000
#define ConvolveAllCaseCP_PUSH_dIn_PTFrame_event 1001
#define ConvolveAllCaseCP_PUSH_pOut_next_event 1000
#define ConvolveAllCaseCP_PUSH_dOut_PTFrame_event 1001
#define ConvolveAllCaseCP_PUSH_dOut_PTFiltered_event 1002

#define DilateAllCaseCP_PUSH_pIn_next_event 1000
#define DilateAllCaseCP_PUSH_dIn_PTFrame_event 1001
#define DilateAllCaseCP_PUSH_pOut_next_event 1000
#define DilateAllCaseCP_PUSH_dOut_PTFrame_event 1001

#define FindThresholdCP_dIn_PTFiltered_event 1000
#define FindThresholdCP_dOut_PTThreshold_event 1000

#define FindParticlesCPNewAutoNext_PUSH_2_pIn_next_event 1000
#define FindParticlesCPNewAutoNext_PUSH_2_dIn_PTFrame_event 1001
#define FindParticlesCPNewAutoNext_PUSH_2_dIn_PTThreshold_event 1002
#define FindParticlesCPNewAutoNext_PUSH_2_pOut_next_event 1000
#define FindParticlesCPNewAutoNext_PUSH_2_dOut_PTFrame_event 1001

#define PositionRefinementCP_PUSH_2_pIn_next_event 1000
#define PositionRefinementCP_PUSH_2_dIn_PTFrame_event 1001
#define PositionRefinementCP_PUSH_2_pOut_next_event 1000
#define PositionRefinementCP_PUSH_2_dOut_PTFrame_event 1001

#define ParticlesDiscriminationStateCP_PUSH_pIn_next_event 1000
#define ParticlesDiscriminationStateCP_PUSH_dIn_PTFrame_event 1001
#define ParticlesDiscriminationStateCP_PUSH_pOut_next_event 1000
#define ParticlesDiscriminationStateCP_PUSH_dOut_PTFrame_event 1001

#define LinkParticlesStateCPAutoNext_PUSH_pIn_next_event 1000
#define LinkParticlesStateCPAutoNext_PUSH_dIn_PTFrame_event 1001
#define LinkParticlesStateCPAutoNext_PUSH_pOut_next_event 1000
#define LinkParticlesStateCPAutoNext_PUSH_dOut_PTFrame_event 1001

#define GenerateTrajectoriesStateCPAutoNextNew_PUSH_pIn_next_event 1000
#define GenerateTrajectoriesStateCPAutoNextNew_PUSH_dIn_PTFrame_event 1001
#define GenerateTrajectoriesStateCPAutoNextNew_PUSH_pOut_next_event 1000
#define GenerateTrajectoriesStateCPAutoNextNew_PUSH_pOut_LastFrameProcessed_event 1001
#define GenerateTrajectoriesStateCPAutoNextNew_PUSH_dOut_Trajectory_event 1002

#define LibraryDataWriter_pIn_LastFrameProcessed_event 1000
#define LibraryDataWriter_dIn_Trajectory_event 1001
#define LibraryDataWriter_pOut_next_event 1000


static INLINE void queueComponent(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *scheduler, DSPEComponent *component) {
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_queueNode *node = NULL;
	
	switch (scheduler->poolNumNodes) {
	case 0:
		node = (ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_queueNode*) memoryManager_allocate((DSPEElement*) scheduler, sizeof(ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_queueNode));
		break;
	case 1:
		node = scheduler->poolHead;
		scheduler->poolHead = NULL;
		scheduler->poolTail = NULL;
		scheduler->poolNumNodes = 0;
		break;
	default:				
		node = scheduler->poolHead;
		scheduler->poolHead = node->next;
		scheduler->poolNumNodes--;
		break;
	}

	node->next = NULL;
	node->component = component;
		
	if (scheduler->queueNumNodes == 0) {
		scheduler->queueHead = node;
		scheduler->queueTail = node;
		scheduler->queueNumNodes = 1;
	} else {
		scheduler->queueTail->next = node;
		scheduler->queueTail = node;
		scheduler->queueNumNodes++;
	}
}

typedef struct InitEvent InitEvent;
struct InitEvent {	
	DSPEEvent superEvent;
};

/* Dispose function */
static void InitEvent_dispose(DSPEEvent *event) {
	if (event->refCount == 1)
		memorySupport_dispose(event);
	else
		event->refCount--;
}

/* Send InitEvent function */
static INLINE void sendInitEvent(DSPEEventsUnit *unit, int queueOnly) {
	DSPEEvent *event = NULL;
	
	/* If unit does not accept initEvent only queue unit */
	if (queueOnly == 0) {
		event = (DSPEEvent*) memoryManager_allocate((DSPEElement*) unit, sizeof(InitEvent));
		event->dispose = InitEvent_dispose;
		event->refCount = 1;
		unit->queueEvent(unit, event, 0);
		event->dispose(event);
	}
	queueComponent((ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler*) ((DSPEElement*) unit)->container, (DSPEComponent*) unit);
}

/* getID function */
char* ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_getID(const DSPEElement *element) {
	return ((const ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application*) element)->ID;
}

/* Initialize gate values */
static INLINE void initValues(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *context) {

	/* Contained configuration unlinked input parameter gates initialization */
	ParticleTrackerDllBoolGate_StandardGate_initialize((DSPEElement*) context, context->GenerateTrajectoriesStateCPAutoNextNew_PUSH_paramIn_Verbose_unlinked);


	/* Application input parameters places initialization */
	ParticleTrackerDllIntGate_StandardGate_setOverride((DSPEElement*) context, context->paramIn_Radius_place, 3);
	ParticleTrackerDllRealGate_CustomGate_setOverride((DSPEElement*) context, context->paramIn_Cutoff_place, 3.0);
	ParticleTrackerDllRealGate_CustomGate_setOverride((DSPEElement*) context, context->paramIn_Percentile_place, 0.1);
	ParticleTrackerDllRealGate_CustomGate_setOverride((DSPEElement*) context, context->paramIn_Displacement_place, 10.0);
	ParticleTrackerDllIntGate_StandardGate_setOverride((DSPEElement*) context, context->paramIn_Linkrange_place, 1);
	ParticleTrackerDllIntGate_StandardGate_initialize((DSPEElement*) context, context->paramIn_ImgsNum_place);
	ParticleTrackerDllIntGate_StandardGate_initialize((DSPEElement*) context, context->paramIn_ImgWidth_place);
	ParticleTrackerDllIntGate_StandardGate_initialize((DSPEElement*) context, context->paramIn_ImgHeight_place);
	ParticleTrackerDllRealGate_CustomGate_initialize((DSPEElement*) context, context->paramIn_ImgMin_place);
	ParticleTrackerDllRealGate_CustomGate_initialize((DSPEElement*) context, context->paramIn_ImgMax_place);

}

/* Earlyalloc function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_earlyAlloc(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *context) {
	initDSPEElement((DSPEElement*) &context->configuration, (DSPEElement*) context);
	/* Initializing process function pointer */
	((DSPEComponent*) context)->process = ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_process;

	/* Application ID init */
	((DSPEElement*) context)->getID = ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_getID;
	context->ID = stringSupport_generateID(0, PTCoproc_3_PUSH_Dll_ID);
	/* Root configuration namePrefix init */
	context->configuration.namePrefix = context->ID;

	/* PoolHandler initialization */
	memoryManager_initPoolHandler(CAST_TO_OWNER((DSPEApplication*) context));
	/* CoprocHandler initialization */
	coprocManager_initCoprocHandler((DSPEApplication*) context);


	/* Configuration earlyalloc() function call */
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_earlyAlloc(&context->configuration);

}

/* Alloc function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_alloc(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *context) {

	/* Contained configuration unlinked input parameter places allocation */
	context->GenerateTrajectoriesStateCPAutoNextNew_PUSH_paramIn_Verbose_unlinked = ParticleTrackerDllBoolGate_StandardGate_allocate((DSPEElement*) context);


	/* Application input parameters places allocation */
	context->paramIn_Radius_place = ParticleTrackerDllIntGate_StandardGate_allocate((DSPEElement*) context);
	context->paramIn_Cutoff_place = ParticleTrackerDllRealGate_CustomGate_allocate((DSPEElement*) context);
	context->paramIn_Percentile_place = ParticleTrackerDllRealGate_CustomGate_allocate((DSPEElement*) context);
	context->paramIn_Displacement_place = ParticleTrackerDllRealGate_CustomGate_allocate((DSPEElement*) context);
	context->paramIn_Linkrange_place = ParticleTrackerDllIntGate_StandardGate_allocate((DSPEElement*) context);
	context->paramIn_ImgsNum_place = ParticleTrackerDllIntGate_StandardGate_allocate((DSPEElement*) context);
	context->paramIn_ImgWidth_place = ParticleTrackerDllIntGate_StandardGate_allocate((DSPEElement*) context);
	context->paramIn_ImgHeight_place = ParticleTrackerDllIntGate_StandardGate_allocate((DSPEElement*) context);
	context->paramIn_ImgMin_place = ParticleTrackerDllRealGate_CustomGate_allocate((DSPEElement*) context);
	context->paramIn_ImgMax_place = ParticleTrackerDllRealGate_CustomGate_allocate((DSPEElement*) context);


	/* Configuration alloc() function call */
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_alloc(&context->configuration);

}

/* Earlyconnect function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_earlyConnect(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *context) {
	/* Contained configuration local variable */
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *configuration = &context->configuration;


	/* Application input parameters gates initialization */
	context->paramIn_Radius = context->paramIn_Radius_place;
	context->paramIn_Cutoff = context->paramIn_Cutoff_place;
	context->paramIn_Percentile = context->paramIn_Percentile_place;
	context->paramIn_Displacement = context->paramIn_Displacement_place;
	context->paramIn_Linkrange = context->paramIn_Linkrange_place;
	context->paramIn_ImgsNum = context->paramIn_ImgsNum_place;
	context->paramIn_ImgWidth = context->paramIn_ImgWidth_place;
	context->paramIn_ImgHeight = context->paramIn_ImgHeight_place;
	context->paramIn_ImgMin = context->paramIn_ImgMin_place;
	context->paramIn_ImgMax = context->paramIn_ImgMax_place;


	/* Configuration earlyconnect() function call */
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_earlyConnect(&context->configuration);


	/* Configuration container parameter output gates initialization */
	context->paramOut_GenerateTrajectories_status = configuration->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramOut_Status;
	context->paramOut_LinkParticles_status = configuration->LinkParticlesStateCPAutoNext_PUSH.baseState.paramOut_Status;
	context->paramOut_ParticlesDiscrimination_status = configuration->ParticlesDiscriminationStateCP_PUSH.baseState.paramOut_Status;
	context->paramOut_PositionRefinement_status = configuration->PositionRefinementCP_PUSH_2.baseState.paramOut_Status;
	context->paramOut_FindParticles_status = configuration->FindParticlesCPNewAutoNext_PUSH_2.baseState.paramOut_Status;
	context->paramOut_FindThreshold_status = configuration->FindThresholdCP.baseState.paramOut_Status;
	context->paramOut_Dilate_status = configuration->DilateAllCaseCP_PUSH.baseState.paramOut_Status;
	context->paramOut_Convolve_status = configuration->ConvolveAllCaseCP_PUSH.baseState.paramOut_Status;
	context->paramOut_DataReader_status = configuration->LibraryDataReader.baseState.paramOut_Status;

}

/* Connect function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_connect(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *context) {
	/* Contained configuration local variable */
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler *configuration = &context->configuration;


	/* Contained configuration unlinked input parameter gates initialization */
	configuration->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramIn_Verbose = context->GenerateTrajectoriesStateCPAutoNextNew_PUSH_paramIn_Verbose_unlinked;


	/* Configuration container parameter input gates initialization */
	configuration->ConvolveAllCaseCP_PUSH.baseState.paramIn_Radius = context->paramIn_Radius;
	configuration->DilateAllCaseCP_PUSH.baseState.paramIn_Radius = context->paramIn_Radius;
	configuration->FindThresholdCP.baseState.paramIn_Percentile = context->paramIn_Percentile;
	configuration->FindParticlesCPNewAutoNext_PUSH_2.baseState.paramIn_Linkrange = context->paramIn_Linkrange;
	configuration->PositionRefinementCP_PUSH_2.baseState.paramIn_Radius = context->paramIn_Radius;
	configuration->ParticlesDiscriminationStateCP_PUSH.baseState.paramIn_Cutoff = context->paramIn_Cutoff;
	configuration->ParticlesDiscriminationStateCP_PUSH.baseState.paramIn_Linkrange = context->paramIn_Linkrange;
	configuration->LinkParticlesStateCPAutoNext_PUSH.baseState.paramIn_Linkrange = context->paramIn_Linkrange;
	configuration->LinkParticlesStateCPAutoNext_PUSH.baseState.paramIn_Displacement = context->paramIn_Displacement;
	configuration->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramIn_Radius = context->paramIn_Radius;
	configuration->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramIn_Cutoff = context->paramIn_Cutoff;
	configuration->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramIn_Percentile = context->paramIn_Percentile;
	configuration->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramIn_Displacement = context->paramIn_Displacement;
	configuration->GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramIn_Linkrange = context->paramIn_Linkrange;
	configuration->LibraryDataReader.baseState.paramIn_LinkRange = context->paramIn_Linkrange;
	configuration->LibraryDataReader.baseState.paramIn_ImgsNum = context->paramIn_ImgsNum;
	configuration->LibraryDataReader.baseState.paramIn_ImgWidth = context->paramIn_ImgWidth;
	configuration->LibraryDataReader.baseState.paramIn_ImgHeight = context->paramIn_ImgHeight;
	configuration->LibraryDataReader.baseState.paramIn_ImgMin = context->paramIn_ImgMin;
	configuration->LibraryDataReader.baseState.paramIn_ImgMax = context->paramIn_ImgMax;

	context->configuration.LibraryDataReader.baseState.paramIn_ImgHeight_numLinks = 1;
	context->configuration.FindThresholdCP.baseState.paramIn_Percentile_numLinks = 1;
	context->configuration.ConvolveAllCaseCP_PUSH.baseState.paramIn_Radius_numLinks = 1;
	context->configuration.LibraryDataReader.baseState.paramIn_LinkRange_numLinks = 1;
	context->configuration.GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramIn_Radius_numLinks = 1;
	context->configuration.LinkParticlesStateCPAutoNext_PUSH.baseState.paramIn_Displacement_numLinks = 1;
	context->configuration.GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramIn_Percentile_numLinks = 1;
	context->configuration.GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramIn_Linkrange_numLinks = 1;
	context->configuration.GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramIn_Displacement_numLinks = 1;
	context->configuration.LinkParticlesStateCPAutoNext_PUSH.baseState.paramIn_Linkrange_numLinks = 1;
	context->configuration.LibraryDataReader.baseState.paramIn_ImgMax_numLinks = 1;
	context->configuration.LibraryDataReader.baseState.paramIn_ImgMin_numLinks = 1;
	context->configuration.LibraryDataReader.baseState.paramIn_ImgsNum_numLinks = 1;
	context->configuration.FindParticlesCPNewAutoNext_PUSH_2.baseState.paramIn_Linkrange_numLinks = 1;
	context->configuration.PositionRefinementCP_PUSH_2.baseState.paramIn_Radius_numLinks = 1;
	context->configuration.ParticlesDiscriminationStateCP_PUSH.baseState.paramIn_Linkrange_numLinks = 1;
	context->configuration.DilateAllCaseCP_PUSH.baseState.paramIn_Radius_numLinks = 1;
	context->configuration.GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramIn_Cutoff_numLinks = 1;
	context->configuration.ParticlesDiscriminationStateCP_PUSH.baseState.paramIn_Cutoff_numLinks = 1;
	context->configuration.LibraryDataReader.baseState.paramIn_ImgWidth_numLinks = 1;
	context->configuration.DilateAllCaseCP_PUSH.baseState.paramOut_Status_numLinks = 1;
	context->configuration.LinkParticlesStateCPAutoNext_PUSH.baseState.paramOut_Status_numLinks = 1;
	context->configuration.ConvolveAllCaseCP_PUSH.baseState.paramOut_Status_numLinks = 1;
	context->configuration.LibraryDataReader.baseState.paramOut_Status_numLinks = 1;
	context->configuration.GenerateTrajectoriesStateCPAutoNextNew_PUSH.baseState.paramOut_Status_numLinks = 1;
	context->configuration.ParticlesDiscriminationStateCP_PUSH.baseState.paramOut_Status_numLinks = 1;
	context->configuration.FindParticlesCPNewAutoNext_PUSH_2.baseState.paramOut_Status_numLinks = 1;
	context->configuration.PositionRefinementCP_PUSH_2.baseState.paramOut_Status_numLinks = 1;
	context->configuration.FindThresholdCP.baseState.paramOut_Status_numLinks = 1;

	/* Configuration connect() function call */
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_connect(&context->configuration);

}

/* Startup function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_startup(DSPEApplication *application) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application*) application;
	/* Base earlyalloc() function call */
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_earlyAlloc(context);

	/* Base alloc() function call */
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_alloc(context);

	/* Initialize gate values */
	initValues(context);

	/* Base earlyconnect() function call */
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_earlyConnect(context);

	/* Base connect() function call */
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_connect(context);

	/* Configuration startup() function call */
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_startup(&context->configuration);

}

/* Preprocess function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_preProcess(DSPEComponent *component) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application*) component;

	/* Configuration preprocess() function call */
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_preProcess(&context->configuration);

	sendInitEvent((DSPEEventsUnit*) &context->configuration.LibraryDataReader, 0);

}

/* Process function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_process(DSPEComponent *component) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application*) component;

	/* Configuration process() function call */
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_process(&context->configuration);

}

/* Postprocess function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_postProcess(DSPEComponent *component) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application*) component;

	/* Configuration postprocess() function call */
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_postProcess(&context->configuration);

}

/* Reset function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_reset(ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *context) {
	/* Configuration reset() function call */
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_reset(&context->configuration);
	/* Initialize gate values */
	initValues(context);

	/* reset Handlers */
	memoryManager_resetHandlerPool((DSPEElement*) context, CAST_TO_OWNER((DSPEApplication*) context));

}

/* Shutdown function */
void ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_shutdown(DSPEApplication *application) {
	ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application *context = (ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application*) application;
	/* Configuration shutdown() function call */
	ParticleTrackerDllPTCoproc_3_PUSH_CoprocScheduler_shutdown(&context->configuration);

	/* Contained configuration unlinked input parameter places dispose */
	ParticleTrackerDllBoolGate_StandardGate_dispose((DSPEElement*) context, context->GenerateTrajectoriesStateCPAutoNextNew_PUSH_paramIn_Verbose_unlinked);

	/* Application input parameters places dispose */
	ParticleTrackerDllIntGate_StandardGate_dispose((DSPEElement*) context, context->paramIn_Radius_place);
	ParticleTrackerDllRealGate_CustomGate_dispose((DSPEElement*) context, context->paramIn_Cutoff_place);
	ParticleTrackerDllRealGate_CustomGate_dispose((DSPEElement*) context, context->paramIn_Percentile_place);
	ParticleTrackerDllRealGate_CustomGate_dispose((DSPEElement*) context, context->paramIn_Displacement_place);
	ParticleTrackerDllIntGate_StandardGate_dispose((DSPEElement*) context, context->paramIn_Linkrange_place);
	ParticleTrackerDllIntGate_StandardGate_dispose((DSPEElement*) context, context->paramIn_ImgsNum_place);
	ParticleTrackerDllIntGate_StandardGate_dispose((DSPEElement*) context, context->paramIn_ImgWidth_place);
	ParticleTrackerDllIntGate_StandardGate_dispose((DSPEElement*) context, context->paramIn_ImgHeight_place);
	ParticleTrackerDllRealGate_CustomGate_dispose((DSPEElement*) context, context->paramIn_ImgMin_place);
	ParticleTrackerDllRealGate_CustomGate_dispose((DSPEElement*) context, context->paramIn_ImgMax_place);

	/* Dispose handlers */
	memoryManager_disposeHandlerPool((DSPEElement*) context, CAST_TO_OWNER((DSPEApplication*) context));

	/* Dispose application ID */
	memorySupport_dispose(context->ID);

}

