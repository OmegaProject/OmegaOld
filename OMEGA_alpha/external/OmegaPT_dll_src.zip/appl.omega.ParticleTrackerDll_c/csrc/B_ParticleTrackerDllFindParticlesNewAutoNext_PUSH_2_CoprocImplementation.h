/**
 * File: B_ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef B_ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_h
#define B_ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_h

#include "CoprocGround.h"
#include "DSPEXTElements.h"

#include "B_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "B_ParticleTrackerDllPTFrameGate_MessageGate.h"
#include "B_ParticleTrackerDllPTThresholdGate_MessageGate.h"
#include "B_ParticleTrackerDllNextGate_SignalGate.h"
#include "B_ParticleTrackerDllIntGate_StandardGate.h"
#include "B_ParticleTrackerDllStatusGate_StringGate.h"

#include "B_ParticleTrackerDllTracker_Requirement.h"

/* Coproc Operation type definition */
typedef struct ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op;

/* This struct may contain user defined additional state variables */
struct ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op {

	DSPEProfileCoprocOp coprocOp;

	/* BlockSize */
	size_t blockSize;

	/* CoprocOp Buffer support */
	ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op *next;
	unsigned int processed;

	//Place additional state variables after this line -- SYD-ADDITIONAL-STATE-START
	int* particles;
	size_t prevParticlesSize;
	//SYD-ADDITIONAL-STATE-END  -- Place additional state variables before this line


	/* Transfered Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame;
	ParticleTrackerDllPTThresholdGate_MessageGate *dataIn_PTThreshold;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame;


	/* Transfered Parameter gates */
	ParticleTrackerDllIntGate_StandardGate *paramIn_stop;
	ParticleTrackerDllIntGate_StandardGate *paramIn_Linkrange;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status;

};



/* Functional implementation state type definition */
typedef struct ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_func ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_func;

/* This struct may contain user defined additional state variables for the unit */
struct ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_func {

	DSPECoprocImplementation coprocImplementation;

	//Place local state variables after this line -- SYD-LOCAL-STATE-START
	//SYD-LOCAL-STATE-END  -- Place local state variables before this line
};

/******************************************************************************
 * FOLLOWING CODE IS NOT INTENDED TO BE MODIFIED BY USERS                     *
 ******************************************************************************/

/* State type definition */
typedef struct ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation;

/* State definition */ 
struct ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation {

	/* Functional implementation state */
	ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_func functionalState;

	/* Current working op state var */
	ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op *curOp;

	DSPEOpInQueue *opQueue;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame;
	ParticleTrackerDllPTThresholdGate_MessageGate *dataIn_PTThreshold;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame;

	/* Parameter gates */
	ParticleTrackerDllIntGate_StandardGate *paramIn_stop;
	ParticleTrackerDllIntGate_StandardGate *paramIn_Linkrange;
	ParticleTrackerDllIntGate_StandardGate *paramOut_stop;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status;


	/* numLinks flags */
	unsigned int dataIn_SequenceValues_numLinks;
	unsigned int dataIn_PTFrame_numLinks;
	unsigned int dataIn_PTThreshold_numLinks;
	unsigned int dataOut_PTFrame_numLinks;
	unsigned int paramIn_next_numLinks;
	unsigned int paramIn_stop_numLinks;
	unsigned int paramIn_Linkrange_numLinks;
	unsigned int paramOut_next_numLinks;
	unsigned int paramOut_stop_numLinks;
	unsigned int paramOut_Status_numLinks;

	/* State */
	unsigned int state;

	/* opBuffer support */
	ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op *opPoolHead;
	ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op *opPoolTail;
	size_t opPoolNumElements;
	ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op *opBufferHead;
	ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op *opBufferTail;
	size_t opBufferNumElements;

	unsigned int opsBusy;
	unsigned int waitingInNext;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

/* Preprocess function */
void ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_preProcess(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context);

/**
 * ArmOp function
 */
void ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_armOp(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context);

/* Process function */
void ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_process(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_op *context);

/**
 * DismissOp function
 */
void ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_dismissOp(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context);

/* Postprocess function */
void ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation_postProcess(ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
