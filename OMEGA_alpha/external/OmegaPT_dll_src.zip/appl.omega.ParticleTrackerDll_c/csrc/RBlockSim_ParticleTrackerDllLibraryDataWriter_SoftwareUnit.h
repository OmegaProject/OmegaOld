/**
 * File: RBlockSim_ParticleTrackerDllLibraryDataWriter_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef RBlockSim_ParticleTrackerDllLibraryDataWriter_SoftwareUnit_h
#define RBlockSim_ParticleTrackerDllLibraryDataWriter_SoftwareUnit_h

#include "B_ParticleTrackerDllLibraryDataWriter_StateImplementation.h"
#include "B_ParticleTrackerDllLibraryDataWriter_SoftwareUnit.h"
#include "RBlock_ParticleTrackerDllTrajectory_MessageGate.h"

/* Block SoftwareUnit state type definition */
typedef struct ParticleTrackerDllLibraryDataWriter_SoftwareUnit_blockSim ParticleTrackerDllLibraryDataWriter_SoftwareUnit_blockSim;

/* Block SoftwareUnit state definition */
struct ParticleTrackerDllLibraryDataWriter_SoftwareUnit_blockSim {

	/* Base unit state */
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllLibraryDataWriter_StateImplementation implState;
	
	/* Block size */
	size_t blockSize;

	/* Samples to process */
	size_t samplesToProcess;

	/* Data transit queues */
	size_t dataIn_Trajectory_transitNumElements;
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *dataIn_Trajectory_transitHead;
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *dataIn_Trajectory_transitTail;
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *dataIn_Trajectory_curTransit;
	unsigned int dataIn_Trajectory_curTransitIndex;

	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllTrajectory_MessageGate *dataIn_Trajectory_unlinked;

};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_transitEventBlockSim(DSPEQueueUnit *unit);

size_t ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getTransitNumElementsBlockSim(DSPEQueueUnit *unit, unsigned int ID);

size_t ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getTransitNumElementsBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getFirstTransitBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getCurTransitBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_dismissEventBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_dismissAllEventsBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_armEventBlockSim(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_postEventBlockSim(DSPEEventsUnit *unit, unsigned int ID);

/* Earlyalloc function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_earlyAllocBlockSim(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_blockSim *context);

/* Alloc function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_allocBlockSim(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_blockSim *context);

/* Earlyconnect function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_earlyConnectBlockSim(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_blockSim *context);

/* Connect function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_connectBlockSim(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_blockSim *context);

/* Startup function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_startupBlockSim(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_blockSim *context);

/* Preprocess function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_preProcessBlockSim(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_processBlockSim(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_postProcessBlockSim(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_resetBlockSim(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_blockSim *context);

/* Shutdown function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_shutdownBlockSim(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_blockSim *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
