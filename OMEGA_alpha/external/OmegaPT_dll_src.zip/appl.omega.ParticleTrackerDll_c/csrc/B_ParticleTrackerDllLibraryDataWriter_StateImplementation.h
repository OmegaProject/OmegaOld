/**
 * File: B_ParticleTrackerDllLibraryDataWriter_StateImplementation.h
 *
 * @author Loris
 * @created Thu May 26 10:23:50 CEST 2011
 */
#ifndef B_ParticleTrackerDllLibraryDataWriter_StateImplementation_h
#define B_ParticleTrackerDllLibraryDataWriter_StateImplementation_h

#include "DSPEXTElements.h"

#include "B_ParticleTrackerDllTrajectory_MessageGate.h"
#include "B_ParticleTrackerDllNextGate_SignalGate.h"
#include "B_ParticleTrackerDllIntGate_StandardGate.h"

/* Functional implementation state type definition */
typedef struct ParticleTrackerDllLibraryDataWriter_StateImplementation_func ParticleTrackerDllLibraryDataWriter_StateImplementation_func;

/* This struct may contain user defined additional state variables for the unit */
struct ParticleTrackerDllLibraryDataWriter_StateImplementation_func {

	DSPEStateImplementation stateImplementation;

	//Place additional state variables after this line -- SYD-ADDITIONAL-STATE-START
	int receivedTrajectories;
	unsigned int lastFrameProcessed;
	//SYD-ADDITIONAL-STATE-END  -- Place additional state variables before this line

};

/******************************************************************************
 * FOLLOWING CODE IS NOT INTENDED TO BE MODIFIED BY USERS                     *
 ******************************************************************************/

/* State type definition */
typedef struct ParticleTrackerDllLibraryDataWriter_StateImplementation ParticleTrackerDllLibraryDataWriter_StateImplementation;

/* State definition */ 
struct ParticleTrackerDllLibraryDataWriter_StateImplementation {

	/* Functional implementation state */
	ParticleTrackerDllLibraryDataWriter_StateImplementation_func functionalState;


	/* Data gates */
	ParticleTrackerDllTrajectory_MessageGate *dataIn_Trajectory;

	/* Parameter gates */
	ParticleTrackerDllIntGate_StandardGate *paramIn_FoundTrajectories;
	ParticleTrackerDllIntGate_StandardGate *paramOut_stop;


	/* numLinks flags */
	unsigned int dataIn_Trajectory_numLinks;
	unsigned int paramIn_LastFrameProcessed_numLinks;
	unsigned int paramIn_FoundTrajectories_numLinks;
	unsigned int paramOut_next_numLinks;
	unsigned int paramOut_stop_numLinks;

	/* State */
	unsigned int state;

};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

/* Startup function */
void ParticleTrackerDllLibraryDataWriter_StateImplementation_startup(ParticleTrackerDllLibraryDataWriter_StateImplementation *context);

/* Preprocess function */
void ParticleTrackerDllLibraryDataWriter_StateImplementation_preProcess(ParticleTrackerDllLibraryDataWriter_StateImplementation *context);

/* Process function */
void ParticleTrackerDllLibraryDataWriter_StateImplementation_process(ParticleTrackerDllLibraryDataWriter_StateImplementation *context);

/* Shutdown function */
void ParticleTrackerDllLibraryDataWriter_StateImplementation_shutdown(ParticleTrackerDllLibraryDataWriter_StateImplementation *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
