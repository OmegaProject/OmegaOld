/**
 * File: B_ParticleTrackerDllPTThresholdGate_MessageGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#include "MemoryManager.h"

#include "B_ParticleTrackerDllPTThresholdGate_MessageGate.h"

#include "B_ParticleTrackerDllTracker_Requirement.h"

/**
 * Allocate. This function will be used to allocate memory to the gate.
 */
ParticleTrackerDllPTThresholdGate_MessageGate ParticleTrackerDllPTThresholdGate_MessageGate_allocateValue(DSPEElement *context) {
//Place implementation after this line -- SYD-ALLOCATEVALUE-START
	return (ParticleTrackerDllPTThresholdGate_MessageGate) memorySupport_allocate(sizeof(PTThreshold));
//SYD-ALLOCATEVALUE-END -- Place implementation before this line
}

/**
 * Initialise. This function will be used to initialise the given gate.
 */
void ParticleTrackerDllPTThresholdGate_MessageGate_initValue(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate data) {
//Place implementation after this line -- SYD-INITVALUE-START
	data->id = -1;
	data->threshold = 0.0;
//SYD-INITVALUE-END -- Place implementation before this line
}

/**
 * Copy. This function will be used to copy data between the given source and destination gates.
 */
void ParticleTrackerDllPTThresholdGate_MessageGate_copyValue(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate destination, ParticleTrackerDllPTThresholdGate_MessageGate source) {
//Place implementation after this line -- SYD-COPYVALUE-START
	memorySupport_copyBlock(destination, source, sizeof(PTThreshold));
//SYD-COPYVALUE-END -- Place implementation before this line
}

/**
 * Dispose. This function will be used to free the given gate memory.
 */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeValue(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate data) {
//Place implementation after this line -- SYD-DISPOSEVALUE-START
	memorySupport_dispose(data);
//SYD-DISPOSEVALUE-END -- Place implementation before this line
}

/******************************************************************************
 * FOLLOWING CODE IS NOT INTENDED TO BE MODIFIED BY USERS                     *
 ******************************************************************************/

/* AllocateManaged function */
void ParticleTrackerDllPTThresholdGate_MessageGate_allocateManaged(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate *anchor) {
	*anchor = ParticleTrackerDllPTThresholdGate_MessageGate_allocateValue(context);
}
/* InitManaged function */
void ParticleTrackerDllPTThresholdGate_MessageGate_initManaged(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate anchor) {
	ParticleTrackerDllPTThresholdGate_MessageGate_initValue(context, anchor);
}

/* DisposeManaged function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeManaged(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate anchor) {
	ParticleTrackerDllPTThresholdGate_MessageGate_disposeValue(context, anchor);
}

/* AllocateGroupManaged function */
void ParticleTrackerDllPTThresholdGate_MessageGate_allocateGroupManaged(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate **anchor, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllPTThresholdGate_MessageGate_allocateManaged(context, anchor[i]);
	}
}
/* InitGroupManaged function */
void ParticleTrackerDllPTThresholdGate_MessageGate_initGroupManaged(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate **anchor, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllPTThresholdGate_MessageGate_initValue(context, *anchor[i]);
	}
}

/* DisposeGroupManaged function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeGroupManaged(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate **anchor, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllPTThresholdGate_MessageGate_disposeValue(context, *anchor[i]);
	}
}

/* eventPool initialization function */
ParticleTrackerDllPTThresholdGate_MessageGate_pool* ParticleTrackerDllPTThresholdGate_MessageGate_initPool(const DSPEOwner *owner) {
	DSPEPoolHandler *handler = memoryManager_getPoolHandler(owner);
	ParticleTrackerDllPTThresholdGate_MessageGate_pool *pool = (ParticleTrackerDllPTThresholdGate_MessageGate_pool*) memoryManager_getPool(handler, &ParticleTrackerDllPTThresholdGate_MessageGate_allocate);
	/* lazy initialization */
	if (pool == NULL) {
		pool = (ParticleTrackerDllPTThresholdGate_MessageGate_pool*) memoryManager_allocate(CAST_TO_ELEMENT(owner), sizeof(ParticleTrackerDllPTThresholdGate_MessageGate_pool));
		initDSPEElement((DSPEElement*) pool, (DSPEElement*) handler);
		initDSPEBaseEventsPool((DSPEBaseEventsPool*) pool);
		pool->eventNumElements = 0;
		pool->headEvent = NULL;
		pool->tailEvent = NULL;
		pool->cloneNumElements = 0;
		pool->headClone = NULL;
		pool->tailClone = NULL;
		((DSPEEventsPool*) pool)->gateDefID = &ParticleTrackerDllPTThresholdGate_MessageGate_allocate;
		((DSPEEventsPool*) pool)->preAlloc = ParticleTrackerDllPTThresholdGate_MessageGate_preAllocPool;
		((DSPEEventsPool*) pool)->reset = ParticleTrackerDllPTThresholdGate_MessageGate_resetPool;
		((DSPEEventsPool*) pool)->dispose = ParticleTrackerDllPTThresholdGate_MessageGate_disposePool;
		memoryManager_addPool(handler, (DSPEBaseEventsPool*) pool);
	}
	return pool;
}

/* eventPool preAlloc function */
void ParticleTrackerDllPTThresholdGate_MessageGate_preAllocPool(DSPEEventsPool *pool, size_t size) {
	ParticleTrackerDllPTThresholdGate_MessageGate_pool *concretePool = (ParticleTrackerDllPTThresholdGate_MessageGate_pool*) pool;
	register size_t i;
	ParticleTrackerDllPTThresholdGate_MessageGate_event *firstEvent = NULL;
	ParticleTrackerDllPTThresholdGate_MessageGate_event *lastEvent = NULL;
	ParticleTrackerDllPTThresholdGate_MessageGate_event *currEvent = NULL;
	
	firstEvent = ParticleTrackerDllPTThresholdGate_MessageGate_allocate(concretePool);
	lastEvent = firstEvent;
	ParticleTrackerDllPTThresholdGate_MessageGate_initialize(firstEvent);
	
	/* size - 1 because of allocation of first */
	for (i = 0; i < size - 1; i++) {
		currEvent = ParticleTrackerDllPTThresholdGate_MessageGate_allocate(concretePool);
		ParticleTrackerDllPTThresholdGate_MessageGate_initialize(currEvent);
	
		((DSPEEvent*) lastEvent)->next = (DSPEEvent*) currEvent;
		lastEvent = currEvent;
	}

	concretePool->headEvent = firstEvent;
	concretePool->tailEvent = lastEvent;
	concretePool->eventNumElements = size;
}

/* eventPool reset function */
void ParticleTrackerDllPTThresholdGate_MessageGate_resetPool(DSPEEventsPool *pool) {
	ParticleTrackerDllPTThresholdGate_MessageGate_pool *concretePool = (ParticleTrackerDllPTThresholdGate_MessageGate_pool*) pool;
	register size_t i;
	ParticleTrackerDllPTThresholdGate_MessageGate_event *event = concretePool->headEvent;
	for (i = 0; i < concretePool->eventNumElements; i++) {
		ParticleTrackerDllPTThresholdGate_MessageGate_initialize(event);
		event = (ParticleTrackerDllPTThresholdGate_MessageGate_event*) ((DSPEEvent*) event)->next;
	}
}

/* Allocate function */
ParticleTrackerDllPTThresholdGate_MessageGate_event* ParticleTrackerDllPTThresholdGate_MessageGate_allocate(ParticleTrackerDllPTThresholdGate_MessageGate_pool *pool) {
	ParticleTrackerDllPTThresholdGate_MessageGate_pool *gatePool = (ParticleTrackerDllPTThresholdGate_MessageGate_pool*) pool;
	ParticleTrackerDllPTThresholdGate_MessageGate_event *event = NULL;
	switch (gatePool->eventNumElements) {
	case 0:
		event = (ParticleTrackerDllPTThresholdGate_MessageGate_event*) memorySupport_allocate(sizeof(ParticleTrackerDllPTThresholdGate_MessageGate_event));
		event->value = (ParticleTrackerDllPTThresholdGate_MessageGate*) memorySupport_allocate(sizeof(ParticleTrackerDllPTThresholdGate_MessageGate));
		initDSPEEvent((DSPEEvent*) event);
		((DSPEEvent*) event)->pool = (DSPEEventsPool*) gatePool;
		((DSPEEvent*) event)->dispose = ParticleTrackerDllPTThresholdGate_MessageGate_dispose;
		((DSPEEvent*) event)->clone = ParticleTrackerDllPTThresholdGate_MessageGate_clone;
		ParticleTrackerDllPTThresholdGate_MessageGate_create(event);
		ParticleTrackerDllPTThresholdGate_MessageGate_initialize(event);
		return event;
	case 1:
		event = gatePool->headEvent;
		gatePool->headEvent = NULL;
		gatePool->tailEvent = NULL;
		gatePool->eventNumElements = 0;
		((DSPEEvent*) event)->next = NULL;
		return event;
	default:
		event = gatePool->headEvent;
		gatePool->headEvent = (ParticleTrackerDllPTThresholdGate_MessageGate_event*) ((DSPEEvent*) event)->next;
		gatePool->eventNumElements--;
		((DSPEEvent*) event)->next = NULL;
		return event;
	}
}

/* Create function */
void ParticleTrackerDllPTThresholdGate_MessageGate_create(ParticleTrackerDllPTThresholdGate_MessageGate_event *event) {
	*event->value = ParticleTrackerDllPTThresholdGate_MessageGate_allocateValue((DSPEElement*) ((DSPEEvent*) event)->pool);
	ParticleTrackerDllPTThresholdGate_MessageGate_initValue((DSPEElement*) ((DSPEEvent*) event)->pool, *event->value);
	event->anchor = *event->value;
}

/* Initialise function */
void ParticleTrackerDllPTThresholdGate_MessageGate_initialize(ParticleTrackerDllPTThresholdGate_MessageGate_event *event) {
	ParticleTrackerDllPTThresholdGate_MessageGate_initValue((DSPEElement*) ((DSPEEvent*) event)->pool, *event->value);
}

/**
 * Copy function
 */
void ParticleTrackerDllPTThresholdGate_MessageGate_copy(ParticleTrackerDllPTThresholdGate_MessageGate_event *event, ParticleTrackerDllPTThresholdGate_MessageGate value) {
	ParticleTrackerDllPTThresholdGate_MessageGate_copyValue((DSPEElement*) ((DSPEEvent*) event)->pool, *event->value, value);
}

/* Clone event function */
DSPEEvent* ParticleTrackerDllPTThresholdGate_MessageGate_clone(DSPEEvent *event) {
	ParticleTrackerDllPTThresholdGate_MessageGate_pool *gatePool = (ParticleTrackerDllPTThresholdGate_MessageGate_pool*) event->pool;
	ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent *clone = NULL;

	switch (gatePool->cloneNumElements) {
	case 0:
		clone = (ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent));
		((DSPEEvent*) clone)->dispose = ParticleTrackerDllPTThresholdGate_MessageGate_disposeClone;
		((DSPEEvent*) clone)->clone = ParticleTrackerDllPTThresholdGate_MessageGate_clone;
		((DSPEEvent*) clone)->blockSize = event->blockSize;
		((DSPEEvent*) clone)->pool = event->pool;
		break;
	case 1:
		clone = gatePool->headClone;
		gatePool->headClone = NULL;
		gatePool->tailClone = NULL;
		gatePool->cloneNumElements = 0;
		break;
	default:
		clone = gatePool->headClone;
		gatePool->headClone = (ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent*) ((DSPEEvent*) clone)->next;
		gatePool->cloneNumElements--;
		break;
	}

	event->refCount++;
	clone->original = event;
	
	((DSPEEvent*) clone)->next = NULL;

	((ParticleTrackerDllPTThresholdGate_MessageGate_event*) clone)->value = ((ParticleTrackerDllPTThresholdGate_MessageGate_event*) event)->value;
	
	return (DSPEEvent*) clone;
}

/* Dispose function */
void ParticleTrackerDllPTThresholdGate_MessageGate_dispose(DSPEEvent *event) {
	ParticleTrackerDllPTThresholdGate_MessageGate_pool *gatePool = (ParticleTrackerDllPTThresholdGate_MessageGate_pool*) event->pool;
	if (event->refCount == 1) {
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->eventNumElements) {
		case 0:
			gatePool->headEvent = (ParticleTrackerDllPTThresholdGate_MessageGate_event*) event;
			gatePool->tailEvent = (ParticleTrackerDllPTThresholdGate_MessageGate_event*) event;
			gatePool->eventNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailEvent)->next = (DSPEEvent*) event;
			gatePool->tailEvent = (ParticleTrackerDllPTThresholdGate_MessageGate_event*) event;
			gatePool->eventNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* Dispose clone function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeClone(DSPEEvent *event) {
	ParticleTrackerDllPTThresholdGate_MessageGate_pool *gatePool = (ParticleTrackerDllPTThresholdGate_MessageGate_pool*) event->pool;
	DSPEEvent *original = (DSPEEvent*) ((ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent*) event)->original;
	if (event->refCount == 1) {
		original->dispose(original);
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->cloneNumElements) {
		case 0:
			gatePool->headClone = (ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent*) event;
			gatePool->tailClone = (ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent*) event;
			gatePool->cloneNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailClone)->next = (DSPEEvent*) event;
			gatePool->tailClone = (ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent*) event;
			gatePool->cloneNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* Destroy function */
void ParticleTrackerDllPTThresholdGate_MessageGate_destroy(ParticleTrackerDllPTThresholdGate_MessageGate_event *event) {
	ParticleTrackerDllPTThresholdGate_MessageGate_disposeValue((DSPEElement*) ((DSPEEvent*) event)->pool, *event->value);
}

/* eventPool dispose function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposePool(DSPEEventsPool *pool) {
	ParticleTrackerDllPTThresholdGate_MessageGate_pool *thisPool = (ParticleTrackerDllPTThresholdGate_MessageGate_pool*) pool;
	register size_t i;
	DSPEEvent *tmp  = NULL;
	/* dispose events */
	for (i = 0; i < thisPool->eventNumElements; i++) {
		tmp = (DSPEEvent*) thisPool->headEvent;
		thisPool->headEvent = (ParticleTrackerDllPTThresholdGate_MessageGate_event*) tmp->next;
		tmp->next = NULL;
		ParticleTrackerDllPTThresholdGate_MessageGate_destroy((ParticleTrackerDllPTThresholdGate_MessageGate_event*) tmp);
		memorySupport_dispose(((ParticleTrackerDllPTThresholdGate_MessageGate_event*) tmp)->value);
		memorySupport_dispose(tmp);
	}
	/* dispose clones */
	for (i = 0; i < thisPool->cloneNumElements; i++) {
		tmp = (DSPEEvent*) thisPool->headClone;
		thisPool->headClone = (ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent*) tmp->next;
		tmp->next = NULL;
		((ParticleTrackerDllPTThresholdGate_MessageGate_event*) tmp)->value = NULL;
		memorySupport_dispose(tmp);
	}
	/* dispose pool */
	memorySupport_dispose(thisPool);
}

/* Allocate function */
ParticleTrackerDllPTThresholdGate_MessageGate* ParticleTrackerDllPTThresholdGate_MessageGate_allocateUnlinked(DSPEElement *context) {
	return memoryManager_allocate(context, sizeof(ParticleTrackerDllPTThresholdGate_MessageGate));
}

/* Initialise function */
void ParticleTrackerDllPTThresholdGate_MessageGate_initializeUnlinked(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate *place) {
	*place = PARTICLETRACKERDLLPTTHRESHOLDGATE_MESSAGEGATE_DEFAULTVALUE;
}

/* Set function */
void ParticleTrackerDllPTThresholdGate_MessageGate_set(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate *place, ParticleTrackerDllPTThresholdGate_MessageGate *value) {
	*place = *value;
}

/* Dispose function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeUnlinked(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate *place) {
	memorySupport_dispose(place);
}

/* groupEventPool initialization function */
ParticleTrackerDllPTThresholdGate_MessageGate_groupPool* ParticleTrackerDllPTThresholdGate_MessageGate_initGroupPool(const DSPEOwner *owner, size_t groupSize) {
	DSPEPoolHandler *handler = memoryManager_getPoolHandler(owner);
	ParticleTrackerDllPTThresholdGate_MessageGate_groupPool *pool = (ParticleTrackerDllPTThresholdGate_MessageGate_groupPool*) memoryManager_getGroupPool(handler, &ParticleTrackerDllPTThresholdGate_MessageGate_allocateGroup, groupSize);
	/* lazy initialization */
	if (pool == NULL) {
		pool = (ParticleTrackerDllPTThresholdGate_MessageGate_groupPool*) memoryManager_allocate(CAST_TO_ELEMENT(owner), sizeof(ParticleTrackerDllPTThresholdGate_MessageGate_groupPool));
		initDSPEElement((DSPEElement*) pool, (DSPEElement*) handler);
		initDSPEGroupEventsPool((DSPEGroupEventsPool*) pool);
		pool->eventNumElements = 0;
		pool->headEvent = NULL;
		pool->tailEvent = NULL;
		pool->cloneNumElements = 0;
		pool->headClone = NULL;
		pool->tailClone = NULL;
		pool->containerNumElements = 0;
		pool->headContainer = NULL;
		pool->tailContainer = NULL;
		((DSPEEventsPool*) pool)->gateDefID = &ParticleTrackerDllPTThresholdGate_MessageGate_allocateGroup;
		((DSPEEventsPool*) pool)->preAlloc = ParticleTrackerDllPTThresholdGate_MessageGate_preAllocGroupPool;
		((DSPEEventsPool*) pool)->reset = ParticleTrackerDllPTThresholdGate_MessageGate_resetGroupPool;
		((DSPEEventsPool*) pool)->dispose = ParticleTrackerDllPTThresholdGate_MessageGate_disposeGroupPool;
		((DSPEGroupEventsPool*) pool)->groupSize = groupSize;
		memoryManager_addGroupPool(handler, (DSPEGroupEventsPool*) pool);
	}
	return pool;
}

/* eventPool preAlloc function */
void ParticleTrackerDllPTThresholdGate_MessageGate_preAllocGroupPool(DSPEEventsPool *pool, size_t size) {
	ParticleTrackerDllPTThresholdGate_MessageGate_groupPool *concretePool = (ParticleTrackerDllPTThresholdGate_MessageGate_groupPool*) pool;
	DSPEEventsPool *childPool = NULL;
	register size_t i, j;
	ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *firstEvent = NULL;
	ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *lastEvent = NULL;
	ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *currEvent = NULL;
	
	/* preAlloc children */
	childPool = (DSPEEventsPool*) ((DSPEGroupEventsPool*) pool)->groupsHead;
	for (i = 0; i < ((DSPEGroupEventsPool*) pool)->groupsNumElements; i++) {
		childPool->preAlloc(childPool, size);
		childPool = childPool->next;
	}

	firstEvent = ParticleTrackerDllPTThresholdGate_MessageGate_allocateGroup(concretePool);
	lastEvent = firstEvent;
	for (i = 0; i < ((DSPEGroupEventsPool*) pool)->groupSize - 1; i++)
		ParticleTrackerDllPTThresholdGate_MessageGate_initializeGroup(firstEvent, i);
	
	/* size - 2 because of allocation of first */
	for (i = 0; i < size - 1; i++) {
		currEvent = ParticleTrackerDllPTThresholdGate_MessageGate_allocateGroup(concretePool);
		for (j = 0; j < ((DSPEGroupEventsPool*) pool)->groupSize; j++) {
			ParticleTrackerDllPTThresholdGate_MessageGate_initializeGroup(currEvent, j);
		}
	
		((DSPEEvent*) lastEvent)->next = (DSPEEvent*) currEvent;
		lastEvent = currEvent;
	}

	concretePool->headEvent = firstEvent;
	concretePool->tailEvent = lastEvent;
	concretePool->eventNumElements = size;
}

/* eventPool reset function */
void ParticleTrackerDllPTThresholdGate_MessageGate_resetGroupPool(DSPEEventsPool *pool) {
	ParticleTrackerDllPTThresholdGate_MessageGate_groupPool *concretePool = (ParticleTrackerDllPTThresholdGate_MessageGate_groupPool*) pool;
	DSPEEventsPool *childPool = NULL;
	register size_t i, j;
	ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *event = concretePool->headEvent;
	/* reset children */
	childPool = (DSPEEventsPool*) ((DSPEGroupEventsPool*) pool)->groupsHead;
	for (i = 0; i < ((DSPEGroupEventsPool*) pool)->groupsNumElements; i++) {
		childPool->reset(childPool);
		childPool = childPool->next;
	}

	/* reset current pool events */
	event = concretePool->headEvent;
	for (i = 0; i < concretePool->eventNumElements; i++) {
		for (j = 0; j < ((DSPEGroupEventsPool*) pool)->groupSize - 1; j++)
			ParticleTrackerDllPTThresholdGate_MessageGate_initializeGroup(event, j);
		event = (ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent*) ((DSPEEvent*) event)->next;
	}

}

/* AllocateGroup function */
ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent* ParticleTrackerDllPTThresholdGate_MessageGate_allocateGroup(ParticleTrackerDllPTThresholdGate_MessageGate_groupPool *grpPool) {
	ParticleTrackerDllPTThresholdGate_MessageGate_groupPool *gatePool = (ParticleTrackerDllPTThresholdGate_MessageGate_groupPool*) grpPool;
	ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *event = NULL;
	register size_t i;
	switch (gatePool->eventNumElements) {
	case 0:
		event = (ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent));
		initDSPEGroupEvent((DSPEGroupEvent*) event);
		((DSPEEvent*) event)->pool = (DSPEEventsPool*) grpPool;
		((DSPEEvent*) event)->dispose = ParticleTrackerDllPTThresholdGate_MessageGate_disposeGroup;
		((DSPEEvent*) event)->clone = ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroup;
		((DSPEGroupEvent*) event)->groupSize = ((DSPEGroupEventsPool*) gatePool)->groupSize;
		event->value = (ParticleTrackerDllPTThresholdGate_MessageGate**) memoryManager_allocate((DSPEElement*) gatePool, ((DSPEGroupEventsPool*) gatePool)->groupSize * sizeof(ParticleTrackerDllPTThresholdGate_MessageGate*));
		for (i = 0; i < ((DSPEGroupEventsPool*) gatePool)->groupSize; i++) {
			ParticleTrackerDllPTThresholdGate_MessageGate_createGroup(event, i);
			ParticleTrackerDllPTThresholdGate_MessageGate_initializeGroup(event, i);
		}
		return event;
	case 1:
		event = gatePool->headEvent;
		gatePool->headEvent = NULL;
		gatePool->tailEvent = NULL;
		gatePool->eventNumElements = 0;
		((DSPEEvent*) event)->next = NULL;
		return event;
	default:
		event = gatePool->headEvent;
		gatePool->headEvent = (ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent*) ((DSPEEvent*) event)->next;
		gatePool->eventNumElements--;
		((DSPEEvent*) event)->next = NULL;
		return event;
	}
}

/* CreateGroup function */
void ParticleTrackerDllPTThresholdGate_MessageGate_createGroup(ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *event, size_t index) {
	event->value[index] = (ParticleTrackerDllPTThresholdGate_MessageGate*) memoryManager_allocate((DSPEElement*) ((DSPEEvent*) event)->pool, sizeof(ParticleTrackerDllPTThresholdGate_MessageGate));
	*event->value[index] = ParticleTrackerDllPTThresholdGate_MessageGate_allocateValue((DSPEElement*) ((DSPEEvent*) event)->pool);
}

/* InitialiseGroup function */
void ParticleTrackerDllPTThresholdGate_MessageGate_initializeGroup(ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *event, size_t index) {
	ParticleTrackerDllPTThresholdGate_MessageGate_initValue((DSPEElement*) ((DSPEEvent*) event)->pool, *event->value[index]);
}

/**
 * Copy function
 */
void ParticleTrackerDllPTThresholdGate_MessageGate_copyGroup(ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *event, ParticleTrackerDllPTThresholdGate_MessageGate value, size_t index) {
	ParticleTrackerDllPTThresholdGate_MessageGate_copyValue((DSPEElement*) ((DSPEEvent*) event)->pool, *event->value[index], value);
}

/* CloneGroup event function */
DSPEEvent* ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroup(DSPEEvent *event) {
	register size_t i;
	ParticleTrackerDllPTThresholdGate_MessageGate_groupPool *gatePool = (ParticleTrackerDllPTThresholdGate_MessageGate_groupPool*) event->pool;
	ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroupEvent *clone = NULL;
	
	switch (gatePool->cloneNumElements) {
	case 0:
		clone = (ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroupEvent*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroupEvent));
		((ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent*) clone)->value = (ParticleTrackerDllPTThresholdGate_MessageGate**) memoryManager_allocate((DSPEElement*) gatePool, ((DSPEGroupEvent*) event)->groupSize * sizeof(ParticleTrackerDllPTThresholdGate_MessageGate*));
		((DSPEEvent*) clone)->dispose = ParticleTrackerDllPTThresholdGate_MessageGate_disposeGroupClone;
		((DSPEEvent*) clone)->clone = ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroup;
		((DSPEEvent*) clone)->pool = event->pool;
		((DSPEEvent*) clone)->blockSize = event->blockSize;
		((DSPEGroupEvent*) clone)->groupSize = ((DSPEGroupEvent*) event)->groupSize;
		break;
	case 1:
		clone = gatePool->headClone;
		gatePool->headClone = NULL;
		gatePool->tailClone = NULL;
		gatePool->cloneNumElements = 0;
		break;
	default:
		clone = gatePool->headClone;
		gatePool->headClone = (ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroupEvent*) ((DSPEEvent*) clone)->next;
		gatePool->cloneNumElements--;
		break;
	}
	
	event->refCount++;
	clone->original = (DSPEGroupEvent*) event;
	
	((DSPEEvent*) clone)->next = NULL;
	
	for (i = 0; i < ((DSPEGroupEvent*) event)->groupSize; i++) {
		((ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent*) clone)->value[i] = ((ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent*) event)->value[i];
	}

	return (DSPEEvent*) clone;
}

/* SubClone event function */
DSPEEvent* ParticleTrackerDllPTThresholdGate_MessageGate_subClone(DSPEGroupEvent *event, DSPEEventsPool *pool, size_t index) {
	ParticleTrackerDllPTThresholdGate_MessageGate_pool *gatePool = (ParticleTrackerDllPTThresholdGate_MessageGate_pool*) pool;
	ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent *clone = NULL;
	
	switch (gatePool->cloneNumElements) {
	case 0:
		clone = (ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent));
		((ParticleTrackerDllPTThresholdGate_MessageGate_event*) clone)->value = NULL;
		((DSPEEvent*) clone)->refCount = 0;
		((DSPEEvent*) clone)->dispose = ParticleTrackerDllPTThresholdGate_MessageGate_disposeClone;
		((DSPEEvent*) clone)->clone = ParticleTrackerDllPTThresholdGate_MessageGate_clone;
		((DSPEEvent*) clone)->pool = pool;
		((DSPEEvent*) clone)->blockSize = ((DSPEEvent*) event)->blockSize;
		break;
	case 1:
		clone = gatePool->headClone;
		gatePool->headClone = NULL;
		gatePool->tailClone = NULL;
		gatePool->cloneNumElements = 0;
		break;
	default:
		clone = gatePool->headClone;
		gatePool->headClone = (ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent*) ((DSPEEvent*) clone)->next;
		gatePool->cloneNumElements--;
		break;
	}
	((DSPEEvent*) clone)->next = NULL;

	/* Set clone's original and increment original's refCounter */
	((DSPEEvent*) event)->refCount++;
	((ParticleTrackerDllPTThresholdGate_MessageGate_cloneEvent*) clone)->original = (DSPEEvent*) event;
	
	((ParticleTrackerDllPTThresholdGate_MessageGate_event*) clone)->value = ((ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent*) event)->value[index];
	return (DSPEEvent*) clone;
}

/**
 * Allocate containerEvent function
 */
ParticleTrackerDllPTThresholdGate_MessageGate_eventContainer* ParticleTrackerDllPTThresholdGate_MessageGate_allocateContainer(ParticleTrackerDllPTThresholdGate_MessageGate_groupPool *grpPool) {
	ParticleTrackerDllPTThresholdGate_MessageGate_groupPool *gatePool = (ParticleTrackerDllPTThresholdGate_MessageGate_groupPool*) grpPool;
	ParticleTrackerDllPTThresholdGate_MessageGate_eventContainer *event = NULL;
	register size_t i;
	switch (gatePool->containerNumElements) {
	case 0:
		event = (ParticleTrackerDllPTThresholdGate_MessageGate_eventContainer*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllPTThresholdGate_MessageGate_eventContainer));
		initDSPEGroupEvent((DSPEGroupEvent*) event);
		((DSPEEvent*) event)->pool = (DSPEEventsPool*) grpPool;
		((DSPEEvent*) event)->dispose = ParticleTrackerDllPTThresholdGate_MessageGate_disposeContainer;
		((DSPEEvent*) event)->clone = ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroup;
		((DSPEGroupEvent*) event)->groupSize = ((DSPEGroupEventsPool*) gatePool)->groupSize;
		((ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent*) event)->value = (ParticleTrackerDllPTThresholdGate_MessageGate**) memoryManager_allocate((DSPEElement*) gatePool, ((DSPEGroupEventsPool*) gatePool)->groupSize * sizeof(ParticleTrackerDllPTThresholdGate_MessageGate*));
		event->containedEvents = (DSPEEvent**) memoryManager_allocate((DSPEElement*) gatePool, ((DSPEGroupEventsPool*) gatePool)->groupSize * sizeof(DSPEEvent*));
		for (i = 0; i < ((DSPEGroupEventsPool*) gatePool)->groupSize; i++) {
			event->containedEvents[i] = NULL;
			((ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent*) event)->value[i] = NULL;
		}
		return event;
	case 1:
		event = gatePool->headContainer;
		gatePool->headContainer = NULL;
		gatePool->tailContainer = NULL;
		gatePool->containerNumElements = 0;
		((DSPEEvent*) event)->next = NULL;
		return event;
	default:
		event = gatePool->headContainer;
		gatePool->headContainer = (ParticleTrackerDllPTThresholdGate_MessageGate_eventContainer*) ((DSPEEvent*) event)->next;
		gatePool->containerNumElements--;
		((DSPEEvent*) event)->next = NULL;
		return event;
	}
}

/**
 * Dispose containerEvent function
 */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeContainer(DSPEEvent *event) {
	ParticleTrackerDllPTThresholdGate_MessageGate_groupPool *gatePool = (ParticleTrackerDllPTThresholdGate_MessageGate_groupPool*) event->pool;
	register size_t i;
	ParticleTrackerDllPTThresholdGate_MessageGate_eventContainer *container = (ParticleTrackerDllPTThresholdGate_MessageGate_eventContainer*) event;
	DSPEEvent *refEvent = NULL;
	if (event->refCount == 1) {
		for (i = 0; i < ((DSPEGroupEventsPool*) gatePool)->groupSize; i++) {
			refEvent = container->containedEvents[i];
			if (refEvent != NULL) {
				refEvent->dispose(refEvent);
				container->containedEvents[i] = NULL;
			}
			((ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent*) container)->value[i] = NULL;
		}
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->containerNumElements) {
		case 0:
			gatePool->headContainer = (ParticleTrackerDllPTThresholdGate_MessageGate_eventContainer*) event;
			gatePool->tailContainer = (ParticleTrackerDllPTThresholdGate_MessageGate_eventContainer*) event;
			gatePool->containerNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailContainer)->next = event;
			gatePool->tailContainer = (ParticleTrackerDllPTThresholdGate_MessageGate_eventContainer*) event;
			gatePool->containerNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* DisposeGroup function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeGroup(DSPEEvent *event) {
	ParticleTrackerDllPTThresholdGate_MessageGate_groupPool *gatePool = (ParticleTrackerDllPTThresholdGate_MessageGate_groupPool*) event->pool;
	if (event->refCount == 1) {
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->eventNumElements) {
		case 0:
			gatePool->headEvent = (ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent*) event;
			gatePool->tailEvent = (ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent*) event;
			gatePool->eventNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailEvent)->next = event;
			gatePool->tailEvent = (ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent*) event;
			gatePool->eventNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* Dispose GroupClone function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeGroupClone(DSPEEvent *event) {
	ParticleTrackerDllPTThresholdGate_MessageGate_groupPool *gatePool = (ParticleTrackerDllPTThresholdGate_MessageGate_groupPool*) event->pool;
	DSPEEvent *original = (DSPEEvent*) ((ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroupEvent*) event)->original;
	if (event->refCount == 1) {
		original->dispose(original);
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->cloneNumElements) {
		case 0:
			gatePool->headClone = (ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroupEvent*) event;
			gatePool->tailClone = (ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroupEvent*) event;
			gatePool->cloneNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailClone)->next = event;
			gatePool->tailClone = (ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroupEvent*) event;
			gatePool->cloneNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* DestroyGroup function */
void ParticleTrackerDllPTThresholdGate_MessageGate_destroyGroup(DSPEElement *context, ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent *event) {
	register size_t i;
	for (i = 0; i < ((DSPEGroupEvent*) event)->groupSize; i++) {
		ParticleTrackerDllPTThresholdGate_MessageGate_disposeValue((DSPEElement*) context, *(event->value[i]));
	}
}

/* eventPool dispose function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeGroupPool(DSPEEventsPool *pool) {
	register size_t i;
	DSPEEvent *tmp = NULL;
	DSPEEventsPool *eventPool = NULL;
	DSPEEventsPool *tmpEventPool = NULL;
	ParticleTrackerDllPTThresholdGate_MessageGate_groupPool *thisPool = (ParticleTrackerDllPTThresholdGate_MessageGate_groupPool*) pool;

	/* dispose children */
	eventPool = (DSPEEventsPool*) ((DSPEGroupEventsPool*) thisPool)->groupsHead;
	for (i = 0; i < ((DSPEGroupEventsPool*) thisPool)->groupsNumElements; i++) {
		tmpEventPool = eventPool;
		eventPool = eventPool->next;
		tmpEventPool->next = NULL;
		tmpEventPool->dispose(tmpEventPool);
	}
	/* dispose events */
	for (i = 0; i < thisPool->eventNumElements; i++) {
		tmp = (DSPEEvent*) thisPool->headEvent;
		thisPool->headEvent = (ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent*) tmp->next;
		tmp->next = NULL;
		ParticleTrackerDllPTThresholdGate_MessageGate_destroyGroup((DSPEElement*) pool, (ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent*) tmp);
		memorySupport_dispose(tmp);
	}
	/* dispose clones */
	for (i = 0; i < thisPool->cloneNumElements; i++) {
		tmp = (DSPEEvent*) thisPool->headClone;
		thisPool->headClone = (ParticleTrackerDllPTThresholdGate_MessageGate_cloneGroupEvent*) tmp->next;
		tmp->next = NULL;
		ParticleTrackerDllPTThresholdGate_MessageGate_destroyGroup((DSPEElement*) pool, (ParticleTrackerDllPTThresholdGate_MessageGate_groupEvent*) tmp);
		memorySupport_dispose(tmp);
	}
	/* dispose pool */
	memorySupport_dispose(thisPool);
}

/* CreateNode function */
ParticleTrackerDllPTThresholdGate_MessageGate_node* ParticleTrackerDllPTThresholdGate_MessageGate_createNode(ParticleTrackerDllPTThresholdGate_MessageGate *localVar, DSPEApplication *application, DSPEEventsPool *pool, unsigned int eventID) {
	ParticleTrackerDllPTThresholdGate_MessageGate_node *node = (ParticleTrackerDllPTThresholdGate_MessageGate_node*) memoryManager_allocate((DSPEElement*) application, sizeof(ParticleTrackerDllPTThresholdGate_MessageGate_node));
	initDSPEGateNode((DSPEGateNode*) node);
	node->eventID = eventID;
	node->application = application;
	node->pool = pool;
	node->localVar = localVar;
	node->sendEvent = 0;
	((DSPEGateNode*) node)->setValue = ParticleTrackerDllPTThresholdGate_MessageGate_setValue;
	((DSPEGateNode*) node)->disposeNode = ParticleTrackerDllPTThresholdGate_MessageGate_disposeNode;
	return node;
}

/* DisposeNode function */
void ParticleTrackerDllPTThresholdGate_MessageGate_disposeNode(DSPEElement *context, DSPEGateNode *node) {
	node->next = NULL;
	memorySupport_dispose(node);
}

/* SetValue function */
void ParticleTrackerDllPTThresholdGate_MessageGate_setValue(DSPEElement *context, DSPEGateNode *node) {
	ParticleTrackerDllPTThresholdGate_MessageGate_event *event = NULL;
	ParticleTrackerDllPTThresholdGate_MessageGate_node *tmpNode = (ParticleTrackerDllPTThresholdGate_MessageGate_node*) node;
	if (tmpNode->sendEvent) {
		tmpNode->sendEvent = 0;
		event = ParticleTrackerDllPTThresholdGate_MessageGate_allocate((ParticleTrackerDllPTThresholdGate_MessageGate_pool*) tmpNode->pool);
		ParticleTrackerDllPTThresholdGate_MessageGate_copy(event, tmpNode->value);
		((DSPEEvent*) event)->refCount = 1;
		if (((DSPEEventsApplication*) tmpNode->application)->queueEvent != NULL)
			((DSPEEventsApplication*) tmpNode->application)->queueEvent((DSPEEventsApplication*) tmpNode->application, (DSPEEvent*) event, tmpNode->eventID);
		ParticleTrackerDllPTThresholdGate_MessageGate_dispose((DSPEEvent*) event);
	}
	if (tmpNode->localVar != 0)
		*tmpNode->localVar = tmpNode->value;
}

