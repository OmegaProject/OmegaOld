/**
 * File: B_ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation.h
 *
 * @author Loris
 * @created Thu May 26 10:23:50 CEST 2011
 */
#ifndef B_ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation_h
#define B_ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation_h

#include "DSPEXTElements.h"

#include "B_ParticleTrackerDllPTFrameGate_MessageGate.h"
#include "B_ParticleTrackerDllNextGate_SignalGate.h"
#include "B_ParticleTrackerDllIntGate_StandardGate.h"
#include "B_ParticleTrackerDllRealGate_CustomGate.h"
#include "B_ParticleTrackerDllStatusGate_StringGate.h"

#include "B_ParticleTrackerDllTracker_Requirement.h"

/* Functional implementation state type definition */
typedef struct ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation_func ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation_func;

/* This struct may contain user defined additional state variables for the unit */
struct ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation_func {

	DSPEStateImplementation stateImplementation;

	//Place additional state variables after this line -- SYD-ADDITIONAL-STATE-START
	PTFrame** framesToLink;
	int linkrangeCounter;
	int currentFrame;
	int index;
	int currentState;
	//SYD-ADDITIONAL-STATE-END  -- Place additional state variables before this line

};

/******************************************************************************
 * FOLLOWING CODE IS NOT INTENDED TO BE MODIFIED BY USERS                     *
 ******************************************************************************/

/* State type definition */
typedef struct ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation;

/* State definition */ 
struct ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation {

	/* Functional implementation state */
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation_func functionalState;


	/* Data gates */
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame;

	/* Parameter gates */
	ParticleTrackerDllIntGate_StandardGate *paramIn_stop;
	ParticleTrackerDllIntGate_StandardGate *paramIn_Linkrange;
	ParticleTrackerDllRealGate_CustomGate *paramIn_Displacement;
	ParticleTrackerDllIntGate_StandardGate *paramOut_stop;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status;


	/* numLinks flags */
	unsigned int dataIn_PTFrame_numLinks;
	unsigned int dataOut_PTFrame_numLinks;
	unsigned int paramIn_next_numLinks;
	unsigned int paramIn_stop_numLinks;
	unsigned int paramIn_Linkrange_numLinks;
	unsigned int paramIn_Displacement_numLinks;
	unsigned int paramOut_next_numLinks;
	unsigned int paramOut_stop_numLinks;
	unsigned int paramOut_Status_numLinks;

	/* State */
	unsigned int state;

	/* Automatic execute support */
	unsigned int isReadyToExecute;
	unsigned int waitingInNext;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

/* Preprocess function */
void ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation_preProcess(ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *context);

/* Process function */
void ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation_process(ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *context);

/* Postprocess function */
void ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation_postProcess(ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
