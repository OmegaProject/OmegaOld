/**
 * File: RBlockSim_ParticleTrackerDllLibraryDataReader_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef RBlockSim_ParticleTrackerDllLibraryDataReader_SoftwareUnit_h
#define RBlockSim_ParticleTrackerDllLibraryDataReader_SoftwareUnit_h

#include "B_ParticleTrackerDllLibraryDataReader_StateImplementation.h"
#include "B_ParticleTrackerDllLibraryDataReader_SoftwareUnit.h"
#include "RBlock_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "RBlock_ParticleTrackerDllPTFrameGate_MessageGate.h"

/* Block SoftwareUnit state type definition */
typedef struct ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockSim ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockSim;

/* Block SoftwareUnit state definition */
struct ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockSim {

	/* Base unit state */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllLibraryDataReader_StateImplementation implState;
	
	/* Block size */
	size_t blockSize;

	/* Samples to process */
	size_t samplesToProcess;

	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;
	DSPEEvent *dataOut_PTFrame_place;
	DSPEEvent *dataOut_PTFrame_armMarker;

	/* Data pending events support */
	size_t dataOut_PTFrame_pendingEvents;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;

	/* EventPools */
	ParticleTrackerDllPTFrameGate_MessageGate_poolBlock *dataOut_PTFrame_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame_unlinked;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataOut_SequenceValues;


	/* Data gates sizes */
	size_t dataOut_SequenceValues_size;
	size_t dataOut_PTFrame_size;


	/* Data gates factors */
	size_t dataOut_SequenceValues_factor;
	size_t dataOut_PTFrame_factor;


	/* Data gates counters */
	size_t dataOut_SequenceValues_counter;
	size_t dataOut_PTFrame_counter;


	/* Output data places */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataOut_SequenceValues_place;


	/* Data gates counters */
	size_t dataOut_PTFrame_samplesCounter;

};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllLibraryDataReader_SoftwareUnit_armEventBlockSim(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllLibraryDataReader_SoftwareUnit_postEventBlockSim(DSPEEventsUnit *unit, unsigned int ID);

/* Earlyalloc function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_earlyAllocBlockSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockSim *context);

/* Alloc function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_allocBlockSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockSim *context);

/* Earlyconnect function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_earlyConnectBlockSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockSim *context);

/* Connect function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_connectBlockSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockSim *context);

/* Startup function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_startupBlockSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockSim *context);

/* Preprocess function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_preProcessBlockSim(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_processBlockSim(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_postProcessBlockSim(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_resetBlockSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockSim *context);

/* Shutdown function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_shutdownBlockSim(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockSim *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
