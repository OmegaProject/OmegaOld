/**
 * File: RBlockProd_ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef RBlockProd_ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_h
#define RBlockProd_ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_h

#include "B_ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation.h"
#include "B_ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit.h"
#include "RBlock_ParticleTrackerDllPTFrameGate_MessageGate.h"

/* Block SoftwareUnit state type definition */
typedef struct ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockProd ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockProd;

/* Block SoftwareUnit state definition */
struct ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockProd {

	/* Base unit state */
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation implState;
	
	/* Block size */
	size_t blockSize;

	/* Samples to process */
	size_t samplesToProcess;

	/* Data transit queues */
	size_t dataIn_PTFrame_transitNumElements;
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_transitHead;
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_transitTail;
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_curTransit;
	unsigned int dataIn_PTFrame_curTransitIndex;

	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;
	DSPEEvent *dataOut_PTFrame_place;
	DSPEEvent *dataOut_PTFrame_armMarker;

	/* Data pending events support */
	size_t dataOut_PTFrame_pendingEvents;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;

	/* EventPools */
	ParticleTrackerDllPTFrameGate_MessageGate_poolBlock *dataOut_PTFrame_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame_unlinked;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame_unlinked;


	/* Data gates sizes */
	size_t dataOut_PTFrame_size;


	/* Data gates factors */
	size_t dataOut_PTFrame_factor;


	/* Data gates counters */
	size_t dataOut_PTFrame_counter;


	/* Data gates counters */
	size_t dataOut_PTFrame_samplesCounter;

	/* Unit profile ID */
	int unitProfileID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_transitEventBlockProd(DSPEQueueUnit *unit);

size_t ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getTransitNumElementsBlockProd(DSPEQueueUnit *unit, unsigned int ID);

size_t ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getTransitNumElementsBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getFirstTransitBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getCurTransitBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_dismissEventBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_dismissAllEventsBlockProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_armEventBlockProd(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_postEventBlockProd(DSPEEventsUnit *unit, unsigned int ID);

/* Earlyalloc function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_earlyAllocBlockProd(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockProd *context);

/* Alloc function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_allocBlockProd(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockProd *context);

/* Earlyconnect function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_earlyConnectBlockProd(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockProd *context);

/* Connect function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_connectBlockProd(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockProd *context);

/* Startup function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_startupBlockProd(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockProd *context);

/* Preprocess function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_preProcessBlockProd(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_processBlockProd(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_postProcessBlockProd(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_resetBlockProd(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockProd *context);

/* Shutdown function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_shutdownBlockProd(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockProd *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
