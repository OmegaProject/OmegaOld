/**
 * File: RBlock_ParticleTrackerDllPTFilteredGate_MessageGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef RBlock_ParticleTrackerDllPTFilteredGate_MessageGate_h
#define RBlock_ParticleTrackerDllPTFilteredGate_MessageGate_h

#include "B_ParticleTrackerDllPTFilteredGate_MessageGate.h"

/* EventGate pool type definition */
typedef struct ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock;

/* EventGate pool definition */
struct ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock {
	DSPEBlockEventsPool pool;

	// Pool for Events
	size_t eventNumElements;
	ParticleTrackerDllPTFilteredGate_MessageGate_event *headEvent;
	ParticleTrackerDllPTFilteredGate_MessageGate_event *tailEvent;

	// Pool for Clones
	size_t cloneNumElements;
	ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent *headClone;
	ParticleTrackerDllPTFilteredGate_MessageGate_cloneEvent *tailClone;
};

/* BlockEventGroupGate pool type definition */
typedef struct ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock;

/* BlockEventGroupGate pool definition */
struct ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock {
	DSPEGroupBlockEventsPool pool;

	/* Pool for Events */
	size_t eventNumElements;
	ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent *headEvent;
	ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent *tailEvent;
	
	/* Pool for Clones */
	size_t cloneNumElements;
	ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupEvent *headClone;
	ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupEvent *tailClone;
	
	/* Pool for EventContainers */
	size_t containerNumElements;
	ParticleTrackerDllPTFilteredGate_MessageGate_eventContainer *headContainer;
	ParticleTrackerDllPTFilteredGate_MessageGate_eventContainer *tailContainer;
};

#ifdef __cplusplus
extern "C" {
#endif

/* AllocateBlockManaged function */
void ParticleTrackerDllPTFilteredGate_MessageGate_allocateBlockManaged(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate *anchor, size_t size);

/* InitBlockManaged function */
void ParticleTrackerDllPTFilteredGate_MessageGate_initBlockManaged(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate *anchor, size_t size);

/* DisposeBlockManaged function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeBlockManaged(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate *anchor, size_t size);

/* AllocateGroupBlockManaged function */
void ParticleTrackerDllPTFilteredGate_MessageGate_allocateGroupBlockManaged(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate **anchor, size_t size, size_t *gateSize);

/* InitGroupBlockManaged function */
void ParticleTrackerDllPTFilteredGate_MessageGate_initGroupBlockManaged(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate **anchor, size_t size, size_t *gateSize);

/* DisposeGroupBlockManaged function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeGroupBlockManaged(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate **anchor, size_t size, size_t *gateSize);

/* eventPool initialization function */
ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock* ParticleTrackerDllPTFilteredGate_MessageGate_initPoolBlock(const DSPEOwner *owner, size_t size);

/* eventPool preAlloc function */
void ParticleTrackerDllPTFilteredGate_MessageGate_preAllocPoolBlock(DSPEEventsPool *pool, size_t size);

/* eventPool reset function */
void ParticleTrackerDllPTFilteredGate_MessageGate_resetPoolBlock(DSPEEventsPool *pool);

/* Allocate function */
ParticleTrackerDllPTFilteredGate_MessageGate_event* ParticleTrackerDllPTFilteredGate_MessageGate_allocateBlock(ParticleTrackerDllPTFilteredGate_MessageGate_poolBlock *pool);

/* Create function */
void ParticleTrackerDllPTFilteredGate_MessageGate_createBlock(ParticleTrackerDllPTFilteredGate_MessageGate_event *event);

/* Initialise function */
void ParticleTrackerDllPTFilteredGate_MessageGate_initializeBlock(ParticleTrackerDllPTFilteredGate_MessageGate_event *event);

/* Clone event function */
DSPEEvent* ParticleTrackerDllPTFilteredGate_MessageGate_cloneBlock(DSPEEvent *event);

/* Dispose function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeBlock(DSPEEvent *event);

/* Dispose clone function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeCloneBlock(DSPEEvent *event);

/* Destroy function */
void ParticleTrackerDllPTFilteredGate_MessageGate_destroyBlock(ParticleTrackerDllPTFilteredGate_MessageGate_event *event);

/* eventPool dispose function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposePoolBlock(DSPEEventsPool *pool);

/* Allocate function */
ParticleTrackerDllPTFilteredGate_MessageGate* ParticleTrackerDllPTFilteredGate_MessageGate_allocateUnlinkedBlock(DSPEElement *context, size_t size);

/* Initialise function */
void ParticleTrackerDllPTFilteredGate_MessageGate_initializeUnlinkedBlock(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate *place, size_t size);

/* Set function */
void ParticleTrackerDllPTFilteredGate_MessageGate_setBlock(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate *place, size_t size, ParticleTrackerDllPTFilteredGate_MessageGate *value);

/* Dispose function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeUnlinkedBlock(DSPEElement *context, ParticleTrackerDllPTFilteredGate_MessageGate *place);

/* groupEventPool initialization function */
ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock* ParticleTrackerDllPTFilteredGate_MessageGate_initGroupPoolBlock(const DSPEOwner *owner, size_t groupSize, size_t blockSize);

/* eventPool preAlloc function */
void ParticleTrackerDllPTFilteredGate_MessageGate_preAllocGroupPoolBlock(DSPEEventsPool *pool, size_t size);

/* eventPool reset function */
void ParticleTrackerDllPTFilteredGate_MessageGate_resetGroupPoolBlock(DSPEEventsPool *pool);

/* AllocateGroup function */
ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent* ParticleTrackerDllPTFilteredGate_MessageGate_allocateGroupBlock(ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock *pool);

/* CreateGroup function */
void ParticleTrackerDllPTFilteredGate_MessageGate_createGroupBlock(ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent *event, size_t index);

/* InitialiseGroup function */
void ParticleTrackerDllPTFilteredGate_MessageGate_initializeGroupBlock(ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent *event, size_t index);

/* CloneGroup event function */
DSPEEvent* ParticleTrackerDllPTFilteredGate_MessageGate_cloneGroupBlock(DSPEEvent *event);

/* SubClone event function */
DSPEEvent* ParticleTrackerDllPTFilteredGate_MessageGate_subCloneBlock(DSPEGroupEvent *event, DSPEEventsPool *pool, size_t index);

/**
 * Allocate containerEvent function
 */
ParticleTrackerDllPTFilteredGate_MessageGate_eventContainer* ParticleTrackerDllPTFilteredGate_MessageGate_allocateContainerBlock(ParticleTrackerDllPTFilteredGate_MessageGate_poolGroupBlock *pool);

/**
 * Dispose containerEvent function
 */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeContainerBlock(DSPEEvent *event);

/* DisposeGroup function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeGroupBlock(DSPEEvent *event);

/* Dispose GroupClone function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeGroupCloneBlock(DSPEEvent *event);

/* DestroyGroup function */
void ParticleTrackerDllPTFilteredGate_MessageGate_destroyGroupBlock(ParticleTrackerDllPTFilteredGate_MessageGate_groupEvent *event);

/* eventPool dispose function */
void ParticleTrackerDllPTFilteredGate_MessageGate_disposeGroupPoolBlock(DSPEEventsPool *pool);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
