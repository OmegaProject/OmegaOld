/**
 * File: RProd_ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef RProd_ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_h
#define RProd_ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_h

#include "B_ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation.h"
#include "B_ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit.h"
#include "B_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "B_ParticleTrackerDllPTFrameGate_MessageGate.h"
#include "B_ParticleTrackerDllPTThresholdGate_MessageGate.h"

/* Real SoftwareUnit state type definition */
typedef struct ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_realProd ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_realProd;

/* Real SoftwareUnit state definition */
struct ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_realProd {

	/* Base unit state */
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllFindParticlesNewAutoNext_PUSH_2_CoprocImplementation implState;
	
	/* Data transit queues */
	size_t dataIn_PTFrame_transitNumElements;
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_queueNode *dataIn_PTFrame_transitHead;
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_queueNode *dataIn_PTFrame_transitTail;
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_queueNode *dataIn_PTFrame_curTransit;
	unsigned int dataIn_PTFrame_curTransitIndex;
	size_t dataIn_PTThreshold_transitNumElements;
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_queueNode *dataIn_PTThreshold_transitHead;
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_queueNode *dataIn_PTThreshold_transitTail;
	ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_queueNode *dataIn_PTThreshold_curTransit;
	unsigned int dataIn_PTThreshold_curTransitIndex;

	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;
	DSPEEvent *dataOut_PTFrame_place;
	DSPEEvent *dataOut_PTFrame_armMarker;

	/* Data pending events support */
	size_t dataOut_PTFrame_pendingEvents;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;

	/* EventPools */
	ParticleTrackerDllPTFrameGate_MessageGate_pool *dataOut_PTFrame_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame_unlinked;
	ParticleTrackerDllPTThresholdGate_MessageGate *dataIn_PTThreshold_unlinked;
	ParticleTrackerDllPTThresholdGate_MessageGate *dataIn_PTThreshold_unlinkedAnchor;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame_unlinked;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;

	/* Unit profile ID */
	int unitProfileID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_transitEventRealProd(DSPEQueueUnit *unit);

size_t ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_getTransitNumElementsRealProd(DSPEQueueUnit *unit, unsigned int ID);

size_t ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_getCurrentNumElementsRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_getFirstTransitRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_getCurTransitRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_dismissEventRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_dismissAllEventsRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_armEventRealProd(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_postEventRealProd(DSPEEventsUnit *unit, unsigned int ID);

/**
 * initOp function
 */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_initOpRealProd(DSPECoprocUnit *unit, DSPEOp *op);

/* Earlyalloc function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_earlyAllocRealProd(ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_realProd *context);

/* Alloc function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_allocRealProd(ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_realProd *context);

/* Earlyconnect function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_earlyConnectRealProd(ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_realProd *context);

/* Connect function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_connectRealProd(ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_realProd *context);

/* Startup function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_startupRealProd(ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_realProd *context);

/* Preprocess function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_preProcessRealProd(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_processRealProd(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_postProcessRealProd(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_resetRealProd(ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_realProd *context);

/* Shutdown function */
void ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_shutdownRealProd(ParticleTrackerDllFindParticlesCPNewAutoNext_PUSH_2_SoftwareUnit_realProd *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
