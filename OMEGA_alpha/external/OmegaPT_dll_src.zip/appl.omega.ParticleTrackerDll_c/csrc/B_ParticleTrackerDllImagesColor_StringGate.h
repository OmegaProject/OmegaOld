/**
 * File: B_ParticleTrackerDllImagesColor_StringGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef B_ParticleTrackerDllImagesColor_StringGate_h
#define B_ParticleTrackerDllImagesColor_StringGate_h

#include "DSPEElements.h"

#define PARTICLETRACKERDLLIMAGESCOLOR_STRINGGATE_TYPECATEGORY "String"
#define PARTICLETRACKERDLLIMAGESCOLOR_STRINGGATE_DEFAULTVALUE "RGB"
#define PARTICLETRACKERDLLIMAGESCOLOR_STRINGGATE_POSSIBLEVALUE0 "RGB"
#define PARTICLETRACKERDLLIMAGESCOLOR_STRINGGATE_POSSIBLEVALUE1 "R"
#define PARTICLETRACKERDLLIMAGESCOLOR_STRINGGATE_POSSIBLEVALUE2 "G"
#define PARTICLETRACKERDLLIMAGESCOLOR_STRINGGATE_POSSIBLEVALUE3 "B"
#define PARTICLETRACKERDLLIMAGESCOLOR_STRINGGATE_MAXIMUMSIZE 32

typedef char* ParticleTrackerDllImagesColor_StringGate;

/* StringGate node type definition */
typedef struct ParticleTrackerDllImagesColor_StringGate_node ParticleTrackerDllImagesColor_StringGate_node; 

/* StringGate node definition */ 
struct ParticleTrackerDllImagesColor_StringGate_node {
	DSPEGateNode node;
	
	ParticleTrackerDllImagesColor_StringGate *gate;
	ParticleTrackerDllImagesColor_StringGate gateAnchor;
	ParticleTrackerDllImagesColor_StringGate *localVar;
	ParticleTrackerDllImagesColor_StringGate localVarAnchor;	
	ParticleTrackerDllImagesColor_StringGate *value;
	ParticleTrackerDllImagesColor_StringGate valueAnchor;
};

#ifdef __cplusplus
extern "C" {
#endif

/* AllocateValue function */
ParticleTrackerDllImagesColor_StringGate ParticleTrackerDllImagesColor_StringGate_allocateValue(DSPEElement *context);
/* InitValue function */
void ParticleTrackerDllImagesColor_StringGate_initValue(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate anchor);

/* CopyValue function */
void ParticleTrackerDllImagesColor_StringGate_copyValue(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate destination, ParticleTrackerDllImagesColor_StringGate source);

/* CompareValue function */
int ParticleTrackerDllImagesColor_StringGate_compareValue(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate first, ParticleTrackerDllImagesColor_StringGate second);

/* DisposeValue function */
void ParticleTrackerDllImagesColor_StringGate_disposeValue(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate anchor);

/* AllocateManaged function */
void ParticleTrackerDllImagesColor_StringGate_allocateManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *anchor);
/* InitManaged function */
void ParticleTrackerDllImagesColor_StringGate_initManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate anchor);

/* DisposeManaged function */
void ParticleTrackerDllImagesColor_StringGate_disposeManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate anchor);

/* AllocateGroupManaged function */
void ParticleTrackerDllImagesColor_StringGate_allocateGroupManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **anchor, size_t size);
/* InitGroupManaged function */
void ParticleTrackerDllImagesColor_StringGate_initGroupManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **anchor, size_t size);

/* DisposeGroupManaged function */
void ParticleTrackerDllImagesColor_StringGate_disposeGroupManaged(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **anchor, size_t size);

/* Allocate function */
ParticleTrackerDllImagesColor_StringGate* ParticleTrackerDllImagesColor_StringGate_allocate(DSPEElement *context);

/* Initialise function */
void ParticleTrackerDllImagesColor_StringGate_initialize(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *place);

/* SetOverride function */
void ParticleTrackerDllImagesColor_StringGate_setOverride(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *place, ParticleTrackerDllImagesColor_StringGate value);

/* Set function */
void ParticleTrackerDllImagesColor_StringGate_set(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *place, ParticleTrackerDllImagesColor_StringGate *value);

/* Dispose function */
void ParticleTrackerDllImagesColor_StringGate_dispose(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *place);

/* AllocateGroup function */
void ParticleTrackerDllImagesColor_StringGate_allocateGroup(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t size);

/* InitialiseGroup function */
void ParticleTrackerDllImagesColor_StringGate_initializeGroup(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t size);

/* SetOverrideGroup function */
void ParticleTrackerDllImagesColor_StringGate_setOverrideGroup(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t size, ParticleTrackerDllImagesColor_StringGate value);

/* SetGroup function */
void ParticleTrackerDllImagesColor_StringGate_setGroup(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t size, ParticleTrackerDllImagesColor_StringGate **value);

/* DisposeGroup function */
void ParticleTrackerDllImagesColor_StringGate_disposeGroup(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate **place, size_t size);

/* CreateNode function */
ParticleTrackerDllImagesColor_StringGate_node* ParticleTrackerDllImagesColor_StringGate_createNode(DSPEElement *context, ParticleTrackerDllImagesColor_StringGate *gate, ParticleTrackerDllImagesColor_StringGate *localVar);

/* DisposeNode function */
void ParticleTrackerDllImagesColor_StringGate_disposeNode(DSPEElement *context, DSPEGateNode *node);

/* SetValue function */
void ParticleTrackerDllImagesColor_StringGate_setValue(DSPEElement *context, DSPEGateNode *node);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
