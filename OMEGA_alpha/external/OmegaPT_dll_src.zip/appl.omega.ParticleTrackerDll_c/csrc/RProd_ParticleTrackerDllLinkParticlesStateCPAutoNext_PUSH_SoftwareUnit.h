/**
 * File: RProd_ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef RProd_ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_h
#define RProd_ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_h

#include "B_ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation.h"
#include "B_ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit.h"
#include "B_ParticleTrackerDllPTFrameGate_MessageGate.h"

/* Real SoftwareUnit state type definition */
typedef struct ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_realProd ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_realProd;

/* Real SoftwareUnit state definition */
struct ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_realProd {

	/* Base unit state */
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation implState;
	
	/* Data transit queues */
	size_t dataIn_PTFrame_transitNumElements;
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_transitHead;
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_transitTail;
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_curTransit;
	unsigned int dataIn_PTFrame_curTransitIndex;

	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;
	DSPEEvent *dataOut_PTFrame_place;
	DSPEEvent *dataOut_PTFrame_armMarker;

	/* Data pending events support */
	size_t dataOut_PTFrame_pendingEvents;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;

	/* EventPools */
	ParticleTrackerDllPTFrameGate_MessageGate_pool *dataOut_PTFrame_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame_unlinked;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame_unlinked;

	/* Unit profile ID */
	int unitProfileID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_transitEventRealProd(DSPEQueueUnit *unit);

size_t ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getTransitNumElementsRealProd(DSPEQueueUnit *unit, unsigned int ID);

size_t ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getCurrentNumElementsRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getFirstTransitRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getCurTransitRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_dismissEventRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_dismissAllEventsRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_armEventRealProd(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_postEventRealProd(DSPEEventsUnit *unit, unsigned int ID);

/* Earlyalloc function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_earlyAllocRealProd(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_realProd *context);

/* Alloc function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_allocRealProd(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_realProd *context);

/* Earlyconnect function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_earlyConnectRealProd(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_realProd *context);

/* Connect function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_connectRealProd(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_realProd *context);

/* Startup function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_startupRealProd(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_realProd *context);

/* Preprocess function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_preProcessRealProd(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_processRealProd(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_postProcessRealProd(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_resetRealProd(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_realProd *context);

/* Shutdown function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_shutdownRealProd(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_realProd *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
