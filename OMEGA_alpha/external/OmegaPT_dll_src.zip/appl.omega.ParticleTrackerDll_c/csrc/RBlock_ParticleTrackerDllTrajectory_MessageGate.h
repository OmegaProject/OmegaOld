/**
 * File: RBlock_ParticleTrackerDllTrajectory_MessageGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef RBlock_ParticleTrackerDllTrajectory_MessageGate_h
#define RBlock_ParticleTrackerDllTrajectory_MessageGate_h

#include "B_ParticleTrackerDllTrajectory_MessageGate.h"

/* EventGate pool type definition */
typedef struct ParticleTrackerDllTrajectory_MessageGate_poolBlock ParticleTrackerDllTrajectory_MessageGate_poolBlock;

/* EventGate pool definition */
struct ParticleTrackerDllTrajectory_MessageGate_poolBlock {
	DSPEBlockEventsPool pool;

	// Pool for Events
	size_t eventNumElements;
	ParticleTrackerDllTrajectory_MessageGate_event *headEvent;
	ParticleTrackerDllTrajectory_MessageGate_event *tailEvent;

	// Pool for Clones
	size_t cloneNumElements;
	ParticleTrackerDllTrajectory_MessageGate_cloneEvent *headClone;
	ParticleTrackerDllTrajectory_MessageGate_cloneEvent *tailClone;
};

/* BlockEventGroupGate pool type definition */
typedef struct ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock;

/* BlockEventGroupGate pool definition */
struct ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock {
	DSPEGroupBlockEventsPool pool;

	/* Pool for Events */
	size_t eventNumElements;
	ParticleTrackerDllTrajectory_MessageGate_groupEvent *headEvent;
	ParticleTrackerDllTrajectory_MessageGate_groupEvent *tailEvent;
	
	/* Pool for Clones */
	size_t cloneNumElements;
	ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent *headClone;
	ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent *tailClone;
	
	/* Pool for EventContainers */
	size_t containerNumElements;
	ParticleTrackerDllTrajectory_MessageGate_eventContainer *headContainer;
	ParticleTrackerDllTrajectory_MessageGate_eventContainer *tailContainer;
};

#ifdef __cplusplus
extern "C" {
#endif

/* eventPool initialization function */
ParticleTrackerDllTrajectory_MessageGate_poolBlock* ParticleTrackerDllTrajectory_MessageGate_initPoolBlock(const DSPEOwner *owner, size_t size);

/* eventPool preAlloc function */
void ParticleTrackerDllTrajectory_MessageGate_preAllocPoolBlock(DSPEEventsPool *pool, size_t size);

/* eventPool reset function */
void ParticleTrackerDllTrajectory_MessageGate_resetPoolBlock(DSPEEventsPool *pool);

/* Allocate function */
ParticleTrackerDllTrajectory_MessageGate_event* ParticleTrackerDllTrajectory_MessageGate_allocateBlock(ParticleTrackerDllTrajectory_MessageGate_poolBlock *pool);

/* Initialise function */
void ParticleTrackerDllTrajectory_MessageGate_initializeBlock(ParticleTrackerDllTrajectory_MessageGate_event *event);

/* Clone event function */
DSPEEvent* ParticleTrackerDllTrajectory_MessageGate_cloneBlock(DSPEEvent *event);

/* Dispose function */
void ParticleTrackerDllTrajectory_MessageGate_disposeBlock(DSPEEvent *event);

/* Dispose clone function */
void ParticleTrackerDllTrajectory_MessageGate_disposeCloneBlock(DSPEEvent *event);

/* eventPool dispose function */
void ParticleTrackerDllTrajectory_MessageGate_disposePoolBlock(DSPEEventsPool *pool);

/* Allocate function */
ParticleTrackerDllTrajectory_MessageGate* ParticleTrackerDllTrajectory_MessageGate_allocateUnlinkedBlock(DSPEElement *context, size_t size);

/* Initialise function */
void ParticleTrackerDllTrajectory_MessageGate_initializeUnlinkedBlock(DSPEElement *context, ParticleTrackerDllTrajectory_MessageGate *place, size_t size);

/* Dispose function */
void ParticleTrackerDllTrajectory_MessageGate_disposeUnlinkedBlock(DSPEElement *context, ParticleTrackerDllTrajectory_MessageGate *place);

/* groupEventPool initialization function */
ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock* ParticleTrackerDllTrajectory_MessageGate_initGroupPoolBlock(const DSPEOwner *owner, size_t groupSize, size_t blockSize);

/* eventPool preAlloc function */
void ParticleTrackerDllTrajectory_MessageGate_preAllocGroupPoolBlock(DSPEEventsPool *pool, size_t size);

/* eventPool reset function */
void ParticleTrackerDllTrajectory_MessageGate_resetGroupPoolBlock(DSPEEventsPool *pool);

/* AllocateGroup function */
ParticleTrackerDllTrajectory_MessageGate_groupEvent* ParticleTrackerDllTrajectory_MessageGate_allocateGroupBlock(ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock *pool);

/* CreateGroup function */
void ParticleTrackerDllTrajectory_MessageGate_createGroupBlock(ParticleTrackerDllTrajectory_MessageGate_groupEvent *event, size_t index);

/* InitialiseGroup function */
void ParticleTrackerDllTrajectory_MessageGate_initializeGroupBlock(ParticleTrackerDllTrajectory_MessageGate_groupEvent *event, size_t index);

/* CloneGroup event function */
DSPEEvent* ParticleTrackerDllTrajectory_MessageGate_cloneGroupBlock(DSPEEvent *event);

/* SubClone event function */
DSPEEvent* ParticleTrackerDllTrajectory_MessageGate_subCloneBlock(DSPEGroupEvent *event, DSPEEventsPool *pool, size_t index);

/**
 * Allocate containerEvent function
 */
ParticleTrackerDllTrajectory_MessageGate_eventContainer* ParticleTrackerDllTrajectory_MessageGate_allocateContainerBlock(ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock *pool);

/**
 * Dispose containerEvent function
 */
void ParticleTrackerDllTrajectory_MessageGate_disposeContainerBlock(DSPEEvent *event);

/* DisposeGroup function */
void ParticleTrackerDllTrajectory_MessageGate_disposeGroupBlock(DSPEEvent *event);

/* Dispose GroupClone function */
void ParticleTrackerDllTrajectory_MessageGate_disposeGroupCloneBlock(DSPEEvent *event);

/* eventPool dispose function */
void ParticleTrackerDllTrajectory_MessageGate_disposeGroupPoolBlock(DSPEEventsPool *pool);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
