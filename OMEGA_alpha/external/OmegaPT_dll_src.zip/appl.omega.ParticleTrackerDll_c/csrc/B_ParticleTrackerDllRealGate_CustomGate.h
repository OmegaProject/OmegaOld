/**
 * File: B_ParticleTrackerDllRealGate_CustomGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef B_ParticleTrackerDllRealGate_CustomGate_h
#define B_ParticleTrackerDllRealGate_CustomGate_h

#include "DSPEXTElements.h"

#include "B_ParticleTrackerDllTracker_Requirement.h"

#define PARTICLETRACKERDLLREALGATE_CUSTOMGATE_TYPECATEGORY "Custom"
#define PARTICLETRACKERDLLREALGATE_CUSTOMGATE_DEFAULTVALUE 0
#define PARTICLETRACKERDLLREALGATE_CUSTOMGATE_COMPATIBILITY double
typedef real ParticleTrackerDllRealGate_CustomGate;

/* CustomGate node type definition */
typedef struct ParticleTrackerDllRealGate_CustomGate_node ParticleTrackerDllRealGate_CustomGate_node; 

/* CustomGate node definition */ 
struct ParticleTrackerDllRealGate_CustomGate_node {
	DSPEGateNode node;
	
	ParticleTrackerDllRealGate_CustomGate *gate;
	ParticleTrackerDllRealGate_CustomGate *localVar;
	ParticleTrackerDllRealGate_CustomGate value;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Allocate function */
ParticleTrackerDllRealGate_CustomGate* ParticleTrackerDllRealGate_CustomGate_allocate(DSPEElement *context);

/* Initialise function */
void ParticleTrackerDllRealGate_CustomGate_initialize(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate *place);

/* SetOverride function */
void ParticleTrackerDllRealGate_CustomGate_setOverride(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate *place, ParticleTrackerDllRealGate_CustomGate value);

/* Set function */
void ParticleTrackerDllRealGate_CustomGate_set(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate *place, ParticleTrackerDllRealGate_CustomGate *value);

/* Dispose function */
void ParticleTrackerDllRealGate_CustomGate_dispose(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate *place);

/* AllocateGroup function */
void ParticleTrackerDllRealGate_CustomGate_allocateGroup(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t size);

/* InitialiseGroup function */
void ParticleTrackerDllRealGate_CustomGate_initializeGroup(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t size);

/* SetOverrideGroup function */
void ParticleTrackerDllRealGate_CustomGate_setOverrideGroup(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t size, ParticleTrackerDllRealGate_CustomGate value);

/* SetGroup function */
void ParticleTrackerDllRealGate_CustomGate_setGroup(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t size, ParticleTrackerDllRealGate_CustomGate **value);

/* DisposeGroup function */
void ParticleTrackerDllRealGate_CustomGate_disposeGroup(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate **place, size_t size);

/* CreateNode function */
ParticleTrackerDllRealGate_CustomGate_node* ParticleTrackerDllRealGate_CustomGate_createNode(DSPEElement *context, ParticleTrackerDllRealGate_CustomGate *gate, ParticleTrackerDllRealGate_CustomGate *localVar);

/* DisposeNode function */
void ParticleTrackerDllRealGate_CustomGate_disposeNode(DSPEElement *context, DSPEGateNode *node);

/* SetValue function */
void ParticleTrackerDllRealGate_CustomGate_setValue(DSPEElement *context, DSPEGateNode *node);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
