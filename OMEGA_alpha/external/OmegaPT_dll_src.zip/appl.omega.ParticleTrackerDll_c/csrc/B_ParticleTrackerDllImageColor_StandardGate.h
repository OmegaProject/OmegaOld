/**
 * File: B_ParticleTrackerDllImageColor_StandardGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef B_ParticleTrackerDllImageColor_StandardGate_h
#define B_ParticleTrackerDllImageColor_StandardGate_h

#include "DSPEElements.h"

#define PARTICLETRACKERDLLIMAGECOLOR_STANDARDGATE_TYPECATEGORY "Standard"
#define PARTICLETRACKERDLLIMAGECOLOR_STANDARDGATE_DEFAULTVALUE 0
#define PARTICLETRACKERDLLIMAGECOLOR_STANDARDGATE_POSSIBLEVALUE0 0
#define PARTICLETRACKERDLLIMAGECOLOR_STANDARDGATE_POSSIBLEVALUE1 1
#define PARTICLETRACKERDLLIMAGECOLOR_STANDARDGATE_POSSIBLEVALUE2 2
#define PARTICLETRACKERDLLIMAGECOLOR_STANDARDGATE_POSSIBLEVALUE3 3
typedef int ParticleTrackerDllImageColor_StandardGate;

/* StandardGate node type definition */
typedef struct ParticleTrackerDllImageColor_StandardGate_node ParticleTrackerDllImageColor_StandardGate_node; 

/* StandardGate node definition */ 
struct ParticleTrackerDllImageColor_StandardGate_node {
	DSPEGateNode node;
	
	ParticleTrackerDllImageColor_StandardGate *gate;
	ParticleTrackerDllImageColor_StandardGate *localVar;
	ParticleTrackerDllImageColor_StandardGate value;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Allocate function */
ParticleTrackerDllImageColor_StandardGate* ParticleTrackerDllImageColor_StandardGate_allocate(DSPEElement *context);

/* Initialise function */
void ParticleTrackerDllImageColor_StandardGate_initialize(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate *place);

/* SetOverride function */
void ParticleTrackerDllImageColor_StandardGate_setOverride(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate *place, ParticleTrackerDllImageColor_StandardGate value);

/* Set function */
void ParticleTrackerDllImageColor_StandardGate_set(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate *place, ParticleTrackerDllImageColor_StandardGate *value);

/* Dispose function */
void ParticleTrackerDllImageColor_StandardGate_dispose(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate *place);

/* AllocateGroup function */
void ParticleTrackerDllImageColor_StandardGate_allocateGroup(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate **place, size_t size);

/* InitialiseGroup function */
void ParticleTrackerDllImageColor_StandardGate_initializeGroup(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate **place, size_t size);

/* SetOverrideGroup function */
void ParticleTrackerDllImageColor_StandardGate_setOverrideGroup(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate **place, size_t size, ParticleTrackerDllImageColor_StandardGate value);

/* SetGroup function */
void ParticleTrackerDllImageColor_StandardGate_setGroup(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate **place, size_t size, ParticleTrackerDllImageColor_StandardGate **value);

/* DisposeGroup function */
void ParticleTrackerDllImageColor_StandardGate_disposeGroup(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate **place, size_t size);

/* CreateNode function */
ParticleTrackerDllImageColor_StandardGate_node* ParticleTrackerDllImageColor_StandardGate_createNode(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate *gate, ParticleTrackerDllImageColor_StandardGate *localVar);

/* DisposeNode function */
void ParticleTrackerDllImageColor_StandardGate_disposeNode(DSPEElement *context, DSPEGateNode *node);

/* SetValue function */
void ParticleTrackerDllImageColor_StandardGate_setValue(DSPEElement *context, DSPEGateNode *node);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
