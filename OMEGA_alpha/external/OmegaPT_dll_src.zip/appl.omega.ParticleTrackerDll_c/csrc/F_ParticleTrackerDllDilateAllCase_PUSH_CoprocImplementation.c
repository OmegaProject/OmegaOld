/**
 * File: F_ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation.c
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#include "InfoManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "EngineManager.h"
#include "CoprocManager.h"

#include "B_ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation.h"
#include "S_ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation.h"

#include "B_ParticleTrackerDllDilate_Requirement.h"

/**
 * Convenience defines to access unit state variables.
 */
#define currState context->state
#define currentOp context->curOp
/* Input ParameterGates Shortcuts */
#define pIn_stop (*context->paramIn_stop)
#define pIn_Radius (*context->paramIn_Radius)

/* Output ParameterGates Shortcuts */
#define pOut_stop (*context->paramOut_stop)
#define pOut_Status (*context->paramOut_Status)
#define pOut_Status_set(str) stringSupport_copy(*context->paramOut_Status, str)

/* Input DataGates Shortcuts */
#define dIn_SequenceValues (*context->dataIn_SequenceValues)
#define dIn_PTFrame (*context->dataIn_PTFrame)

/* Output DataGates Shortcuts */
#define dOut_Mask (*context->dataOut_Mask)
#define dOut_PTFrame (*context->dataOut_PTFrame)

/* numLinks shortcuts */
#define dIn_SequenceValues_numLinks context->dataIn_SequenceValues_numLinks
#define dIn_PTFrame_numLinks context->dataIn_PTFrame_numLinks
#define dOut_Mask_numLinks context->dataOut_Mask_numLinks
#define dOut_PTFrame_numLinks context->dataOut_PTFrame_numLinks
#define pIn_next_numLinks context->paramIn_next_numLinks
#define pIn_stop_numLinks context->paramIn_stop_numLinks
#define pIn_Radius_numLinks context->paramIn_Radius_numLinks
#define pOut_next_numLinks context->paramOut_next_numLinks
#define pOut_stop_numLinks context->paramOut_stop_numLinks
#define pOut_Status_numLinks context->paramOut_Status_numLinks

/* AdditionalStateVariables default values */
#define ADDS_KERNELWIDTH_DEFAULTVALUE 0
#define ADDS_MASK_DEFAULTVALUE 0


/* CoprocEvent ID */
#define pIn_Coproc_event 100

/* Input EventGate IDs */
#define pIn_next_event 1000
#define dIn_PTFrame_event 1001

/* MemoryManager function shortcuts */
#define memory_allocate(size) memoryManager_allocate((DSPEElement*) context, size)
#define memory_allocateAndInit(blockSize, size) memoryManager_allocateAndInit((DSPEElement*) context, blockSize, size)
#define memory_realloc(pointer, newSize) memorySupport_realloc(pointer, newSize)
#define memory_dispose(pointer) memorySupport_dispose(pointer)
#define memory_copyBlock(destination, source, size) memorySupport_copyBlock(destination, source, size)
#define memory_resetBlock(destination, size) memorySupport_resetBlock(destination, size)

/* StringManager function shortcuts */
#define string_copy(destination, source) stringSupport_copy(destination, source)
#define string_nCopy(destination, source, numChars) stringSupport_nCopy(destination, source, numChars)
#define string_compare(first, second) stringSupport_compare(first, second)
#define string_nCompare(first, second, numChars) stringSupport_nCompare(first, second, numChars)
#define string_compareNoCase(first, second) stringSupport_compareNoCase(first, second)
#define string_nCompareNoCase(first, second, numChars) stringSupport_nCompareNoCase(first, second, numChars)
#define string_length(string) stringSupport_length(string)

/* EngineManager function shortcuts */
#define engine_run() engineManager_run((DSPEElement*) context)
#define engine_stop() engineManager_stop((DSPEElement*) context)
#define engine_pause() engineManager_pause((DSPEElement*) context)
#define engine_skip(cycles) engineManager_skip((DSPEElement*) context, cycles)
#define engine_quit() engineManager_quit((DSPEElement*) context)
#define engine_suspend() engineManager_suspend((DSPEElement*) context)
#define engine_freeze() engineManager_freeze((DSPEElement*) context)
#define engine_resume() engineManager_resume((DSPEElement*) context)

#define engine_isExecuting() engineManager_isExecuting((DSPEElement*) context)
#define engine_isStopping() engineManager_isStopping((DSPEElement*) context)
#define engine_isStopped() engineManager_isStopped((DSPEElement*) context)
#define engine_isPaused() engineManager_isPaused((DSPEElement*) context)
#define engine_isSkipping() engineManager_isSkipping((DSPEElement*) context)
#define engine_isExiting() engineManager_isExiting((DSPEElement*) context)
#define engine_isSuspended() engineManager_isSuspended((DSPEElement*) context)

/* InfoManager function shortcuts */
#if defined(INFOMANAGER_BYPASS_CONSOLE) && (INFOMANAGER_BYPASS_CONSOLE == 1)
#define info_writeInfo(info, ...)
#define info_collectAndWriteInfo(id)
#define info_nCollectAndWriteInfo(id, increment)
#else
#define info_writeInfo(info, ...) infoManager_writeInfo((DSPEElement*) context, info , ##__VA_ARGS__)
#define info_collectAndWriteInfo(id) infoManager_collectAndWriteInfo((DSPEElement*) context, id, 1)
#define info_nCollectAndWriteInfo(id, increment) infoManager_collectAndWriteInfo((DSPEElement*) context, id, increment)
#endif
#if defined(INFOMANAGER_BYPASS_LOG) && (INFOMANAGER_BYPASS_LOG == 1)
#define info_logInfo(info, ...)
#define info_collectAndLogInfo(id)
#define info_nCollectAndLogInfo(id, increment)
#else
#define info_logInfo(info, ...) infoManager_logInfo((DSPEElement*) context, info , ##__VA_ARGS__)
#define info_collectAndLogInfo(id) infoManager_collectAndLogInfo((DSPEElement*) context, id, 1)
#define info_nCollectAndLogInfo(id, increment) infoManager_collectAndLogInfo((DSPEElement*) context, id, increment)
#endif

/* Op readOnly AdditionalStateVariables shortcuts */
#define addS_kernelWidth context->persistent->kernelWidth
#define addS_mask context->persistent->mask

/* Common event shortcuts */
#define event_isAvailable() isEventAvailable(context)
#define event_transit() transitEvent(context)
#define event_getID() getEventID(context)

/* Parameter Output support function shortcuts */
#define pOut_next_sendEvent() sendPE_next(context)

/* Data Input getEvent function shortcuts */
#define dIn_PTFrame_getEvent() getDE_PTFrame(context)

/* Data Input transit support functions */
#define dIn_PTFrame_transitNumElements() getTransitNumElementsDE_PTFrame(context)
#define dIn_PTFrame_getFirstTransit() getFirstTransitDE_PTFrame(context)
#define dIn_PTFrame_currentNumElements() getCurrentNumElementsDE_PTFrame(context)
#define dIn_PTFrame_getCurTransit() getCurTransitDE_PTFrame(context)
#define dIn_PTFrame_dismissEvent() dismissDE_PTFrame(context)

/* Data Output support function shortcuts */
#define dOut_PTFrame_armEvent() armDE_PTFrame(context)
#define dOut_PTFrame_sendEvent() sendDE_PTFrame(context)

/* Coproc support function shortcuts */
#define coproc_isCoprocQueueFull() isCoprocFull(context)
#define coproc_queueOp(coprocOp) queueOp(context, (DSPEOp*) coprocOp)
#define coproc_getProcessedOp() getProcessedOp(context)
#define coproc_createOp() createOp(context)
#define coproc_initOp(coprocOp) initOp(context, coprocOp)
#define coproc_destroyOp(coprocOp) destroyOp(coprocOp)

/* CoprocBuffer support function shortcuts */
#define coproc_getEmptyOp() getEmptyOp(context)
#define coproc_getBufferedOp() getBufferedOp(context)
#define coproc_getNextOp() getNextOp(context)
#define coproc_releaseOp(coprocOp) releaseOp(context, coprocOp)

/**
 * PreProcess algorithm. Process phase initialization should take place here.
 * This function will be called ONCE before the process phase.
 */
void ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_preProcess(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
//Place implementation after this line -- SYD-PREPROCESS-START
	addS_kernelWidth = (2 * pIn_Radius) + 1;
	addS_mask = PT_GenerateMask(pIn_Radius);
	dOut_Mask = addS_mask;

	switch(pIn_Radius) {
	case 1:
		pOut_Status_set("Running: dilate1");
		break;
	case 2:
		pOut_Status_set("Running: dilate2");
		break;
	case 3:
		pOut_Status_set("Running: dilate3");
		break;
	case 4:
		pOut_Status_set("Running: dilate4");
		break;
	case 5:
		pOut_Status_set("Running: dilate5");
		break;
	default:
		if(pIn_Radius <= 0) {
			pOut_Status_set("Radius must be greater than 0");
		} else {
			pOut_Status_set("Running: dilate generic");
		}
		break;
	}
//SYD-PREPROCESS-END -- Place implementation before this line
}

/* Op readOnly AdditionalStateVariables shortcuts */
#undef addS_kernelWidth
#undef addS_mask

/* Op readOnly AdditionalStateVariables shortcuts */
#define addS_kernelWidth ((const ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_persistent*) context->persistent)->kernelWidth
#define addS_mask ((const ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_persistent*) context->persistent)->mask

#undef event_isAvailable
#undef event_getID

#undef event_transit

#undef pOut_next_sendEvent

#undef dIn_PTFrame_getEvent

#undef dIn_PTFrame_transitNumElements
#undef dIn_PTFrame_getFirstTransit
#undef dIn_PTFrame_currentNumElements
#undef dIn_PTFrame_getCurTransit
#undef dIn_PTFrame_dismissEvent

#undef dOut_PTFrame_armEvent
#undef dOut_PTFrame_sendEvent

/* Coproc support function shortcuts */
#undef coproc_isCoprocQueueFull
#undef coproc_queueOp
#undef coproc_getProcessedOp
#undef coproc_createOp
#undef coproc_initOp
#undef coproc_destroyOp
#undef coproc_getEmptyOp
#undef coproc_getBufferedOp
#undef coproc_getNextOp
#undef coproc_releaseOp

/**
 * Process algorithm. What the unit really does should take place here.
 * This function will be called at each process cycle.
 */
void ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_process(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_op *context) {
//Place implementation after this line -- SYD-PROCESS-START
	switch(pIn_Radius) {
	case 1:
		PT_Dilate1(addS_mask, dIn_SequenceValues->width, dIn_SequenceValues->height, dIn_PTFrame->dilated, dIn_PTFrame->filtered);
		break;
	case 2:
		PT_Dilate2(addS_mask, dIn_SequenceValues->width, dIn_SequenceValues->height, dIn_PTFrame->dilated, dIn_PTFrame->filtered);
		break;
	case 3:
		PT_Dilate3(addS_mask, dIn_SequenceValues->width, dIn_SequenceValues->height, dIn_PTFrame->dilated, dIn_PTFrame->filtered);
		break;
	case 4:
		PT_Dilate4(addS_mask, dIn_SequenceValues->width, dIn_SequenceValues->height, dIn_PTFrame->dilated, dIn_PTFrame->filtered);
		break;
	case 5:
		PT_Dilate5(addS_mask, dIn_SequenceValues->width, dIn_SequenceValues->height, dIn_PTFrame->dilated, dIn_PTFrame->filtered);
		break;
	default:
		PT_DilateGeneric(addS_mask, addS_kernelWidth, dIn_SequenceValues->width, dIn_SequenceValues->height, pIn_Radius, dIn_PTFrame->dilated, dIn_PTFrame->filtered);
		break;
	}

	dOut_PTFrame = dIn_PTFrame;
//SYD-PROCESS-END -- Place implementation before this line 
}

/* Op readOnly AdditionalStateVariables shortcuts */
#undef addS_kernelWidth
#undef addS_mask

/* Op readOnly AdditionalStateVariables shortcuts */
#define addS_kernelWidth context->persistent->kernelWidth
#define addS_mask context->persistent->mask

/**
 * PostProcess algorithm. Process phase cleanup should take place here.
 * This function will be called ONCE after the process phase.
 */
void ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation_postProcess(ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation *context) {
//Place implementation after this line -- SYD-POSTPROCESS-START
	memory_dispose(addS_mask);
//SYD-POSTPROCESS-END -- Place implementation before this line 
}

/* Op readOnly AdditionalStateVariables shortcuts */
#undef addS_kernelWidth
#undef addS_mask

#undef currState
/* Input ParameterGates Shortcuts */
#undef pIn_stop
#undef pIn_Radius

/* Output ParameterGates Shortcuts */
#undef pOut_stop
#undef pOut_Status
#undef pOut_Status_set

/* Input DataGates Shortcuts */
#undef dIn_SequenceValues
#undef dIn_PTFrame

/* Output DataGates Shortcuts */
#undef dOut_Mask
#undef dOut_PTFrame

/* numLinks shortcuts */
#undef dIn_SequenceValues_numLinks
#undef dIn_PTFrame_numLinks
#undef dOut_Mask_numLinks
#undef dOut_PTFrame_numLinks
#undef pIn_next_numLinks
#undef pIn_stop_numLinks
#undef pIn_Radius_numLinks
#undef pOut_next_numLinks
#undef pOut_stop_numLinks
#undef pOut_Status_numLinks

#undef ADDS_KERNELWIDTH_DEFAULTVALUE
#undef ADDS_MASK_DEFAULTVALUE

#undef currentOp
#undef pIn_Coproc_event

#undef pIn_next_event
#undef dIn_PTFrame_event
/* MemoryManager function shortcuts */
#undef memory_allocate
#undef memory_allocateAndInit
#undef memory_realloc
#undef memory_dispose
#undef memory_copyBlock
#undef memory_resetBlock

/* StringManager function shortcuts */
#undef string_copy
#undef string_nCopy
#undef string_compare
#undef string_nCompare
#undef string_compareNoCase
#undef string_nCompareNoCase
#undef string_length

/* EngineManager function shortcuts */
#undef engine_run
#undef engine_stop
#undef engine_pause
#undef engine_skip
#undef engine_quit
#undef engine_suspend
#undef engine_freeze
#undef engine_resume

#undef engine_isExecuting
#undef engine_isStopping
#undef engine_isStopped
#undef engine_isPaused
#undef engine_isSkipping
#undef engine_isExiting
#undef engine_isSuspended

/* InfoManager function shortcuts */
#undef info_writeInfo
#undef info_collectAndWriteInfo
#undef info_nCollectAndWriteInfo
#undef info_logInfo
#undef info_collectAndLogInfo
#undef info_nCollectAndLogInfo

