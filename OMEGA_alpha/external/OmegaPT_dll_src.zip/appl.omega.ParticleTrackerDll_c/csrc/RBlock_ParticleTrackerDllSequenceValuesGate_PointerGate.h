/**
 * File: RBlock_ParticleTrackerDllSequenceValuesGate_PointerGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef RBlock_ParticleTrackerDllSequenceValuesGate_PointerGate_h
#define RBlock_ParticleTrackerDllSequenceValuesGate_PointerGate_h

#include "B_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#ifdef __cplusplus
extern "C" {
#endif

/* Allocate function */
ParticleTrackerDllSequenceValuesGate_PointerGate* ParticleTrackerDllSequenceValuesGate_PointerGate_allocateBlock(DSPEElement *context, size_t size);

/* Initialise function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_initializeBlock(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate *place, size_t size);

/* SetOverrideBlock function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_setOverrideBlock(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate *place, size_t size, ParticleTrackerDllSequenceValuesGate_PointerGate value);

/* Set function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_setBlock(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate *place, size_t size, ParticleTrackerDllSequenceValuesGate_PointerGate *value);

/* Dispose function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_disposeBlock(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate *place);

/* AllocateGroup function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_allocateGroupBlock(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t groupSize, size_t *gateSize);

/* InitialiseGroup function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_initializeGroupBlock(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t groupSize, size_t *gateSize);

/* SetOverrideGroupBlock function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_setOverrideGroupBlock(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllSequenceValuesGate_PointerGate value);

/* SetGroupBlock function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_setGroupBlock(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllSequenceValuesGate_PointerGate **value);

/* DisposeGroup function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_disposeGroupBlock(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t size);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
