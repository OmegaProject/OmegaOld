/**
 * File: RBlock_ParticleTrackerDllIntGate_StandardGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "MemoryManager.h"

#include "RBlock_ParticleTrackerDllIntGate_StandardGate.h"

/* Allocate function */
ParticleTrackerDllIntGate_StandardGate* ParticleTrackerDllIntGate_StandardGate_allocateBlock(DSPEElement *context, size_t size) {
	return memoryManager_allocate(context, size * sizeof(ParticleTrackerDllIntGate_StandardGate));
}

/* Initialise function */
void ParticleTrackerDllIntGate_StandardGate_initializeBlock(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate *place, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllIntGate_StandardGate_initialize(context, &place[i]);
	}
}

/* SetOverrideBlock function */
void ParticleTrackerDllIntGate_StandardGate_setOverrideBlock(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate *place, size_t size, ParticleTrackerDllIntGate_StandardGate value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllIntGate_StandardGate_setOverride(context, &place[i], value);
	}
}

/* SetBlock function */
void ParticleTrackerDllIntGate_StandardGate_setBlock(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate *place, size_t size, ParticleTrackerDllIntGate_StandardGate *value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		place[i] = value[i]; 
	}
}

/* Dispose function */
void ParticleTrackerDllIntGate_StandardGate_disposeBlock(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate *place) {
	memorySupport_dispose(place);
}

/* AllocateGroup function */
void ParticleTrackerDllIntGate_StandardGate_allocateGroupBlock(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t groupSize, size_t *gateSize) {
	register size_t i;	
	for (i = 0; i < groupSize; i++) {
	 	place[i] = ParticleTrackerDllIntGate_StandardGate_allocateBlock(context, gateSize[i]);	
	}
}

/* InitialiseGroup function */
void ParticleTrackerDllIntGate_StandardGate_initializeGroupBlock(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t groupSize, size_t *gateSize) {
	register size_t i;
	for (i = 0; i < groupSize; i++) {
		ParticleTrackerDllIntGate_StandardGate_initializeBlock(context, place[i], gateSize[i]);
	}
}

/* SetOverrideGroupBlock function */
void ParticleTrackerDllIntGate_StandardGate_setOverrideGroupBlock(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllIntGate_StandardGate value) {
	register size_t i;
	for (i = 0; i < groupSize; i++) {
		ParticleTrackerDllIntGate_StandardGate_setOverrideBlock(context, place[i], gateSize[i], value);
	}
}

/* SetGroupBlock function */
void ParticleTrackerDllIntGate_StandardGate_setGroupBlock(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllIntGate_StandardGate **value) {
	register size_t i;
	for (i = 0; i < groupSize; i++) {
		ParticleTrackerDllIntGate_StandardGate_setBlock(context, place[i], gateSize[i], value[i]);
	}
}

/* DisposeGroup function */
void ParticleTrackerDllIntGate_StandardGate_disposeGroupBlock(DSPEElement *context, ParticleTrackerDllIntGate_StandardGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	memorySupport_dispose(place[i]);
	}
}

