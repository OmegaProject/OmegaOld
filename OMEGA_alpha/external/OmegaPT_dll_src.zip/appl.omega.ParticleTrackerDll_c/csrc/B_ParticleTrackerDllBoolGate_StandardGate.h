/**
 * File: B_ParticleTrackerDllBoolGate_StandardGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef B_ParticleTrackerDllBoolGate_StandardGate_h
#define B_ParticleTrackerDllBoolGate_StandardGate_h

#include "DSPEElements.h"

#define PARTICLETRACKERDLLBOOLGATE_STANDARDGATE_TYPECATEGORY "Standard"
#define PARTICLETRACKERDLLBOOLGATE_STANDARDGATE_DEFAULTVALUE 0
#define PARTICLETRACKERDLLBOOLGATE_STANDARDGATE_POSSIBLEVALUE0 0
#define PARTICLETRACKERDLLBOOLGATE_STANDARDGATE_POSSIBLEVALUE1 1
typedef int ParticleTrackerDllBoolGate_StandardGate;

/* StandardGate node type definition */
typedef struct ParticleTrackerDllBoolGate_StandardGate_node ParticleTrackerDllBoolGate_StandardGate_node; 

/* StandardGate node definition */ 
struct ParticleTrackerDllBoolGate_StandardGate_node {
	DSPEGateNode node;
	
	ParticleTrackerDllBoolGate_StandardGate *gate;
	ParticleTrackerDllBoolGate_StandardGate *localVar;
	ParticleTrackerDllBoolGate_StandardGate value;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Allocate function */
ParticleTrackerDllBoolGate_StandardGate* ParticleTrackerDllBoolGate_StandardGate_allocate(DSPEElement *context);

/* Initialise function */
void ParticleTrackerDllBoolGate_StandardGate_initialize(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate *place);

/* SetOverride function */
void ParticleTrackerDllBoolGate_StandardGate_setOverride(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate *place, ParticleTrackerDllBoolGate_StandardGate value);

/* Set function */
void ParticleTrackerDllBoolGate_StandardGate_set(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate *place, ParticleTrackerDllBoolGate_StandardGate *value);

/* Dispose function */
void ParticleTrackerDllBoolGate_StandardGate_dispose(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate *place);

/* AllocateGroup function */
void ParticleTrackerDllBoolGate_StandardGate_allocateGroup(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t size);

/* InitialiseGroup function */
void ParticleTrackerDllBoolGate_StandardGate_initializeGroup(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t size);

/* SetOverrideGroup function */
void ParticleTrackerDllBoolGate_StandardGate_setOverrideGroup(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t size, ParticleTrackerDllBoolGate_StandardGate value);

/* SetGroup function */
void ParticleTrackerDllBoolGate_StandardGate_setGroup(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t size, ParticleTrackerDllBoolGate_StandardGate **value);

/* DisposeGroup function */
void ParticleTrackerDllBoolGate_StandardGate_disposeGroup(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate **place, size_t size);

/* CreateNode function */
ParticleTrackerDllBoolGate_StandardGate_node* ParticleTrackerDllBoolGate_StandardGate_createNode(DSPEElement *context, ParticleTrackerDllBoolGate_StandardGate *gate, ParticleTrackerDllBoolGate_StandardGate *localVar);

/* DisposeNode function */
void ParticleTrackerDllBoolGate_StandardGate_disposeNode(DSPEElement *context, DSPEGateNode *node);

/* SetValue function */
void ParticleTrackerDllBoolGate_StandardGate_setValue(DSPEElement *context, DSPEGateNode *node);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
