/**
 * File: RBlock_ParticleTrackerDllStatusGate_StringGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef RBlock_ParticleTrackerDllStatusGate_StringGate_h
#define RBlock_ParticleTrackerDllStatusGate_StringGate_h

#include "B_ParticleTrackerDllStatusGate_StringGate.h"

#ifdef __cplusplus
extern "C" {
#endif

/* AllocateBlockManaged function */
void ParticleTrackerDllStatusGate_StringGate_allocateBlockManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *anchor, size_t size);

/* InitBlockManaged function */
void ParticleTrackerDllStatusGate_StringGate_initBlockManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *anchor, size_t size);

/* DisposeBlockManaged function */
void ParticleTrackerDllStatusGate_StringGate_disposeBlockManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *anchor, size_t size);

/* AllocateGroupBlockManaged function */
void ParticleTrackerDllStatusGate_StringGate_allocateGroupBlockManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **anchor, size_t size, size_t *gateSize);

/* InitGroupBlockManaged function */
void ParticleTrackerDllStatusGate_StringGate_initGroupBlockManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **anchor, size_t size, size_t *gateSize);

/* DisposeGroupBlockManaged function */
void ParticleTrackerDllStatusGate_StringGate_disposeGroupBlockManaged(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **anchor, size_t size, size_t *gateSize);

/* Allocate function */
ParticleTrackerDllStatusGate_StringGate* ParticleTrackerDllStatusGate_StringGate_allocateBlock(DSPEElement *context, size_t size);

/* Initialise function */
void ParticleTrackerDllStatusGate_StringGate_initializeBlock(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *place, size_t size);

/* SetOverrideBlock function */
void ParticleTrackerDllStatusGate_StringGate_setOverrideBlock(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *place, size_t size, ParticleTrackerDllStatusGate_StringGate value);

/* Set function */
void ParticleTrackerDllStatusGate_StringGate_setBlock(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *place, size_t size, ParticleTrackerDllStatusGate_StringGate *value);

/* Dispose function */
void ParticleTrackerDllStatusGate_StringGate_disposeBlock(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate *place);

/* AllocateGroup function */
void ParticleTrackerDllStatusGate_StringGate_allocateGroupBlock(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t groupSize, size_t *gateSize);

/* InitialiseGroup function */
void ParticleTrackerDllStatusGate_StringGate_initializeGroupBlock(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t groupSize, size_t *gateSize);

/* SetOverrideGroupBlock function */
void ParticleTrackerDllStatusGate_StringGate_setOverrideGroupBlock(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllStatusGate_StringGate value);

/* SetGroup function */
void ParticleTrackerDllStatusGate_StringGate_setGroupBlock(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllStatusGate_StringGate **value);

/* DisposeGroup function */
void ParticleTrackerDllStatusGate_StringGate_disposeGroupBlock(DSPEElement *context, ParticleTrackerDllStatusGate_StringGate **place, size_t size);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
