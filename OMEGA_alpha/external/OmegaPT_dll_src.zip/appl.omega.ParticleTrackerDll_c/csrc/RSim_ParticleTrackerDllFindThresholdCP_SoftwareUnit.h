/**
 * File: RSim_ParticleTrackerDllFindThresholdCP_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef RSim_ParticleTrackerDllFindThresholdCP_SoftwareUnit_h
#define RSim_ParticleTrackerDllFindThresholdCP_SoftwareUnit_h

#include "B_ParticleTrackerDllFindThreshold_CoprocImplementation.h"
#include "B_ParticleTrackerDllFindThresholdCP_SoftwareUnit.h"
#include "B_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "B_ParticleTrackerDllPTFilteredGate_MessageGate.h"
#include "B_ParticleTrackerDllPTThresholdGate_MessageGate.h"

/* Real SoftwareUnit state type definition */
typedef struct ParticleTrackerDllFindThresholdCP_SoftwareUnit_realSim ParticleTrackerDllFindThresholdCP_SoftwareUnit_realSim;

/* Real SoftwareUnit state definition */
struct ParticleTrackerDllFindThresholdCP_SoftwareUnit_realSim {

	/* Base unit state */
	ParticleTrackerDllFindThresholdCP_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllFindThreshold_CoprocImplementation implState;
	
	/* Data transit queues */
	size_t dataIn_PTFiltered_transitNumElements;
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode *dataIn_PTFiltered_transitHead;
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode *dataIn_PTFiltered_transitTail;
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode *dataIn_PTFiltered_curTransit;
	unsigned int dataIn_PTFiltered_curTransitIndex;

	DSPEEvent *dataOut_PTThreshold_place;
	DSPEEvent *dataOut_PTThreshold_armMarker;

	/* EventPools */
	ParticleTrackerDllPTThresholdGate_MessageGate_pool *dataOut_PTThreshold_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFilteredGate_MessageGate *dataIn_PTFiltered_unlinked;
	ParticleTrackerDllPTFilteredGate_MessageGate *dataIn_PTFiltered_unlinkedAnchor;
	ParticleTrackerDllPTThresholdGate_MessageGate *dataOut_PTThreshold_unlinked;
	ParticleTrackerDllPTThresholdGate_MessageGate *dataOut_PTThreshold_unlinkedAnchor;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;

	/* Unit profile ID */
	int unitProfileID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_transitEventRealSim(DSPEQueueUnit *unit);

size_t ParticleTrackerDllFindThresholdCP_SoftwareUnit_getTransitNumElementsRealSim(DSPEQueueUnit *unit, unsigned int ID);

size_t ParticleTrackerDllFindThresholdCP_SoftwareUnit_getCurrentNumElementsRealSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_getFirstTransitRealSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_getCurTransitRealSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_dismissEventRealSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_dismissAllEventsRealSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_armEventRealSim(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_postEventRealSim(DSPEEventsUnit *unit, unsigned int ID);

/**
 * initOp function
 */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_initOpRealSim(DSPECoprocUnit *unit, DSPEOp *op);

/* Earlyalloc function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_earlyAllocRealSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_realSim *context);

/* Alloc function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_allocRealSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_realSim *context);

/* Earlyconnect function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_earlyConnectRealSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_realSim *context);

/* Connect function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_connectRealSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_realSim *context);

/* Startup function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_startupRealSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_realSim *context);

/* Preprocess function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_preProcessRealSim(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_processRealSim(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_postProcessRealSim(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_resetRealSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_realSim *context);

/* Shutdown function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_shutdownRealSim(ParticleTrackerDllFindThresholdCP_SoftwareUnit_realSim *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
