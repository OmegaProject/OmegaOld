/**
 * File: B_ParticleTrackerDllImageColor_StandardGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#include "MemoryManager.h"

#include "B_ParticleTrackerDllImageColor_StandardGate.h"

/* Allocate function */
ParticleTrackerDllImageColor_StandardGate* ParticleTrackerDllImageColor_StandardGate_allocate(DSPEElement *context) {
	return memoryManager_allocate(context, sizeof(ParticleTrackerDllImageColor_StandardGate));
}

/* Initialise function */
void ParticleTrackerDllImageColor_StandardGate_initialize(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate *place) {
	*place = PARTICLETRACKERDLLIMAGECOLOR_STANDARDGATE_DEFAULTVALUE;
}

/* Set function */
void ParticleTrackerDllImageColor_StandardGate_setOverride(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate *place, ParticleTrackerDllImageColor_StandardGate value) {
	*place = value;
}

/* Set function */
void ParticleTrackerDllImageColor_StandardGate_set(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate *place, ParticleTrackerDllImageColor_StandardGate *value) {
	*place = *value;
}

/* Dispose function */
void ParticleTrackerDllImageColor_StandardGate_dispose(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate *place) {
	memorySupport_dispose(place);
}

/* AllocateGroup function */
void ParticleTrackerDllImageColor_StandardGate_allocateGroup(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	place[i] = ParticleTrackerDllImageColor_StandardGate_allocate(context);
	}
}

/* InitialiseGroup function */
void ParticleTrackerDllImageColor_StandardGate_initializeGroup(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate **place, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
	 	ParticleTrackerDllImageColor_StandardGate_initialize(context, place[i]);
	}
}

/* SetOverrideGroup function */
void ParticleTrackerDllImageColor_StandardGate_setOverrideGroup(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate **place, size_t size, ParticleTrackerDllImageColor_StandardGate value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllImageColor_StandardGate_setOverride(context, place[i], value);
	}
}

/* SetGroup function */
void ParticleTrackerDllImageColor_StandardGate_setGroup(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate **place, size_t size, ParticleTrackerDllImageColor_StandardGate **value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllImageColor_StandardGate_set(context, place[i], value[i]);
	}
}

/* DisposeGroup function */
void ParticleTrackerDllImageColor_StandardGate_disposeGroup(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	memorySupport_dispose(place[i]);
	}
}

/* CreateNode function */
ParticleTrackerDllImageColor_StandardGate_node* ParticleTrackerDllImageColor_StandardGate_createNode(DSPEElement *context, ParticleTrackerDllImageColor_StandardGate *gate, ParticleTrackerDllImageColor_StandardGate *localVar) {
	ParticleTrackerDllImageColor_StandardGate_node *node = (ParticleTrackerDllImageColor_StandardGate_node*) memoryManager_allocate(context, sizeof(ParticleTrackerDllImageColor_StandardGate_node));
	initDSPEGateNode((DSPEGateNode*) node);
	node->gate = gate;
	node->localVar = localVar;
	((DSPEGateNode*) node)->setValue = ParticleTrackerDllImageColor_StandardGate_setValue;
	((DSPEGateNode*) node)->disposeNode = ParticleTrackerDllImageColor_StandardGate_disposeNode;
	return node;
}

/* DisposeNode function */
void ParticleTrackerDllImageColor_StandardGate_disposeNode(DSPEElement *context, DSPEGateNode *node) {
	node->next = NULL;
	memorySupport_dispose(node);
}

/* SetValue function */
void ParticleTrackerDllImageColor_StandardGate_setValue(DSPEElement *context, DSPEGateNode *node) {
	ParticleTrackerDllImageColor_StandardGate_node *tmpNode = (ParticleTrackerDllImageColor_StandardGate_node*) node;
	if (tmpNode->gate != 0)
		*tmpNode->gate = tmpNode->value;
	if (tmpNode->localVar != 0)
		*tmpNode->localVar = tmpNode->value;
}

