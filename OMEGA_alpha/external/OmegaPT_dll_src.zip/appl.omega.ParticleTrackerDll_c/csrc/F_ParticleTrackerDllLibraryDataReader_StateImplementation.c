/**
 * File: F_ParticleTrackerDllLibraryDataReader_StateImplementation.c
 *
 * @author Loris
 * @created Thu May 26 10:23:50 CEST 2011
 */
#include "InfoManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "EngineManager.h"
#include "B_ParticleTrackerDllLibraryDataReader_StateImplementation.h"
#include "S_ParticleTrackerDllLibraryDataReader_StateImplementation.h"

#include "B_ParticleTrackerDllLibraryDataReader_Requirement.h"

/**
 * Convenience defines to access unit state variables.
 */
#define currState context->state
/* Input ParameterGates Shortcuts */
#define pIn_stop (*context->paramIn_stop)
#define pIn_LinkRange (*context->paramIn_LinkRange)
#define pIn_ImgsNum (*context->paramIn_ImgsNum)
#define pIn_ImgWidth (*context->paramIn_ImgWidth)
#define pIn_ImgHeight (*context->paramIn_ImgHeight)
#define pIn_ImgMin (*context->paramIn_ImgMin)
#define pIn_ImgMax (*context->paramIn_ImgMax)

/* Output ParameterGates Shortcuts */
#define pOut_Status (*context->paramOut_Status)
#define pOut_Status_set(str) stringSupport_copy(*context->paramOut_Status, str)

/* Output DataGates Shortcuts */
#define dOut_SequenceValues (*context->dataOut_SequenceValues)
#define dOut_PTFrame (*context->dataOut_PTFrame)

/* numLinks shortcuts */
#define dOut_SequenceValues_numLinks context->dataOut_SequenceValues_numLinks
#define dOut_PTFrame_numLinks context->dataOut_PTFrame_numLinks
#define pIn_sourceNext_numLinks context->paramIn_sourceNext_numLinks
#define pIn_next_numLinks context->paramIn_next_numLinks
#define pIn_stop_numLinks context->paramIn_stop_numLinks
#define pIn_LinkRange_numLinks context->paramIn_LinkRange_numLinks
#define pIn_ImgsNum_numLinks context->paramIn_ImgsNum_numLinks
#define pIn_ImgWidth_numLinks context->paramIn_ImgWidth_numLinks
#define pIn_ImgHeight_numLinks context->paramIn_ImgHeight_numLinks
#define pIn_ImgMin_numLinks context->paramIn_ImgMin_numLinks
#define pIn_ImgMax_numLinks context->paramIn_ImgMax_numLinks
#define pOut_next_numLinks context->paramOut_next_numLinks
#define pOut_Status_numLinks context->paramOut_Status_numLinks

/* AdditionalStateVariables shortcuts */
#define addS_queue context->functionalState.queue
#define addS_remainingImgs context->functionalState.remainingImgs
#define addS_id context->functionalState.id

/* AdditionalStateVariables default values */
#define ADDS_QUEUE_DEFAULTVALUE 0
#define ADDS_REMAININGIMGS_DEFAULTVALUE 0
#define ADDS_ID_DEFAULTVALUE 0

/* InitEvent ID */
#define pIn_Init_event 0

/* Input EventGate IDs */
#define pIn_sourceNext_event 1000
#define pIn_next_event 1001

/* Common event shortcuts */
#define event_isAvailable() isEventAvailable(context)
#define event_transit() transitEvent(context)
#define event_getID() getEventID(context)

/* Parameter Output support function shortcuts */
#define pOut_next_sendEvent() sendPE_next(context)

/* Data Output support function shortcuts */
#define dOut_PTFrame_armEvent() armDE_PTFrame(context)
#define dOut_PTFrame_sendEvent() sendDE_PTFrame(context)

/* MemoryManager function shortcuts */
#define memory_allocate(size) memoryManager_allocate((DSPEElement*) context, size)
#define memory_allocateAndInit(blockSize, size) memoryManager_allocateAndInit((DSPEElement*) context, blockSize, size)
#define memory_realloc(pointer, newSize) memorySupport_realloc(pointer, newSize)
#define memory_dispose(pointer) memorySupport_dispose(pointer)
#define memory_copyBlock(destination, source, size) memorySupport_copyBlock(destination, source, size)
#define memory_resetBlock(destination, size) memorySupport_resetBlock(destination, size)

/* StringManager function shortcuts */
#define string_copy(destination, source) stringSupport_copy(destination, source)
#define string_nCopy(destination, source, numChars) stringSupport_nCopy(destination, source, numChars)
#define string_compare(first, second) stringSupport_compare(first, second)
#define string_nCompare(first, second, numChars) stringSupport_nCompare(first, second, numChars)
#define string_compareNoCase(first, second) stringSupport_compareNoCase(first, second)
#define string_nCompareNoCase(first, second, numChars) stringSupport_nCompareNoCase(first, second, numChars)
#define string_length(string) stringSupport_length(string)

/* EngineManager function shortcuts */
#define engine_run() engineManager_run((DSPEElement*) context)
#define engine_stop() engineManager_stop((DSPEElement*) context)
#define engine_pause() engineManager_pause((DSPEElement*) context)
#define engine_skip(cycles) engineManager_skip((DSPEElement*) context, cycles)
#define engine_quit() engineManager_quit((DSPEElement*) context)
#define engine_suspend() engineManager_suspend((DSPEElement*) context)
#define engine_freeze() engineManager_freeze((DSPEElement*) context)
#define engine_resume() engineManager_resume((DSPEElement*) context)

#define engine_isExecuting() engineManager_isExecuting((DSPEElement*) context)
#define engine_isStopping() engineManager_isStopping((DSPEElement*) context)
#define engine_isStopped() engineManager_isStopped((DSPEElement*) context)
#define engine_isPaused() engineManager_isPaused((DSPEElement*) context)
#define engine_isSkipping() engineManager_isSkipping((DSPEElement*) context)
#define engine_isExiting() engineManager_isExiting((DSPEElement*) context)
#define engine_isSuspended() engineManager_isSuspended((DSPEElement*) context)

/* InfoManager function shortcuts */
#if defined(INFOMANAGER_BYPASS_CONSOLE) && (INFOMANAGER_BYPASS_CONSOLE == 1)
#define info_writeInfo(info, ...)
#define info_collectAndWriteInfo(id)
#define info_nCollectAndWriteInfo(id, increment)
#else
#define info_writeInfo(info, ...) infoManager_writeInfo((DSPEElement*) context, info , ##__VA_ARGS__)
#define info_collectAndWriteInfo(id) infoManager_collectAndWriteInfo((DSPEElement*) context, id, 1)
#define info_nCollectAndWriteInfo(id, increment) infoManager_collectAndWriteInfo((DSPEElement*) context, id, increment)
#endif
#if defined(INFOMANAGER_BYPASS_LOG) && (INFOMANAGER_BYPASS_LOG == 1)
#define info_logInfo(info, ...)
#define info_collectAndLogInfo(id)
#define info_nCollectAndLogInfo(id, increment)
#else
#define info_logInfo(info, ...) infoManager_logInfo((DSPEElement*) context, info , ##__VA_ARGS__)
#define info_collectAndLogInfo(id) infoManager_collectAndLogInfo((DSPEElement*) context, id, 1)
#define info_nCollectAndLogInfo(id, increment) infoManager_collectAndLogInfo((DSPEElement*) context, id, increment)
#endif

/**
 * Startup algorithm. Unit initialization should take place here.
 * This function will be called ONCE at application startup.
 */
void ParticleTrackerDllLibraryDataReader_StateImplementation_startup(ParticleTrackerDllLibraryDataReader_StateImplementation *context) {
//Place implementation after this line -- SYD-STARTUP-START
	addS_queue = initPTFrameQueue();
//SYD-STARTUP-END -- Place implementation before this line
}

/**
 * PreProcess algorithm. Process phase initialization should take place here.
 * This function will be called ONCE before the process phase.
 */
void ParticleTrackerDllLibraryDataReader_StateImplementation_preProcess(ParticleTrackerDllLibraryDataReader_StateImplementation *context) {
//Place implementation after this line -- SYD-PREPROCESS-START
	dOut_SequenceValues = (PTSequenceValues *) memory_allocate(sizeof(PTSequenceValues));
	dOut_SequenceValues->min = pIn_ImgMin;
	dOut_SequenceValues->max = pIn_ImgMax;
	dOut_SequenceValues->height = pIn_ImgHeight;
	dOut_SequenceValues->width = pIn_ImgWidth;
	dOut_SequenceValues->numberOfImages = pIn_ImgsNum;

	addS_remainingImgs = pIn_ImgsNum;

	// FIXME Rimpiazzare la dimensione massima del buffer con un parametro in entrata!!
	initInputBuffers((void*) ((DSPEElement*) context)->application, pIn_ImgWidth, pIn_ImgHeight, 20);
//SYD-PREPROCESS-END -- Place implementation before this line
}

/**
 * Process algorithm. What the unit really does should take place here.
 * This function will be called at each process cycle.
 */
void ParticleTrackerDllLibraryDataReader_StateImplementation_process(ParticleTrackerDllLibraryDataReader_StateImplementation *context) {
//Place implementation after this line -- SYD-PROCESS-START
	image* tmpImg;

	if (addS_remainingImgs == 0)
		// No more images to process
		return;

	// Get image to process from inputBuffer
	tmpImg = getDataToProcess((void*) ((DSPEElement*) context)->application);
	if (tmpImg == NULL)
		// No images ready to process
		return;

	addS_remainingImgs--;

	if (hasInputData((void*) ((DSPEElement*) context)->application))
		// If no data are available, don't send next event. An init event
		// will be sent as soon as a new data is ready to process.
		pOut_next_sendEvent();

	dOut_PTFrame_armEvent();
	if(dOut_PTFrame == NULL || dOut_PTFrame->inUse) {
		dOut_PTFrame = (PTFrame *) memory_allocate(sizeof(PTFrame));
		dOut_PTFrame->inUse = 0;
		addPTFrameNode(addS_queue, dOut_PTFrame);
	}
	PT_InitPTFrame(dOut_PTFrame, addS_id);
	if (addS_remainingImgs == pIn_LinkRange - 1)
		dOut_PTFrame->isLast = 1;
	addS_id++;

	// Normalize image
	PT_AllocatePTFrame(dOut_PTFrame, pIn_ImgHeight, pIn_ImgWidth);
	PT_ReadNormalizedFrame(dOut_PTFrame, tmpImg->imgData, pIn_ImgHeight, pIn_ImgWidth, pIn_ImgMin, pIn_ImgMax);

	// Put processed image into inputPool
	releaseInputData((void*) ((DSPEElement*) context)->application, tmpImg);

	// Output check
	if (dOut_PTFrame->workingFrame == NULL) {
		sprintf(pOut_Status, "Image %d cannot be correctly normalized", dOut_PTFrame->id);
		info_writeInfo(pOut_Status);
		engine_stop();
		return;
	} else
		sprintf(pOut_Status, "Image %d loaded and normalized",  dOut_PTFrame->id);

	if (addS_remainingImgs == 0) {
		pOut_Status_set("Done reading images");
		info_writeInfo(pOut_Status);
	}

	// Send output event
	dOut_PTFrame_sendEvent();
//SYD-PROCESS-END -- Place implementation before this line 
}

/**
 * PostProcess algorithm. Process phase cleanup should take place here.
 * This function will be called ONCE after the process phase.
 */
void ParticleTrackerDllLibraryDataReader_StateImplementation_postProcess(ParticleTrackerDllLibraryDataReader_StateImplementation *context) {
//Place implementation after this line -- SYD-POSTPROCESS-START
	releasePTFrameQueue(addS_queue);
	memory_dispose(dOut_SequenceValues);
	disposeInputBuffers((void*) ((DSPEElement*) context)->application);
//SYD-POSTPROCESS-END -- Place implementation before this line 
}

/**
 * Shutdown algorithm. Unit cleanup should take place here.
 * This function will be called ONCE at application shutdown.
 */
void ParticleTrackerDllLibraryDataReader_StateImplementation_shutdown(ParticleTrackerDllLibraryDataReader_StateImplementation *context) {
//Place implementation after this line -- SYD-SHUTDOWN-START
	memory_dispose(addS_queue);
//SYD-SHUTDOWN-END -- Place implementation before this line
}

#undef currState
/* Input ParameterGates Shortcuts */
#undef pIn_stop
#undef pIn_LinkRange
#undef pIn_ImgsNum
#undef pIn_ImgWidth
#undef pIn_ImgHeight
#undef pIn_ImgMin
#undef pIn_ImgMax

/* Output ParameterGates Shortcuts */
#undef pOut_Status
#undef pOut_Status_set

/* Output DataGates Shortcuts */
#undef dOut_SequenceValues
#undef dOut_PTFrame

/* numLinks shortcuts */
#undef dOut_SequenceValues_numLinks
#undef dOut_PTFrame_numLinks
#undef pIn_sourceNext_numLinks
#undef pIn_next_numLinks
#undef pIn_stop_numLinks
#undef pIn_LinkRange_numLinks
#undef pIn_ImgsNum_numLinks
#undef pIn_ImgWidth_numLinks
#undef pIn_ImgHeight_numLinks
#undef pIn_ImgMin_numLinks
#undef pIn_ImgMax_numLinks
#undef pOut_next_numLinks
#undef pOut_Status_numLinks

/* AdditionalStateVariables shortcuts */
#undef addS_queue
#undef addS_remainingImgs
#undef addS_id

#undef ADDS_QUEUE_DEFAULTVALUE
#undef ADDS_REMAININGIMGS_DEFAULTVALUE
#undef ADDS_ID_DEFAULTVALUE

#undef pIn_Init_event

#undef pIn_sourceNext_event
#undef pIn_next_event
#undef event_isAvailable
#undef event_getID

#undef event_transit

#undef pOut_next_sendEvent

#undef dOut_PTFrame_armEvent
#undef dOut_PTFrame_sendEvent

/* MemoryManager function shortcuts */
#undef memory_allocate
#undef memory_allocateAndInit
#undef memory_realloc
#undef memory_dispose
#undef memory_copyBlock
#undef memory_resetBlock

/* StringManager function shortcuts */
#undef string_copy
#undef string_nCopy
#undef string_compare
#undef string_nCompare
#undef string_compareNoCase
#undef string_nCompareNoCase
#undef string_length

/* EngineManager function shortcuts */
#undef engine_run
#undef engine_stop
#undef engine_pause
#undef engine_skip
#undef engine_quit
#undef engine_suspend
#undef engine_freeze
#undef engine_resume

#undef engine_isExecuting
#undef engine_isStopping
#undef engine_isStopped
#undef engine_isPaused
#undef engine_isSkipping
#undef engine_isExiting
#undef engine_isSuspended

/* InfoManager function shortcuts */
#undef info_writeInfo
#undef info_collectAndWriteInfo
#undef info_nCollectAndWriteInfo
#undef info_logInfo
#undef info_collectAndLogInfo
#undef info_nCollectAndLogInfo

