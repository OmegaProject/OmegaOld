/**
 * File: B_ParticleTrackerDllTrajectory_MessageGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#include "MemoryManager.h"

#include "B_ParticleTrackerDllTrajectory_MessageGate.h"

/* MemoryManager function shortcuts */
#define memory_allocate(size) memorySupport_allocate(size)
#define memory_allocateAndInit(blockSize, size) memorySupport_allocateAndInit(blockSize, size)
#define memory_realloc(pointer, newSize) memorySupport_realloc(pointer, newSize)
#define memory_dispose(pointer) memorySupport_dispose(pointer)
#define memory_copyBlock(destination, source, size) memorySupport_copyBlock(destination, source, size)
#define memory_resetBlock(destination, size) memorySupport_resetBlock(destination, size)

/* eventPool initialization function */
ParticleTrackerDllTrajectory_MessageGate_pool* ParticleTrackerDllTrajectory_MessageGate_initPool(const DSPEOwner *owner) {
	DSPEPoolHandler *handler = memoryManager_getPoolHandler(owner);
	ParticleTrackerDllTrajectory_MessageGate_pool *pool = (ParticleTrackerDllTrajectory_MessageGate_pool*) memoryManager_getPool(handler, &ParticleTrackerDllTrajectory_MessageGate_allocate);
	/* lazy initialization */
	if (pool == NULL) {
		pool = (ParticleTrackerDllTrajectory_MessageGate_pool*) memoryManager_allocate(CAST_TO_ELEMENT(owner), sizeof(ParticleTrackerDllTrajectory_MessageGate_pool));
		initDSPEElement((DSPEElement*) pool, (DSPEElement*) handler);
		initDSPEBaseEventsPool((DSPEBaseEventsPool*) pool);
		pool->eventNumElements = 0;
		pool->headEvent = NULL;
		pool->tailEvent = NULL;
		pool->cloneNumElements = 0;
		pool->headClone = NULL;
		pool->tailClone = NULL;
		((DSPEEventsPool*) pool)->gateDefID = &ParticleTrackerDllTrajectory_MessageGate_allocate;
		((DSPEEventsPool*) pool)->preAlloc = ParticleTrackerDllTrajectory_MessageGate_preAllocPool;
		((DSPEEventsPool*) pool)->reset = ParticleTrackerDllTrajectory_MessageGate_resetPool;
		((DSPEEventsPool*) pool)->dispose = ParticleTrackerDllTrajectory_MessageGate_disposePool;
		memoryManager_addPool(handler, (DSPEBaseEventsPool*) pool);
	}
	return pool;
}

/* eventPool preAlloc function */
void ParticleTrackerDllTrajectory_MessageGate_preAllocPool(DSPEEventsPool *pool, size_t size) {
	ParticleTrackerDllTrajectory_MessageGate_pool *concretePool = (ParticleTrackerDllTrajectory_MessageGate_pool*) pool;
	register size_t i;
	ParticleTrackerDllTrajectory_MessageGate_event *firstEvent = NULL;
	ParticleTrackerDllTrajectory_MessageGate_event *lastEvent = NULL;
	ParticleTrackerDllTrajectory_MessageGate_event *currEvent = NULL;
	
	firstEvent = ParticleTrackerDllTrajectory_MessageGate_allocate(concretePool);
	lastEvent = firstEvent;
	ParticleTrackerDllTrajectory_MessageGate_initialize(firstEvent);
	
	/* size - 1 because of allocation of first */
	for (i = 0; i < size - 1; i++) {
		currEvent = ParticleTrackerDllTrajectory_MessageGate_allocate(concretePool);
		ParticleTrackerDllTrajectory_MessageGate_initialize(currEvent);
	
		((DSPEEvent*) lastEvent)->next = (DSPEEvent*) currEvent;
		lastEvent = currEvent;
	}

	concretePool->headEvent = firstEvent;
	concretePool->tailEvent = lastEvent;
	concretePool->eventNumElements = size;
}

/* eventPool reset function */
void ParticleTrackerDllTrajectory_MessageGate_resetPool(DSPEEventsPool *pool) {
	ParticleTrackerDllTrajectory_MessageGate_pool *concretePool = (ParticleTrackerDllTrajectory_MessageGate_pool*) pool;
	register size_t i;
	ParticleTrackerDllTrajectory_MessageGate_event *event = concretePool->headEvent;
	for (i = 0; i < concretePool->eventNumElements; i++) {
		ParticleTrackerDllTrajectory_MessageGate_initialize(event);
		event = (ParticleTrackerDllTrajectory_MessageGate_event*) ((DSPEEvent*) event)->next;
	}
}

/* Allocate function */
ParticleTrackerDllTrajectory_MessageGate_event* ParticleTrackerDllTrajectory_MessageGate_allocate(ParticleTrackerDllTrajectory_MessageGate_pool *pool) {
	ParticleTrackerDllTrajectory_MessageGate_pool *gatePool = (ParticleTrackerDllTrajectory_MessageGate_pool*) pool;
	ParticleTrackerDllTrajectory_MessageGate_event *event = NULL;

	switch (gatePool->eventNumElements) {
	case 0:
		event = (ParticleTrackerDllTrajectory_MessageGate_event*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllTrajectory_MessageGate_event));
		event->value = (ParticleTrackerDllTrajectory_MessageGate*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllTrajectory_MessageGate));
		initDSPEEvent((DSPEEvent*) event);
		((DSPEEvent*) event)->pool = (DSPEEventsPool*) pool;
		((DSPEEvent*) event)->dispose = ParticleTrackerDllTrajectory_MessageGate_dispose;
		((DSPEEvent*) event)->clone = ParticleTrackerDllTrajectory_MessageGate_clone;
		ParticleTrackerDllTrajectory_MessageGate_initialize(event);
		return event;
	case 1:
		event = gatePool->headEvent;
		gatePool->headEvent = NULL;
		gatePool->tailEvent = NULL;
		gatePool->eventNumElements = 0;
		((DSPEEvent*) event)->next = NULL;
		return event;
	default:
		event = gatePool->headEvent;
		gatePool->headEvent = (ParticleTrackerDllTrajectory_MessageGate_event*) ((DSPEEvent*) event)->next;
		gatePool->eventNumElements--;
		((DSPEEvent*) event)->next = NULL;
		return event;
	}
}

/* Initialise function */
void ParticleTrackerDllTrajectory_MessageGate_initialize(ParticleTrackerDllTrajectory_MessageGate_event *event) {
	*event->value = PARTICLETRACKERDLLTRAJECTORY_MESSAGEGATE_DEFAULTVALUE;
}

/**
 * Copy function
 */
void ParticleTrackerDllTrajectory_MessageGate_copy(ParticleTrackerDllTrajectory_MessageGate_event *event, ParticleTrackerDllTrajectory_MessageGate value) {
	*event->value = value;
}

/* Clone event function */
DSPEEvent* ParticleTrackerDllTrajectory_MessageGate_clone(DSPEEvent *event) {
	ParticleTrackerDllTrajectory_MessageGate_pool *gatePool = (ParticleTrackerDllTrajectory_MessageGate_pool*) event->pool;
	ParticleTrackerDllTrajectory_MessageGate_cloneEvent *clone = NULL;

	switch (gatePool->cloneNumElements) {
	case 0:
		clone = (ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllTrajectory_MessageGate_cloneEvent));
		((DSPEEvent*) clone)->dispose = ParticleTrackerDllTrajectory_MessageGate_disposeClone;
		((DSPEEvent*) clone)->clone = ParticleTrackerDllTrajectory_MessageGate_clone;
		((DSPEEvent*) clone)->blockSize = event->blockSize;
		((DSPEEvent*) clone)->pool = event->pool;
		break;
	case 1:
		clone = gatePool->headClone;
		gatePool->headClone = NULL;
		gatePool->tailClone = NULL;
		gatePool->cloneNumElements = 0;
		break;
	default:
		clone = gatePool->headClone;
		gatePool->headClone = (ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) ((DSPEEvent*) clone)->next;
		gatePool->cloneNumElements--;
		break;
	}

	event->refCount++;
	clone->original = event;
	
	((DSPEEvent*) clone)->next = NULL;

	((ParticleTrackerDllTrajectory_MessageGate_event*) clone)->value = ((ParticleTrackerDllTrajectory_MessageGate_event*) event)->value;
	
	return (DSPEEvent*) clone;
}

/* Dispose function */
void ParticleTrackerDllTrajectory_MessageGate_dispose(DSPEEvent *event) {
	ParticleTrackerDllTrajectory_MessageGate_pool *gatePool = (ParticleTrackerDllTrajectory_MessageGate_pool*) event->pool;
	if (event->refCount == 1) {
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->eventNumElements) {
		case 0:
			gatePool->headEvent = (ParticleTrackerDllTrajectory_MessageGate_event*) event;
			gatePool->tailEvent = (ParticleTrackerDllTrajectory_MessageGate_event*) event;
			gatePool->eventNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailEvent)->next = (DSPEEvent*) event;
			gatePool->tailEvent = (ParticleTrackerDllTrajectory_MessageGate_event*) event;
			gatePool->eventNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* Dispose clone function */
void ParticleTrackerDllTrajectory_MessageGate_disposeClone(DSPEEvent *event) {
	ParticleTrackerDllTrajectory_MessageGate_pool *gatePool = (ParticleTrackerDllTrajectory_MessageGate_pool*) event->pool;
	DSPEEvent *original = (DSPEEvent*) ((ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) event)->original;
	if (event->refCount == 1) {
		original->dispose(original);
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->cloneNumElements) {
		case 0:
			gatePool->headClone = (ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) event;
			gatePool->tailClone = (ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) event;
			gatePool->cloneNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailClone)->next = (DSPEEvent*) event;
			gatePool->tailClone = (ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) event;
			gatePool->cloneNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* eventPool dispose function */
void ParticleTrackerDllTrajectory_MessageGate_disposePool(DSPEEventsPool *pool) {
	ParticleTrackerDllTrajectory_MessageGate_pool *thisPool = (ParticleTrackerDllTrajectory_MessageGate_pool*) pool;
	register size_t i;
	DSPEEvent *tmp  = NULL;
	/* Dispose events */
	for (i = 0; i < thisPool->eventNumElements; i++) {
		tmp = (DSPEEvent*) thisPool->headEvent;
		thisPool->headEvent = (ParticleTrackerDllTrajectory_MessageGate_event*) tmp->next;
		tmp->next = NULL;
		memorySupport_dispose(((ParticleTrackerDllTrajectory_MessageGate_event*) tmp)->value);
		memorySupport_dispose(tmp);
	}
	/* Dispose clones */
	for (i = 0; i < thisPool->cloneNumElements; i++) {
		tmp = (DSPEEvent*) thisPool->headClone;
		thisPool->headClone = (ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) tmp->next;
		tmp->next = NULL;
		memorySupport_dispose(tmp);
	}
	/* dispose pool */
	memorySupport_dispose(thisPool);
}

/* Allocate function */
ParticleTrackerDllTrajectory_MessageGate* ParticleTrackerDllTrajectory_MessageGate_allocateUnlinked(DSPEElement *context) {
	return memoryManager_allocate(context, sizeof(ParticleTrackerDllTrajectory_MessageGate));
}

/* Initialise function */
void ParticleTrackerDllTrajectory_MessageGate_initializeUnlinked(DSPEElement *context, ParticleTrackerDllTrajectory_MessageGate *place) {
	*place = PARTICLETRACKERDLLTRAJECTORY_MESSAGEGATE_DEFAULTVALUE;
}

/* Dispose function */
void ParticleTrackerDllTrajectory_MessageGate_disposeUnlinked(DSPEElement *context, ParticleTrackerDllTrajectory_MessageGate *place) {
	memorySupport_dispose(place);
}

/* groupEventPool initialization function */
ParticleTrackerDllTrajectory_MessageGate_groupPool* ParticleTrackerDllTrajectory_MessageGate_initGroupPool(const DSPEOwner *owner, size_t groupSize) {
	DSPEPoolHandler *handler = memoryManager_getPoolHandler(owner);
	ParticleTrackerDllTrajectory_MessageGate_groupPool *pool = (ParticleTrackerDllTrajectory_MessageGate_groupPool*) memoryManager_getGroupPool(handler, &ParticleTrackerDllTrajectory_MessageGate_allocateGroup, groupSize);
	/* lazy initialization */
	if (pool == NULL) {
		pool = (ParticleTrackerDllTrajectory_MessageGate_groupPool*) memoryManager_allocate(CAST_TO_ELEMENT(owner), sizeof(ParticleTrackerDllTrajectory_MessageGate_groupPool));
		initDSPEElement((DSPEElement*) pool, (DSPEElement*) handler);
		initDSPEGroupEventsPool((DSPEGroupEventsPool*) pool);
		pool->eventNumElements = 0;
		pool->headEvent = NULL;
		pool->tailEvent = NULL;
		pool->cloneNumElements = 0;
		pool->headClone = NULL;
		pool->tailClone = NULL;
		pool->containerNumElements = 0;
		pool->headContainer = NULL;
		pool->tailContainer = NULL;
		((DSPEEventsPool*) pool)->gateDefID = &ParticleTrackerDllTrajectory_MessageGate_allocateGroup;
		((DSPEEventsPool*) pool)->preAlloc = ParticleTrackerDllTrajectory_MessageGate_preAllocGroupPool;
		((DSPEEventsPool*) pool)->reset = ParticleTrackerDllTrajectory_MessageGate_resetGroupPool;
		((DSPEEventsPool*) pool)->dispose = ParticleTrackerDllTrajectory_MessageGate_disposeGroupPool;
		((DSPEGroupEventsPool*) pool)->groupSize = groupSize;
		memoryManager_addGroupPool(handler, (DSPEGroupEventsPool*) pool);
	}
	return pool;
}

/* eventPool preAlloc function */
void ParticleTrackerDllTrajectory_MessageGate_preAllocGroupPool(DSPEEventsPool *pool, size_t size) {
	ParticleTrackerDllTrajectory_MessageGate_groupPool *concretePool = (ParticleTrackerDllTrajectory_MessageGate_groupPool*) pool;
	DSPEEventsPool *childPool = NULL;
	register size_t i, j;
	ParticleTrackerDllTrajectory_MessageGate_groupEvent *firstEvent = NULL;
	ParticleTrackerDllTrajectory_MessageGate_groupEvent *lastEvent = NULL;
	ParticleTrackerDllTrajectory_MessageGate_groupEvent *currEvent = NULL;
	
	/* preAlloc children */
	childPool = (DSPEEventsPool*) ((DSPEGroupEventsPool*) pool)->groupsHead;
	for (i = 0; i < ((DSPEGroupEventsPool*) pool)->groupsNumElements; i++) {
		childPool->preAlloc(childPool, size);
		childPool = childPool->next;
	}

	firstEvent = ParticleTrackerDllTrajectory_MessageGate_allocateGroup(concretePool);
	lastEvent = firstEvent;
	for (i = 0; i < ((DSPEGroupEventsPool*) pool)->groupSize - 1; i++)
		ParticleTrackerDllTrajectory_MessageGate_initializeGroup(firstEvent, i);
	
	/* size - 2 because of allocation of first */
	for (i = 0; i < size - 1; i++) {
		currEvent = ParticleTrackerDllTrajectory_MessageGate_allocateGroup(concretePool);
		for (j = 0; j < ((DSPEGroupEventsPool*) pool)->groupSize; j++) {
			ParticleTrackerDllTrajectory_MessageGate_initializeGroup(currEvent, j);
		}
	
		((DSPEEvent*) lastEvent)->next = (DSPEEvent*) currEvent;
		lastEvent = currEvent;
	}

	concretePool->headEvent = firstEvent;
	concretePool->tailEvent = lastEvent;
	concretePool->eventNumElements = size;
}

/* eventPool reset function */
void ParticleTrackerDllTrajectory_MessageGate_resetGroupPool(DSPEEventsPool *pool) {
	ParticleTrackerDllTrajectory_MessageGate_groupPool *concretePool = (ParticleTrackerDllTrajectory_MessageGate_groupPool*) pool;
	DSPEEventsPool *childPool = NULL;
	register size_t i, j;
	ParticleTrackerDllTrajectory_MessageGate_groupEvent *event = concretePool->headEvent;
	/* reset children */
	childPool = (DSPEEventsPool*) ((DSPEGroupEventsPool*) pool)->groupsHead;
	for (i = 0; i < ((DSPEGroupEventsPool*) pool)->groupsNumElements; i++) {
		childPool->reset(childPool);
		childPool = childPool->next;
	}

	/* reset current pool events */
	event = concretePool->headEvent;
	for (i = 0; i < concretePool->eventNumElements; i++) {
		for (j = 0; j < ((DSPEGroupEventsPool*) pool)->groupSize - 1; j++)
			ParticleTrackerDllTrajectory_MessageGate_initializeGroup(event, j);
		event = (ParticleTrackerDllTrajectory_MessageGate_groupEvent*) ((DSPEEvent*) event)->next;
	}

}

/* AllocateGroup function */
ParticleTrackerDllTrajectory_MessageGate_groupEvent* ParticleTrackerDllTrajectory_MessageGate_allocateGroup(ParticleTrackerDllTrajectory_MessageGate_groupPool *grpPool) {
	ParticleTrackerDllTrajectory_MessageGate_groupPool *gatePool = (ParticleTrackerDllTrajectory_MessageGate_groupPool*) grpPool;
	ParticleTrackerDllTrajectory_MessageGate_groupEvent *event = NULL;
	register size_t i;
	switch (gatePool->eventNumElements) {
	case 0:
		event = (ParticleTrackerDllTrajectory_MessageGate_groupEvent*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllTrajectory_MessageGate_groupEvent));
		initDSPEGroupEvent((DSPEGroupEvent*) event);
		((DSPEEvent*) event)->pool = (DSPEEventsPool*) grpPool;
		((DSPEEvent*) event)->dispose = ParticleTrackerDllTrajectory_MessageGate_disposeGroup;
		((DSPEEvent*) event)->clone = ParticleTrackerDllTrajectory_MessageGate_cloneGroup;
		((DSPEGroupEvent*) event)->groupSize = ((DSPEGroupEventsPool*) gatePool)->groupSize;
		event->value = (ParticleTrackerDllTrajectory_MessageGate**) memoryManager_allocate((DSPEElement*) gatePool, ((DSPEGroupEventsPool*) gatePool)->groupSize * sizeof(ParticleTrackerDllTrajectory_MessageGate*));
		for (i = 0; i < ((DSPEGroupEventsPool*) gatePool)->groupSize; i++) {
			ParticleTrackerDllTrajectory_MessageGate_createGroup(event, i);
			ParticleTrackerDllTrajectory_MessageGate_initializeGroup(event, i);
		}
		return event;
	case 1:
		event = gatePool->headEvent;
		gatePool->headEvent = NULL;
		gatePool->tailEvent = NULL;
		gatePool->eventNumElements = 0;
		((DSPEEvent*) event)->next = NULL;
		return event;
	default:
		event = gatePool->headEvent;
		gatePool->headEvent = (ParticleTrackerDllTrajectory_MessageGate_groupEvent*) ((DSPEEvent*) event)->next;
		gatePool->eventNumElements--;
		((DSPEEvent*) event)->next = NULL;
		return event;
	}
}

/* CreateGroup function */
void ParticleTrackerDllTrajectory_MessageGate_createGroup(ParticleTrackerDllTrajectory_MessageGate_groupEvent *event, size_t index) {
	event->value[index] = (ParticleTrackerDllTrajectory_MessageGate*) memoryManager_allocate((DSPEElement*) ((DSPEEvent*) event)->pool, sizeof(ParticleTrackerDllTrajectory_MessageGate));
}

/* InitialiseGroup function */
void ParticleTrackerDllTrajectory_MessageGate_initializeGroup(ParticleTrackerDllTrajectory_MessageGate_groupEvent *event, size_t index) {
	*event->value[index] = PARTICLETRACKERDLLTRAJECTORY_MESSAGEGATE_DEFAULTVALUE;
}

/**
 * Copy function
 */
void ParticleTrackerDllTrajectory_MessageGate_copyGroup(ParticleTrackerDllTrajectory_MessageGate_groupEvent *event, ParticleTrackerDllTrajectory_MessageGate value, size_t index) {
	*event->value[index] = value;
}

/* CloneGroup event function */
DSPEEvent* ParticleTrackerDllTrajectory_MessageGate_cloneGroup(DSPEEvent *event) {
	register size_t i;
	ParticleTrackerDllTrajectory_MessageGate_groupPool *gatePool = (ParticleTrackerDllTrajectory_MessageGate_groupPool*) event->pool;
	ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent *clone = NULL;
	
	switch (gatePool->cloneNumElements) {
	case 0:
		clone = (ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent));
		((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) clone)->value = (ParticleTrackerDllTrajectory_MessageGate**) memoryManager_allocate((DSPEElement*) gatePool, ((DSPEGroupEvent*) event)->groupSize * sizeof(ParticleTrackerDllTrajectory_MessageGate*));
		((DSPEEvent*) clone)->dispose = ParticleTrackerDllTrajectory_MessageGate_disposeGroupClone;
		((DSPEEvent*) clone)->clone = ParticleTrackerDllTrajectory_MessageGate_cloneGroup;
		((DSPEEvent*) clone)->pool = event->pool;
		((DSPEEvent*) clone)->blockSize = event->blockSize;
		((DSPEGroupEvent*) clone)->groupSize = ((DSPEGroupEvent*) event)->groupSize;
		break;
	case 1:
		clone = gatePool->headClone;
		gatePool->headClone = NULL;
		gatePool->tailClone = NULL;
		gatePool->cloneNumElements = 0;
		break;
	default:
		clone = gatePool->headClone;
		gatePool->headClone = (ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent*) ((DSPEEvent*) clone)->next;
		gatePool->cloneNumElements--;
		break;
	}
	
	event->refCount++;
	clone->original = (DSPEGroupEvent*) event;
	
	((DSPEEvent*) clone)->next = NULL;
	
	for (i = 0; i < ((DSPEGroupEvent*) event)->groupSize; i++) {
		((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) clone)->value[i] = ((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) event)->value[i];
	}

	return (DSPEEvent*) clone;
}

/* SubClone event function */
DSPEEvent* ParticleTrackerDllTrajectory_MessageGate_subClone(DSPEGroupEvent *event, DSPEEventsPool *pool, size_t index) {
	ParticleTrackerDllTrajectory_MessageGate_pool *gatePool = (ParticleTrackerDllTrajectory_MessageGate_pool*) pool;
	ParticleTrackerDllTrajectory_MessageGate_cloneEvent *clone = NULL;
	
	switch (gatePool->cloneNumElements) {
	case 0:
		clone = (ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllTrajectory_MessageGate_cloneEvent));
		((ParticleTrackerDllTrajectory_MessageGate_event*) clone)->value = NULL;
		((DSPEEvent*) clone)->refCount = 0;
		((DSPEEvent*) clone)->dispose = ParticleTrackerDllTrajectory_MessageGate_disposeClone;
		((DSPEEvent*) clone)->clone = ParticleTrackerDllTrajectory_MessageGate_clone;
		((DSPEEvent*) clone)->pool = pool;
		((DSPEEvent*) clone)->blockSize = ((DSPEEvent*) event)->blockSize;
		break;
	case 1:
		clone = gatePool->headClone;
		gatePool->headClone = NULL;
		gatePool->tailClone = NULL;
		gatePool->cloneNumElements = 0;
		break;
	default:
		clone = gatePool->headClone;
		gatePool->headClone = (ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) ((DSPEEvent*) clone)->next;
		gatePool->cloneNumElements--;
		break;
	}
	((DSPEEvent*) clone)->next = NULL;

	/* Set clone's original and increment original's refCounter */
	((DSPEEvent*) event)->refCount++;
	((ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) clone)->original = (DSPEEvent*) event;
	
	((ParticleTrackerDllTrajectory_MessageGate_event*) clone)->value = ((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) event)->value[index];
	return (DSPEEvent*) clone;
}

/**
 * Allocate containerEvent function
 */
ParticleTrackerDllTrajectory_MessageGate_eventContainer* ParticleTrackerDllTrajectory_MessageGate_allocateContainer(ParticleTrackerDllTrajectory_MessageGate_groupPool *grpPool) {
	ParticleTrackerDllTrajectory_MessageGate_groupPool *gatePool = (ParticleTrackerDllTrajectory_MessageGate_groupPool*) grpPool;
	ParticleTrackerDllTrajectory_MessageGate_eventContainer *event = NULL;
	register size_t i;
	switch (gatePool->containerNumElements) {
	case 0:
		event = (ParticleTrackerDllTrajectory_MessageGate_eventContainer*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllTrajectory_MessageGate_eventContainer));
		initDSPEGroupEvent((DSPEGroupEvent*) event);
		((DSPEEvent*) event)->pool = (DSPEEventsPool*) grpPool;
		((DSPEEvent*) event)->dispose = ParticleTrackerDllTrajectory_MessageGate_disposeContainer;
		((DSPEEvent*) event)->clone = ParticleTrackerDllTrajectory_MessageGate_cloneGroup;
		((DSPEGroupEvent*) event)->groupSize = ((DSPEGroupEventsPool*) gatePool)->groupSize;
		((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) event)->value = (ParticleTrackerDllTrajectory_MessageGate**) memoryManager_allocate((DSPEElement*) gatePool, ((DSPEGroupEventsPool*) gatePool)->groupSize * sizeof(ParticleTrackerDllTrajectory_MessageGate*));
		event->containedEvents = (DSPEEvent**) memoryManager_allocate((DSPEElement*) gatePool, ((DSPEGroupEventsPool*) gatePool)->groupSize * sizeof(DSPEEvent*));
		for (i = 0; i < ((DSPEGroupEventsPool*) gatePool)->groupSize; i++) {
			event->containedEvents[i] = NULL;
			((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) event)->value[i] = NULL;
		}
		return event;
	case 1:
		event = gatePool->headContainer;
		gatePool->headContainer = NULL;
		gatePool->tailContainer = NULL;
		gatePool->containerNumElements = 0;
		((DSPEEvent*) event)->next = NULL;
		return event;
	default:
		event = gatePool->headContainer;
		gatePool->headContainer = (ParticleTrackerDllTrajectory_MessageGate_eventContainer*) ((DSPEEvent*) event)->next;
		gatePool->containerNumElements--;
		((DSPEEvent*) event)->next = NULL;
		return event;
	}
}

/**
 * Dispose containerEvent function
 */
void ParticleTrackerDllTrajectory_MessageGate_disposeContainer(DSPEEvent *event) {
	ParticleTrackerDllTrajectory_MessageGate_groupPool *gatePool = (ParticleTrackerDllTrajectory_MessageGate_groupPool*) event->pool;
	register size_t i;
	ParticleTrackerDllTrajectory_MessageGate_eventContainer *container = (ParticleTrackerDllTrajectory_MessageGate_eventContainer*) event;
	DSPEEvent *refEvent = NULL;
	if (event->refCount == 1) {
		for (i = 0; i < ((DSPEGroupEventsPool*) gatePool)->groupSize; i++) {
			refEvent = container->containedEvents[i];
			if (refEvent != NULL) {
				refEvent->dispose(refEvent);
				container->containedEvents[i] = NULL;
			}
			((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) container)->value[i] = NULL;
		}
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->containerNumElements) {
		case 0:
			gatePool->headContainer = (ParticleTrackerDllTrajectory_MessageGate_eventContainer*) event;
			gatePool->tailContainer = (ParticleTrackerDllTrajectory_MessageGate_eventContainer*) event;
			gatePool->containerNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailContainer)->next = event;
			gatePool->tailContainer = (ParticleTrackerDllTrajectory_MessageGate_eventContainer*) event;
			gatePool->containerNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* DisposeGroup function */
void ParticleTrackerDllTrajectory_MessageGate_disposeGroup(DSPEEvent *event) {
	ParticleTrackerDllTrajectory_MessageGate_groupPool *gatePool = (ParticleTrackerDllTrajectory_MessageGate_groupPool*) event->pool;
	if (event->refCount == 1) {
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->eventNumElements) {
		case 0:
			gatePool->headEvent = (ParticleTrackerDllTrajectory_MessageGate_groupEvent*) event;
			gatePool->tailEvent = (ParticleTrackerDllTrajectory_MessageGate_groupEvent*) event;
			gatePool->eventNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailEvent)->next = event;
			gatePool->tailEvent = (ParticleTrackerDllTrajectory_MessageGate_groupEvent*) event;
			gatePool->eventNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* Dispose GroupClone function */
void ParticleTrackerDllTrajectory_MessageGate_disposeGroupClone(DSPEEvent *event) {
	ParticleTrackerDllTrajectory_MessageGate_groupPool *gatePool = (ParticleTrackerDllTrajectory_MessageGate_groupPool*) event->pool;
	DSPEEvent *original = (DSPEEvent*) ((ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent*) event)->original;
	if (event->refCount == 1) {
		original->dispose(original);
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->cloneNumElements) {
		case 0:
			gatePool->headClone = (ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent*) event;
			gatePool->tailClone = (ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent*) event;
			gatePool->cloneNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailClone)->next = event;
			gatePool->tailClone = (ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent*) event;
			gatePool->cloneNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* eventPool dispose function */
void ParticleTrackerDllTrajectory_MessageGate_disposeGroupPool(DSPEEventsPool *pool) {
	register size_t i, j;
	DSPEEvent *tmpEvent = NULL;
	DSPEEventsPool *eventPool = NULL;
	DSPEEventsPool *tmpEventPool = NULL;
	ParticleTrackerDllTrajectory_MessageGate_groupPool *thisPool = (ParticleTrackerDllTrajectory_MessageGate_groupPool*) pool;

	/* dispose children */
	eventPool = (DSPEEventsPool*) ((DSPEGroupEventsPool*) thisPool)->groupsHead;
	for (i = 0; i < ((DSPEGroupEventsPool*) thisPool)->groupsNumElements; i++) {
		tmpEventPool = eventPool;
		eventPool = eventPool->next;
		tmpEventPool->next = NULL;
		tmpEventPool->dispose(tmpEventPool);
	}
	
	/* dispose events */
	for (i = 0; i < thisPool->eventNumElements; i++) {
		tmpEvent = (DSPEEvent*) thisPool->headEvent;
		thisPool->headEvent = (ParticleTrackerDllTrajectory_MessageGate_groupEvent*) tmpEvent->next;
		tmpEvent->next = NULL;
		for (j = 0; j < ((DSPEGroupEventsPool*) thisPool)->groupSize; j++) {
			memorySupport_dispose(((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) tmpEvent)->value[j]);
		}
		memorySupport_dispose(((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) tmpEvent)->value);
		memorySupport_dispose(tmpEvent);
	}
	
	/* dispose clones */
	for (i = 0; i < thisPool->cloneNumElements; i++) {
		tmpEvent = (DSPEEvent*) thisPool->headClone;
		thisPool->headClone = (ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent*) tmpEvent->next;
		tmpEvent->next = NULL;
		memorySupport_dispose(((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) tmpEvent)->value);
		memorySupport_dispose(tmpEvent);
	}
	
	/* Dispose eventContainers if any present */
	for (i = 0; i < thisPool->containerNumElements; i++) {
		tmpEvent = (DSPEEvent*) thisPool->headContainer;
		thisPool->headContainer = (ParticleTrackerDllTrajectory_MessageGate_eventContainer*) tmpEvent->next;
		tmpEvent->next = NULL;
		memorySupport_dispose(((ParticleTrackerDllTrajectory_MessageGate_eventContainer*) tmpEvent)->containedEvents);
		memorySupport_dispose(((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) tmpEvent)->value);
		memorySupport_dispose(tmpEvent);
	}
	
	/* dispose pool */
	memorySupport_dispose(thisPool);
}

/* CreateNode function */
ParticleTrackerDllTrajectory_MessageGate_node* ParticleTrackerDllTrajectory_MessageGate_createNode(ParticleTrackerDllTrajectory_MessageGate *localVar, DSPEApplication *application, DSPEEventsPool *pool, unsigned int eventID) {
	ParticleTrackerDllTrajectory_MessageGate_node *node = (ParticleTrackerDllTrajectory_MessageGate_node*) memoryManager_allocate((DSPEElement*) application, sizeof(ParticleTrackerDllTrajectory_MessageGate_node));
	initDSPEGateNode((DSPEGateNode*) node);
	node->eventID = eventID;
	node->application = application;
	node->pool = pool;
	node->localVar = localVar;
	node->sendEvent = 0;
	((DSPEGateNode*) node)->setValue = ParticleTrackerDllTrajectory_MessageGate_setValue;
	((DSPEGateNode*) node)->disposeNode = ParticleTrackerDllTrajectory_MessageGate_disposeNode;
	return node;
}

/* DisposeNode function */
void ParticleTrackerDllTrajectory_MessageGate_disposeNode(DSPEElement *context, DSPEGateNode *node) {
	node->next = NULL;
	memorySupport_dispose(node);
}

/* SetValue function */
void ParticleTrackerDllTrajectory_MessageGate_setValue(DSPEElement *context, DSPEGateNode *node) {
	ParticleTrackerDllTrajectory_MessageGate_event *event = NULL;
	ParticleTrackerDllTrajectory_MessageGate_node *tmpNode = (ParticleTrackerDllTrajectory_MessageGate_node*) node;
	if (tmpNode->sendEvent) {
		tmpNode->sendEvent = 0;
		event = ParticleTrackerDllTrajectory_MessageGate_allocate((ParticleTrackerDllTrajectory_MessageGate_pool*) tmpNode->pool);
		ParticleTrackerDllTrajectory_MessageGate_copy(event, tmpNode->value);
		((DSPEEvent*) event)->refCount = 1;
		if (((DSPEEventsApplication*) tmpNode->application)->queueEvent != NULL)
			((DSPEEventsApplication*) tmpNode->application)->queueEvent((DSPEEventsApplication*) tmpNode->application, (DSPEEvent*) event, tmpNode->eventID);
		ParticleTrackerDllTrajectory_MessageGate_dispose((DSPEEvent*) event);
	}
	if (tmpNode->localVar != 0)
		*tmpNode->localVar = tmpNode->value;
}

