/**
 * File: RProd_ParticleTrackerDllLibraryDataWriter_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef RProd_ParticleTrackerDllLibraryDataWriter_SoftwareUnit_h
#define RProd_ParticleTrackerDllLibraryDataWriter_SoftwareUnit_h

#include "B_ParticleTrackerDllLibraryDataWriter_StateImplementation.h"
#include "B_ParticleTrackerDllLibraryDataWriter_SoftwareUnit.h"
#include "B_ParticleTrackerDllTrajectory_MessageGate.h"

/* Real SoftwareUnit state type definition */
typedef struct ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd;

/* Real SoftwareUnit state definition */
struct ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd {

	/* Base unit state */
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllLibraryDataWriter_StateImplementation implState;
	
	/* Data transit queues */
	size_t dataIn_Trajectory_transitNumElements;
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *dataIn_Trajectory_transitHead;
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *dataIn_Trajectory_transitTail;
	ParticleTrackerDllLibraryDataWriter_SoftwareUnit_queueNode *dataIn_Trajectory_curTransit;
	unsigned int dataIn_Trajectory_curTransitIndex;

	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllTrajectory_MessageGate *dataIn_Trajectory_unlinked;

};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_transitEventRealProd(DSPEQueueUnit *unit);

size_t ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getTransitNumElementsRealProd(DSPEQueueUnit *unit, unsigned int ID);

size_t ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getCurrentNumElementsRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getFirstTransitRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_getCurTransitRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_dismissEventRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_dismissAllEventsRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_armEventRealProd(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_postEventRealProd(DSPEEventsUnit *unit, unsigned int ID);

/* Earlyalloc function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_earlyAllocRealProd(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context);

/* Alloc function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_allocRealProd(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context);

/* Earlyconnect function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_earlyConnectRealProd(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context);

/* Connect function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_connectRealProd(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context);

/* Startup function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_startupRealProd(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context);

/* Preprocess function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_preProcessRealProd(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_processRealProd(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_postProcessRealProd(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_resetRealProd(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context);

/* Shutdown function */
void ParticleTrackerDllLibraryDataWriter_SoftwareUnit_shutdownRealProd(ParticleTrackerDllLibraryDataWriter_SoftwareUnit_realProd *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
