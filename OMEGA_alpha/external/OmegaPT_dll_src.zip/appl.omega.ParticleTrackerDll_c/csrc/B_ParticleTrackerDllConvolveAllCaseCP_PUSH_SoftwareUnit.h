/**
 * File: B_ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef B_ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_h
#define B_ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_h

#include "DSPEElements.h"
#include "DSPEXTElements.h"

#include "B_ParticleTrackerDllNextGate_SignalGate.h"
#include "B_ParticleTrackerDllIntGate_StandardGate.h"
#include "B_ParticleTrackerDllStatusGate_StringGate.h"

/* Queue node type definition */
typedef struct ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueNode ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueNode;

/* Queue node type definition */
struct ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueNode {
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueNode *next;
	unsigned int ID;
	DSPEEvent *event;
	/* Transit node support */
	short inTransit;
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueNode *nextInTransit;
};

/* State type definition */
typedef struct ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit;

/* State definition */ 
struct ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit {

	DSPECoprocUnit coprocUnit;

	unsigned int poolNumNodes;
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueNode *poolHead;
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueNode *poolTail;

	unsigned int queueNumNodes;
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueNode *queueHead;
	ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueNode *queueTail;

	/* Parameter gates */
	ParticleTrackerDllIntGate_StandardGate *paramIn_stop;
	ParticleTrackerDllIntGate_StandardGate *paramIn_Radius;
	ParticleTrackerDllIntGate_StandardGate *paramOut_stop;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status;


	/* Output parameters places */
	ParticleTrackerDllIntGate_StandardGate *paramOut_stop_place;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status_place;


	/* Output parameters places anchors */
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status_placeAnchor;

	/* Gates numLinks */
	unsigned int dataIn_SequenceValues_numLinks;
	unsigned int dataIn_PTFrame_numLinks;
	unsigned int dataOut_PTFrame_numLinks;
	unsigned int dataOut_PTFiltered_numLinks;
	unsigned int paramIn_next_numLinks;
	unsigned int paramIn_stop_numLinks;
	unsigned int paramIn_Radius_numLinks;
	unsigned int paramOut_next_numLinks;
	unsigned int paramOut_stop_numLinks;
	unsigned int paramOut_Status_numLinks;

	/* unit ID */
	char *ID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_queueEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID);

void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_releaseEvent(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *context);

int ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_isEventAvailable(const DSPEQueueUnit *unit);

DSPEEvent* ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_getEvent(const DSPEQueueUnit *unit);

unsigned int ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_getEventID(const DSPEQueueUnit *unit);

/* getID function */
char* ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_getID(const DSPEElement *element);

/* Alloc function */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_alloc(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *context);

/* Earlyconnect function */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_earlyConnect(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *context);

/* Postprocess function */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_postProcess(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *context);

/* Reset function */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_reset(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *context);

/* Shutdown function */
void ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit_shutdown(ParticleTrackerDllConvolveAllCaseCP_PUSH_SoftwareUnit *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
