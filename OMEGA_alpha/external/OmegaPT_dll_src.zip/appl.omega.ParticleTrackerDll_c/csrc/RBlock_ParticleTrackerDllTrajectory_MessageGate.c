/**
 * File: RBlock_ParticleTrackerDllTrajectory_MessageGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#include "MemoryManager.h"

#include "RBlock_ParticleTrackerDllTrajectory_MessageGate.h"

/* eventPool initialization function */
ParticleTrackerDllTrajectory_MessageGate_poolBlock* ParticleTrackerDllTrajectory_MessageGate_initPoolBlock(const DSPEOwner *owner, size_t size) {
	DSPEPoolHandler *handler = memoryManager_getPoolHandler(owner);
	ParticleTrackerDllTrajectory_MessageGate_poolBlock *pool = (ParticleTrackerDllTrajectory_MessageGate_poolBlock*) memoryManager_getPoolBlock(handler, &ParticleTrackerDllTrajectory_MessageGate_allocateBlock, size);
	/* lazy initialization */
	if (pool == NULL) {
		pool = (ParticleTrackerDllTrajectory_MessageGate_poolBlock*) memoryManager_allocate(CAST_TO_ELEMENT(owner), sizeof(ParticleTrackerDllTrajectory_MessageGate_poolBlock));
		initDSPEElement((DSPEElement*) pool, (DSPEElement*) handler);
		initDSPEBlockEventsPool((DSPEBlockEventsPool*) pool);
		pool->eventNumElements = 0;
		pool->headEvent = NULL;
		pool->tailEvent = NULL;
		pool->cloneNumElements = 0;
		pool->headClone = NULL;
		pool->tailClone = NULL;
		((DSPEEventsPool*) pool)->gateDefID = &ParticleTrackerDllTrajectory_MessageGate_allocateBlock;
		((DSPEEventsPool*) pool)->preAlloc = ParticleTrackerDllTrajectory_MessageGate_preAllocPoolBlock;
		((DSPEEventsPool*) pool)->reset = ParticleTrackerDllTrajectory_MessageGate_resetPoolBlock;
		((DSPEEventsPool*) pool)->dispose = ParticleTrackerDllTrajectory_MessageGate_disposePoolBlock;
		((DSPEBlockEventsPool*) pool)->size = size;
		memoryManager_addPoolBlock(handler, (DSPEBlockEventsPool*) pool);
	}
	return pool;
}

/* eventPool preAlloc function */
void ParticleTrackerDllTrajectory_MessageGate_preAllocPoolBlock(DSPEEventsPool *pool, size_t size) {
	ParticleTrackerDllTrajectory_MessageGate_poolBlock *concretePool = (ParticleTrackerDllTrajectory_MessageGate_poolBlock*) pool;
	DSPEEventsPool *childPool = NULL;
	register size_t i;
	ParticleTrackerDllTrajectory_MessageGate_event *firstEvent = NULL;
	ParticleTrackerDllTrajectory_MessageGate_event *lastEvent = NULL;
	ParticleTrackerDllTrajectory_MessageGate_event *currEvent = NULL;

	/* PreAlloc blocks children */
	childPool = (DSPEEventsPool*) ((DSPEBlockEventsPool*) pool)->blocksHead;
	for (i = 0; i < ((DSPEBlockEventsPool*) pool)->blocksNumElements; i++) {
		childPool->preAlloc(childPool, size);
		childPool = childPool->next;
	}

	firstEvent = ParticleTrackerDllTrajectory_MessageGate_allocateBlock(concretePool);
	lastEvent = firstEvent;
	ParticleTrackerDllTrajectory_MessageGate_initializeBlock(firstEvent);

	/* size - 1 because of allocation of first */
	for (i = 0; i < size - 1; i++) {
		currEvent = ParticleTrackerDllTrajectory_MessageGate_allocateBlock(concretePool);
		ParticleTrackerDllTrajectory_MessageGate_initializeBlock(currEvent);
		
		((DSPEEvent*) lastEvent)->next = (DSPEEvent*) currEvent;
		lastEvent = currEvent;
	}

	concretePool->headEvent = firstEvent;
	concretePool->tailEvent = lastEvent;
	concretePool->eventNumElements = size;
}

/* eventPool reset function */
void ParticleTrackerDllTrajectory_MessageGate_resetPoolBlock(DSPEEventsPool *pool) {
	ParticleTrackerDllTrajectory_MessageGate_poolBlock *concretePool = (ParticleTrackerDllTrajectory_MessageGate_poolBlock*) pool;
	DSPEEventsPool *childPool = NULL;
	register size_t i;
	ParticleTrackerDllTrajectory_MessageGate_event *event = NULL;
	/* Reset blocks children */
	childPool = (DSPEEventsPool*) ((DSPEBlockEventsPool*) pool)->blocksHead;
	for (i = 0; i < ((DSPEBlockEventsPool*) pool)->blocksNumElements; i++) {
		childPool->reset(childPool);
		childPool = childPool->next;
	}

	event = concretePool->headEvent;
	for (i = 0; i < concretePool->eventNumElements; i++) {
		ParticleTrackerDllTrajectory_MessageGate_initializeBlock(event);
		event = (ParticleTrackerDllTrajectory_MessageGate_event*) ((DSPEEvent*) event)->next;
	}
}

/* Allocate function */
ParticleTrackerDllTrajectory_MessageGate_event* ParticleTrackerDllTrajectory_MessageGate_allocateBlock(ParticleTrackerDllTrajectory_MessageGate_poolBlock *pool) {
	ParticleTrackerDllTrajectory_MessageGate_poolBlock *gatePool = (ParticleTrackerDllTrajectory_MessageGate_poolBlock*) pool;
	ParticleTrackerDllTrajectory_MessageGate_event *event = NULL;

	switch (gatePool->eventNumElements) {
	case 0:
		event = (ParticleTrackerDllTrajectory_MessageGate_event*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllTrajectory_MessageGate_event));
		initDSPEEvent((DSPEEvent*) event);
		event->value = (ParticleTrackerDllTrajectory_MessageGate*) memoryManager_allocate((DSPEElement*) gatePool, ((DSPEBlockEventsPool*) gatePool)->size * sizeof(ParticleTrackerDllTrajectory_MessageGate));
		((DSPEEvent*) event)->blockSize = ((DSPEBlockEventsPool*) gatePool)->size;
		((DSPEEvent*) event)->pool = (DSPEEventsPool*) pool;
		((DSPEEvent*) event)->dispose = ParticleTrackerDllTrajectory_MessageGate_disposeBlock;
		((DSPEEvent*) event)->clone = ParticleTrackerDllTrajectory_MessageGate_cloneBlock;
		ParticleTrackerDllTrajectory_MessageGate_initializeBlock(event);
		return event;
	case 1:
		event = (ParticleTrackerDllTrajectory_MessageGate_event*) gatePool->headEvent;
		gatePool->headEvent = NULL;
		gatePool->tailEvent = NULL;
		gatePool->eventNumElements = 0;
		((DSPEEvent*) event)->next = NULL;
		return event;
	default:
		event = (ParticleTrackerDllTrajectory_MessageGate_event*) gatePool->headEvent;
		gatePool->headEvent = (ParticleTrackerDllTrajectory_MessageGate_event*) ((DSPEEvent*) event)->next;
		gatePool->eventNumElements--;
		((DSPEEvent*) event)->next = NULL;
		return event;
	}
}

/* Initialise function */
void ParticleTrackerDllTrajectory_MessageGate_initializeBlock(ParticleTrackerDllTrajectory_MessageGate_event *event) {
	register size_t i;
	for (i = 0; i <  ((DSPEEvent*) event)->blockSize; i++) {
		event->value[i] = PARTICLETRACKERDLLTRAJECTORY_MESSAGEGATE_DEFAULTVALUE;
	}
}

/* Clone event function */
DSPEEvent* ParticleTrackerDllTrajectory_MessageGate_cloneBlock(DSPEEvent *event) {
	ParticleTrackerDllTrajectory_MessageGate_poolBlock *gatePool = (ParticleTrackerDllTrajectory_MessageGate_poolBlock*) event->pool;
	ParticleTrackerDllTrajectory_MessageGate_cloneEvent *clone = NULL;
	
	switch (gatePool->cloneNumElements) {
	case 0:
		clone = (ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllTrajectory_MessageGate_cloneEvent));
		initDSPEEvent((DSPEEvent*) clone);
		((DSPEEvent*) clone)->dispose = ParticleTrackerDllTrajectory_MessageGate_disposeCloneBlock;
		((DSPEEvent*) clone)->clone = ParticleTrackerDllTrajectory_MessageGate_cloneBlock;
		((DSPEEvent*) clone)->pool = event->pool;
		((DSPEEvent*) clone)->blockSize = event->blockSize;
		break;
	case 1:
		clone = gatePool->headClone;
		gatePool->headClone = NULL;
		gatePool->tailClone = NULL;
		gatePool->cloneNumElements = 0;
		break;
	default:
		clone = gatePool->headClone;
		gatePool->headClone = (ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) ((DSPEEvent*) clone)->next;
		gatePool->cloneNumElements--;
		break;
	}

	event->refCount++;
	clone->original = event;

	((DSPEEvent*) clone)->next = NULL;

	((ParticleTrackerDllTrajectory_MessageGate_event*) clone)->value = ((ParticleTrackerDllTrajectory_MessageGate_event*) event)->value;

	return (DSPEEvent*) clone;
}

/* Dispose function */
void ParticleTrackerDllTrajectory_MessageGate_disposeBlock(DSPEEvent *event) {
	ParticleTrackerDllTrajectory_MessageGate_poolBlock *gatePool = (ParticleTrackerDllTrajectory_MessageGate_poolBlock*) event->pool;
	if (event->refCount == 1) {
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->eventNumElements) {
		case 0:
			gatePool->headEvent = (ParticleTrackerDllTrajectory_MessageGate_event*) event;
			gatePool->tailEvent = (ParticleTrackerDllTrajectory_MessageGate_event*) event;
			gatePool->eventNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailEvent)->next = (DSPEEvent*) event;
			gatePool->tailEvent = (ParticleTrackerDllTrajectory_MessageGate_event*) event;
			gatePool->eventNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* Dispose clone function */
void ParticleTrackerDllTrajectory_MessageGate_disposeCloneBlock(DSPEEvent *event) {
	ParticleTrackerDllTrajectory_MessageGate_poolBlock *gatePool = (ParticleTrackerDllTrajectory_MessageGate_poolBlock*) event->pool;
	DSPEEvent *original = (DSPEEvent*) ((ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) event)->original;
	if (event->refCount == 1) {
		original->dispose(original);
		((ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) event)->original = NULL;
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->cloneNumElements) {
		case 0:
			gatePool->headClone = (ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) event;
			gatePool->tailClone = (ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) event;
			gatePool->cloneNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailClone)->next = (DSPEEvent*) event;
			gatePool->tailClone = (ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) event;
			gatePool->cloneNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* eventPool dispose function */
void ParticleTrackerDllTrajectory_MessageGate_disposePoolBlock(DSPEEventsPool *pool) {
	ParticleTrackerDllTrajectory_MessageGate_poolBlock *thisPool = (ParticleTrackerDllTrajectory_MessageGate_poolBlock*) pool;
	register size_t i;
	DSPEEventsPool *eventPool = NULL;
	DSPEEventsPool *tmpEventPool = NULL;
	DSPEEvent *tmpEvent = NULL;

	/* Dispose children */
	eventPool = (DSPEEventsPool*) ((DSPEBlockEventsPool*) thisPool)->blocksHead;
	for (i = 0; i < ((DSPEBlockEventsPool*) thisPool)->blocksNumElements; i++) {
		tmpEventPool = eventPool;
		eventPool = eventPool->next;
		tmpEventPool->next = NULL;
		tmpEventPool->dispose(tmpEventPool);
	}
	
	/* Dispose events if any present */
	for (i = 0; i < thisPool->eventNumElements; i++) {
		tmpEvent = (DSPEEvent*) thisPool->headEvent;
		thisPool->headEvent = (ParticleTrackerDllTrajectory_MessageGate_event*) tmpEvent->next;
		tmpEvent->next = NULL;
		memorySupport_dispose(((ParticleTrackerDllTrajectory_MessageGate_event*) tmpEvent)->value);
		memorySupport_dispose(tmpEvent);
	}
	/* Dispose clones if any present */
	for (i = 0; i < thisPool->cloneNumElements; i++) {
		tmpEvent = (DSPEEvent*) thisPool->headClone;
		thisPool->headClone = (ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) tmpEvent->next;
		tmpEvent->next = NULL;
		((ParticleTrackerDllTrajectory_MessageGate_event*) tmpEvent)->value = NULL;
		memorySupport_dispose(tmpEvent);
	}
	memorySupport_dispose(thisPool);
}

/* Allocate function */
ParticleTrackerDllTrajectory_MessageGate* ParticleTrackerDllTrajectory_MessageGate_allocateUnlinkedBlock(DSPEElement *context, size_t size) {
	return memoryManager_allocate(context, size * sizeof(ParticleTrackerDllTrajectory_MessageGate));
}

/* Initialise function */
void ParticleTrackerDllTrajectory_MessageGate_initializeUnlinkedBlock(DSPEElement *context, ParticleTrackerDllTrajectory_MessageGate *place, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllTrajectory_MessageGate_initializeUnlinked(context, &place[i]);
	}
}

/* Dispose function */
void ParticleTrackerDllTrajectory_MessageGate_disposeUnlinkedBlock(DSPEElement *context, ParticleTrackerDllTrajectory_MessageGate *place) {
	memorySupport_dispose(place);
}

/* groupEventPool initialization function */
ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock* ParticleTrackerDllTrajectory_MessageGate_initGroupPoolBlock(const DSPEOwner *owner, size_t groupSize, size_t blockSize) {
	DSPEPoolHandler *handler = memoryManager_getPoolHandler(owner);
	ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock *pool = (ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock*) memoryManager_getGroupPoolBlock(handler, &ParticleTrackerDllTrajectory_MessageGate_allocateGroupBlock, groupSize, blockSize);
	/* lazy initialization */
	if (pool == NULL){
		pool = (ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock*) memoryManager_allocate(CAST_TO_ELEMENT(owner), sizeof(ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock));
		initDSPEElement((DSPEElement*) pool, (DSPEElement*) handler);
		initDSPEGroupBlockEventsPool((DSPEGroupBlockEventsPool*) pool);
		pool->eventNumElements = 0;
		pool->headEvent = NULL;
		pool->tailEvent = NULL;
		pool->cloneNumElements = 0;
		pool->headClone = NULL;
		pool->tailClone = NULL;
		pool->containerNumElements = 0;
		pool->headContainer = NULL;
		pool->tailContainer = NULL;
		((DSPEEventsPool*) pool)->gateDefID = &ParticleTrackerDllTrajectory_MessageGate_allocateGroupBlock;
		((DSPEEventsPool*) pool)->preAlloc = ParticleTrackerDllTrajectory_MessageGate_preAllocGroupPoolBlock;
		((DSPEEventsPool*) pool)->reset = ParticleTrackerDllTrajectory_MessageGate_resetGroupPoolBlock;
		((DSPEEventsPool*) pool)->dispose = ParticleTrackerDllTrajectory_MessageGate_disposeGroupPoolBlock;
		((DSPEBlockEventsPool*) pool)->size = blockSize;
		((DSPEGroupBlockEventsPool*) pool)->groupSize = groupSize;
		memoryManager_addGroupPoolBlock(handler, (DSPEGroupBlockEventsPool*) pool);
	}
	return pool;
}

/* eventPool preAlloc function */
void ParticleTrackerDllTrajectory_MessageGate_preAllocGroupPoolBlock(DSPEEventsPool *pool, size_t size) {
	ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock *concretePool = (ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock*) pool;
	DSPEEventsPool *childPool = NULL;
	register size_t i, j;
	ParticleTrackerDllTrajectory_MessageGate_groupEvent *firstEvent = NULL;
	ParticleTrackerDllTrajectory_MessageGate_groupEvent *lastEvent = NULL;
	ParticleTrackerDllTrajectory_MessageGate_groupEvent *currEvent = NULL;
	
	/* PreAlloc blocks children */
	childPool = (DSPEEventsPool*) ((DSPEGroupBlockEventsPool*) pool)->blocksHead;
	for (i = 0; i < ((DSPEGroupBlockEventsPool*) pool)->blocksNumElements; i++) {
		childPool->preAlloc(childPool, size);
		childPool = childPool->next;
	}

	/* PreAlloc groups children */
	childPool = (DSPEEventsPool*) ((DSPEGroupBlockEventsPool*) pool)->groupsHead;
	for (i = 0; i < ((DSPEGroupBlockEventsPool*) pool)->groupsNumElements; i++) {
		childPool->preAlloc(childPool, size);
		childPool = childPool->next;
	}

	firstEvent = ParticleTrackerDllTrajectory_MessageGate_allocateGroupBlock(concretePool);
	lastEvent = firstEvent;
	for (i = 0; i < ((DSPEGroupBlockEventsPool*) pool)->groupSize; i++) {
		ParticleTrackerDllTrajectory_MessageGate_initializeGroupBlock(firstEvent, i);
	}

	/* size - 1 because of allocation of first */
	for (i = 0; i < size - 1; i++) {
		currEvent = ParticleTrackerDllTrajectory_MessageGate_allocateGroupBlock(concretePool);
		for (j = 0; j < ((DSPEGroupBlockEventsPool*) pool)->groupSize; j++) {
			ParticleTrackerDllTrajectory_MessageGate_initializeGroupBlock(currEvent, j);
		}
		
		((DSPEEvent*) lastEvent)->next = (DSPEEvent*) currEvent;
		lastEvent = currEvent;
	}

	concretePool->headEvent = firstEvent;
	concretePool->tailEvent = lastEvent;
	concretePool->eventNumElements = size;
}

/* eventPool reset function */
void ParticleTrackerDllTrajectory_MessageGate_resetGroupPoolBlock(DSPEEventsPool *pool) {
	ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock *concretePool = (ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock*) pool;
	DSPEEventsPool *childPool = NULL;
	register size_t i, j;
	ParticleTrackerDllTrajectory_MessageGate_groupEvent *event = NULL;
	/* PreAlloc blocks children */
	childPool = (DSPEEventsPool*) ((DSPEGroupBlockEventsPool*) pool)->blocksHead;
	for (i = 0; i < ((DSPEGroupBlockEventsPool*) pool)->blocksNumElements; i++) {
		childPool->reset(childPool);
		childPool = childPool->next;
	}

	/* PreAlloc groups children */
	childPool = (DSPEEventsPool*) ((DSPEGroupBlockEventsPool*) pool)->groupsHead;
	for (i = 0; i < ((DSPEGroupBlockEventsPool*) pool)->groupsNumElements; i++) {
		childPool->reset(childPool);
		childPool = childPool->next;
	}
	
	event = concretePool->headEvent;
	for (i = 0; i < concretePool->eventNumElements; i++) {
		for (j = 0; j < ((DSPEGroupBlockEventsPool*) pool)->groupSize; j++) {
			ParticleTrackerDllTrajectory_MessageGate_initializeGroupBlock(event, j);
		}
		event = (ParticleTrackerDllTrajectory_MessageGate_groupEvent*) ((DSPEEvent*) event)->next;
	}
}

/* AllocateGroup function */
ParticleTrackerDllTrajectory_MessageGate_groupEvent* ParticleTrackerDllTrajectory_MessageGate_allocateGroupBlock(ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock *pool) {
	ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock *gatePool = (ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock*) pool;
	register size_t i;
	ParticleTrackerDllTrajectory_MessageGate_groupEvent *event = NULL;

	switch (gatePool->eventNumElements) {
	case 0:
		event = (ParticleTrackerDllTrajectory_MessageGate_groupEvent*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllTrajectory_MessageGate_groupEvent));
		initDSPEEvent((DSPEEvent*) event);
		initDSPEGroupEvent((DSPEGroupEvent*) event);
		((DSPEGroupEvent*) event)->groupSize = ((DSPEGroupBlockEventsPool*) pool)->groupSize;
		((DSPEEvent*) event)->blockSize = ((DSPEBlockEventsPool*) pool)->size;
		((DSPEEvent*) event)->pool = (DSPEEventsPool*) pool;
		((DSPEEvent*) event)->dispose = ParticleTrackerDllTrajectory_MessageGate_disposeGroupBlock;
		((DSPEEvent*) event)->clone = ParticleTrackerDllTrajectory_MessageGate_cloneGroupBlock;
		event->value = (ParticleTrackerDllTrajectory_MessageGate**) memoryManager_allocate((DSPEElement*) gatePool, ((DSPEGroupBlockEventsPool*) pool)->groupSize * sizeof(ParticleTrackerDllTrajectory_MessageGate*));
		for (i = 0; i < ((DSPEGroupBlockEventsPool*) pool)->groupSize; i++) {
			ParticleTrackerDllTrajectory_MessageGate_createGroupBlock(event, i);
			ParticleTrackerDllTrajectory_MessageGate_initializeGroupBlock(event, i);
		}
		return event;
	case 1:
		event = gatePool->headEvent;
		gatePool->headEvent = NULL;
		gatePool->tailEvent = NULL;
		gatePool->eventNumElements = 0;
		((DSPEEvent*) event)->next = NULL;
		return event;
	default:
		event = gatePool->headEvent;
		gatePool->headEvent = (ParticleTrackerDllTrajectory_MessageGate_groupEvent*) ((DSPEEvent*) event)->next;
		gatePool->eventNumElements--;
		((DSPEEvent*) event)->next = NULL;
		return event;
	}
}

/* CreateGroup function */
void ParticleTrackerDllTrajectory_MessageGate_createGroupBlock(ParticleTrackerDllTrajectory_MessageGate_groupEvent *event, size_t index) {
	event->value[index] = (ParticleTrackerDllTrajectory_MessageGate*) memoryManager_allocate((DSPEElement*) ((DSPEEvent*) event)->pool, ((DSPEEvent*) event)->blockSize * sizeof(ParticleTrackerDllTrajectory_MessageGate));
}

/* InitialiseGroup function */
void ParticleTrackerDllTrajectory_MessageGate_initializeGroupBlock(ParticleTrackerDllTrajectory_MessageGate_groupEvent *event, size_t index) {
	register size_t i;
	for (i = 0; i <  ((DSPEEvent*) event)->blockSize; i++) {
		event->value[index][i] = PARTICLETRACKERDLLTRAJECTORY_MESSAGEGATE_DEFAULTVALUE;
	}
}

/* CloneGroup event function */
DSPEEvent* ParticleTrackerDllTrajectory_MessageGate_cloneGroupBlock(DSPEEvent *event) {
	register size_t i;
	ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock *gatePool = (ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock*) event->pool;
	ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent *clone = NULL;

	switch (gatePool->cloneNumElements) {
	case 0:
		clone = (ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent));
		((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) clone)->value = (ParticleTrackerDllTrajectory_MessageGate**) memoryManager_allocate((DSPEElement*) gatePool, ((DSPEGroupEvent*) event)->groupSize * sizeof(ParticleTrackerDllTrajectory_MessageGate*));
		initDSPEGroupEvent((DSPEGroupEvent*) clone);
		((DSPEGroupEvent*) clone)->groupSize = ((DSPEGroupEvent*) event)->groupSize;
		((DSPEEvent*) clone)->dispose = ParticleTrackerDllTrajectory_MessageGate_disposeGroupCloneBlock;
		((DSPEEvent*) clone)->clone = ParticleTrackerDllTrajectory_MessageGate_cloneGroupBlock;
		((DSPEEvent*) clone)->pool = event->pool;
		((DSPEEvent*) clone)->blockSize = event->blockSize;
		break;
	case 1:
		clone = gatePool->headClone;
		gatePool->headClone = NULL;
		gatePool->tailClone = NULL;
		gatePool->cloneNumElements = 0;
		break;
	default:
		clone = gatePool->headClone;
		gatePool->headClone = (ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent*) ((DSPEEvent*) clone)->next;
		gatePool->cloneNumElements--;
		break;
	}
	((DSPEEvent*) clone)->next = NULL;
	
	event->refCount++;
	clone->original = (DSPEGroupEvent*) event;

	for (i = 0; i < ((DSPEGroupEvent*) event)->groupSize; i++) {
		((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) clone)->value[i] = ((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) event)->value[i];
	}
	
	return (DSPEEvent*) clone;
}

/* SubClone event function */
DSPEEvent* ParticleTrackerDllTrajectory_MessageGate_subCloneBlock(DSPEGroupEvent *event, DSPEEventsPool *pool, size_t index) {
	ParticleTrackerDllTrajectory_MessageGate_poolBlock *gatePool = (ParticleTrackerDllTrajectory_MessageGate_poolBlock*) pool;
	ParticleTrackerDllTrajectory_MessageGate_cloneEvent *clone = NULL;

	switch (gatePool->cloneNumElements) {
	case 0:
		clone = (ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllTrajectory_MessageGate_cloneEvent));
		((ParticleTrackerDllTrajectory_MessageGate_event*) clone)->value = NULL;
		initDSPEEvent((DSPEEvent*) clone);
		((DSPEEvent*) clone)->dispose = ParticleTrackerDllTrajectory_MessageGate_disposeCloneBlock;
		((DSPEEvent*) clone)->clone = ParticleTrackerDllTrajectory_MessageGate_cloneBlock;
		((DSPEEvent*) clone)->pool = pool;
		((DSPEEvent*) clone)->blockSize = ((DSPEBlockEventsPool*) pool)->size;
		break;
	case 1:
		clone = gatePool->headClone;
		gatePool->headClone = NULL;
		gatePool->tailClone = NULL;
		gatePool->cloneNumElements = 0;
		break;
	default:
		clone = gatePool->headClone;
		gatePool->headClone = (ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) ((DSPEEvent*) clone)->next;
		gatePool->cloneNumElements--;
		break;
	}
	((DSPEEvent*) clone)->next = NULL;
	
	/* Set clones's original and increment original's refCounter */
	((DSPEEvent*) event)->refCount++;
	((ParticleTrackerDllTrajectory_MessageGate_cloneEvent*) clone)->original = (DSPEEvent*) event;
	
	((ParticleTrackerDllTrajectory_MessageGate_event*) clone)->value = ((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) event)->value[index];
	return (DSPEEvent*) clone;
}

/**
 * Allocate containerEvent function
 */
ParticleTrackerDllTrajectory_MessageGate_eventContainer* ParticleTrackerDllTrajectory_MessageGate_allocateContainerBlock(ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock *pool) {
	ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock *gatePool = (ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock*) pool;
	ParticleTrackerDllTrajectory_MessageGate_eventContainer *event = NULL;
	register size_t i;
	switch (gatePool->containerNumElements) {
	case 0:
		event = (ParticleTrackerDllTrajectory_MessageGate_eventContainer*) memoryManager_allocate((DSPEElement*) gatePool, sizeof(ParticleTrackerDllTrajectory_MessageGate_eventContainer));
		initDSPEGroupEvent((DSPEGroupEvent*) event);
		((DSPEEvent*) event)->pool = (DSPEEventsPool*) pool;
		((DSPEEvent*) event)->dispose = ParticleTrackerDllTrajectory_MessageGate_disposeContainerBlock;
		((DSPEEvent*) event)->clone = ParticleTrackerDllTrajectory_MessageGate_cloneGroupBlock;
		((DSPEGroupEvent*) event)->groupSize = ((DSPEGroupBlockEventsPool*) gatePool)->groupSize;
		((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) event)->value = (ParticleTrackerDllTrajectory_MessageGate**) memoryManager_allocate((DSPEElement*) gatePool, ((DSPEGroupEventsPool*) gatePool)->groupSize * sizeof(ParticleTrackerDllTrajectory_MessageGate*));
		event->containedEvents = (DSPEEvent**) memoryManager_allocate((DSPEElement*) gatePool, ((DSPEGroupBlockEventsPool*) gatePool)->groupSize * sizeof(DSPEEvent*));
		for (i = 0; i < ((DSPEGroupBlockEventsPool*) gatePool)->groupSize; i++) {
			event->containedEvents[i] = NULL;
			((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) event)->value[i] = NULL;
		}
		return event;
	case 1:
		event = gatePool->headContainer;
		gatePool->headContainer = NULL;
		gatePool->tailContainer = NULL;
		gatePool->containerNumElements = 0;
		((DSPEEvent*) event)->next = NULL;
		return event;
	default:
		event = gatePool->headContainer;
		gatePool->headContainer = (ParticleTrackerDllTrajectory_MessageGate_eventContainer*) ((DSPEEvent*) event)->next;
		gatePool->containerNumElements--;
		((DSPEEvent*) event)->next = NULL;
		return event;
	}
}

/**
 * Dispose containerEvent function
 */
void ParticleTrackerDllTrajectory_MessageGate_disposeContainerBlock(DSPEEvent *event) {
	ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock *gatePool = (ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock*) event->pool;
	register size_t i;
	ParticleTrackerDllTrajectory_MessageGate_eventContainer *container = (ParticleTrackerDllTrajectory_MessageGate_eventContainer*) event;
	DSPEEvent *refEvent = NULL;
	if (event->refCount == 1) {
		for (i = 0; i < ((DSPEGroupBlockEventsPool*) gatePool)->groupSize; i++) {
			refEvent = container->containedEvents[i];
			if (refEvent != NULL) {
				refEvent->dispose(refEvent);
				container->containedEvents[i] = NULL;
			}
			((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) container)->value[i] = NULL;
		}
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->containerNumElements) {
		case 0:
			gatePool->headContainer = (ParticleTrackerDllTrajectory_MessageGate_eventContainer*) event;
			gatePool->tailContainer = (ParticleTrackerDllTrajectory_MessageGate_eventContainer*) event;
			gatePool->containerNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailContainer)->next = event;
			gatePool->tailContainer = (ParticleTrackerDllTrajectory_MessageGate_eventContainer*) event;
			gatePool->containerNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* DisposeGroup function */
void ParticleTrackerDllTrajectory_MessageGate_disposeGroupBlock(DSPEEvent *event) {
	ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock *gatePool = (ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock*) event->pool;
	if (event->refCount == 1) {
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->eventNumElements) {
		case 0:
			gatePool->headEvent = (ParticleTrackerDllTrajectory_MessageGate_groupEvent*) event;
			gatePool->tailEvent = (ParticleTrackerDllTrajectory_MessageGate_groupEvent*) event;
			gatePool->eventNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailEvent)->next = (DSPEEvent*) event;
			gatePool->tailEvent = (ParticleTrackerDllTrajectory_MessageGate_groupEvent*) event;
			gatePool->eventNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* Dispose GroupClone function */
void ParticleTrackerDllTrajectory_MessageGate_disposeGroupCloneBlock(DSPEEvent *event) {
	ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock *gatePool = (ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock*) event->pool;
	DSPEEvent *original = (DSPEEvent*) ((ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent*) event)->original;
	if (event->refCount == 1) {
		original->dispose(original);
		event->refCount = 0;
		event->next = NULL;
		switch (gatePool->cloneNumElements) {
		case 0:
			gatePool->headClone = (ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent*) event;
			gatePool->tailClone = (ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent*) event;
			gatePool->cloneNumElements = 1;
			break;
		default:
			((DSPEEvent*) gatePool->tailClone)->next = (DSPEEvent*) event;
			gatePool->tailClone = (ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent*) event;
			gatePool->cloneNumElements++;
			break;
		}
	} else
		event->refCount--;
}

/* eventPool dispose function */
void ParticleTrackerDllTrajectory_MessageGate_disposeGroupPoolBlock(DSPEEventsPool *pool) {
	register size_t i, j;
	DSPEEvent *tmpEvent = NULL;
	DSPEEventsPool *eventPool = NULL;
	DSPEEventsPool *tmpEventPool = NULL;
	ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock *thisPool = (ParticleTrackerDllTrajectory_MessageGate_poolGroupBlock*) pool;
	
	/* Dispose blocks children */
	eventPool = (DSPEEventsPool*) ((DSPEGroupBlockEventsPool*) thisPool)->blocksHead;
	for (i = 0; i < ((DSPEGroupBlockEventsPool*) thisPool)->blocksNumElements; i++) {
		tmpEventPool = eventPool;
		eventPool = eventPool->next;
		tmpEventPool->next = NULL;
		tmpEventPool->dispose(tmpEventPool);
	}

	/* Dispose groups children */
	eventPool = (DSPEEventsPool*) ((DSPEGroupBlockEventsPool*) thisPool)->groupsHead;
	for (i = 0; i < ((DSPEGroupBlockEventsPool*) thisPool)->groupsNumElements; i++) {
		tmpEventPool = eventPool;
		eventPool = eventPool->next;
		tmpEventPool->next = NULL;
		tmpEventPool->dispose(tmpEventPool);
	}
	
	/* Dispose events if any present */
	for (i = 0; i < thisPool->eventNumElements; i++) {
		tmpEvent = (DSPEEvent*) thisPool->headEvent;
		thisPool->headEvent = (ParticleTrackerDllTrajectory_MessageGate_groupEvent*) tmpEvent->next;
		for (j = 0; j < ((DSPEGroupBlockEventsPool*) thisPool)->groupSize; j++) {
			memorySupport_dispose(((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) tmpEvent)->value[j]);
		}
		memorySupport_dispose(((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) tmpEvent)->value);
		tmpEvent->next = NULL;
		memorySupport_dispose(tmpEvent);
	}
	
	/* Dispose clones if any present */
	for (i = 0; i < thisPool->cloneNumElements; i++) {
		tmpEvent = (DSPEEvent*) thisPool->headClone;
		thisPool->headClone = (ParticleTrackerDllTrajectory_MessageGate_cloneGroupEvent*) tmpEvent->next;
		tmpEvent->next = NULL;
		memorySupport_dispose(((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) tmpEvent)->value);
		memorySupport_dispose(tmpEvent);
	}
	
	/* Dispose eventContainers if any present */
	for (i = 0; i < thisPool->containerNumElements; i++) {
		tmpEvent = (DSPEEvent*) thisPool->headContainer;
		thisPool->headContainer = (ParticleTrackerDllTrajectory_MessageGate_eventContainer*) tmpEvent->next;
		tmpEvent->next = NULL;
		memorySupport_dispose(((ParticleTrackerDllTrajectory_MessageGate_groupEvent*) tmpEvent)->value);
		memorySupport_dispose(((ParticleTrackerDllTrajectory_MessageGate_eventContainer*) tmpEvent)->containedEvents);
		memorySupport_dispose(tmpEvent);
	}
	
	/* dispose pool */
	memorySupport_dispose(thisPool);
}

