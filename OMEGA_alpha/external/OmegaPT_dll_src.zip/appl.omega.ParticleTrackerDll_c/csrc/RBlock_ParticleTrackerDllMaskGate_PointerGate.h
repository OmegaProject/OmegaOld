/**
 * File: RBlock_ParticleTrackerDllMaskGate_PointerGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef RBlock_ParticleTrackerDllMaskGate_PointerGate_h
#define RBlock_ParticleTrackerDllMaskGate_PointerGate_h

#include "B_ParticleTrackerDllMaskGate_PointerGate.h"
#ifdef __cplusplus
extern "C" {
#endif

/* Allocate function */
ParticleTrackerDllMaskGate_PointerGate* ParticleTrackerDllMaskGate_PointerGate_allocateBlock(DSPEElement *context, size_t size);

/* Initialise function */
void ParticleTrackerDllMaskGate_PointerGate_initializeBlock(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate *place, size_t size);

/* SetOverrideBlock function */
void ParticleTrackerDllMaskGate_PointerGate_setOverrideBlock(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate *place, size_t size, ParticleTrackerDllMaskGate_PointerGate value);

/* Set function */
void ParticleTrackerDllMaskGate_PointerGate_setBlock(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate *place, size_t size, ParticleTrackerDllMaskGate_PointerGate *value);

/* Dispose function */
void ParticleTrackerDllMaskGate_PointerGate_disposeBlock(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate *place);

/* AllocateGroup function */
void ParticleTrackerDllMaskGate_PointerGate_allocateGroupBlock(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t groupSize, size_t *gateSize);

/* InitialiseGroup function */
void ParticleTrackerDllMaskGate_PointerGate_initializeGroupBlock(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t groupSize, size_t *gateSize);

/* SetOverrideGroupBlock function */
void ParticleTrackerDllMaskGate_PointerGate_setOverrideGroupBlock(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllMaskGate_PointerGate value);

/* SetGroupBlock function */
void ParticleTrackerDllMaskGate_PointerGate_setGroupBlock(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t groupSize, size_t *gateSize, ParticleTrackerDllMaskGate_PointerGate **value);

/* DisposeGroup function */
void ParticleTrackerDllMaskGate_PointerGate_disposeGroupBlock(DSPEElement *context, ParticleTrackerDllMaskGate_PointerGate **place, size_t size);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
