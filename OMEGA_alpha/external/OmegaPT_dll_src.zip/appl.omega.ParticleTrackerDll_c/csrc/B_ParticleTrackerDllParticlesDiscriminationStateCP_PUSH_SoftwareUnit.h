/**
 * File: B_ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef B_ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_h
#define B_ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_h

#include "DSPEElements.h"

#include "B_ParticleTrackerDllNextGate_SignalGate.h"
#include "B_ParticleTrackerDllIntGate_StandardGate.h"
#include "B_ParticleTrackerDllRealGate_CustomGate.h"
#include "B_ParticleTrackerDllStatusGate_StringGate.h"

/* Queue node type definition */
typedef struct ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_queueNode ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_queueNode;

/* Queue node type definition */
struct ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_queueNode {
	ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_queueNode *next;
	unsigned int ID;
	DSPEEvent *event;
	/* Transit node support */
	short inTransit;
	ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_queueNode *nextInTransit;
};

/* State type definition */
typedef struct ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit;

/* State definition */ 
struct ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit {

	DSPEQueueUnit queueUnit;

	unsigned int poolNumNodes;
	ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_queueNode *poolHead;
	ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_queueNode *poolTail;

	unsigned int queueNumNodes;
	ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_queueNode *queueHead;
	ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_queueNode *queueTail;

	/* Parameter gates */
	ParticleTrackerDllIntGate_StandardGate *paramIn_stop;
	ParticleTrackerDllRealGate_CustomGate *paramIn_Cutoff;
	ParticleTrackerDllIntGate_StandardGate *paramIn_Linkrange;
	ParticleTrackerDllIntGate_StandardGate *paramOut_stop;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status;


	/* Output parameters places */
	ParticleTrackerDllIntGate_StandardGate *paramOut_stop_place;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status_place;


	/* Output parameters places anchors */
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status_placeAnchor;

	/* Gates numLinks */
	unsigned int dataIn_PTFrame_numLinks;
	unsigned int dataOut_PTFrame_numLinks;
	unsigned int paramIn_next_numLinks;
	unsigned int paramIn_stop_numLinks;
	unsigned int paramIn_Cutoff_numLinks;
	unsigned int paramIn_Linkrange_numLinks;
	unsigned int paramOut_next_numLinks;
	unsigned int paramOut_stop_numLinks;
	unsigned int paramOut_Status_numLinks;

	/* unit ID */
	char *ID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_queueEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID);

void ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_releaseEvent(ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit *context);

int ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_isEventAvailable(const DSPEQueueUnit *unit);

DSPEEvent* ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_getEvent(const DSPEQueueUnit *unit);

unsigned int ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_getEventID(const DSPEQueueUnit *unit);

/* getID function */
char* ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_getID(const DSPEElement *element);

/* Alloc function */
void ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_alloc(ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit *context);

/* Earlyconnect function */
void ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_earlyConnect(ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit *context);

/* Postprocess function */
void ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_postProcess(ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit *context);

/* Reset function */
void ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_reset(ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit *context);

/* Shutdown function */
void ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit_shutdown(ParticleTrackerDllParticlesDiscriminationStateCP_PUSH_SoftwareUnit *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
