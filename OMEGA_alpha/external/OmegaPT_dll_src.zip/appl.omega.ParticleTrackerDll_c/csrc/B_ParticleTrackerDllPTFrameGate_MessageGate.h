/**
 * File: B_ParticleTrackerDllPTFrameGate_MessageGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#ifndef B_ParticleTrackerDllPTFrameGate_MessageGate_h
#define B_ParticleTrackerDllPTFrameGate_MessageGate_h

#include "DSPEXTElements.h"
#include "MemoryGround.h"

#include "B_ParticleTrackerDllTracker_Requirement.h"


#define PARTICLETRACKERDLLPTFRAMEGATE_MESSAGEGATE_TYPECATEGORY "Message"
#define PARTICLETRACKERDLLPTFRAMEGATE_MESSAGEGATE_DEFAULTVALUE 0

typedef PTFrame* ParticleTrackerDllPTFrameGate_MessageGate;


/* EventGate state type definition */
typedef struct ParticleTrackerDllPTFrameGate_MessageGate_event ParticleTrackerDllPTFrameGate_MessageGate_event;

/* EventGate state definition */
struct ParticleTrackerDllPTFrameGate_MessageGate_event {
	DSPEEvent event;
	
	ParticleTrackerDllPTFrameGate_MessageGate *value;
};

/* Event clone state type definition */
typedef struct ParticleTrackerDllPTFrameGate_MessageGate_cloneEvent ParticleTrackerDllPTFrameGate_MessageGate_cloneEvent;

/* Event clone state definition */
struct ParticleTrackerDllPTFrameGate_MessageGate_cloneEvent {
	ParticleTrackerDllPTFrameGate_MessageGate_event event;

	DSPEEvent *original;
};

/* EventGate pool type definition */
typedef struct ParticleTrackerDllPTFrameGate_MessageGate_pool ParticleTrackerDllPTFrameGate_MessageGate_pool;

/* EventGate pool definition */
struct ParticleTrackerDllPTFrameGate_MessageGate_pool {
	DSPEBaseEventsPool pool;

	// Pool for events
	size_t eventNumElements;
	ParticleTrackerDllPTFrameGate_MessageGate_event *headEvent;
	ParticleTrackerDllPTFrameGate_MessageGate_event *tailEvent;

	// Pool for clones
	size_t cloneNumElements;
	ParticleTrackerDllPTFrameGate_MessageGate_cloneEvent *headClone;
	ParticleTrackerDllPTFrameGate_MessageGate_cloneEvent *tailClone;
};


/* GroupEventGate state type definition */
typedef struct ParticleTrackerDllPTFrameGate_MessageGate_groupEvent ParticleTrackerDllPTFrameGate_MessageGate_groupEvent;

/* GroupEventGate state definition */
struct ParticleTrackerDllPTFrameGate_MessageGate_groupEvent {
	DSPEGroupEvent event;
	
	ParticleTrackerDllPTFrameGate_MessageGate **value;
};

/* GroupEvent clone state type definition */
typedef struct ParticleTrackerDllPTFrameGate_MessageGate_cloneGroupEvent ParticleTrackerDllPTFrameGate_MessageGate_cloneGroupEvent;

/* GroupEvent clone state definition */
struct ParticleTrackerDllPTFrameGate_MessageGate_cloneGroupEvent {
	ParticleTrackerDllPTFrameGate_MessageGate_groupEvent event;

	DSPEGroupEvent *original;
};

/* GroupEvent container state type definition */
typedef struct ParticleTrackerDllPTFrameGate_MessageGate_eventContainer ParticleTrackerDllPTFrameGate_MessageGate_eventContainer;

/* GroupEvent container state definition */
struct ParticleTrackerDllPTFrameGate_MessageGate_eventContainer {
	ParticleTrackerDllPTFrameGate_MessageGate_groupEvent event;

	DSPEEvent **containedEvents;
};

/* GroupEventGate pool type definition */
typedef struct ParticleTrackerDllPTFrameGate_MessageGate_groupPool ParticleTrackerDllPTFrameGate_MessageGate_groupPool;

/* GroupEventGate pool definition */
struct ParticleTrackerDllPTFrameGate_MessageGate_groupPool {
	DSPEGroupEventsPool pool;

	/* Pool for Events */
	size_t eventNumElements;
	ParticleTrackerDllPTFrameGate_MessageGate_groupEvent *headEvent;
	ParticleTrackerDllPTFrameGate_MessageGate_groupEvent *tailEvent;
	
	/* Pool for Clones */
	size_t cloneNumElements;
	ParticleTrackerDllPTFrameGate_MessageGate_cloneGroupEvent *headClone;
	ParticleTrackerDllPTFrameGate_MessageGate_cloneGroupEvent *tailClone;
	
	/* Pool for EventContainers */
	size_t containerNumElements;
	ParticleTrackerDllPTFrameGate_MessageGate_eventContainer *headContainer;
	ParticleTrackerDllPTFrameGate_MessageGate_eventContainer *tailContainer;
};

/* EventGate node type definition */
typedef struct ParticleTrackerDllPTFrameGate_MessageGate_node ParticleTrackerDllPTFrameGate_MessageGate_node; 

/* EventGate node definition */ 
struct ParticleTrackerDllPTFrameGate_MessageGate_node {
	DSPEGateNode node;

	ParticleTrackerDllPTFrameGate_MessageGate *localVar;
	ParticleTrackerDllPTFrameGate_MessageGate value;
	int sendEvent;
	unsigned int eventID;
	DSPEApplication *application;
	DSPEEventsPool *pool;
};

#ifdef __cplusplus
extern "C" {
#endif

/* eventPool initialization function */
ParticleTrackerDllPTFrameGate_MessageGate_pool* ParticleTrackerDllPTFrameGate_MessageGate_initPool(const DSPEOwner *owner);

/* eventPool preAlloc function */
void ParticleTrackerDllPTFrameGate_MessageGate_preAllocPool(DSPEEventsPool *pool, size_t size);

/* eventPool reset function */
void ParticleTrackerDllPTFrameGate_MessageGate_resetPool(DSPEEventsPool *pool);

/* Allocate function */
ParticleTrackerDllPTFrameGate_MessageGate_event* ParticleTrackerDllPTFrameGate_MessageGate_allocate(ParticleTrackerDllPTFrameGate_MessageGate_pool *pool);

/* Initialise function */
void ParticleTrackerDllPTFrameGate_MessageGate_initialize(ParticleTrackerDllPTFrameGate_MessageGate_event *event);

/**
 * Copy function
 */
void ParticleTrackerDllPTFrameGate_MessageGate_copy(ParticleTrackerDllPTFrameGate_MessageGate_event *event, ParticleTrackerDllPTFrameGate_MessageGate value);

/* Clone event function */
DSPEEvent* ParticleTrackerDllPTFrameGate_MessageGate_clone(DSPEEvent *event);

/* Dispose function */
void ParticleTrackerDllPTFrameGate_MessageGate_dispose(DSPEEvent *event);

/* Dispose clone function */
void ParticleTrackerDllPTFrameGate_MessageGate_disposeClone(DSPEEvent *event);

/* eventPool dispose function */
void ParticleTrackerDllPTFrameGate_MessageGate_disposePool(DSPEEventsPool *pool);

/* Allocate function */
ParticleTrackerDllPTFrameGate_MessageGate* ParticleTrackerDllPTFrameGate_MessageGate_allocateUnlinked(DSPEElement *context);

/* Initialise function */
void ParticleTrackerDllPTFrameGate_MessageGate_initializeUnlinked(DSPEElement *context, ParticleTrackerDllPTFrameGate_MessageGate *place);

/* Dispose function */
void ParticleTrackerDllPTFrameGate_MessageGate_disposeUnlinked(DSPEElement *context, ParticleTrackerDllPTFrameGate_MessageGate *place);

/* groupEventPool initialization function */
ParticleTrackerDllPTFrameGate_MessageGate_groupPool* ParticleTrackerDllPTFrameGate_MessageGate_initGroupPool(const DSPEOwner *owner, size_t groupSize);

/* eventPool preAlloc function */
void ParticleTrackerDllPTFrameGate_MessageGate_preAllocGroupPool(DSPEEventsPool *pool, size_t size);

/* eventPool reset function */
void ParticleTrackerDllPTFrameGate_MessageGate_resetGroupPool(DSPEEventsPool *pool);

/* AllocateGroup function */
ParticleTrackerDllPTFrameGate_MessageGate_groupEvent* ParticleTrackerDllPTFrameGate_MessageGate_allocateGroup(ParticleTrackerDllPTFrameGate_MessageGate_groupPool *grpPool);

/* CreateGroup function */
void ParticleTrackerDllPTFrameGate_MessageGate_createGroup(ParticleTrackerDllPTFrameGate_MessageGate_groupEvent *event, size_t index);

/* InitialiseGroup function */
void ParticleTrackerDllPTFrameGate_MessageGate_initializeGroup(ParticleTrackerDllPTFrameGate_MessageGate_groupEvent *event, size_t index);

/**
 * Copy function
 */
void ParticleTrackerDllPTFrameGate_MessageGate_copyGroup(ParticleTrackerDllPTFrameGate_MessageGate_groupEvent *event, ParticleTrackerDllPTFrameGate_MessageGate value, size_t index);

/* CloneGroup event function */
DSPEEvent* ParticleTrackerDllPTFrameGate_MessageGate_cloneGroup(DSPEEvent *event);

/* SubClone event function */
DSPEEvent* ParticleTrackerDllPTFrameGate_MessageGate_subClone(DSPEGroupEvent *event, DSPEEventsPool *pool, size_t index);

/**
 * Allocate containerEvent function
 */
ParticleTrackerDllPTFrameGate_MessageGate_eventContainer* ParticleTrackerDllPTFrameGate_MessageGate_allocateContainer(ParticleTrackerDllPTFrameGate_MessageGate_groupPool *grpPool);

/**
 * Dispose containerEvent function
 */
void ParticleTrackerDllPTFrameGate_MessageGate_disposeContainer(DSPEEvent *event);

/* DisposeGroup function */
void ParticleTrackerDllPTFrameGate_MessageGate_disposeGroup(DSPEEvent *event);

/* Dispose GroupClone function */
void ParticleTrackerDllPTFrameGate_MessageGate_disposeGroupClone(DSPEEvent *event);

/* eventPool dispose function */
void ParticleTrackerDllPTFrameGate_MessageGate_disposeGroupPool(DSPEEventsPool *pool);

/* CreateNode function */
ParticleTrackerDllPTFrameGate_MessageGate_node* ParticleTrackerDllPTFrameGate_MessageGate_createNode(ParticleTrackerDllPTFrameGate_MessageGate *localVar, DSPEApplication *application, DSPEEventsPool *pool, unsigned int eventID);

/* DisposeNode function */
void ParticleTrackerDllPTFrameGate_MessageGate_disposeNode(DSPEElement *context, DSPEGateNode *node);

/* SetValue function */
void ParticleTrackerDllPTFrameGate_MessageGate_setValue(DSPEElement *context, DSPEGateNode *node);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
