/**
 * File: RBlockProd_ParticleTrackerDllLibraryDataReader_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef RBlockProd_ParticleTrackerDllLibraryDataReader_SoftwareUnit_h
#define RBlockProd_ParticleTrackerDllLibraryDataReader_SoftwareUnit_h

#include "B_ParticleTrackerDllLibraryDataReader_StateImplementation.h"
#include "B_ParticleTrackerDllLibraryDataReader_SoftwareUnit.h"
#include "RBlock_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "RBlock_ParticleTrackerDllPTFrameGate_MessageGate.h"

/* Block SoftwareUnit state type definition */
typedef struct ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd;

/* Block SoftwareUnit state definition */
struct ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd {

	/* Base unit state */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllLibraryDataReader_StateImplementation implState;
	
	/* Block size */
	size_t blockSize;

	/* Samples to process */
	size_t samplesToProcess;

	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;
	DSPEEvent *dataOut_PTFrame_place;
	DSPEEvent *dataOut_PTFrame_armMarker;

	/* Data pending events support */
	size_t dataOut_PTFrame_pendingEvents;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;

	/* EventPools */
	ParticleTrackerDllPTFrameGate_MessageGate_poolBlock *dataOut_PTFrame_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame_unlinked;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataOut_SequenceValues;


	/* Data gates sizes */
	size_t dataOut_SequenceValues_size;
	size_t dataOut_PTFrame_size;


	/* Data gates factors */
	size_t dataOut_SequenceValues_factor;
	size_t dataOut_PTFrame_factor;


	/* Data gates counters */
	size_t dataOut_SequenceValues_counter;
	size_t dataOut_PTFrame_counter;


	/* Output data places */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataOut_SequenceValues_place;


	/* Data gates counters */
	size_t dataOut_PTFrame_samplesCounter;

};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllLibraryDataReader_SoftwareUnit_armEventBlockProd(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllLibraryDataReader_SoftwareUnit_postEventBlockProd(DSPEEventsUnit *unit, unsigned int ID);

/* Earlyalloc function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_earlyAllocBlockProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context);

/* Alloc function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_allocBlockProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context);

/* Earlyconnect function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_earlyConnectBlockProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context);

/* Connect function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_connectBlockProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context);

/* Startup function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_startupBlockProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context);

/* Preprocess function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_preProcessBlockProd(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_processBlockProd(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_postProcessBlockProd(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_resetBlockProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context);

/* Shutdown function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_shutdownBlockProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
