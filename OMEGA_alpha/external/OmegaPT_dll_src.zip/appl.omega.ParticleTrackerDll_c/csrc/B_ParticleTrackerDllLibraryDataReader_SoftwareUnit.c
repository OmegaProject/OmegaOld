/**
 * File: B_ParticleTrackerDllLibraryDataReader_SoftwareUnit.c
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#include "PlatformManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "EngineManager.h"

#include "B_ParticleTrackerDllLibraryDataReader_SoftwareUnit.h"

#define pIn_sourceNext_event 1000
#define pIn_next_event 1001

#define pOut_next_event 1000
#define dOut_PTFrame_event 1001

static INLINE void initQueue(ParticleTrackerDllLibraryDataReader_SoftwareUnit *unit) {
	unit->poolNumNodes = 0;
	unit->poolHead = NULL;
	unit->poolTail = NULL;

	unit->queueNumNodes = 0;
	unit->queueHead = NULL;
	unit->queueTail = NULL;

}

static INLINE void resetQueue(ParticleTrackerDllLibraryDataReader_SoftwareUnit *unit) {
	// REMARK: avoid calling the installed release function because of possible
	// overriding implementations. Just need to release the event here.
	// TODO non esistono piu versioni sovrascritte!!
	while (unit->queueNumNodes != 0)
		ParticleTrackerDllLibraryDataReader_SoftwareUnit_releaseEvent(unit);
}

static INLINE void disposeQueue(ParticleTrackerDllLibraryDataReader_SoftwareUnit *unit) {
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueNode *node = unit->poolHead;
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueNode *tmp = NULL;

	/* Dispose queueNodes in pool */
	while (node != NULL) {
		tmp = node->next;
		node->next = NULL;
		memorySupport_dispose(node);
		node = tmp;
	}
}

void ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID) {
	ParticleTrackerDllLibraryDataReader_SoftwareUnit *context = (ParticleTrackerDllLibraryDataReader_SoftwareUnit*) unit;
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueNode *node = NULL;
	
	switch (context->poolNumNodes) {
	case 0:
		node = (ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueNode*) memoryManager_allocate((DSPEElement*) context, sizeof(ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueNode));
		node->nextInTransit = NULL;
		break;
	case 1:
		node = context->poolHead;
		context->poolHead = NULL;
		context->poolTail = NULL;
		context->poolNumNodes = 0;
		break;
	default:
		node = context->poolHead;
		context->poolHead = node->next;
		context->poolNumNodes--;
		break;
	}

	node->next = NULL;
	node->ID = ID;
	node->event = event;
	event->refCount++;

	if (context->queueNumNodes == 0) {
		context->queueHead = node;
		context->queueTail = node;
		context->queueNumNodes = 1;
	} else {
		context->queueTail->next = node;
		context->queueTail = node;
		context->queueNumNodes++;
	}
	node->inTransit = 0;
}

void ParticleTrackerDllLibraryDataReader_SoftwareUnit_releaseEvent(ParticleTrackerDllLibraryDataReader_SoftwareUnit *context) {
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueNode *node = context->queueHead;
	DSPEEvent *event = NULL;
	
	switch (context->queueNumNodes) {
	case 0:
		/* No events in queue */
		// REMARK: this could happen if we have idleTimeSequence and we want to re-schedule a unit
		return;
	case 1:
		context->queueHead = NULL;
		context->queueTail = NULL;
		context->queueNumNodes = 0;
		break;
	default:
		context->queueHead = node->next;
		context->queueNumNodes--;
		break;
	}

	node->next = NULL;

	/* REMARK:
	 * If node is in transit avoid disposing event and putting the node 
	 * back to pool. This will happen when user calls dismiss function 
	 */
	if (node->inTransit == 1)
		return;
	
	event = node->event;
	event->dispose(event);
	node->event = NULL;
	node->ID = 0;

	if (context->poolNumNodes == 0) {
		context->poolHead = node;
		context->poolTail = node;
		context->poolNumNodes = 1;
	} else {
		context->poolTail->next = node;
		context->poolTail = node;
		context->poolNumNodes++;
	}
}

int ParticleTrackerDllLibraryDataReader_SoftwareUnit_isEventAvailable(const DSPEQueueUnit *unit) {
	ParticleTrackerDllLibraryDataReader_SoftwareUnit *context = (ParticleTrackerDllLibraryDataReader_SoftwareUnit*) unit;
	return context->queueNumNodes != 0;
}

DSPEEvent* ParticleTrackerDllLibraryDataReader_SoftwareUnit_getEvent(const DSPEQueueUnit *unit) {
	ParticleTrackerDllLibraryDataReader_SoftwareUnit *context = (ParticleTrackerDllLibraryDataReader_SoftwareUnit*) unit;
	return context->queueHead->event;
}

unsigned int ParticleTrackerDllLibraryDataReader_SoftwareUnit_getEventID(const DSPEQueueUnit *unit) {
	ParticleTrackerDllLibraryDataReader_SoftwareUnit *context = (ParticleTrackerDllLibraryDataReader_SoftwareUnit*) unit;
	return context->queueHead->ID;
}

/* getID function */
char* ParticleTrackerDllLibraryDataReader_SoftwareUnit_getID(const DSPEElement *element) {
	return ((const ParticleTrackerDllLibraryDataReader_SoftwareUnit*) element)->ID;
}

/* Initialize gate values */
static INLINE void initValues(ParticleTrackerDllLibraryDataReader_SoftwareUnit *context) {
	/* Parameter Output gates initializazion */
	ParticleTrackerDllStatusGate_StringGate_initManaged((DSPEElement*) context, *context->paramOut_Status_placeAnchor);
	ParticleTrackerDllStatusGate_StringGate_set((DSPEElement*) context, context->paramOut_Status_place, context->paramOut_Status_placeAnchor);
}

/* Alloc function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_alloc(ParticleTrackerDllLibraryDataReader_SoftwareUnit *context) {
	((DSPEElement*) context)->getID = ParticleTrackerDllLibraryDataReader_SoftwareUnit_getID;
	initQueue(context);

	((DSPEEventsUnit*) context)->queueEvent = ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueEvent;
	((DSPEQueueUnit*) context)->isEventAvailable = ParticleTrackerDllLibraryDataReader_SoftwareUnit_isEventAvailable;
	((DSPEQueueUnit*) context)->getEventID = ParticleTrackerDllLibraryDataReader_SoftwareUnit_getEventID;
	((DSPEQueueUnit*) context)->getEvent = ParticleTrackerDllLibraryDataReader_SoftwareUnit_getEvent;

	/* Output parameters places allocation */
	context->paramOut_Status_place = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);

	/* Places anchors allocation */
	context->paramOut_Status_placeAnchor = ParticleTrackerDllStatusGate_StringGate_allocate((DSPEElement*) context);

	/* Places anchors allocation */
	ParticleTrackerDllStatusGate_StringGate_allocateManaged((DSPEElement*) context, context->paramOut_Status_placeAnchor);

	/* Initialize gate values */
	initValues(context);
}

/* Earlyconnect function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_earlyConnect(ParticleTrackerDllLibraryDataReader_SoftwareUnit *context) {
	/* Gates numLinks initialization */
	context->dataOut_SequenceValues_numLinks = 0;
	context->dataOut_PTFrame_numLinks = 0;
	context->paramIn_sourceNext_numLinks = 0;
	context->paramIn_next_numLinks = 0;
	context->paramIn_stop_numLinks = 0;
	context->paramIn_LinkRange_numLinks = 0;
	context->paramIn_ImgsNum_numLinks = 0;
	context->paramIn_ImgWidth_numLinks = 0;
	context->paramIn_ImgHeight_numLinks = 0;
	context->paramIn_ImgMin_numLinks = 0;
	context->paramIn_ImgMax_numLinks = 0;
	context->paramOut_next_numLinks = 0;
	context->paramOut_Status_numLinks = 0;


	/* Output parameters gates initialization */
	context->paramOut_Status = context->paramOut_Status_place;

}


/* Postprocess function
 * Remark: this function is not installed as pointer to function because it will be called
 * from either RealUnit's postProcess or BlockUnit's postProcess function.
 */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_postProcess(ParticleTrackerDllLibraryDataReader_SoftwareUnit *context) {
	resetQueue(context);

}

/* Reset function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_reset(ParticleTrackerDllLibraryDataReader_SoftwareUnit *context) {
	/* Initialize gate values */
	initValues(context);
}

/* Shutdown function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_shutdown(ParticleTrackerDllLibraryDataReader_SoftwareUnit *context) {
	disposeQueue(context);

	/* Output parameters places dispose */
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_Status_place);


	/* Places anchors memory dispose */
	ParticleTrackerDllStatusGate_StringGate_disposeManaged((DSPEElement*) context, *context->paramOut_Status_placeAnchor);


	/* Places anchors memory dispose */
	ParticleTrackerDllStatusGate_StringGate_dispose((DSPEElement*) context, context->paramOut_Status_placeAnchor);

	/* UnitID dispose */
	memorySupport_dispose(context->ID);
}

