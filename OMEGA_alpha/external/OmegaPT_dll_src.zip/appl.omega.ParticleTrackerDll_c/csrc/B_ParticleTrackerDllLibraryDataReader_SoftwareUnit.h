/**
 * File: B_ParticleTrackerDllLibraryDataReader_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef B_ParticleTrackerDllLibraryDataReader_SoftwareUnit_h
#define B_ParticleTrackerDllLibraryDataReader_SoftwareUnit_h

#include "DSPEElements.h"

#include "B_ParticleTrackerDllNextGate_SignalGate.h"
#include "B_ParticleTrackerDllIntGate_StandardGate.h"
#include "B_ParticleTrackerDllRealGate_CustomGate.h"
#include "B_ParticleTrackerDllStatusGate_StringGate.h"

/* Queue node type definition */
typedef struct ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueNode ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueNode;

/* Queue node type definition */
struct ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueNode {
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueNode *next;
	unsigned int ID;
	DSPEEvent *event;
	/* Transit node support */
	short inTransit;
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueNode *nextInTransit;
};

/* State type definition */
typedef struct ParticleTrackerDllLibraryDataReader_SoftwareUnit ParticleTrackerDllLibraryDataReader_SoftwareUnit;

/* State definition */ 
struct ParticleTrackerDllLibraryDataReader_SoftwareUnit {

	DSPEQueueUnit queueUnit;

	unsigned int poolNumNodes;
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueNode *poolHead;
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueNode *poolTail;

	unsigned int queueNumNodes;
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueNode *queueHead;
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueNode *queueTail;

	/* Parameter gates */
	ParticleTrackerDllIntGate_StandardGate *paramIn_stop;
	ParticleTrackerDllIntGate_StandardGate *paramIn_LinkRange;
	ParticleTrackerDllIntGate_StandardGate *paramIn_ImgsNum;
	ParticleTrackerDllIntGate_StandardGate *paramIn_ImgWidth;
	ParticleTrackerDllIntGate_StandardGate *paramIn_ImgHeight;
	ParticleTrackerDllRealGate_CustomGate *paramIn_ImgMin;
	ParticleTrackerDllRealGate_CustomGate *paramIn_ImgMax;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status;


	/* Output parameters places */
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status_place;


	/* Output parameters places anchors */
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status_placeAnchor;

	/* Gates numLinks */
	unsigned int dataOut_SequenceValues_numLinks;
	unsigned int dataOut_PTFrame_numLinks;
	unsigned int paramIn_sourceNext_numLinks;
	unsigned int paramIn_next_numLinks;
	unsigned int paramIn_stop_numLinks;
	unsigned int paramIn_LinkRange_numLinks;
	unsigned int paramIn_ImgsNum_numLinks;
	unsigned int paramIn_ImgWidth_numLinks;
	unsigned int paramIn_ImgHeight_numLinks;
	unsigned int paramIn_ImgMin_numLinks;
	unsigned int paramIn_ImgMax_numLinks;
	unsigned int paramOut_next_numLinks;
	unsigned int paramOut_Status_numLinks;

	/* unit ID */
	char *ID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllLibraryDataReader_SoftwareUnit_queueEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID);

void ParticleTrackerDllLibraryDataReader_SoftwareUnit_releaseEvent(ParticleTrackerDllLibraryDataReader_SoftwareUnit *context);

int ParticleTrackerDllLibraryDataReader_SoftwareUnit_isEventAvailable(const DSPEQueueUnit *unit);

DSPEEvent* ParticleTrackerDllLibraryDataReader_SoftwareUnit_getEvent(const DSPEQueueUnit *unit);

unsigned int ParticleTrackerDllLibraryDataReader_SoftwareUnit_getEventID(const DSPEQueueUnit *unit);

/* getID function */
char* ParticleTrackerDllLibraryDataReader_SoftwareUnit_getID(const DSPEElement *element);

/* Alloc function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_alloc(ParticleTrackerDllLibraryDataReader_SoftwareUnit *context);

/* Earlyconnect function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_earlyConnect(ParticleTrackerDllLibraryDataReader_SoftwareUnit *context);

/* Postprocess function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_postProcess(ParticleTrackerDllLibraryDataReader_SoftwareUnit *context);

/* Reset function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_reset(ParticleTrackerDllLibraryDataReader_SoftwareUnit *context);

/* Shutdown function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_shutdown(ParticleTrackerDllLibraryDataReader_SoftwareUnit *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
