/**
 * File: RBlockProd_ParticleTrackerDllLibraryDataReader_SoftwareUnit.c
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#include "PlatformManager.h"
#include "StringManager.h"
#include "MemoryManager.h"
#include "EngineManager.h"
#include "ErrorManager.h"

#include "RBlockProd_ParticleTrackerDllLibraryDataReader_SoftwareUnit.h"

#define PENDING_EVENTS_MAX 10

/* NoEvent ID */
#define NOEVENT 10

#define pIn_sourceNext_event 1000
#define pIn_next_event 1001

#define pOut_next_event 1000
#define dOut_PTFrame_event 1001

/******************************************************************************
 * PENDING EVENTS SUPPORT FUNCTIONS
 ******************************************************************************/

/* hasPendingEvents function */
static INLINE int hasPendingEvents(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context) {
	if (context->implState.dataOut_PTFrame_numLinks > 0 &&
		context->dataOut_PTFrame_pendingEvents == 0)
		return 0;
	return 1;
}

/* pendingEvents_aboveMaxThreshold function
 * Returns true if at least one pendingEvents counter is found that passes PENDING_EVENTS_MAX value
 */
static INLINE int pendingEvents_aboveMaxThreshold(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context) {
	return 	context->dataOut_PTFrame_pendingEvents > PENDING_EVENTS_MAX;
}

// TODO
// gate_sendEvent functions are generated only if pendingEvents support is needed.
// Consider refactoring postEvent and eventually armEvent functions so that the send functionality 
// is always available to the user enabling the soCalled 'immediate send' which may override the postEvent
// function call and send the event immediately through gate_sendEvent.
// This refactoring should also consider possible enhancements to gates like installing function pointers
// on gates to arm/post or sendImmediate events. ((DSPEEventGate*) gate)->armEvent((DSPEEventGate*) gate);

static INLINE void dataOut_PTFrame_sendEvent(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context) {
	unsigned int ID = 0;
	DSPEEventsUnit *unit = (DSPEEventsUnit*) context;
	DSPEEvent *event = NULL;

		/* Decrement pendingEvents counter for gate */
		if (context->dataOut_PTFrame_pendingEvents > 0)
			context->dataOut_PTFrame_pendingEvents--;
		/* Set ID for current gate */
		ID = dOut_PTFrame_event;
		event = context->dataOut_PTFrame_place;
		if (event == NULL)
			return;
		context->dataOut_PTFrame_place = event->next;
		if (context->dataOut_PTFrame_armMarker == event || context->dataOut_PTFrame_place == NULL)
			context->dataOut_PTFrame_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
}

/******************************************************************************
 * NEXT EVENT SUPPORT FUNCTIONS
 ******************************************************************************/

/* input next handler function */
static INLINE void handleIncomingNextRequest(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context) {
	ParticleTrackerDllLibraryDataReader_StateImplementation *implState = &context->implState;
	/* If not stop requested */
	if (*((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_stop == 0) {
		/* Send all available results */
		while (hasPendingEvents(context)) {
			dataOut_PTFrame_sendEvent(context);
		}
	}
	//REMARK:
	// else ignore next request. There will be sent at least one more next request
	// as soon as receiving unit unlocks the stop.
}

/******************************************************************************
 * GATE AUTOMATION SUPPORT FUNCTIONS
 ******************************************************************************/

/******************************************************************************
 * EVENT SUPPORT FUNCTIONS
 ******************************************************************************/

static INLINE void resetEventPlaces(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context) {
	DSPEEvent *event = NULL;
	context->paramOut_next_armMarker = NULL;
	
	while (context->paramOut_next_place != NULL) {
		event = (DSPEEvent*) context->paramOut_next_place;
		context->paramOut_next_place = event->next;
		/* force disposal */
		event->refCount = 1;
		event->dispose(event);
	}
	context->dataOut_PTFrame_armMarker = NULL;
	
	while (context->dataOut_PTFrame_place != NULL) {
		event = (DSPEEvent*) context->dataOut_PTFrame_place;
		context->dataOut_PTFrame_place = event->next;
		/* force disposal */
		event->refCount = 1;
		event->dispose(event);
	}
}

void ParticleTrackerDllLibraryDataReader_SoftwareUnit_armEventBlockProd(DSPEEventsUnit *unit, unsigned int ID) {
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context = (ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd*) unit;
	ParticleTrackerDllLibraryDataReader_StateImplementation *implState = &context->implState;

	register size_t i;
	DSPEEvent *event = NULL;
	DSPEEvent *insert = NULL;

	switch (ID) {
	case pOut_next_event:
		/* If gate is unlinked no event will be sent. Avoid creating event */
		if (implState->paramOut_next_numLinks == 0)
			return;
		insert = context->paramOut_next_armMarker;
		event = (DSPEEvent*) ParticleTrackerDllNextGate_SignalGate_allocate(context->paramOut_next_pool);
		event->refCount = 1;
		if (insert == NULL)
			context->paramOut_next_place = event;
		else
			insert->next = event;
		context->paramOut_next_armMarker = event;
		break;
	case dOut_PTFrame_event:
		/* If gate is unlinked no event will be sent. Avoid creating event */
		if (implState->dataOut_PTFrame_numLinks == 0)
			return;
		insert = context->dataOut_PTFrame_armMarker;
		if (insert == NULL) {
			if (context->dataOut_PTFrame_place == NULL) {
				event = (DSPEEvent*) ParticleTrackerDllPTFrameGate_MessageGate_allocateBlock(context->dataOut_PTFrame_pool);
				event->refCount = 1;
				context->dataOut_PTFrame_place = event;
				context->dataOut_PTFrame_armMarker = event;
				implState->dataOut_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value;
				/* create clones if needed */
				for (i = 0; i < context->dataOut_PTFrame_factor - 1; i++) {
					insert = event;
					event = insert->clone(insert);
					event->refCount = 1;
					((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value += context->blockSize;
					/* append clone */
					insert->next = event;
				}
			} else {
				event = context->dataOut_PTFrame_place;
				context->dataOut_PTFrame_armMarker = event;
				implState->dataOut_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value;
			}
		} else if (insert->next == NULL) {
			event = (DSPEEvent*) ParticleTrackerDllPTFrameGate_MessageGate_allocateBlock(context->dataOut_PTFrame_pool);
			event->refCount = 1;
			context->dataOut_PTFrame_armMarker->next = event;
			context->dataOut_PTFrame_armMarker = event;
			implState->dataOut_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value;
			/* create clones if needed */
			for (i = 0; i < context->dataOut_PTFrame_factor - 1; i++) {
				insert = event;
				event = insert->clone(insert);
				event->refCount = 1;
				((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value += context->blockSize;
				/* append clone */
				insert->next = event;
			}
		} else {
			/* use insert->next*/
			event = insert->next;
			context->dataOut_PTFrame_armMarker = event;
			implState->dataOut_PTFrame = ((ParticleTrackerDllPTFrameGate_MessageGate_event*) event)->value;
		}
		break;
	}
}

/* BlockUnit Post Function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_postEventBlockProd(DSPEEventsUnit *unit, unsigned int ID) {
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context = (ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd*) unit;
	ParticleTrackerDllLibraryDataReader_StateImplementation *implState = &context->implState;
	DSPEEvent *event = NULL;
	switch (ID) {
	case pOut_next_event:
		/* If gate is unlinked no event will be sent */
		if (implState->paramOut_next_numLinks == 0)
			return;
		event = context->paramOut_next_place;
		if (event == NULL)
			return;
		context->paramOut_next_place = event->next;
		if (context->paramOut_next_place == NULL)
			context->paramOut_next_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
		break;
	case dOut_PTFrame_event:
		/* If gate is unlinked no event will be sent */
		if (implState->dataOut_PTFrame_numLinks == 0)
			return;
		/* Restore save place to write */
		implState->dataOut_PTFrame = context->dataOut_PTFrame_unlinked;
		// Push pendingEvents support. If stop requested start collecting events instead of sending them
		// if pendingEvents available: we cannot send current data because there is other data to be sent before. Wait inputNext request to empty pending events
		// if stop requested: unit will send next to request all collected data!
		if (hasPendingEvents(context) ||
			*((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_stop == 1) {
			// Start collecting events. Incrementing pendingEvents counter and returning.
			// Event will be sent when inputEvent arrives
			context->dataOut_PTFrame_pendingEvents++;
			return;
		}
		event = context->dataOut_PTFrame_place;
		if (event == NULL)
			return;
		context->dataOut_PTFrame_place = event->next;
		if (context->dataOut_PTFrame_armMarker == event || context->dataOut_PTFrame_place == NULL)
			context->dataOut_PTFrame_armMarker = NULL;
		if (unit->sendEvent != NULL)
			unit->sendEvent(unit, event, ID);
		event->dispose(event);
		break;
	}

}

/* Initialize gate values */
static INLINE void initValues(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllLibraryDataReader_StateImplementation *implState = &context->implState;
	/* Data output places initializazion */
	ParticleTrackerDllSequenceValuesGate_PointerGate_initializeBlock((DSPEElement*) context, context->dataOut_SequenceValues_place, context->dataOut_SequenceValues_size);

	ParticleTrackerDllPTFrameGate_MessageGate_initializeUnlinkedBlock((DSPEElement*) context, context->dataOut_PTFrame_unlinked, context->blockSize);
	implState->dataOut_PTFrame = context->dataOut_PTFrame_unlinked;

}

/******************************************************************************
 * COMMON UNIT FUNCTIONS
 ******************************************************************************/

/* Earlyalloc function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_earlyAllocBlockProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context) {
	ParticleTrackerDllLibraryDataReader_StateImplementation *implState = &context->implState;

	initDSPEElement((DSPEElement*) &context->implState, (DSPEElement*) context);
	initDSPEQueueUnit((DSPEQueueUnit*) context);
	((DSPEComponent*) context)->preprocess = ParticleTrackerDllLibraryDataReader_SoftwareUnit_preProcessBlockProd;
	((DSPEComponent*) context)->process = ParticleTrackerDllLibraryDataReader_SoftwareUnit_processBlockProd;
	((DSPEComponent*) context)->postprocess = ParticleTrackerDllLibraryDataReader_SoftwareUnit_postProcessBlockProd;
	/* Data gates size initialization */
	context->dataOut_SequenceValues_size = context->blockSize;
	context->dataOut_PTFrame_size = context->blockSize;

	/* Data pendingEvents initialization */
	context->dataOut_PTFrame_pendingEvents = 0;

	/* Implementation AdditionalStateVariables initialization */
	implState->functionalState.queue = 0;
	implState->functionalState.remainingImgs = 0;
	implState->functionalState.id = 0;
}

/* Alloc function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_allocBlockProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context) {
	const DSPEOwner *owner = ((DSPEElement*) context)->owner;

	/* Base alloc() function call */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_alloc(&context->baseState);

	((DSPEEventsUnit*) context)->armEvent = ParticleTrackerDllLibraryDataReader_SoftwareUnit_armEventBlockProd;
	((DSPEEventsUnit*) context)->postEvent = ParticleTrackerDllLibraryDataReader_SoftwareUnit_postEventBlockProd;

	/* Initializing event Hooks and Inserts */
	context->paramOut_next_place = NULL;
	context->paramOut_next_armMarker = NULL;

	/* Allocate unlinked places for input event gates */
	context->dataOut_PTFrame_unlinked = ParticleTrackerDllPTFrameGate_MessageGate_allocateUnlinkedBlock((DSPEElement*) context, context->blockSize);


	/* Data output gates factor and counter initialization */
	context->dataOut_SequenceValues_factor = context->dataOut_SequenceValues_size / context->blockSize;
	context->dataOut_PTFrame_factor = context->dataOut_PTFrame_size / context->blockSize;

	/* Data output gates factor and counter initialization */
	context->dataOut_SequenceValues_counter = context->dataOut_SequenceValues_factor;


	/* Output data places memory allocation */
	context->dataOut_SequenceValues_place = ParticleTrackerDllSequenceValuesGate_PointerGate_allocateBlock((DSPEElement*) context, context->dataOut_SequenceValues_size);

	/* Initialize eventPools for parameter gates */
	context->paramOut_next_pool = ParticleTrackerDllNextGate_SignalGate_initPool(owner);

	context->dataOut_PTFrame_place = NULL;
	context->dataOut_PTFrame_armMarker = NULL;

	/* Initialize eventPools for data gates */
	context->dataOut_PTFrame_pool = ParticleTrackerDllPTFrameGate_MessageGate_initPoolBlock(owner, context->dataOut_PTFrame_size);

}

/* Earlyconnect function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_earlyConnectBlockProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllLibraryDataReader_StateImplementation *implState = &context->implState;

	/* Implementation output parameters gates initialization */
	implState->paramOut_Status = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramOut_Status_place;


	/* Base earlyconnect() function call */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_earlyConnect(&context->baseState);


	/* Output data gates initialization */
	context->dataOut_SequenceValues = context->dataOut_SequenceValues_place;

}

/* Connect function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_connectBlockProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context) {
	/* Implementation state local variable initialization */
	ParticleTrackerDllLibraryDataReader_StateImplementation *implState = &context->implState;

	/* Implementation input parameters gates initialization */
	implState->paramIn_stop = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_stop;
	implState->paramIn_LinkRange = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_LinkRange;
	implState->paramIn_ImgsNum = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgsNum;
	implState->paramIn_ImgWidth = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgWidth;
	implState->paramIn_ImgHeight = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgHeight;
	implState->paramIn_ImgMin = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgMin;
	implState->paramIn_ImgMax = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgMax;

	/* Implementation data gates initialization */
	implState->dataOut_SequenceValues = context->dataOut_SequenceValues;

	/* Implementation gates numLinks initialization */
	implState->dataOut_SequenceValues_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->dataOut_SequenceValues_numLinks;
	implState->dataOut_PTFrame_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->dataOut_PTFrame_numLinks;
	implState->paramIn_sourceNext_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_sourceNext_numLinks;
	implState->paramIn_next_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_next_numLinks;
	implState->paramIn_stop_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_stop_numLinks;
	implState->paramIn_LinkRange_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_LinkRange_numLinks;
	implState->paramIn_ImgsNum_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgsNum_numLinks;
	implState->paramIn_ImgWidth_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgWidth_numLinks;
	implState->paramIn_ImgHeight_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgHeight_numLinks;
	implState->paramIn_ImgMin_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgMin_numLinks;
	implState->paramIn_ImgMax_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_ImgMax_numLinks;
	implState->paramOut_next_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramOut_next_numLinks;
	implState->paramOut_Status_numLinks = ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramOut_Status_numLinks;

}

/* Startup function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_startupBlockProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context) {
	/* Initialize gate values */
	initValues(context);


	/* Implementation startup() call */
	ParticleTrackerDllLibraryDataReader_StateImplementation_startup(&context->implState);

}

/* Preprocess function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_preProcessBlockProd(DSPEComponent *component) {
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context = (ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd*) component;
	/* Implementation preprocess() call */
	ParticleTrackerDllLibraryDataReader_StateImplementation_preProcess(&context->implState);
}

/* Process function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_processBlockProd(DSPEComponent *component) {
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context = (ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd*) component;
	/* Implementation state local variable initialization */
	ParticleTrackerDllLibraryDataReader_StateImplementation *implState = &context->implState;
	const unsigned int ID = (((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->queueNumNodes == 0) ? NOEVENT : ((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->queueHead->ID;
	/* Loop counter */
	register size_t i;

	/* Implementation data gates and counters update */
	if (context->dataOut_SequenceValues_counter == context->dataOut_SequenceValues_factor) {
		implState->dataOut_SequenceValues = context->dataOut_SequenceValues;
		context->dataOut_SequenceValues_counter = 0;
	} else {
		implState->dataOut_SequenceValues++;
	}

	/* Push support: send all pending events if available */
	if (*((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_stop == 0) {
		while (hasPendingEvents(context)) {		
			dataOut_PTFrame_sendEvent(context);
		}
	}
	/* Switch input event ID */
	switch (ID) {
	case pIn_next_event:
		handleIncomingNextRequest(context);
		break;
	}

	/* Blocksize loop */
	for (i = 0; i < context->samplesToProcess - 1; i++) {

		/* Implementation process() call */
		ParticleTrackerDllLibraryDataReader_StateImplementation_process(implState);

		/* Block loop pointers increment */
		implState->dataOut_SequenceValues++;


		/* For Implementation having Advanced EventSupport also pointers for data output events have to be incremented */
		if (implState->dataOut_PTFrame != NULL)
			implState->dataOut_PTFrame++;

	}

	/* Implementation process() call */
	ParticleTrackerDllLibraryDataReader_StateImplementation_process(implState);

	/* input next push support */
	if (*((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context)->paramIn_stop == 1) {
	}
	/* Block counters increment */
	context->dataOut_SequenceValues_counter++;

	/* Release event */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_releaseEvent((ParticleTrackerDllLibraryDataReader_SoftwareUnit*) context);
}

/* Postprocess function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_postProcessBlockProd(DSPEComponent *component) {
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context = (ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd*) component;

	/* Implementation postprocess() call */
	ParticleTrackerDllLibraryDataReader_StateImplementation_postProcess(&context->implState);

	/* Move all output events that have been armed but not sent to their related pool */
	resetEventPlaces(context);

	/* Base postprocess() function call */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_postProcess(&context->baseState);
}

/* Reset function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_resetBlockProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context) {
	ParticleTrackerDllLibraryDataReader_StateImplementation *implState = &context->implState;

	/* Base reset() function call */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_reset(&context->baseState);

	/* Initialize gate values */
	initValues(context);
	/* Data pendingEvents initialization */
	context->dataOut_PTFrame_pendingEvents = 0;

	/* Implementation AdditionalStateVariables initialization */
	implState->functionalState.remainingImgs = 0;
	implState->functionalState.id = 0;
}

/* Shutdown function */
void ParticleTrackerDllLibraryDataReader_SoftwareUnit_shutdownBlockProd(ParticleTrackerDllLibraryDataReader_SoftwareUnit_blockProd *context) {
	/* Implementation shutdown() call */
	ParticleTrackerDllLibraryDataReader_StateImplementation_shutdown(&context->implState);



	/* Base shutdown() function call */
	ParticleTrackerDllLibraryDataReader_SoftwareUnit_shutdown(&context->baseState);


	/* Output data places dispose */
	ParticleTrackerDllSequenceValuesGate_PointerGate_disposeBlock((DSPEElement*) context, context->dataOut_SequenceValues_place);

	/* Dispose unlinked places for input event gates */
	ParticleTrackerDllPTFrameGate_MessageGate_disposeUnlinkedBlock((DSPEElement*) context, context->dataOut_PTFrame_unlinked);

}

