/**
 * File: RBlockSim_ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:48 CEST 2011
 */
#ifndef RBlockSim_ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_h
#define RBlockSim_ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_h

#include "B_ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation.h"
#include "B_ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit.h"
#include "RBlock_ParticleTrackerDllPTFrameGate_MessageGate.h"

/* Block SoftwareUnit state type definition */
typedef struct ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim;

/* Block SoftwareUnit state definition */
struct ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim {

	/* Base unit state */
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllLinkParticlesCPAutoNext_PUSH_StateImplementation implState;
	
	/* Block size */
	size_t blockSize;

	/* Samples to process */
	size_t samplesToProcess;

	/* Data transit queues */
	size_t dataIn_PTFrame_transitNumElements;
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_transitHead;
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_transitTail;
	ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_curTransit;
	unsigned int dataIn_PTFrame_curTransitIndex;

	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;
	DSPEEvent *dataOut_PTFrame_place;
	DSPEEvent *dataOut_PTFrame_armMarker;

	/* Data pending events support */
	size_t dataOut_PTFrame_pendingEvents;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;

	/* EventPools */
	ParticleTrackerDllPTFrameGate_MessageGate_poolBlock *dataOut_PTFrame_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame_unlinked;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame_unlinked;


	/* Data gates sizes */
	size_t dataOut_PTFrame_size;


	/* Data gates factors */
	size_t dataOut_PTFrame_factor;


	/* Data gates counters */
	size_t dataOut_PTFrame_counter;


	/* Data gates counters */
	size_t dataOut_PTFrame_samplesCounter;

	/* Unit profile ID */
	int unitProfileID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_transitEventBlockSim(DSPEQueueUnit *unit);

size_t ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getTransitNumElementsBlockSim(DSPEQueueUnit *unit, unsigned int ID);

size_t ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getTransitNumElementsBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getFirstTransitBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_getCurTransitBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_dismissEventBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_dismissAllEventsBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_armEventBlockSim(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_postEventBlockSim(DSPEEventsUnit *unit, unsigned int ID);

/* Earlyalloc function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_earlyAllocBlockSim(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context);

/* Alloc function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_allocBlockSim(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context);

/* Earlyconnect function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_earlyConnectBlockSim(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context);

/* Connect function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_connectBlockSim(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context);

/* Startup function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_startupBlockSim(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context);

/* Preprocess function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_preProcessBlockSim(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_processBlockSim(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_postProcessBlockSim(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_resetBlockSim(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context);

/* Shutdown function */
void ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_shutdownBlockSim(ParticleTrackerDllLinkParticlesStateCPAutoNext_PUSH_SoftwareUnit_blockSim *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
