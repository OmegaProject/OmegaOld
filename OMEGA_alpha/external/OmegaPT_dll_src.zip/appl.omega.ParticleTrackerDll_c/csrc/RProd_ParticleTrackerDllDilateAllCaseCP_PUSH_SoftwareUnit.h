/**
 * File: RProd_ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef RProd_ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_h
#define RProd_ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_h

#include "B_ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation.h"
#include "B_ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit.h"
#include "B_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "B_ParticleTrackerDllPTFrameGate_MessageGate.h"
#include "B_ParticleTrackerDllMaskGate_PointerGate.h"

/* Real SoftwareUnit state type definition */
typedef struct ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_realProd ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_realProd;

/* Real SoftwareUnit state definition */
struct ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_realProd {

	/* Base unit state */
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation implState;
	
	/* Data transit queues */
	size_t dataIn_PTFrame_transitNumElements;
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_transitHead;
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_transitTail;
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_curTransit;
	unsigned int dataIn_PTFrame_curTransitIndex;

	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;
	DSPEEvent *dataOut_PTFrame_place;
	DSPEEvent *dataOut_PTFrame_armMarker;

	/* Data pending events support */
	size_t dataOut_PTFrame_pendingEvents;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;

	/* EventPools */
	ParticleTrackerDllPTFrameGate_MessageGate_pool *dataOut_PTFrame_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame_unlinked;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame_unlinked;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;
	ParticleTrackerDllMaskGate_PointerGate *dataOut_Mask;


	/* Output data places */
	ParticleTrackerDllMaskGate_PointerGate *dataOut_Mask_place;

	/* Unit profile ID */
	int unitProfileID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_transitEventRealProd(DSPEQueueUnit *unit);

size_t ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getTransitNumElementsRealProd(DSPEQueueUnit *unit, unsigned int ID);

size_t ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getCurrentNumElementsRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getFirstTransitRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getCurTransitRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_dismissEventRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_dismissAllEventsRealProd(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_armEventRealProd(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_postEventRealProd(DSPEEventsUnit *unit, unsigned int ID);

/**
 * initOp function
 */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_initOpRealProd(DSPECoprocUnit *unit, DSPEOp *op);

/* Earlyalloc function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_earlyAllocRealProd(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_realProd *context);

/* Alloc function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_allocRealProd(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_realProd *context);

/* Earlyconnect function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_earlyConnectRealProd(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_realProd *context);

/* Connect function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_connectRealProd(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_realProd *context);

/* Startup function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_startupRealProd(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_realProd *context);

/* Preprocess function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_preProcessRealProd(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_processRealProd(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_postProcessRealProd(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_resetRealProd(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_realProd *context);

/* Shutdown function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_shutdownRealProd(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_realProd *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
