/**
 * File: B_ParticleTrackerDllNextGate_SignalGate.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef B_ParticleTrackerDllNextGate_SignalGate_h
#define B_ParticleTrackerDllNextGate_SignalGate_h

#include "DSPEElements.h"
#include "MemoryGround.h"
#define PARTICLETRACKERDLLNEXTGATE_SIGNALGATE_TYPECATEGORY "Signal"
/* EventGate state type definition */
typedef struct ParticleTrackerDllNextGate_SignalGate_event ParticleTrackerDllNextGate_SignalGate_event;

/* EventGate state definition */
struct ParticleTrackerDllNextGate_SignalGate_event {
	DSPEEvent event;

};

/* Event clone state type definition */
typedef struct ParticleTrackerDllNextGate_SignalGate_cloneEvent ParticleTrackerDllNextGate_SignalGate_cloneEvent;

/* Event clone state definition */
struct ParticleTrackerDllNextGate_SignalGate_cloneEvent {
	ParticleTrackerDllNextGate_SignalGate_event event;

	DSPEEvent *original;
};

/* EventGate pool type definition */
typedef struct ParticleTrackerDllNextGate_SignalGate_pool ParticleTrackerDllNextGate_SignalGate_pool;

/* EventGate pool definition */
struct ParticleTrackerDllNextGate_SignalGate_pool {
	DSPEBaseEventsPool pool;

	// Pool for events
	size_t eventNumElements;
	ParticleTrackerDllNextGate_SignalGate_event *headEvent;
	ParticleTrackerDllNextGate_SignalGate_event *tailEvent;

	// Pool for clones
	size_t cloneNumElements;
	ParticleTrackerDllNextGate_SignalGate_cloneEvent *headClone;
	ParticleTrackerDllNextGate_SignalGate_cloneEvent *tailClone;
};

/* SignalGate node type definition */
typedef struct ParticleTrackerDllNextGate_SignalGate_node ParticleTrackerDllNextGate_SignalGate_node; 

/* SignalGate node definition */ 
struct ParticleTrackerDllNextGate_SignalGate_node {
	DSPEGateNode node;

	int sendEvent;
	unsigned int eventID;
	DSPEApplication *application;
	DSPEEventsPool *pool;
};


/* GroupEventGate state type definition */
typedef struct ParticleTrackerDllNextGate_SignalGate_groupEvent ParticleTrackerDllNextGate_SignalGate_groupEvent;

/* GroupEventGate state definition */
struct ParticleTrackerDllNextGate_SignalGate_groupEvent {
	DSPEGroupEvent event;

};

/* GroupEvent clone state type definition */
typedef struct ParticleTrackerDllNextGate_SignalGate_cloneGroupEvent ParticleTrackerDllNextGate_SignalGate_cloneGroupEvent;

/* GroupEvent clone state definition */
struct ParticleTrackerDllNextGate_SignalGate_cloneGroupEvent {
	ParticleTrackerDllNextGate_SignalGate_groupEvent event;

	DSPEGroupEvent *original;
};

/* GroupEvent container state type definition */
typedef struct ParticleTrackerDllNextGate_SignalGate_eventContainer ParticleTrackerDllNextGate_SignalGate_eventContainer;

/* GroupEvent container state definition */
struct ParticleTrackerDllNextGate_SignalGate_eventContainer {
	ParticleTrackerDllNextGate_SignalGate_groupEvent event;

	DSPEEvent **containedEvents;
};

/* GroupEventGate pool type definition */
typedef struct ParticleTrackerDllNextGate_SignalGate_groupPool ParticleTrackerDllNextGate_SignalGate_groupPool;

/* GroupEventGate pool definition */
struct ParticleTrackerDllNextGate_SignalGate_groupPool {
	DSPEGroupEventsPool pool;

	/* Pool for Events */
	size_t eventNumElements;
	ParticleTrackerDllNextGate_SignalGate_groupEvent *headEvent;
	ParticleTrackerDllNextGate_SignalGate_groupEvent *tailEvent;
	
	/* Pool for Clones */
	size_t cloneNumElements;
	ParticleTrackerDllNextGate_SignalGate_cloneGroupEvent *headClone;
	ParticleTrackerDllNextGate_SignalGate_cloneGroupEvent *tailClone;
	
	/* Pool for EventContainers */
	size_t containerNumElements;
	ParticleTrackerDllNextGate_SignalGate_eventContainer *headContainer;
	ParticleTrackerDllNextGate_SignalGate_eventContainer *tailContainer;
};

#ifdef __cplusplus
extern "C" {
#endif

/* eventPool initialization function */
ParticleTrackerDllNextGate_SignalGate_pool* ParticleTrackerDllNextGate_SignalGate_initPool(const DSPEOwner *owner);

/* eventPool preAlloc function */
void ParticleTrackerDllNextGate_SignalGate_preAllocPool(DSPEEventsPool *pool, size_t size);

/* Allocate function */
ParticleTrackerDllNextGate_SignalGate_event* ParticleTrackerDllNextGate_SignalGate_allocate(ParticleTrackerDllNextGate_SignalGate_pool *pool);

/* Clone event function */
DSPEEvent* ParticleTrackerDllNextGate_SignalGate_clone(DSPEEvent *event);

/* Dispose function */
void ParticleTrackerDllNextGate_SignalGate_dispose(DSPEEvent *event);

/* eventPool dispose function */
void ParticleTrackerDllNextGate_SignalGate_disposePool(DSPEEventsPool *pool);

/* groupEventPool initialization function */
ParticleTrackerDllNextGate_SignalGate_groupPool* ParticleTrackerDllNextGate_SignalGate_initGroupPool(const DSPEOwner *owner, size_t groupSize);

/* eventPool preAlloc function */
void ParticleTrackerDllNextGate_SignalGate_preAllocGroupPool(DSPEEventsPool *pool, size_t size);

/* AllocateGroup function */
ParticleTrackerDllNextGate_SignalGate_groupEvent* ParticleTrackerDllNextGate_SignalGate_allocateGroup(ParticleTrackerDllNextGate_SignalGate_groupPool *grpPool);

/* SubClone event function */
DSPEEvent* ParticleTrackerDllNextGate_SignalGate_subClone(DSPEGroupEvent *event, DSPEEventsPool *pool, size_t index);

/* CloneGroup event function */
DSPEEvent* ParticleTrackerDllNextGate_SignalGate_cloneGroup(DSPEEvent *event);

/* DisposeGroup function */
void ParticleTrackerDllNextGate_SignalGate_disposeGroup(DSPEEvent *event);

/* eventPool dispose function */
void ParticleTrackerDllNextGate_SignalGate_disposeGroupPool(DSPEEventsPool *pool);

/**
 * Allocate containerEvent function
 */
ParticleTrackerDllNextGate_SignalGate_eventContainer* ParticleTrackerDllNextGate_SignalGate_allocateContainer(ParticleTrackerDllNextGate_SignalGate_groupPool *grpPool);

/**
 * Dispose containerEvent function
 */
void ParticleTrackerDllNextGate_SignalGate_disposeContainer(DSPEEvent *event);

/* CreateNode function */
ParticleTrackerDllNextGate_SignalGate_node* ParticleTrackerDllNextGate_SignalGate_createNode(DSPEApplication *application, DSPEEventsPool *pool, unsigned int eventID);

/* DisposeNode function */
void ParticleTrackerDllNextGate_SignalGate_disposeNode(DSPEElement *context, DSPEGateNode *node);

/* SetValue function */
void ParticleTrackerDllNextGate_SignalGate_setValue(DSPEElement *context, DSPEGateNode *node);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
