/**
 * File: B_ParticleTrackerDllSequenceValuesGate_PointerGate.c
 *
 * @author Loris
 * @created Thu May 26 10:23:49 CEST 2011
 */
#include "MemoryManager.h"

#include "B_ParticleTrackerDllSequenceValuesGate_PointerGate.h"

#include "B_ParticleTrackerDllTracker_Requirement.h"

/* Allocate function */
ParticleTrackerDllSequenceValuesGate_PointerGate* ParticleTrackerDllSequenceValuesGate_PointerGate_allocate(DSPEElement *context) {
	return memoryManager_allocate(context, sizeof(ParticleTrackerDllSequenceValuesGate_PointerGate));
}

/* Initialise function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_initialize(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate *place) {
	*place = PARTICLETRACKERDLLSEQUENCEVALUESGATE_POINTERGATE_DEFAULTVALUE;
}

/* SetOverride function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_setOverride(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate *place, ParticleTrackerDllSequenceValuesGate_PointerGate value) {
	*place = value;
}

/* Set function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_set(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate *place, ParticleTrackerDllSequenceValuesGate_PointerGate *value) {
	*place = *value;
}

/* Dispose function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_dispose(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate *place) {
	memorySupport_dispose(place);
}

/* AllocateGroup function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_allocateGroup(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	place[i] = ParticleTrackerDllSequenceValuesGate_PointerGate_allocate(context);
	}
}

/* InitialiseGroup function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_initializeGroup(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t size) {
	register size_t i;
	for (i = 0; i < size; i++) {
	 	ParticleTrackerDllSequenceValuesGate_PointerGate_initialize(context, place[i]);
	}
}

/* SetOverrideGroup function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_setOverrideGroup(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t size, ParticleTrackerDllSequenceValuesGate_PointerGate value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllSequenceValuesGate_PointerGate_setOverride(context, place[i], value);
	}
}

/* SetGroup function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_setGroup(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t size, ParticleTrackerDllSequenceValuesGate_PointerGate **value) {
	register size_t i;
	for (i = 0; i < size; i++) {
		ParticleTrackerDllSequenceValuesGate_PointerGate_set(context, place[i], value[i]);
	}
}

/* DisposeGroup function */
void ParticleTrackerDllSequenceValuesGate_PointerGate_disposeGroup(DSPEElement *context, ParticleTrackerDllSequenceValuesGate_PointerGate **place, size_t size) {
	register size_t i;	
	for (i = 0; i < size; i++) {
	 	memorySupport_dispose(place[i]);
	}
}

