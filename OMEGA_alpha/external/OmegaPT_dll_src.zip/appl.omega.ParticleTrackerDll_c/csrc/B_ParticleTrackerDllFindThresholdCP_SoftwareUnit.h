/**
 * File: B_ParticleTrackerDllFindThresholdCP_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef B_ParticleTrackerDllFindThresholdCP_SoftwareUnit_h
#define B_ParticleTrackerDllFindThresholdCP_SoftwareUnit_h

#include "DSPEElements.h"
#include "DSPEXTElements.h"

#include "B_ParticleTrackerDllRealGate_CustomGate.h"
#include "B_ParticleTrackerDllStatusGate_StringGate.h"

/* Queue node type definition */
typedef struct ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode;

/* Queue node type definition */
struct ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode {
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode *next;
	unsigned int ID;
	DSPEEvent *event;
	/* Transit node support */
	short inTransit;
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode *nextInTransit;
};

/* State type definition */
typedef struct ParticleTrackerDllFindThresholdCP_SoftwareUnit ParticleTrackerDllFindThresholdCP_SoftwareUnit;

/* State definition */ 
struct ParticleTrackerDllFindThresholdCP_SoftwareUnit {

	DSPECoprocUnit coprocUnit;

	unsigned int poolNumNodes;
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode *poolHead;
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode *poolTail;

	unsigned int queueNumNodes;
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode *queueHead;
	ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueNode *queueTail;

	/* Parameter gates */
	ParticleTrackerDllRealGate_CustomGate *paramIn_Percentile;
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status;


	/* Output parameters places */
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status_place;


	/* Output parameters places anchors */
	ParticleTrackerDllStatusGate_StringGate *paramOut_Status_placeAnchor;

	/* Gates numLinks */
	unsigned int dataIn_SequenceValues_numLinks;
	unsigned int dataIn_PTFiltered_numLinks;
	unsigned int dataOut_PTThreshold_numLinks;
	unsigned int paramIn_Percentile_numLinks;
	unsigned int paramOut_Status_numLinks;

	/* unit ID */
	char *ID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_queueEvent(DSPEEventsUnit *unit, DSPEEvent *event, unsigned int ID);

void ParticleTrackerDllFindThresholdCP_SoftwareUnit_releaseEvent(ParticleTrackerDllFindThresholdCP_SoftwareUnit *context);

int ParticleTrackerDllFindThresholdCP_SoftwareUnit_isEventAvailable(const DSPEQueueUnit *unit);

DSPEEvent* ParticleTrackerDllFindThresholdCP_SoftwareUnit_getEvent(const DSPEQueueUnit *unit);

unsigned int ParticleTrackerDllFindThresholdCP_SoftwareUnit_getEventID(const DSPEQueueUnit *unit);

/* getID function */
char* ParticleTrackerDllFindThresholdCP_SoftwareUnit_getID(const DSPEElement *element);

/* Alloc function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_alloc(ParticleTrackerDllFindThresholdCP_SoftwareUnit *context);

/* Earlyconnect function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_earlyConnect(ParticleTrackerDllFindThresholdCP_SoftwareUnit *context);

/* Postprocess function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_postProcess(ParticleTrackerDllFindThresholdCP_SoftwareUnit *context);

/* Reset function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_reset(ParticleTrackerDllFindThresholdCP_SoftwareUnit *context);

/* Shutdown function */
void ParticleTrackerDllFindThresholdCP_SoftwareUnit_shutdown(ParticleTrackerDllFindThresholdCP_SoftwareUnit *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
