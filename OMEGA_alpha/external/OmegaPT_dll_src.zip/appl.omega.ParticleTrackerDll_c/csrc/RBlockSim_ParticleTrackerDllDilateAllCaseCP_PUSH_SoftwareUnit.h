/**
 * File: RBlockSim_ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit.h
 *
 * @author Loris
 * @created Thu May 26 10:23:47 CEST 2011
 */
#ifndef RBlockSim_ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_h
#define RBlockSim_ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_h

#include "B_ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation.h"
#include "B_ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit.h"
#include "RBlock_ParticleTrackerDllSequenceValuesGate_PointerGate.h"
#include "RBlock_ParticleTrackerDllPTFrameGate_MessageGate.h"
#include "RBlock_ParticleTrackerDllMaskGate_PointerGate.h"

/* Block SoftwareUnit state type definition */
typedef struct ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim;

/* Block SoftwareUnit state definition */
struct ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim {

	/* Base unit state */
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit baseState;

	/* Base implementation state */
	ParticleTrackerDllDilateAllCase_PUSH_CoprocImplementation implState;
	
	/* Block size */
	size_t blockSize;

	/* Samples to process */
	size_t samplesToProcess;

	/* Data transit queues */
	size_t dataIn_PTFrame_transitNumElements;
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_transitHead;
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_transitTail;
	ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_queueNode *dataIn_PTFrame_curTransit;
	unsigned int dataIn_PTFrame_curTransitIndex;

	DSPEEvent *paramOut_next_place;
	DSPEEvent *paramOut_next_armMarker;
	DSPEEvent *dataOut_PTFrame_place;
	DSPEEvent *dataOut_PTFrame_armMarker;

	/* Data pending events support */
	size_t dataOut_PTFrame_pendingEvents;

	/* EventPools */
	ParticleTrackerDllNextGate_SignalGate_pool *paramOut_next_pool;

	/* EventPools */
	ParticleTrackerDllPTFrameGate_MessageGate_poolBlock *dataOut_PTFrame_pool;

	/* Unlinked places for dataGates */
	ParticleTrackerDllPTFrameGate_MessageGate *dataIn_PTFrame_unlinked;
	ParticleTrackerDllPTFrameGate_MessageGate *dataOut_PTFrame_unlinked;


	/* Data gates */
	ParticleTrackerDllSequenceValuesGate_PointerGate *dataIn_SequenceValues;
	ParticleTrackerDllMaskGate_PointerGate *dataOut_Mask;


	/* Data gates sizes */
	size_t dataIn_SequenceValues_size;
	size_t dataOut_Mask_size;
	size_t dataOut_PTFrame_size;


	/* Data gates factors */
	size_t dataIn_SequenceValues_factor;
	size_t dataOut_Mask_factor;
	size_t dataOut_PTFrame_factor;


	/* Data gates counters */
	size_t dataIn_SequenceValues_counter;
	size_t dataOut_Mask_counter;
	size_t dataOut_PTFrame_counter;


	/* Output data places */
	ParticleTrackerDllMaskGate_PointerGate *dataOut_Mask_place;


	/* Data gates counters */
	size_t dataOut_PTFrame_samplesCounter;

	/* Unit profile ID */
	int unitProfileID;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Exported local functions */

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_transitEventBlockSim(DSPEQueueUnit *unit);

size_t ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getTransitNumElementsBlockSim(DSPEQueueUnit *unit, unsigned int ID);

size_t ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getTransitNumElementsBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getFirstTransitBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_getCurTransitBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_dismissEventBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_dismissAllEventsBlockSim(DSPEQueueUnit *unit, unsigned int ID);

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_armEventBlockSim(DSPEEventsUnit *unit, unsigned int ID);

void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_postEventBlockSim(DSPEEventsUnit *unit, unsigned int ID);

/**
 * initOp function
 */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_initOpBlockSim(DSPECoprocUnit *unit, DSPEOp *op);

/* Earlyalloc function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_earlyAllocBlockSim(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context);

/* Alloc function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_allocBlockSim(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context);

/* Earlyconnect function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_earlyConnectBlockSim(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context);

/* Connect function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_connectBlockSim(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context);

/* Startup function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_startupBlockSim(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context);

/* Preprocess function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_preProcessBlockSim(DSPEComponent *component);

/* Process function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_processBlockSim(DSPEComponent *component);

/* Postprocess function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_postProcessBlockSim(DSPEComponent *component);

/* Reset function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_resetBlockSim(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context);

/* Shutdown function */
void ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_shutdownBlockSim(ParticleTrackerDllDilateAllCaseCP_PUSH_SoftwareUnit_blockSim *context);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
