#ifndef _STRINGLIST_H_
#define _STRINGLIST_H_

/*
* StringNode
*
* A node of the linked list of string
*
* It contains:
* An array of 128 char to hold the string
* A StringNode pointer to previous element
* A StringNode pointer to next element
*/
typedef struct StringNode {
	char string[128];
	struct StringNode *next;
} StringNode;

/*
* StringList
*
* The linked list of string
*
* It contains:
* An int to hold the number of node of the list
* A StringNode pointer to the root of the list
* A StringNode pointer to the tail of the list
*/
typedef struct StringList {
	int numberOfString;
	StringNode *head;
	StringNode *tail;
} StringList;

//New methods
void addAll(StringList *slDestination, StringList *slSource);
void addString(StringList *sl, const char *string, ...);
void releaseStringList(StringList *sl);
StringList* initStringList() ;

#endif // _STRINGLIST_H_
