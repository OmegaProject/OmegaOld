/*
 * Dilation subroutines
 *
 * Ingo Oppermann, 18.7.2003
 * Institute of Computational Science, Swiss Federal
 * Institute of Technology (ETH) Zurich. 
 * E-mail: oingo@student.ethz.ch
 *
 */

#include <stdio.h>
#include "tracker.h"
#include "dilate.h"

/*
 * This file contains the function for dilating an image
 * with an given mask.
 *
 * PT_DilateGeneric is a generic dilation useable with any
 * sizes of the image or mask.
 * There are optimized functions for the mask radius from 1 to 5
 * The optimized functions are named accordingly
 * PT_Dilate1, PT_Dilate2, PT_Dilate3, PT_Dilate4 and PT_Dilate5
 *
 * INPUT:	PTSequence*	The sequence containing the mask
 *		real*		The resulting image
 *		real*		The image to be dilated
 *
 * OUTPUT:	real*		The resulting image
 *
 * USES:	-
 *
 */

real *PT_DilateGeneric(int *mask, int kernel_width, int width, int height,  int radius, real *dilated, real *input) {
	int i, j, k, l, m, x, y;
	real h;

	// upper bound and lower bound
	for(j = 0; j < width; j++) {

		// upper bound
		for(i = 0; i < radius; i++) {

			h = input[COORD(i, j, width)];

			for(k = -radius; k <= radius; k++) {
				if((i + k) < 0)
					continue;
				else
					x = i + k;

				for(l = -radius; l <= radius; l++) {
					if(mask[COORD(k + radius, l + radius, kernel_width)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}

		// lower bound
		for(i = (height - radius); i < height; i++) {

			h = input[COORD(i, j, width)];

			for(k = -radius; k <= radius; k++) {
				if((i + k) >= height)
					continue;
				else
					x = i + k;

				for(l = -radius; l <= radius; l++) {
					if(mask[COORD(k + radius, l + radius, kernel_width)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	// left bound and right bound
	for(i = radius; i < (height - radius); i++) {

		// left bound
		for(j = 0; j < radius; j++) {

			h = input[COORD(i, j, width)];

			for(k = -radius; k <= radius; k++) {
				x = i + k;

				for(l = -radius; l <= radius; l++) {
					if(mask[COORD(k + radius, l + radius, kernel_width)] == 0)
						continue;

					if((j + l) < 0)
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}

		// right bound
		for(j = (width - radius); j < width; j++) {

			h = input[COORD(i, j, width)];

			for(k = -radius; k <= radius; k++) {
				x = i + k;

				for(l = -radius; l <= radius; l++) {
					if(mask[COORD(k + radius, l + radius, kernel_width)] == 0)
						continue;

					if((j + l) >= width)
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	// the interior
	for(i = radius; i < (height - radius); i++) {
		for(j = radius; j < (width - radius); j++) {

			k = COORD(i - radius, j - radius, width);
			h = input[k];

			for(l = 0; l < kernel_width; l++) {
				for(m = 0; m < kernel_width; m++) {
					if(mask[COORD(l, m, kernel_width)] == 0)
						continue;

					if(input[k + m] > h)
						h = input[k + m];
				}
				k += width;
			}

			dilated[COORD(i, j, width)] = h;
		}
	}

	return dilated;
}

real *PT_Dilate1(int *mask, int width, int height, real *dilated, real *input) {
	int i, j, k, l, x, y;
	real c[5], h;

	// obere kante
	for(i = 0; i < 1; i++) {
		for(j = 0; j < width; j++) {

			h = input[COORD(i, j, width)];

			for(k = -1; k <= 1; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -1; l <= 1; l++) {
					if(mask[COORD(k + 1, l + 1, 3)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	// untere kante
	for(i = (height - 1); i < height; i++) {
		for(j = 0; j < width; j++) {

			h = input[COORD(i, j, width)];

			for(k = -1; k <= 1; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -1; l <= 1; l++) {
					if(mask[COORD(k + 1, l + 1, 3)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	// linke seite
	for(i = 1; i < (height - 1); i++) {
		for(j = 0; j < 1; j++) {

			h = input[COORD(i, j, width)];

			for(k = -1; k <= 1; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -1; l <= 1; l++) {
					if(mask[COORD(k + 1, l + 1, 3)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	// rechte seite
	for(i = 1; i < (height - 1); i++) {
		for(j = (width - 1); j < width; j++) {

			h = input[COORD(i, j, width)];

			for(k = -1; k <= 1; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -1; l <= 1; l++) {
					if(mask[COORD(k + 1, l + 1, 3)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	for(i = 1; i < (height - 1); i++) {
		for(j = 1; j < (width - 1); j++) {

			k = COORD(i - 1, j - 1, width);

			c[0] = input[k + 1];

			k += width;

			c[1] = input[k];
			c[2] = input[k + 1];
			c[3] = input[k + 2];

			k += width;

			c[4] = input[k + 1];

			h = c[0];

			for(k = 1; k < 5; k++)
				if(c[k] > h) h = c[k];

			dilated[COORD(i, j, width)] = h;
		}
	}

	return dilated;
}

real *PT_Dilate2(int *mask, int width, int height, real *dilated, real *input) {
	int i, j, k, l, x, y;
	real c[13], h;

	// obere kante
	for(i = 0; i < 2; i++) {
		for(j = 0; j < width; j++) {

			h = input[COORD(i, j, width)];

			for(k = -2; k <= 2; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -2; l <= 2; l++) {
					if(mask[COORD(k + 2, l + 2, 5)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	// untere kante
	for(i = (height - 2); i < height; i++) {
		for(j = 0; j < width; j++) {

			h = input[COORD(i, j, width)];

			for(k = -2; k <= 2; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -2; l <= 2; l++) {
					if(mask[COORD(k + 2, l + 2, 5)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	// linke seite
	for(i = 2; i < (height - 2); i++) {
		for(j = 0; j < 2; j++) {

			h = input[COORD(i, j, width)];

			for(k = -2; k <= 2; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -2; l <= 2; l++) {
					if(mask[COORD(k + 2, l + 2, 5)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	// rechte seite
	for(i = 2; i < (height - 2); i++) {
		for(j = (width - 2); j < width; j++) {

			h = input[COORD(i, j, width)];

			for(k = -2; k <= 2; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -2; l <= 2; l++) {
					if(mask[COORD(k + 2, l + 2, 5)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	for(i = 2; i < (height - 2); i++) {
		for(j = 2; j < (width - 2); j++) {

			k = COORD(i - 2, j - 2, width);

			c[0] = input[k + 2];

			k += width;

			c[1] = input[k + 1];
			c[2] = input[k + 2];
			c[3] = input[k + 3];

			k += width;

			c[4] = input[k];
			c[5] = input[k + 1];
			c[6] = input[k + 2];
			c[7] = input[k + 3];
			c[8] = input[k + 4];

			k += width;

			c[9] = input[k + 1];
			c[10] = input[k + 2];
			c[11] = input[k + 3];

			k += width;

			c[12] = input[k + 2];

			h = c[0];

			for(k = 1; k < 13; k++)
				if(c[k] > h) h = c[k];

			dilated[COORD(i, j, width)] = h;
		}
	}

	return dilated;
}

real *PT_Dilate3(int *mask, int width, int height, real *dilated, real *input) {
	int i, j, k, l, x, y;
	real c[29], h;

	// obere kante
	for(i = 0; i < 3; i++) {
		for(j = 0; j < width; j++) {

			h = input[COORD(i, j, width)];

			for(k = -3; k <= 3; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -3; l <= 3; l++) {
					if(mask[COORD(k + 3, l + 3, 7)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	// untere kante
	for(i = (height - 3); i < height; i++) {
		for(j = 0; j < width; j++) {

			h = input[COORD(i, j, width)];

			for(k = -3; k <= 3; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -3; l <= 3; l++) {
					if(mask[COORD(k + 3, l + 3, 7)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	// linke seite
	for(i = 3; i < (height - 3); i++) {
		for(j = 0; j < 3; j++) {

			h = input[COORD(i, j, width)];

			for(k = -3; k <= 3; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -3; l <= 3; l++) {
					if(mask[COORD(k + 3, l + 3, 7)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	// rechte seite
	for(i = 3; i < (height - 3); i++) {
		for(j = (width - 3); j < width; j++) {

			h = input[COORD(i, j, width)];

			for(k = -3; k <= 3; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -3; l <= 3; l++) {
					if(mask[COORD(k + 3, l + 3, 7)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	for(i = 3; i < (height - 3); i++) {
		for(j = 3; j < (width - 3); j++) {

			k = COORD(i - 3, j - 3, width);

			c[0] = input[k + 3];

			k += width;

			c[1] = input[k + 1];
			c[2] = input[k + 2];
			c[3] = input[k + 3];
			c[4] = input[k + 4];
			c[5] = input[k + 5];

			k += width;

			c[6] = input[k + 1];
			c[7] = input[k + 2];
			c[8] = input[k + 3];
			c[9] = input[k + 4];
			c[10] = input[k + 5];

			k += width;

			c[11] = input[k];
			c[12] = input[k + 1];
			c[13] = input[k + 2];
			c[14] = input[k + 3];
			c[15] = input[k + 4];
			c[16] = input[k + 5];
			c[17] = input[k + 6];

			k += width;

			c[18] = input[k + 1];
			c[19] = input[k + 2];
			c[20] = input[k + 3];
			c[21] = input[k + 4];
			c[22] = input[k + 5];

			k += width;

			c[23] = input[k + 1];
			c[24] = input[k + 2];
			c[25] = input[k + 3];
			c[26] = input[k + 4];
			c[27] = input[k + 5];

			k += width;

			c[28] = input[k + 3];

			h = c[0];

			for(k = 1; k < 29; k++)
				if(c[k] > h) h = c[k];

			dilated[COORD(i, j, width)] = h;
		}
	}

	return dilated;
}

real *PT_Dilate4(int *mask, int width, int height, real *dilated, real *input) {
	int i, j, k, l, x, y;
	real c[49], h;

	// obere kante
	for(i = 0; i < 4; i++) {
		for(j = 0; j < width; j++) {

			h = input[COORD(i, j, width)];

			for(k = -4; k <= 4; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -4; l <= 4; l++) {
					if(mask[COORD(k + 4, l + 4, 9)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	// untere kante
	for(i = (height - 4); i < height; i++) {
		for(j = 0; j < width; j++) {

			h = input[COORD(i, j, width)];

			for(k = -4; k <= 4; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -4; l <= 4; l++) {
					if(mask[COORD(k + 4, l + 4, 9)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	// linke seite
	for(i = 4; i < (height - 4); i++) {
		for(j = 0; j < 4; j++) {

			h = input[COORD(i, j, width)];

			for(k = -4; k <= 4; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -4; l <= 4; l++) {
					if(mask[COORD(k + 4, l + 4, 9)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	// rechte seite
	for(i = 4; i < (height - 4); i++) {
		for(j = (width - 4); j < width; j++) {

			h = input[COORD(i, j, width)];

			for(k = -4; k <= 4; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -4; l <= 4; l++) {
					if(mask[COORD(k + 4, l + 4, 9)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	for(i = 4; i < (height - 4); i++) {
		for(j = 4; j < (width - 4); j++) {

			k = COORD(i - 4, j - 4, width);

			c[0] = input[k + 4];

			k += width;

			c[1] = input[k + 2];
			c[2] = input[k + 3];
			c[3] = input[k + 4];
			c[4] = input[k + 5];
			c[5] = input[k + 6];

			k += width;

			c[6] = input[k + 1];
			c[7] = input[k + 2];
			c[8] = input[k + 3];
			c[9] = input[k + 4];
			c[10] = input[k + 5];
			c[11] = input[k + 6];
			c[12] = input[k + 7];

			k += width;

			c[13] = input[k + 1];
			c[14] = input[k + 2];
			c[15] = input[k + 3];
			c[16] = input[k + 4];
			c[17] = input[k + 5];
			c[18] = input[k + 6];
			c[19] = input[k + 7];

			k += width;

			c[20] = input[k];
			c[21] = input[k + 1];
			c[22] = input[k + 2];
			c[23] = input[k + 3];
			c[24] = input[k + 4];
			c[25] = input[k + 5];
			c[26] = input[k + 6];
			c[27] = input[k + 7];
			c[28] = input[k + 8];

			k += width;

			c[29] = input[k + 1];
			c[30] = input[k + 2];
			c[31] = input[k + 3];
			c[32] = input[k + 4];
			c[33] = input[k + 5];
			c[34] = input[k + 6];
			c[35] = input[k + 7];

			k += width;

			c[36] = input[k + 1];
			c[37] = input[k + 2];
			c[38] = input[k + 3];
			c[39] = input[k + 4];
			c[40] = input[k + 5];
			c[41] = input[k + 6];
			c[42] = input[k + 7];

			k += width;

			c[43] = input[k + 2];
			c[44] = input[k + 3];
			c[45] = input[k + 4];
			c[46] = input[k + 5];
			c[47] = input[k + 6];

			k += width;

			c[48] = input[k + 4];

			h = c[0];

			for(k = 1; k < 49; k++)
				if(c[k] > h) h = c[k];

			dilated[COORD(i, j, width)] = h;
		}
	}

	return dilated;
}

real *PT_Dilate5(int *mask, int width, int height, real *dilated, real *input) {
	int i, j, k, l, x, y;
	real c[121], h;

	// obere kante
	for(i = 0; i < 5; i++) {
		for(j = 0; j < width; j++) {

			h = input[COORD(i, j, width)];

			for(k = -5; k <= 5; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -5; l <= 5; l++) {
					if(mask[COORD(k + 5, l + 5, 11)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	// untere kante
	for(i = (height - 5); i < height; i++) {
		for(j = 0; j < width; j++) {

			h = input[COORD(i, j, width)];

			for(k = -5; k <= 5; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -5; l <= 5; l++) {
					if(mask[COORD(k + 5, l + 5, 11)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	// linke seite
	for(i = 5; i < (height - 5); i++) {
		for(j = 0; j < 5; j++) {

			h = input[COORD(i, j, width)];

			for(k = -5; k <= 5; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -5; l <= 5; l++) {
					if(mask[COORD(k + 5, l + 5, 11)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	// rechte seite
	for(i = 5; i < (height - 5); i++) {
		for(j = (width - 5); j < width; j++) {

			h = input[COORD(i, j, width)];

			for(k = -5; k <= 5; k++) {
				if((i + k) < 0 || (i + k) >= height)
					//x = i;
					continue;
				else
					x = i + k;

				for(l = -5; l <= 5; l++) {
					if(mask[COORD(k + 5, l + 5, 11)] == 0)
						continue;

					if((j + l) < 0 || (j + l) >= width)
						//y = j;
						continue;
					else
						y = j + l;

					if(input[COORD(x, y, width)] > h)
						h = input[COORD(x, y, width)];
				}
			}
			dilated[COORD(i, j, width)] = h;
		}
	}

	for(i = 5; i < (height - 5); i++) {
		for(j = 5; j < (width - 5); j++) {

			k = COORD(i - 5, j - 5, width);

			for(l = 0; l < 11; l++) {
				c[COORD(0, l, 11)] = input[k] * mask[COORD(0, l, 11)];
				c[COORD(1, l, 11)] = input[k + 1] * mask[COORD(1, l, 11)];
				c[COORD(2, l, 11)] = input[k + 2] * mask[COORD(2, l, 11)];
				c[COORD(3, l, 11)] = input[k + 3] * mask[COORD(3, l, 11)];
				c[COORD(4, l, 11)] = input[k + 4] * mask[COORD(4, l, 11)];
				c[COORD(5, l, 11)] = input[k + 5] * mask[COORD(5, l, 11)];
				c[COORD(6, l, 11)] = input[k + 6] * mask[COORD(6, l, 11)];
				c[COORD(7, l, 11)] = input[k + 7] * mask[COORD(7, l, 11)];
				c[COORD(8, l, 11)] = input[k + 8] * mask[COORD(8, l, 11)];
				c[COORD(9, l, 11)] = input[k + 9] * mask[COORD(9, l, 11)];
				c[COORD(10, l, 11)] = input[k + 10] * mask[COORD(10, l, 11)];

				k += width;
			}

			h = c[0];

			for(k = 1; k < 121; k++)
				if(c[k] > h) h = c[k];

			dilated[COORD(i, j, width)] = h;
		}
	}

	return dilated;
}
