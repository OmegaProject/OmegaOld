#ifndef _SING_H_
#define _SING_H_

#ifndef TWO_PI
#define		TWO_PI	((real)2.0 * M_PI)
#endif
#define		MAXF  23
#define		MAXP  209

void radix_2(real *a, real *b);
void radix_4(int isn, real *a, real *b);
void fac_des(long n);
void permute(long ntot, long n, real *a, real *b);
void radix_3(real *a, real *b);
void radix_5(real *a, real *b);
void fac_imp(real *a, real *b);
void sing(real *a, real *b, long ntot, long n, long nspan, int isn);
void realtr(real *a, real *b, long half_length, int isn);

#endif		// _SING_H_