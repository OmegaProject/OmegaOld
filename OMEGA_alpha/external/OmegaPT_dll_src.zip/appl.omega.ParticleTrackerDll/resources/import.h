#ifndef _IMPORT_H_
#define _IMPORT_H_

#include "tracker.h"

int IMPORT_TIFFCheck(const char *filename);
int IMPORT_TIFFCheckAndGetFields(const char *filename, PTSequenceValues *sequenceValues, int color);
int	IMPORT_TIFFRead(const char *filename, PTFrame *ptFrame, int *originalImage, PTSequenceValues *sequenceValues, int color);

#endif	// _IMPORT_H_
