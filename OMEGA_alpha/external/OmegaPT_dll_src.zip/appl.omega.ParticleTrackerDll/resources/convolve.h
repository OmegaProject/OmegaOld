#ifndef _CONVOLVE_H_
#define _CONVOLVE_H_

#include "fft.h"

real *PT_ConvolveGeneric(real *kernel, int kernel_width, int width, int height, int radius, real *filtered, real *input);
real *PT_Convolve1(real *kernel, int width, int height, real *filtered, real *input);
real *PT_Convolve2(real *kernel, int width, int height, real *filtered, real *input);
real *PT_Convolve3(real *kernel, int width, int height, real *filtered, real *input);
real *PT_Convolve4(real *kernel, int width, int height, real *filtered, real *input);
real *PT_Convolve5(real *kernel, int width, int height, real *filtered, real *input);
real *PT_ConvolveFFT(FFT *fft, int width, int height, int radius, real *filtered, real *input);

int PT_InitFFT(FFT *fft, real *kernel, int kernel_width, int width, int height, int radius);

#endif	// _CONVOLVE_H_
