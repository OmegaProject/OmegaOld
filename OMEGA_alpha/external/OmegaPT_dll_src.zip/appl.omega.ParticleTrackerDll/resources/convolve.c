/*
 * Convolution subroutines
 *
 * Ingo Oppermann, 18.7.2003
 * Institute of Computational Science, Swiss Federal
 * Institute of Technology (ETH) Zurich. 
 * E-mail: oingo@student.ethz.ch
 *
 */

#include <stdio.h>
#ifdef _WIN32	// For the Sleep(...) function
#include <windows.h>
#endif
#include "tracker.h"
#include "convolve.h"
#include "sing.h"

#include "MemoryManager.h"

// The FFT routine is based on global variables. Unfortunately
// threads share the same global variables.
// A semaphore is needed to prevent two or more threads using the
// FFT routine at the same time (with fork() (i.e. under UNIX) this
// has no effect)

int FFT_InUse = 0;

/*
 * This file contains the function for convolving an image
 * with an given kernel.
 *
 * PT_ConvolveGeneric is a generic convolution useable with any
 * sizes of the image or kernel.
 * There are optimized functions for the kernel radius from 1 to 5
 * The optimized functions are named accordingly
 * PT_Convolve1, PT_Convolve2, PT_Convolve3, PT_Convolve4 and
 * PT_Convolve5. Besides that there is a PT_ConvolveFFT and
 * PT_InitFFT
 *
 * INPUT:	PTSequence*	The sequence containing the kernel
 *		real*		The resulting image
 *		real*		The image to be convolved
 *
 * OUTPUT:	real*		The resulting image
 *
 * USES:	-
 *
 */

real *PT_ConvolveGeneric(real *kernel, int kernel_width, int width, int height, int radius, real *filtered, real *input) {
	int i, j, k, l, m, x, y;
	real c;
	
	// upper bound and lower bound
	for(j = 0; j < width; j++) {

		// upper bound
		for(i = 0; i < radius; i++) {

			c = 0.0;

			for(k = -radius; k <= radius; k++) {
				if((i + k) < 0)
					x = i;
				else
					x = i + k;

				for(l = -radius; l <= radius; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + radius, l + radius, kernel_width)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}

		// lower bound
		for(i = (height - radius); i < height; i++) {

			c = 0.0;

			for(k = -radius; k <= radius; k++) {
				if((i + k) >= height)
					x = i;
				else
					x = i + k;

				for(l = -radius; l <= radius; l++) {
					if((j+ l) < 0 || (j + l) >= width)
						y = j;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + radius, l + radius, kernel_width)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	// left bound and right bound
	for(i = radius; i < (height - radius); i++) {

		// left bound
		for(j = 0; j < radius; j++) {

			c = 0.0;

			for(k = -radius; k <= radius; k++) {
				x = i + k;

				for(l = -radius; l <= radius; l++) {
					if((j + l) < 0)
						y = j;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + radius, l + radius, kernel_width)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}

		// right bound
		for(j = (width - radius); j < width; j++) {

			c = 0.0;

			for(k = -radius; k <= radius; k++) {
				x = i + k;

				for(l = -radius; l <= radius; l++) {
					if((j + l) >= width)
						y = j;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + radius, l + radius, kernel_width)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	for(i = radius; i < (height - radius); i++) {
		for(j = radius; j < (width - radius); j++) {

			c = 0.0;
			k = COORD(i - radius, j - radius, width);

			for(l = 0; l < kernel_width; l++) {
				for(m = 0; m < kernel_width; m++) {
					c += input[k + m] * kernel[COORD(l, m, kernel_width)];
				}
				k += width;
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	return filtered;
}

real *PT_Convolve1(real *kernel, int width, int height, real *filtered, real *input) {
	int i, j, k, l, x, y;
	real c;
	real k0, k1, k2, k3, k4, k5, k6, k7, k8;

	k0 =  kernel[0];
	k1 =  kernel[1];
	k2 =  kernel[2];
	k3 =  kernel[3];
	k4 =  kernel[4];
	k5 =  kernel[5];
	k6 =  kernel[6];
	k7 =  kernel[7];
	k8 =  kernel[8];
	
	// obere kante
	for(i = 0; i < 1; i++) {
		for(j = 0; j < width; j++) {

			c = 0.0;

			for(k = -1; k <= 1; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -1; l <= 1; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 1, l + 1, 3)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	// untere kante
	for(i = (height - 1); i < height; i++) {
		for(j = 0; j < width; j++) {

			c = 0.0;

			for(k = -1; k <= 1; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -1; l <= 1; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 1, l + 1, 3)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	// linke seite
	for(i = 1; i < (height - 1); i++) {
		for(j = 0; j < 1; j++) {

			c = 0.0;

			for(k = -1; k <= 1; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -1; l <= 1; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 1, l + 1, 3)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	// rechte seite
	for(i = 1; i < (height - 1); i++) {
		for(j = (width - 1); j < width; j++) {

			c = 0.0;

			for(k = -1; k <= 1; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -1; l <= 1; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 1, l + 1, 3)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	for(i = 1; i < (height - 1); i++) {
		for(j = 1; j < (width - 1); j++) {

			k = COORD(i - 1, j - 1, width);

			c = input[k] * k0;
			c += input[k + 1] * k1;
			c += input[k + 2] * k2;

			k += width;

			c += input[k] * k3;
			c += input[k + 1] * k4;
			c += input[k + 2] * k5;

			k += width;

			c += input[k] * k6;
			c += input[k + 1] * k7;
			c += input[k + 2] * k8;

			filtered[COORD(i, j, width)] = c;
		}
	}

	return filtered;
}

real *PT_Convolve2(real *kernel, int width, int height, real *filtered, real *input) {
	int i, j, k, l, x, y;
	real c;
	real k0, k1, k2, k3, k4, k5, k6, k7, k8, k9;
	real k10, k11, k12, k13, k14, k15, k16, k17, k18, k19;
	real k20, k21, k22, k23, k24;

	k0 =  kernel[0];
	k1 =  kernel[1];
	k2 =  kernel[2];
	k3 =  kernel[3];
	k4 =  kernel[4];
	k5 =  kernel[5];
	k6 =  kernel[6];
	k7 =  kernel[7];
	k8 =  kernel[8];
	k9 =  kernel[9];
	k10 =  kernel[10];
	k11 =  kernel[11];
	k12 =  kernel[12];
	k13 =  kernel[13];
	k14 =  kernel[14];
	k15 =  kernel[15];
	k16 =  kernel[16];
	k17 =  kernel[17];
	k18 =  kernel[18];
	k19 =  kernel[19];
	k20 =  kernel[20];
	k21 =  kernel[21];
	k22 =  kernel[22];
	k23 =  kernel[23];
	k24 =  kernel[24];
	
	// obere kante
	for(i = 0; i < 2; i++) {
		for(j = 0; j < width; j++) {

			c = 0.0;

			for(k = -2; k <= 2; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -2; l <= 2; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 2, l + 2, 5)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	// untere kante
	for(i = (height - 2); i < height; i++) {
		for(j = 0; j < width; j++) {

			c = 0.0;

			for(k = -2; k <= 2; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -2; l <= 2; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 2, l + 2, 5)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	// linke seite
	for(i = 2; i < (height - 2); i++) {
		for(j = 0; j < 2; j++) {

			c = 0.0;

			for(k = -2; k <= 2; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -2; l <= 2; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 2, l + 2, 5)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	// rechte seite
	for(i = 2; i < (height - 2); i++) {
		for(j = (width - 2); j < width; j++) {

			c = 0.0;

			for(k = -2; k <= 2; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -2; l <= 2; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 2, l + 2, 5)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	for(i = 2; i < (height - 2); i++) {
		for(j = 2; j < (width - 2); j++) {

			k = COORD(i - 2, j - 2, width);

			c = input[k] * k0;
			c += input[k + 1] * k1;
			c += input[k + 2] * k2;
			c += input[k + 3] * k3;
			c += input[k + 4] * k4;

			k += width;

			c += input[k] * k5;
			c += input[k + 1] * k6;
			c += input[k + 2] * k7;
			c += input[k + 3] * k8;
			c += input[k + 4] * k9;

			k += width;

			c += input[k] * k10;
			c += input[k + 1] * k11;
			c += input[k + 2] * k12;
			c += input[k + 3] * k13;
			c += input[k + 4] * k14;

			k += width;

			c += input[k] * k15;
			c += input[k + 1] * k16;
			c += input[k + 2] * k17;
			c += input[k + 3] * k18;
			c += input[k + 4] * k19;

			k += width;

			c += input[k] * k20;
			c += input[k + 1] * k21;
			c += input[k + 2] * k22;
			c += input[k + 3] * k23;
			c += input[k + 4] * k24;

			filtered[COORD(i, j, width)] = c;
		}
	}

	return filtered;
}

real *PT_Convolve3(real *kernel, int width, int height, real *filtered, real *input) {
	int i, j, k, l, x, y;
	real c;
	real k0, k1, k2, k3, k4, k5, k6, k7, k8, k9;
	real k10, k11, k12, k13, k14, k15, k16, k17, k18, k19;
	real k20, k21, k22, k23, k24, k25, k26, k27, k28, k29;
	real k30, k31, k32, k33, k34, k35, k36, k37, k38, k39;
	real k40, k41, k42, k43, k44, k45, k46, k47, k48;

	k0 =  kernel[0];
	k1 =  kernel[1];
	k2 =  kernel[2];
	k3 =  kernel[3];
	k4 =  kernel[4];
	k5 =  kernel[5];
	k6 =  kernel[6];
	k7 =  kernel[7];
	k8 =  kernel[8];
	k9 =  kernel[9];
	k10 =  kernel[10];
	k11 =  kernel[11];
	k12 =  kernel[12];
	k13 =  kernel[13];
	k14 =  kernel[14];
	k15 =  kernel[15];
	k16 =  kernel[16];
	k17 =  kernel[17];
	k18 =  kernel[18];
	k19 =  kernel[19];
	k20 =  kernel[20];
	k21 =  kernel[21];
	k22 =  kernel[22];
	k23 =  kernel[23];
	k24 =  kernel[24];
	k25 =  kernel[25];
	k26 =  kernel[26];
	k27 =  kernel[27];
	k28 =  kernel[28];
	k29 =  kernel[29];
	k30 =  kernel[30];
	k31 =  kernel[31];
	k32 =  kernel[32];
	k33 =  kernel[33];
	k34 =  kernel[34];
	k35 =  kernel[35];
	k36 =  kernel[36];
	k37 =  kernel[37];
	k38 =  kernel[38];
	k39 =  kernel[39];
	k40 =  kernel[40];
	k41 =  kernel[41];
	k42 =  kernel[42];
	k43 =  kernel[43];
	k44 =  kernel[44];
	k45 =  kernel[45];
	k46 =  kernel[46];
	k47 =  kernel[47];
	k48 =  kernel[48];
	
	// obere kante
	for(i = 0; i < 3; i++) {
		for(j = 0; j < width; j++) {

			c = 0.0;

			for(k = -3; k <= 3; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -3; l <= 3; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 3, l + 3, 7)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	// untere kante
	for(i = (height - 3); i < height; i++) {
		for(j = 0; j < width; j++) {

			c = 0.0;

			for(k = -3; k <= 3; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -3; l <= 3; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 3, l + 3, 7)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	// linke seite
	for(i = 3; i < (height - 3); i++) {
		for(j = 0; j < 3; j++) {

			c = 0.0;

			for(k = -3; k <= 3; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -3; l <= 3; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 3, l + 3, 7)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	// rechte seite
	for(i = 3; i < (height - 3); i++) {
		for(j = (width - 3); j < width; j++) {

			c = 0.0;

			for(k = -3; k <= 3; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -3; l <= 3; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 3, l + 3, 7)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	for(i = 3; i < (height - 3); i++) {
		for(j = 3; j < (width - 3); j++) {

			k = COORD(i - 3, j - 3, width);

			c = input[k] * k0;
			c += input[k + 1] * k1;
			c += input[k + 2] * k2;
			c += input[k + 3] * k3;
			c += input[k + 4] * k4;
			c += input[k + 5] * k5;
			c += input[k + 6] * k6;

			k += width;

			c += input[k] * k7;
			c += input[k + 1] * k8;
			c += input[k + 2] * k9;
			c += input[k + 3] * k10;
			c += input[k + 4] * k11;
			c += input[k + 5] * k12;
			c += input[k + 6] * k13;

			k += width;

			c += input[k] * k14;
			c += input[k + 1] * k15;
			c += input[k + 2] * k16;
			c += input[k + 3] * k17;
			c += input[k + 4] * k18;
			c += input[k + 5] * k19;
			c += input[k + 6] * k20;

			k += width;

			c += input[k] * k21;
			c += input[k + 1] * k22;
			c += input[k + 2] * k23;
			c += input[k + 3] * k24;
			c += input[k + 4] * k25;
			c += input[k + 5] * k26;
			c += input[k + 6] * k27;

			k += width;

			c += input[k] * k28;
			c += input[k + 1] * k29;
			c += input[k + 2] * k30;
			c += input[k + 3] * k31;
			c += input[k + 4] * k32;
			c += input[k + 5] * k33;
			c += input[k + 6] * k34;

			k += width;

			c += input[k] * k35;
			c += input[k + 1] * k36;
			c += input[k + 2] * k37;
			c += input[k + 3] * k38;
			c += input[k + 4] * k39;
			c += input[k + 5] * k40;
			c += input[k + 6] * k41;

			k += width;

			c += input[k] * k42;
			c += input[k + 1] * k43;
			c += input[k + 2] * k44;
			c += input[k + 3] * k45;
			c += input[k + 4] * k46;
			c += input[k + 5] * k47;
			c += input[k + 6] * k48;

			filtered[COORD(i, j, width)] = c;
		}
	}

	return filtered;
}

real *PT_Convolve4(real *kernel, int width, int height, real *filtered, real *input) {
	int i, j, k, l, x, y;
	real c;
	real k0, k1, k2, k3, k4, k5, k6, k7, k8, k9;
	real k10, k11, k12, k13, k14, k15, k16, k17, k18, k19;
	real k20, k21, k22, k23, k24, k25, k26, k27, k28, k29;
	real k30, k31, k32, k33, k34, k35, k36, k37, k38, k39;
	real k40, k41, k42, k43, k44, k45, k46, k47, k48, k49;
	real k50, k51, k52, k53, k54, k55, k56, k57, k58, k59;
	real k60, k61, k62, k63, k64, k65, k66, k67, k68, k69;
	real k70, k71, k72, k73, k74, k75, k76, k77, k78, k79;
	real k80;

	k0 =  kernel[0];
	k1 =  kernel[1];
	k2 =  kernel[2];
	k3 =  kernel[3];
	k4 =  kernel[4];
	k5 =  kernel[5];
	k6 =  kernel[6];
	k7 =  kernel[7];
	k8 =  kernel[8];
	k9 =  kernel[9];
	k10 =  kernel[10];
	k11 =  kernel[11];
	k12 =  kernel[12];
	k13 =  kernel[13];
	k14 =  kernel[14];
	k15 =  kernel[15];
	k16 =  kernel[16];
	k17 =  kernel[17];
	k18 =  kernel[18];
	k19 =  kernel[19];
	k20 =  kernel[20];
	k21 =  kernel[21];
	k22 =  kernel[22];
	k23 =  kernel[23];
	k24 =  kernel[24];
	k25 =  kernel[25];
	k26 =  kernel[26];
	k27 =  kernel[27];
	k28 =  kernel[28];
	k29 =  kernel[29];
	k30 =  kernel[30];
	k31 =  kernel[31];
	k32 =  kernel[32];
	k33 =  kernel[33];
	k34 =  kernel[34];
	k35 =  kernel[35];
	k36 =  kernel[36];
	k37 =  kernel[37];
	k38 =  kernel[38];
	k39 =  kernel[39];
	k40 =  kernel[40];
	k41 =  kernel[41];
	k42 =  kernel[42];
	k43 =  kernel[43];
	k44 =  kernel[44];
	k45 =  kernel[45];
	k46 =  kernel[46];
	k47 =  kernel[47];
	k48 =  kernel[48];
	k49 =  kernel[49];
	k50 =  kernel[50];
	k51 =  kernel[51];
	k52 =  kernel[52];
	k53 =  kernel[53];
	k54 =  kernel[54];
	k55 =  kernel[55];
	k56 =  kernel[56];
	k57 =  kernel[57];
	k58 =  kernel[58];
	k59 =  kernel[59];
	k60 =  kernel[60];
	k61 =  kernel[61];
	k62 =  kernel[62];
	k63 =  kernel[63];
	k64 =  kernel[64];
	k65 =  kernel[65];
	k66 =  kernel[66];
	k67 =  kernel[67];
	k68 =  kernel[68];
	k69 =  kernel[69];
	k70 =  kernel[70];
	k71 =  kernel[71];
	k72 =  kernel[72];
	k73 =  kernel[73];
	k74 =  kernel[74];
	k75 =  kernel[75];
	k76 =  kernel[76];
	k77 =  kernel[77];
	k78 =  kernel[78];
	k79 =  kernel[79];
	k80 =  kernel[80];
	
	// obere kante
	for(i = 0; i < 4; i++) {
		for(j = 0; j < width; j++) {

			c = 0.0;

			for(k = -4; k <= 4; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -4; l <= 4; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 4, l + 4, 9)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	// untere kante
	for(i = (height - 4); i < height; i++) {
		for(j = 0; j < width; j++) {

			c = 0.0;

			for(k = -4; k <= 4; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -4; l <= 4; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 4, l + 4, 9)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	// linke seite
	for(i = 4; i < (height - 4); i++) {
		for(j = 0; j < 4; j++) {

			c = 0.0;

			for(k = -4; k <= 4; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -4; l <= 4; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 4, l + 4, 9)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	// rechte seite
	for(i = 4; i < (height - 4); i++) {
		for(j = (width - 4); j < width; j++) {

			c = 0.0;

			for(k = -4; k <= 4; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -4; l <= 4; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 4, l + 4, 9)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	for(i = 4; i < (height - 4); i++) {
		for(j = 4; j < (width - 4); j++) {

			k = COORD(i - 4, j - 4, width);

			c = input[k] * k0;
			c += input[k + 1] * k1;
			c += input[k + 2] * k2;
			c += input[k + 3] * k3;
			c += input[k + 4] * k4;
			c += input[k + 5] * k5;
			c += input[k + 6] * k6;
			c += input[k + 7] * k7;
			c += input[k + 8] * k8;

			k += width;

			c += input[k] * k9;
			c += input[k + 1] * k10;
			c += input[k + 2] * k11;
			c += input[k + 3] * k12;
			c += input[k + 4] * k13;
			c += input[k + 5] * k14;
			c += input[k + 6] * k15;
			c += input[k + 7] * k16;
			c += input[k + 8] * k17;

			k += width;

			c += input[k] * k18;
			c += input[k + 1] * k19;
			c += input[k + 2] * k20;
			c += input[k + 3] * k21;
			c += input[k + 4] * k22;
			c += input[k + 5] * k23;
			c += input[k + 6] * k24;
			c += input[k + 7] * k25;
			c += input[k + 8] * k26;

			k += width;

			c += input[k] * k27;
			c += input[k + 1] * k28;
			c += input[k + 2] * k29;
			c += input[k + 3] * k30;
			c += input[k + 4] * k31;
			c += input[k + 5] * k32;
			c += input[k + 6] * k33;
			c += input[k + 7] * k34;
			c += input[k + 8] * k35;

			k += width;

			c += input[k] * k36;
			c += input[k + 1] * k37;
			c += input[k + 2] * k38;
			c += input[k + 3] * k39;
			c += input[k + 4] * k40;
			c += input[k + 5] * k41;
			c += input[k + 6] * k42;
			c += input[k + 7] * k43;
			c += input[k + 8] * k44;

			k += width;

			c += input[k] * k45;
			c += input[k + 1] * k46;
			c += input[k + 2] * k47;
			c += input[k + 3] * k48;
			c += input[k + 4] * k49;
			c += input[k + 5] * k50;
			c += input[k + 6] * k51;
			c += input[k + 7] * k52;
			c += input[k + 8] * k53;

			k += width;

			c += input[k] * k54;
			c += input[k + 1] * k55;
			c += input[k + 2] * k56;
			c += input[k + 3] * k57;
			c += input[k + 4] * k58;
			c += input[k + 5] * k59;
			c += input[k + 6] * k60;
			c += input[k + 7] * k61;
			c += input[k + 8] * k62;

			k += width;

			c += input[k] * k63;
			c += input[k + 1] * k64;
			c += input[k + 2] * k65;
			c += input[k + 3] * k66;
			c += input[k + 4] * k67;
			c += input[k + 5] * k68;
			c += input[k + 6] * k69;
			c += input[k + 7] * k70;
			c += input[k + 8] * k71;

			k += width;

			c += input[k] * k72;
			c += input[k + 1] * k73;
			c += input[k + 2] * k74;
			c += input[k + 3] * k75;
			c += input[k + 4] * k76;
			c += input[k + 5] * k77;
			c += input[k + 6] * k78;
			c += input[k + 7] * k79;
			c += input[k + 8] * k80;

			filtered[COORD(i, j, width)] = c;
		}
	}

	return filtered;
}

real *PT_Convolve5(real *kernel, int width, int height, real *filtered, real *input) {
	int i, j, k, l, x, y;
	real c, h[121];

	for(i = 0; i < 121; i++)
		h[i] = kernel[i];
	
	// obere kante
	for(i = 0; i < 5; i++) {
		for(j = 0; j < width; j++) {

			c = 0.0;

			for(k = -5; k <= 5; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -5; l <= 5; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 5, l + 5, 11)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	// untere kante
	for(i = (height - 5); i < height; i++) {
		for(j = 0; j < width; j++) {

			c = 0.0;

			for(k = -5; k <= 5; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -5; l <= 5; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 5, l + 5, 11)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	// linke seite
	for(i = 5; i < (height - 5); i++) {
		for(j = 0; j < 5; j++) {

			c = 0.0;

			for(k = -5; k <= 5; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -5; l <= 5; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 5, l + 5, 11)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	// rechte seite
	for(i = 5; i < (height - 5); i++) {
		for(j = (width - 5); j < width; j++) {

			c = 0.0;

			for(k = -5; k <= 5; k++) {
				if((i + k) < 0 || (i + k) >= height)
					x = i;
					//continue;
				else
					x = i + k;

				for(l = -5; l <= 5; l++) {
					if((j + l) < 0 || (j + l) >= width)
						y = j;
						//continue;
					else
						y = j + l;

					c += input[COORD(x, y, width)] * kernel[COORD(k + 5, l + 5, 11)];
				}
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	for(i = 5; i < (height - 5); i++) {
		for(j = 5; j < (width - 5); j++) {

			c = 0.0;
			k = COORD(i - 5, j - 5, width);

			for(l = 0; l < 11; l++) {
				c += input[k] * h[COORD(0, l, 11)];
				c += input[k + 1] * h[COORD(1, l, 11)];
				c += input[k + 2] * h[COORD(2, l, 11)];
				c += input[k + 3] * h[COORD(3, l, 11)];
				c += input[k + 4] * h[COORD(4, l, 11)];
				c += input[k + 5] * h[COORD(5, l, 11)];
				c += input[k + 6] * h[COORD(6, l, 11)];
				c += input[k + 7] * h[COORD(7, l, 11)];
				c += input[k + 8] * h[COORD(8, l, 11)];
				c += input[k + 9] * h[COORD(9, l, 11)];
				c += input[k + 10] * h[COORD(10, l, 11)];

				k += width;
			}
			filtered[COORD(i, j, width)] = c;
		}
	}

	return filtered;
}

real *PT_ConvolveFFT(FFT *fft, int width, int height, int radius, real *filtered, real *input) {
	int i, j;
	real *preal, *pimag;
	real re, im;
//	FFT *fft;
//
//	fft = &pts->fft;

	memset(fft->image_real, 0, fft->fft_height * fft->fft_width * sizeof(real));
	memset(fft->image_imag, 0, fft->fft_height * fft->fft_width * sizeof(real));

	// fill in the image data and repeat the last column and row to get
	// rid of the fft artifacts at the border of the convoluted image
	for(i = 0; i < height; i++) {
		for(j = 0; j < width; j++) {
			fft->image_real[i * fft->fft_width + j] = input[i * width + j];
		}
		for(j = width; j < fft->fft_width; j++) {
			fft->image_real[i * fft->fft_width + j] = input[i * width + (width - 1)];
		}
	}

	for(j = 0; j < fft->fft_width; j++) {
		for(i = height; i < fft->fft_height; i++) {
			fft->image_real[i * fft->fft_width + j] = fft->image_real[(height - 1) * fft->fft_width + j];
		}
	}

	// Let's see if FFT is available
	for(;;) {
		if(FFT_InUse == 0) {
			// Now it's my turn
			FFT_InUse = 1;
			break;
		}
		return NULL;
#ifdef _WIN32
		// Milliseconds
		Sleep(1000);
#else
		// Seconds
		sleep(1);
#endif
	}

	// transform into frequency domain
	for(i = 0; i < fft->fft_height; i++) {
		preal = &fft->image_real[i * fft->fft_width];
		pimag = &fft->image_imag[i * fft->fft_width];

		sing(preal, pimag, fft->fft_width, fft->fft_width, fft->fft_width, -1);
	}

	for(j = 0; j < fft->fft_width; j++) {
		for(i = 0; i < fft->fft_height; i++) {
			fft->temp_real[i] = fft->image_real[i * fft->fft_width + j];
			fft->temp_imag[i] = fft->image_imag[i * fft->fft_width + j];
		}

		sing(fft->temp_real, fft->temp_imag, fft->fft_height, fft->fft_height, fft->fft_height, -1);

		for(i = 0; i < fft->fft_height; i++) {
			fft->image_real[i * fft->fft_width + j] = fft->temp_real[i];
			fft->image_imag[i * fft->fft_width + j] = fft->temp_imag[i];
		}
	}

	// do the convolution
	for(i = 0; i < fft->fft_height; i++) {
		for(j = 0; j < fft->fft_width; j++) {
			re = fft->image_real[i * fft->fft_width + j] * fft->kernel_real[i * fft->fft_width + j] - fft->image_imag[i * fft->fft_width + j] * fft->kernel_imag[i * fft->fft_width + j];
			im = fft->image_real[i * fft->fft_width + j] * fft->kernel_imag[i * fft->fft_width + j] + fft->kernel_real[i * fft->fft_width + j] * fft->image_imag[i * fft->fft_width + j];
			fft->image_real[i * fft->fft_width + j] = re;
			fft->image_imag[i * fft->fft_width + j] = im;
		}
	}

	// transform back to spatial domain
	for(i = 0; i < fft->fft_height; i++) {
		preal = &fft->image_real[i * fft->fft_width];
		pimag = &fft->image_imag[i * fft->fft_width];

		sing(preal, pimag, fft->fft_width, fft->fft_width, fft->fft_width, 1);
	}

	for(j = 0; j < fft->fft_width; j++) {
		for(i = 0; i < fft->fft_height; i++) {
			fft->temp_real[i] = fft->image_real[i * fft->fft_width + j];
			fft->temp_imag[i] = fft->image_imag[i * fft->fft_width + j];
		}

		sing(fft->temp_real, fft->temp_imag, fft->fft_height, fft->fft_height, fft->fft_height, 1);

		for(i = 0; i < fft->fft_height; i++) {
			fft->image_real[i * fft->fft_width + j] = fft->temp_real[i];
			fft->image_imag[i * fft->fft_width + j] = fft->temp_imag[i];
		}
	}

	// release the FFT routine
	FFT_InUse = 0;

	// read out the transformed values
	// and scale them
	for(i = 0; i < height; i++) {
		for(j = 0; j < width; j++) {
			filtered[i * width + j] = fft->image_real[(i + radius) * fft->fft_width + (j + radius)] / (real)(fft->fft_height * fft->fft_width);
		}
	}

	return filtered;
}

int PT_InitFFT(FFT *fft, real *kernel, int kernel_width, int width, int height, int radius) {
	int convolution_width, convolution_height;
	int pow, i, j;
	real *preal, *pimag;
//	FFT *fft;
//
//	fft = &pts->fft;

	convolution_width = width + radius;
	convolution_height = height + radius;

	pow = 1;

	// find the final width and height for the FFT
	// it has to be a power of 2
//	pts->fft.fft_width = 0;
//	pts->fft.fft_height = 0;
	fft->fft_width = 0;
	fft->fft_height = 0;

	for(i = 1; i < 23; i++) {
		pow *= 2;
		if(pow >= convolution_width) {
			fft->fft_width = pow;
			break;
		}
	}

	pow = 1;

	for(i = 1; i < 23; i++) {
		pow *= 2;
		if(pow >= convolution_height) {
			fft->fft_height = pow;
			break;
		}
	}

	// allocate all the needed memory

	fft->temp_real = (real *) memorySupport_allocate(fft->fft_height * sizeof(real));
	fft->temp_imag = (real *) memorySupport_allocate(fft->fft_height * sizeof(real));

	if(fft->temp_real == NULL || fft->temp_imag == NULL)
		return 0;

	fft->image_real = (real *) memorySupport_allocate(fft->fft_height * fft->fft_width * sizeof(real));
	fft->image_imag = (real *) memorySupport_allocate(fft->fft_height * fft->fft_width * sizeof(real));

	if(fft->image_real == NULL || fft->image_imag == NULL)
		return 0;

	fft->kernel_real = (real *) memorySupport_allocate(fft->fft_height * fft->fft_width * sizeof(real));
	fft->kernel_imag = (real *) memorySupport_allocate(fft->fft_height * fft->fft_width * sizeof(real));

	if(fft->kernel_real == NULL || fft->kernel_imag == NULL)
		return 0;

	memset(fft->kernel_real, 0, fft->fft_height * fft->fft_width * sizeof(real));
	memset(fft->kernel_imag, 0, fft->fft_height * fft->fft_width * sizeof(real));

	// pre calculate the kernel. this won't change the whole calculation

	// Let's see if FFT is available
	for(;;) {
		if(FFT_InUse == 0) {
			// Now it's my turn
			FFT_InUse = 1;
			break;
		}
		return 0;
#ifdef _WIN32
		// Milliseconds
		Sleep(1000);
#else
		// Seconds
		sleep(1);
#endif
	}

	for(i = 0; i < kernel_width; i++) {
		for(j = 0; j < kernel_width; j++) {
			fft->kernel_real[i * fft->fft_width + j] = kernel[i * kernel_width + j];
		}
	}

	// transform into frequency domain
	for(i = 0; i < fft->fft_height; i++) {
		preal = &fft->kernel_real[i * fft->fft_width];
		pimag = &fft->kernel_imag[i * fft->fft_width];

		sing(preal, pimag, fft->fft_width, fft->fft_width, fft->fft_width, -1);
	}

	for(j = 0; j < fft->fft_width; j++) {
		for(i = 0; i < fft->fft_height; i++) {
			fft->temp_real[i] = fft->kernel_real[i * fft->fft_width + j];
			fft->temp_imag[i] = fft->kernel_imag[i * fft->fft_width + j];
		}

		sing(fft->temp_real, fft->temp_imag, fft->fft_height, fft->fft_height, fft->fft_height, -1);

		for(i = 0; i < fft->fft_height; i++) {
			fft->kernel_real[i * fft->fft_width + j] = fft->temp_real[i];
			fft->kernel_imag[i * fft->fft_width + j] = fft->temp_imag[i];
		}
	}

	FFT_InUse = 0;
	fft->isInit = 1;

	return 1;
}
