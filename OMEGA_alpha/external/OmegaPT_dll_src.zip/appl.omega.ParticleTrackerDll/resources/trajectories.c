#include "trajectories.h"


Particle *TRAJ_CreateNewParticle(int frameId, real x, real y, real m0, real m2, real score) {
	Particle* p = (Particle *) memorySupport_allocate(sizeof(Particle));

	p->frameId = frameId;
	p->x = x;
	p->y = y;
	p->m0 = m0;
	p->m2 = m2;
	p->score = score;

	return p;
}

ParticleNode *TRAJ_CreateNewParticleNode(int frameId, real x, real y, real m0, real m2, real score) {
	ParticleNode* pNode = (ParticleNode *) memorySupport_allocate(sizeof(ParticleNode));

	pNode->p = TRAJ_CreateNewParticle(frameId, x, y, m0, m2, score);
	pNode->next = NULL;

	return pNode;
}

Trajectory *TRAJ_CreateNewTrajectory(int id) {
	Trajectory* traj = (Trajectory *) memorySupport_allocate(sizeof(Trajectory));

	traj->id = id;
	traj->head = NULL;
	traj->tail = NULL;
	traj->numberOfParticle = 0;
	traj->nextParticleFrameId = -1;
	traj->nextParticleId = -1;

	return traj;
}

TrajectoryNode *TRAJ_CreateNewTrajectoryNode(int id) {
	TrajectoryNode* tNode = (TrajectoryNode *) memorySupport_allocate(sizeof(TrajectoryNode));

	tNode->traj = TRAJ_CreateNewTrajectory(id);
	tNode->next = NULL;

	return tNode;
}

TrajectoriesList *TRAJ_CreateNewTrajectoriesList() {
	TrajectoriesList *tl = (TrajectoriesList *) memorySupport_allocate(sizeof(TrajectoriesList));

	tl->head = NULL;
	tl->tail = NULL;
	tl->numberOfTrajectories = 0;
	tl->nott = 0;

	return tl;
}

void TRAJ_DestroyTrajectory(Trajectory *traj) {
	ParticleNode *pNode;

	while(traj->numberOfParticle > 0) {
		pNode = traj->head;
		traj->head = pNode->next;
		traj->numberOfParticle--;

		pNode->next = NULL;
		memorySupport_dispose(pNode->p);
		memorySupport_dispose(pNode);
	}

	memorySupport_dispose(traj);
}

void TRAJ_DestroyTrajectories(TrajectoriesList *tl) {
	TrajectoryNode *tNode;

	while(tl->numberOfTrajectories > 0) {
		tNode = tl->head;
		tl->head = tNode->next;
		tl->numberOfTrajectories--;

		tNode->next = NULL;
		TRAJ_DestroyTrajectory(tNode->traj);
		memorySupport_dispose(tNode);
	}

	memorySupport_dispose(tl);
}

int TRAJ_IsTrajFirstP(PTParticle p, int linkrange) {
	int l;
	for(l = 0; l < linkrange; l++) {
		if(p.next[l] != -1)
			return 1;
	}

	return 0;
}

int TRAJ_IsNextTargetFree(TrajectoriesList *tl, int nextFrameId, int nextParticleId) {
	TrajectoryNode *tNode;
	Trajectory *traj;

	tNode = tl->head;
	while(tNode != NULL) {
		traj = tNode->traj;

		if(traj->nextParticleFrameId == nextFrameId && traj->nextParticleId == nextParticleId)
			return 0;

		tNode = tNode->next;
	}

	return 1;
}

int TRAJ_IsTrajFirstPNew(TrajectoriesList *tl, int frameId, PTParticle p, int linkrange) {
	int nextFrameId, nextParticleId;
	int l;
	for(l = 0; l < linkrange; l++) {
		if(p.next[l] != -1) {
			nextFrameId = frameId+l+1;
			nextParticleId = p.next[l];
			if(TRAJ_IsNextTargetFree(tl, nextFrameId, nextParticleId))
				return 1;
		}
	}

	return 0;
}

Trajectory *TRAJ_IsTrajNextP(TrajectoriesList *tl, int frameId, int particleId) {
	TrajectoryNode *tNode;
	Trajectory *traj;

	tNode = tl->head;
	while(tNode != NULL) {
		traj = tNode->traj;

		if(traj->nextParticleFrameId == frameId && traj->nextParticleId == particleId)
			return traj;

		tNode = tNode->next;
	}

	return NULL;
}

void TRAJ_PrintTrajInSl(Trajectory *traj, StringList *sl) {
	Particle *p;
	ParticleNode *pNode = traj->head;

	addString(sl, "%% Trajectory id: %d\n", traj->id);
	while(pNode != NULL) {
		p = pNode->p;
		addString(sl, "%d %f %f %f %f %f\n", p->frameId, p->x, p->y, p->m0, p->m2, p->score);

		pNode = pNode->next;
	}

	addString(sl, "\n");
}

void TRAJ_SetTrajNext(Trajectory* traj, int frameId, int particleId) {
	traj->nextParticleFrameId = frameId;
	traj->nextParticleId = particleId;
}

Particle *TRAJ_AddPNodeToTraj(Trajectory *traj, int frameId, real x, real y, real m0, real m2, real score) {
	ParticleNode* pNode = TRAJ_CreateNewParticleNode(frameId, x, y, m0, m2, score);

	if(traj->numberOfParticle == 0) {
		traj->head = pNode;
		traj->tail = pNode;
		traj->numberOfParticle++;
	} else {
		traj->tail->next = pNode;
		traj->tail = pNode;
		traj->numberOfParticle++;
	}

	return pNode->p;
}

Trajectory *TRAJ_AddTrajNodeToTl(TrajectoriesList *tl, int id) {
	TrajectoryNode* tNode = TRAJ_CreateNewTrajectoryNode(id);

	if(tl->numberOfTrajectories == 0) {
		tl->head = tNode;
		tl->tail = tNode;
		tl->numberOfTrajectories++;
		tl->nott++;
	} else {
		tl->tail->next = tNode;
		tl->tail = tNode;
		tl->numberOfTrajectories++;
		tl->nott++;
	}

	return tNode->traj;
}

void TRAJ_CleanAndPrintAllTraj(TrajectoriesList *tl, StringList *sl) {
	TrajectoryNode *tNodePrev;
	TrajectoryNode *tNode;
	Trajectory *traj;

	tNodePrev = NULL;
	tNode = tl->head;

	while(tNode != NULL) {
		traj = tNode->traj;
		TRAJ_PrintTrajInSl(traj, sl);

		TRAJ_DestroyTrajectory(traj);
		tNode->traj = NULL;

		tl->numberOfTrajectories--;

		tl->head = tNode->next;

		tNode->next = NULL;
		memorySupport_dispose(tNode);

		tNode = tl->head;
	}
}

void TRAJ_CheckForUnusedTraj(TrajectoriesList *tl) {
	TrajectoryNode *tNodePrev;
	TrajectoryNode *tNode;
	Trajectory *traj;

	tNodePrev = NULL;
	tNode = tl->head;

	while(tNode != NULL) {
		traj = tNode->traj;
		if(traj->numberOfParticle <= 1) {
			if(tNode == tl->head) {
				TRAJ_DestroyTrajectory(traj);
				tNode->traj = NULL;

				tl->numberOfTrajectories--;
				tl->nott--;

				tl->head = tNode->next;

				tNode->next = NULL;
				memorySupport_dispose(tNode);

				tNode = tl->head;
			} else if(tNode == tl->tail) {
				TRAJ_DestroyTrajectory(traj);
				tNode->traj = NULL;

				tl->numberOfTrajectories--;
				tl->nott--;

				tl->tail = tNodePrev;
				tl->tail->next = NULL;

				memorySupport_dispose(tNode);
				tNode = NULL;
			} else {
				TRAJ_DestroyTrajectory(traj);
				tNode->traj = NULL;

				tl->numberOfTrajectories--;
				tl->nott--;

				tNodePrev->next = tNode->next;

				tNode->next = NULL;
				memorySupport_dispose(tNode);

				tNode = tNodePrev->next;
			}
		} else {
			tNodePrev = tNode;
			tNode = tNode->next;
		}
	}
}

void TRAJ_CleanAndPrintTrajNotActive(TrajectoriesList *tl, StringList *sl) {
	TrajectoryNode *tNodePrev;
	TrajectoryNode *tNode;
	Trajectory *traj;

	tNodePrev = NULL;
	tNode = tl->head;

	while(tNode != NULL) {
		traj = tNode->traj;
		if(traj->nextParticleFrameId == -1 && traj->nextParticleId == -1) {
			if(tNode == tl->head) {
				TRAJ_PrintTrajInSl(traj, sl);

				TRAJ_DestroyTrajectory(traj);
				tNode->traj = NULL;

				tl->numberOfTrajectories--;

				tl->head = tNode->next;

				tNode->next = NULL;
				memorySupport_dispose(tNode);

				tNode = tl->head;
			} else if(tNode == tl->tail) {
				TRAJ_PrintTrajInSl(traj, sl);

				TRAJ_DestroyTrajectory(traj);
				tNode->traj = NULL;

				tl->numberOfTrajectories--;

				tl->tail = tNodePrev;
				tl->tail->next = NULL;

				memorySupport_dispose(tNode);
				tNode = NULL;
			} else {
				TRAJ_PrintTrajInSl(traj, sl);

				TRAJ_DestroyTrajectory(traj);
				tNode->traj = NULL;

				tl->numberOfTrajectories--;

				tNodePrev->next = tNode->next;

				tNode->next = NULL;
				memorySupport_dispose(tNode);

				tNode = tNodePrev->next;
			}
		} else {
			tNodePrev = tNode;
			tNode = tNode->next;
		}
	}
}


