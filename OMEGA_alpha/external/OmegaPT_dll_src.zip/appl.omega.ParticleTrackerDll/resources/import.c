#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32	// For the Sleep(...) function
#include <windows.h>
#endif

#include "tiff/tiffio.h"
#include "tiff/tiffiop.h"

#include "import.h"
#include "tracker.h"

#include "MemoryManager.h"

int IMPORT_TIFFCheckAndGetFields(const char *filename, PTSequenceValues *sequenceValues, int color) {
	TIFF *tif;
	uint32 *image;
	int i, j, c;
	int height = 0, width = 0;
	real min = 0, max = 0;

	// Set the warning and error handler of the TIFF library to NULL
	_TIFFerrorHandler = NULL;
	_TIFFwarningHandler = NULL;

	tif = TIFFOpen(filename, "r");

	if(tif) {
		TIFFGetField(tif, TIFFTAG_IMAGEWIDTH, &width);
		TIFFGetField(tif, TIFFTAG_IMAGELENGTH, &height);

		image = (uint32 *)_TIFFmalloc(height * width * sizeof(uint32));

		TIFFReadRGBAImage(tif, width, height, image, 0);

		for(i = height - 1; i >= 0; i--) {
			for(j = 0; j < width; j++) {
				switch(color) {
				case 0: c = (TIFFGetR(image[i * width + j]) + TIFFGetG(image[i * width + j]) + TIFFGetB(image[i * width + j])) / 3;
				break;
				case 1: c = TIFFGetR(image[i * width + j]);
				break;
				case 2: c = TIFFGetG(image[i * width + j]);
				break;
				case 3: c = TIFFGetB(image[i * width + j]);
				break;
				}

				if((real)c < min)
					min = (real)c;
				else if((real)c > max)
					max = (real)c;
			}
		}

		_TIFFfree(image);
		TIFFClose(tif);

		if(sequenceValues->width == 0)
			sequenceValues->width = width;
		else if(sequenceValues->width != width)
			return -1;

		if(sequenceValues->height == 0)
			sequenceValues->height = height;
		else if(sequenceValues->height != height)
			return -1;

		if(sequenceValues->min > min)
			sequenceValues->min = min;

		if(sequenceValues->max < max)
			sequenceValues->max = max;

		return 1;
	}

	TIFFClose(tif);
	return 0;
}

int IMPORT_TIFFCheck(const char *filename) {
	TIFF *tif;

	// Set the warning and error handler of the TIFF library to NULL
	_TIFFerrorHandler = NULL;
	_TIFFwarningHandler = NULL;

	tif = TIFFOpen(filename, "r");

	if(tif) {
		TIFFClose(tif);
		return 1;
	}

	return 0;
}

int	IMPORT_TIFFRead(const char *filename, PTFrame *ptFrame, int *originalImage, PTSequenceValues *sequenceValues, int color) {
	//Added by AlexR to count the int position in the frame pointer contained in the PTFrame
	int counter;
	int tmpH = 0, tmpW = 0;
	real tmpMax = 0, tmpMin = 0;
	int i, j, c;
	uint32 *image;
	TIFF *tif;

	// Set the warning and error handler of the TIFF library to NULL
	_TIFFerrorHandler = NULL;
	_TIFFwarningHandler = NULL;

	if(color < 0)
		color = 0;
	else if(color > 3)
		color = 3;

	sprintf(ptFrame->name, "%s", filename);

	counter = 0;
	tif = TIFFOpen(filename, "r");
	if(tif) {
		TIFFGetField(tif, TIFFTAG_IMAGEWIDTH, &tmpW);
		TIFFGetField(tif, TIFFTAG_IMAGELENGTH, &tmpH);

		if(tmpW != sequenceValues->width) {
			TIFFClose(tif);
			return -1;
		}

		if(tmpH != sequenceValues->height) {
			TIFFClose(tif);
			return -2;
		}

		image = (uint32 *)_TIFFmalloc(sequenceValues->height * sequenceValues->width * sizeof(uint32));

		if(image == NULL) {
			TIFFClose(tif);
			return 0;
		}

		TIFFReadRGBAImage(tif, sequenceValues->width, sequenceValues->height, image, 0);

		for(i = sequenceValues->height - 1; i >= 0; i--) {
			for(j = 0; j < sequenceValues->width; j++) {
				switch(color) {
				case 0: c = (TIFFGetR(image[i * sequenceValues->width + j]) + TIFFGetG(image[i * sequenceValues->width + j]) + TIFFGetB(image[i * sequenceValues->width + j])) / 3;
				break;
				case 1: c = TIFFGetR(image[i * sequenceValues->width + j]);
				break;
				case 2: c = TIFFGetG(image[i * sequenceValues->width + j]);
				break;
				case 3: c = TIFFGetB(image[i * sequenceValues->width + j]);
				break;
				}

				originalImage[counter] = c;
				counter++;

				if((real)c < tmpMin)
					tmpMin = (real)c;
				else if((real)c > tmpMax)
					tmpMax = (real)c;
			}
		}

		_TIFFfree(image);

		if(sequenceValues->max < tmpMax) {
			TIFFClose(tif);
			return -3;
		}

		if(sequenceValues->min > tmpMin) {
			TIFFClose(tif);
			return -4;
		}
	}

	TIFFClose(tif);
	return 1;
}
