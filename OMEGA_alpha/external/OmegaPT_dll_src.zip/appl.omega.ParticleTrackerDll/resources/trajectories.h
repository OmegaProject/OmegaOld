#ifndef _TRAJECTORIES_H_
#define _TRAJECTORIES_H_

#include "MemoryManager.h"
#include "PlatformManager.h"

#include "stringlist.h"
#include "tracker.h"

typedef struct Particle{
	int frameId;
	real x, y;
	real m0, m2;
	real score;
}Particle;

typedef struct ParticleNode{
	Particle* p;
	struct ParticleNode* next;
}ParticleNode;

typedef struct Trajectory{
	int id;
	ParticleNode* head;
	ParticleNode* tail;
	int numberOfParticle;
	int nextParticleFrameId;
	int nextParticleId;
}Trajectory;

typedef struct TrajectoryNode{
	Trajectory* traj;
	struct TrajectoryNode* next;
}TrajectoryNode;

typedef struct TrajectoriesList{
	TrajectoryNode* head;
	TrajectoryNode* tail;
	int numberOfTrajectories;
	int nott;
}TrajectoriesList;

Particle *TRAJ_CreateNewParticle(int frameId, real x, real y, real m0, real m2, real score);
ParticleNode *TRAJ_CreateNewParticleNode(int frameId, real x, real y, real m0, real m2, real score);
Trajectory *TRAJ_CreateNewTrajectory(int id);
TrajectoryNode *TRAJ_CreateNewTrajectoryNode(int id);
TrajectoriesList *TRAJ_CreateNewTrajectoriesList();
void TRAJ_DestroyTrajectory(Trajectory *traj);
void TRAJ_DestroyTrajectories(TrajectoriesList *tl);
int TRAJ_IsTrajFirstP(PTParticle p, int linkrange);
Trajectory *TRAJ_IsTrajNextP(TrajectoriesList *tl, int frameId, int particleId);
void TRAJ_SetTrajNext(Trajectory* traj, int frameId, int particleId);
Particle *TRAJ_AddPNodeToTraj(Trajectory *traj, int frameId, real x, real y, real m0, real m2, real score);
Trajectory *TRAJ_AddTrajNodeToTl(TrajectoriesList *tl, int id);
void TRAJ_PrintTrajInSl(Trajectory *traj, StringList *sl);
void TRAJ_CleanAndPrintTrajNotActive(TrajectoriesList *tl, StringList *sl);
void TRAJ_CleanAndPrintAllTraj(TrajectoriesList *tl, StringList *sl);

int TRAJ_IsNextTargetFree(TrajectoriesList *tl, int nextFrameId, int nextParticleId);
int TRAJ_IsTrajFirstPNew(TrajectoriesList *tl, int frameId, PTParticle p, int linkrange);

void TRAJ_CheckForUnusedTraj(TrajectoriesList *tl);

#endif	// _TRAJECTORIES_H_
