/*
 * LibraryDataReader.c
 *
 *  Created on: 17-mar-2011
 *      Author: grossi
 */

#include "LibraryDataReader.h"

#include "PlatformManager.h"
#include "MemoryManager.h"
#include "ThreadManager.h"

#include "RunnerGround.h"

// Se tutto lo stato necessario per l'utilizzo dei due buffer viene messo come
// stato sul reader, quando le funzioni sono chiamate dall'esterno per aggiungere
// dei dati da processare, non si ha la referencza alla unit / impl e quindi non
// si pu� risalire ai buffers.
// Come alternativa alle global variables, si potrebbe racchiudere questo stato
// in una struct e tenere una referenza alla struct direttamente sul runner. Cos�
// facendo, anche se sono chiamate dall'esterno, il salto sullo stato dei buffers
// � possibile farlo(((.._shell*) runner)->inputBuffers)

// Input pool
image* inPoolHead;
image* inPoolTail;
unsigned int inPoolNumElements;

// Input data buffer
image* inDataHead;
image* inDataTail;
unsigned int inDataNumElements;
unsigned int inDataMaxSize;

// Image size
int imgWidth, imgHeight;

// Locks and condition
void* inPoolLock;
void* inDataBufferLock;
void* inDataBufferFullCondition;

/*
 * API
 */

/*
 * GetInputDataPtr function
 */
image* getInputDataPtr(void* runner) {
	DSPEElement* element = (DSPEElement*) ((ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) runner)->runnerDelegate;
	image* img = NULL;

	threadManager_lockSpin(element, inPoolLock);
	if (inPoolNumElements == 0) {
		threadManager_unlockSpin(element, inPoolLock);
		// Create a new image
		img = (image*) memoryManager_allocate(element, sizeof(image));
		img->imgData = (int*) memoryManager_allocateAndInit(element, imgWidth * imgHeight, sizeof(int));
	} else {
		// Retrieve an image from pool
		img = inPoolHead;
		inPoolHead = img->next;
		inPoolNumElements--;
		if (inPoolNumElements == 0)
			inPoolTail = NULL;
		threadManager_unlockSpin(element, inPoolLock);
	}
	img->next = NULL;
	return img;
}

/*
 * SetInputData function
 */
void setInputData(void* runner, image* inputData) {
	DSPEElement* element = (DSPEElement*) ((ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application_lib*) runner)->runnerDelegate;

	// Add data to process to data buffer
	inputData->next = NULL;
	threadManager_lockMutex(element, inDataBufferLock);
	// Wait conditional variable when the input buffer is full
	// REMARK: While loop to avoid spurious wake-ups
	while (inDataNumElements == inDataMaxSize)
		threadManager_waitCondition(element, inDataBufferFullCondition, inDataBufferLock);

	if (inDataNumElements == 0) {
		inDataHead = inputData;
		// Send InitEvent - Cannot be queued here since event queue is not
		// protected by lock => only 'scheduler' thread can queue events!
		memoryManager_addExternalEventToQueue((DSPEScheduler*) &((ParticleTrackerDllPTCoproc_3_PUSH_Dll_Application*) runner)->configuration, 0);
	}
	else
		inDataTail->next = inputData;

	inDataTail = inputData;
	inDataNumElements++;
	threadManager_unlockMutex(element, inDataBufferLock);
}

/*
 * CopyInputData function
 */
void copyInputData(image* dst, image* src) {
	memorySupport_copyBlock(dst->imgData, src->imgData, imgWidth * imgHeight * sizeof(int));
}

/*
 * PRIVATE FUNCTIONS - USED ONLY BY LIBRARY DATA READER
 */

/*
 * InitInputBuffers function
 */
void initInputBuffers(void* runner, int imgW, int imgH, int inDataMax) {
	DSPEElement* element = (DSPEElement*) ((DSPEElement*) runner)->application;

	// Init input pool
	inPoolHead = NULL;
	inPoolTail = NULL;
	inPoolNumElements = 0;

	// Init data buffer
	inDataHead = NULL;
	inDataTail = NULL;
	inDataNumElements = 0;

	imgWidth = imgW;
	imgHeight = imgH;
	inDataMaxSize = inDataMax;

	// Create locks and condition
	inPoolLock = threadManager_createSpin(element);

	inDataBufferFullCondition = threadManager_createCondition(element);
	inDataBufferLock = threadManager_createMutex(element);
}

/*
 * DisposeImage function
 */
static INLINE void disposeImage(image* img) {
	img->next = NULL;
	memorySupport_dispose(img->imgData);
	memorySupport_dispose(img);
}

/*
 * DisposeInputBuffers function
 */
void disposeInputBuffers(void* runner) {
	DSPEElement* element = (DSPEElement*) ((DSPEElement*) runner)->application;
	image* tmpImg = NULL;

	// FIXME Proteggerlo con lock?? Oppure � gi� tutto fermo e non serve??

	// Dispose data buffer
	while (inDataNumElements > 0) {
		tmpImg = inDataHead;
		inDataHead = tmpImg->next;
		inDataNumElements--;
		disposeImage(tmpImg);
	}

	// Dispose pool
	while (inPoolNumElements > 0) {
		tmpImg = inPoolHead;
		inPoolHead = tmpImg->next;
		inPoolNumElements--;
		disposeImage(tmpImg);
	}

	// Dispose locks and condition
	threadManager_destroyCondition(element, inDataBufferFullCondition);
	threadManager_deleteMutex(element, inDataBufferLock);

	threadManager_deleteSpin(element, inPoolLock);
}

/*
 * HasInputData function
 */
int hasInputData(void* runner) {
	DSPEElement* element = (DSPEElement*) ((DSPEElement*) runner)->application;
	int hasData = 0;
	threadManager_lockMutex(element, inDataBufferLock);
	hasData = inDataNumElements != 0;
	threadManager_unlockMutex(element, inDataBufferLock);
	return hasData;
}

/*
 * GetDataToProcess function
 */
image* getDataToProcess(void* runner) {
	DSPEElement* element = (DSPEElement*) ((DSPEElement*) runner)->application;
	image* tmpImg = NULL;

	threadManager_lockMutex(element, inDataBufferLock);
	if (inDataNumElements == 0) {
		// no data to process is available
		threadManager_unlockMutex(element, inDataBufferLock);
		return NULL;
	}

	// Retrieve data to process from input buffer
	tmpImg = inDataHead;
	inDataHead = tmpImg->next;
	inDataNumElements--;
	if (inDataNumElements == 0)
		inDataTail = NULL;

	// FIXME Rivedere la condizione - la conditional variable viene aspettata solo
	// quando il buffer � pieno e qualcuno cerca di aggiungere qualcosa.
	// Con questa condizione, si risveglia anche quando il buffer � pieno ma nessuno
	// aspetta la conditional variable perch� nessuno ha cercato di aggiungere
	// qualcosa al buffer pieno.
	if (inDataNumElements == inDataMaxSize - 1)
		// The input buffer was full, wake bufferFull conditional variable
		// to continue adding data to process
		threadManager_wakeCondition(element, inDataBufferFullCondition);

	threadManager_unlockMutex(element, inDataBufferLock);

	tmpImg->next = NULL;
	return tmpImg;
}

/*
 * ReleaseInputData function
 */
void releaseInputData(void* runner, image* inputData) {
	DSPEElement* element = (DSPEElement*) ((DSPEElement*) runner)->application;

	// Add input data to pool
	inputData->next = NULL;
	threadManager_lockSpin(element, inPoolLock);
	if (inPoolNumElements == 0)
		inPoolHead = inputData;
	else
		inPoolTail->next = inputData;

	inPoolTail = inputData;
	inPoolNumElements++;
	threadManager_unlockSpin(element, inPoolLock);
}
