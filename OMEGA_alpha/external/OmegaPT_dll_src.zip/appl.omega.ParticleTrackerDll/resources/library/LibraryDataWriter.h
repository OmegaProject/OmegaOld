/*
 * LibraryDataWriter.h
 *
 *  Created on: 17-mar-2011
 *      Author: grossi
 */

#ifndef LIBRARY_DATA_WRITER_H_
#define LIBRARY_DATA_WRITER_H_

#include "LibraryDataWriterAPI.h"

// PRIVATE FUNCTIONS - USED ONLY BY LIBRARY DATA WRITER

void initOutputBuffers(void* runner, int outDataMax);

void resetOutputBuffers(void* runner);

void disposeOutputBuffers(void* runner);

track* getOutputDataPtr(void* runner, int npoints);

int setOutputData(void* runner, track* outputData);

#endif /* LIBRARY_DATA_WRITER_H_ */
