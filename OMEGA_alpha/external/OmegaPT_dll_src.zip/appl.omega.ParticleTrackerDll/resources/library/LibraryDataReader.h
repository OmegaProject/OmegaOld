/*
 * LibraryDataReader.h
 *
 *  Created on: 17-mar-2011
 *      Author: grossi
 */

#ifndef LIBRARY_DATA_READER_H_
#define LIBRARY_DATA_READER_H_

#include "LibraryDataReaderAPI.h"

// PRIVATE FUNCTIONS - USED ONLY BY LIBRARY DATA READER

void initInputBuffers(void* runner, int imgW, int imgH, int inDataMax);

void disposeInputBuffers(void* runner);

int hasInputData(void* runner);

image* getDataToProcess(void* runner);

void releaseInputData(void* runner, image* inputData);

#endif /* LIBRARY_DATA_READER_H_ */
