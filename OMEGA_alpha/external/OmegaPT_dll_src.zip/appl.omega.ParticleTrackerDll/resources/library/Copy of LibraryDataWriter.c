/*
 * LibraryDataWriter.c
 *
 *  Created on: 17-mar-2011
 *      Author: grossi
 */

#include "LibraryDataWriter.h"

#include "PlatformManager.h"
#include "MemoryManager.h"
#include "ThreadManager.h"

// Se tutto lo stato necessario per l'utilizzo dei due buffer viene messo come
// stato sul writer, quando le funzioni sono chiamate dall'esterno per ottenere
// i dati processati, non si ha la referencza alla unit / impl e quindi non
// si pu� risalire ai buffers.
// Come alternativa alle global variables, si potrebbe racchiudere questo stato
// in una struct e tenere una referenza alla struct direttamente sul runner. Cos�
// facendo, anche se sono chiamate dall'esterno, il salto sullo stato dei buffers
// � possibile farlo(((.._shell*) runner)->outputBuffers)

// Output pool
track* outPoolHead;
track* outPoolTail;
unsigned int outPoolNumElements;

// Output data buffer
track* outDataHead;
track* outDataTail;
unsigned int outDataNumElements;
unsigned int outDataMaxSize;

// Locks
void* outPoolLock;
void* outDataBufferLock;

// Next event ID
unsigned int nextEvtID;

/*
 * API
 */

/*
 * HasOutputData function
 */
int hasOutputData(void* runner) {
	DSPEElement* element = (DSPEElement*) runner;
	int hasData = 0;
	threadManager_lockSpin(element, outDataBufferLock);
	hasData = outDataNumElements != 0;
	threadManager_unlockSpin(element, outDataBufferLock);
	return hasData;
}

/*
 * GetOutputData function
 */
track* getOutputData(void* runner) {
	DSPEElement* element = (DSPEElement*) runner;
	track* trk = NULL;

	threadManager_lockSpin(element, outDataBufferLock);
	if (outDataNumElements == 0) {
		// no processed data is available
		threadManager_unlockSpin(element, outDataBufferLock);
		return NULL;
	}

	// Retrieve processed data from output buffer
	trk = outDataHead;
	outDataHead = trk->next;
	outDataNumElements--;
	if (outDataNumElements == 0)
		outDataTail = NULL;

	if (outDataNumElements == outDataMaxSize - 1) {
		// The output buffer was full, set stop = 0 and send a next event
		// FIXME Manca stop = 0 e invio evento di next!!
	}

	threadManager_unlockSpin(element, outDataBufferLock);

	trk->next = NULL;
	return trk;
}

/*
 * ReleaseOutputData function
 */
void releaseOutputData(void* runner, track* outputData) {
	DSPEElement* element = (DSPEElement*) runner;

	// Add output data to pool
	outputData->next = NULL;
	threadManager_lockSpin(element, outPoolLock);
	if (outPoolNumElements == 0)
		outPoolHead = outputData;
	else
		outPoolTail->next = outputData;

	outPoolTail = outputData;
	outPoolNumElements++;
	threadManager_unlockSpin(element, outPoolLock);
}

/*
 * CopyOutputData function
 */
void copyOutputData(track* dst, track* src) {
	memorySupport_copyBlock(dst->frameNo, src->frameNo, src->npoints * sizeof(int));
	memorySupport_copyBlock(dst->x, src->x, src->npoints * sizeof(double));
	memorySupport_copyBlock(dst->y, src->y, src->npoints * sizeof(double));
}

/*
 * PRIVATE FUNCTIONS - USED ONLY BY LIBRARY DATA WRITER
 */

/*
 * InitOutputBuffers function
 */
void initOutputBuffers(void* runner, int outDataMax, unsigned int evtID) {
	DSPEElement* element = (DSPEElement*) runner;

	// Init output pool
	outPoolHead = NULL;
	outPoolTail = NULL;
	outPoolNumElements = 0;

	// Init data buffer
	outDataHead = NULL;
	outDataTail = NULL;
	outDataNumElements = 0;

	outDataMaxSize = outDataMax;
	nextEvtID = evtID;

	// Create locks
	outPoolLock = threadManager_createSpin(element);
	outDataBufferLock = threadManager_createSpin(element);
}

/*
 * DisposeTrack function
 */
static INLINE void disposeTrack(track* trk) {
	// FIXME Add disposal of missing fields (fileName, labels!)
	trk->next = NULL;
	memorySupport_dispose(trk->frameNo);
	memorySupport_dispose(trk->x);
	memorySupport_dispose(trk->y);
	memorySupport_dispose(trk);
}

/*
 * DisposeOutputBuffers function
 */
void disposeOutputBuffers(void* runner) {
	DSPEElement* element = (DSPEElement*) runner;
	track* tmpTrack = NULL;

	// FIXME Proteggerlo con lock?? Oppure � gi� tutto fermo e non serve??

	// Dispose data buffer
	while (outDataNumElements > 0) {
		tmpTrack = outDataHead;
		outDataHead = tmpTrack->next;
		outDataNumElements--;
		disposeTrack(tmpTrack);
	}

	// Dispose pool
	while (outPoolNumElements) {
		tmpTrack = outPoolHead;
		outPoolHead = tmpTrack->next;
		outPoolNumElements--;
		disposeTrack(tmpTrack);
	}

	// Dispose locks
	threadManager_deleteSpin(element, outDataBufferLock);
	threadManager_deleteSpin(element, outPoolLock);
}

/*
 * GetOutputDataPtr function
 */
track* getOutputDataPtr(void* runner, int npoints) {
	DSPEElement* element = (DSPEElement*) runner;
	track* trk = NULL;

	threadManager_lockSpin(element, outPoolLock);
	if (outPoolNumElements == 0) {
		threadManager_unlockSpin(element, outPoolLock);
		// Create a new track
		trk = (track*) memoryManager_allocate(element, sizeof(track));
		trk->frameNo = (int*) memoryManager_allocateAndInit(element, npoints, sizeof(int));
		trk->x = (double*) memoryManager_allocateAndInit(element, npoints, sizeof(double));
		trk->y = (double*) memoryManager_allocateAndInit(element, npoints, sizeof(double));
		trk->filename = NULL;
		trk->labels = NULL;
		trk->maxSize = npoints;
	} else {
		// Retrieve a track from pool
		trk = outPoolHead;
		outPoolHead = trk->next;
		outPoolNumElements--;
		if (outPoolNumElements == 0)
			outPoolTail = NULL;
		threadManager_unlockSpin(element, outPoolLock);

		// Check if array sizes are OK
		if (trk->maxSize < npoints) {
			// Realloc frameNo, x and y arrays
			// FIXME Realloc missing fields (label)
			trk->frameNo = (int*) memorySupport_realloc(trk->frameNo, npoints * sizeof(int));
			trk->x = (double*) memorySupport_realloc(trk->x, npoints * sizeof(double));
			trk->y = (double*) memorySupport_realloc(trk->y, npoints * sizeof(double));
			trk->maxSize = npoints;
		}
	}
	trk->next = NULL;
	trk->npoints = npoints;
	return trk;
}

/*
 * SetOutputData function
 * REMARK: Returns 1 if the output data buffer is full.
 */
int setOutputData(void* runner, track* outputData) {
	DSPEElement* element = (DSPEElement*) runner;
	int isFull = 0;

	// Add processed data to data buffer
	outputData->next = NULL;
	threadManager_lockSpin(element, outDataBufferLock);
	if (outDataNumElements == 0)
		outDataHead = outputData;
	else
		outDataTail->next = outputData;

	outDataTail = outputData;
	outDataNumElements++;
	isFull = outDataNumElements == outDataMaxSize;
	threadManager_unlockSpin(element, outDataBufferLock);

	return isFull;
}
