/*
 * LibraryDataReaderAPI.h
 *
 *  Created on: 17-mar-2011
 *      Author: grossi
 */

#ifndef LIBRARY_DATA_READER_API_H_
#define LIBRARY_DATA_READER_API_H_

typedef struct image image;

struct image {
	int* imgData;

	image* next;
};

/*
 * When building the DLL code, you should define DLL_BUILD so that
 * the variables/functions are exported correctly. When using the DLL,
 * do NOT define DLL_BUILD, and then the variables/functions will
 * be imported correctly.
 */
#define DLL_BUILD

# ifdef DLL_BUILD
#    define DLLPORT __declspec (dllexport)
#  else
#    define DLLPORT __declspec (dllimport)
#  endif

#ifdef __cplusplus
extern "C" {
#endif

DLLPORT image* getInputDataPtr(void* runner);

DLLPORT void setInputData(void* runner, image* inputData);

DLLPORT void copyInputData(image* dst, image* src);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* LIBRARY_DATA_READER_API_H_ */
