#include "debug.h"


void DEBUG_initFile(const char *fileName, const char *fileMode) {
	FILE *f;

	f = fopen(fileName, fileMode);

	fclose(f);
}

void DEBUG_printFrameId(const char *fileName, int id) {
	FILE *f;

	f = fopen(fileName, "a");

	fprintf(f, "Frame %d:\n", id);

	fclose(f);
}

void DEBUG_printLinkParticles(const char *fileName, PTFrame *ptFrame, int linkrange) {
	FILE *f;
	int j, k;

	f = fopen(fileName, "a");

	fprintf(f, "Frame %d:\n", ptFrame->id);
	for(j = 0; j < ptFrame->pl->number_of_particles; j++) {
		fprintf(f, "Particle %d (%f, %f):\n", j, ptFrame->pl->particle[j].x, ptFrame->pl->particle[j].y);
		for(k = 0; k < linkrange; k++) {
			fprintf(f, "\tlinked to particle %d in frame %d\n", ptFrame->pl->particle[j].next[k], ptFrame->id + k + 1);
		}
	}

	fclose(f);
}

void DEBUG_printParticles(char const *fileName, PTFrame *ptFrame) {
	FILE *f;
	int j;

	f = fopen(fileName, "a");

	fprintf(f, "After discrimination: \n");
	for(j = 0; j < ptFrame->pl->number_of_particles; j++)
		fprintf(f, "x: %f, y: %f\n", ptFrame->pl->particle[j].x, ptFrame->pl->particle[j].y);

	fclose(f);
}
