#ifndef _CONFIG_H_
#define _CONFIG_H_

// Define whether the particle tracker has to
// calculate in double precision or in single
// precision
#define DOUBLE_PRECISION
//#define SINGLE_PRECISION

#endif	// _CONFIG_H_
