#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#include "stringlist.h"

#include "MemoryManager.h"

StringList* initStringList() {
	StringList *temp;
	temp = (StringList *) memorySupport_allocate(sizeof(StringList));
	temp->head = NULL;
	temp->tail = NULL;
	temp->numberOfString = 0;
	return temp;
}

void addString(StringList *sl, const char *string, ...) {
	StringNode *node;
	char myString[128];

	va_list args;
	va_start(args, string);
	vsprintf(myString, string, args);
	va_end(args);

	node = (StringNode *) memorySupport_allocate(sizeof(StringNode));

	node->next =  NULL;
	strcpy(node->string, myString);

	if (sl->numberOfString == 0) {
		sl->head = node;
		sl->tail = node;
		sl->numberOfString = 1;
	} else {
		sl->tail->next = node;
		sl->tail = node;
		sl->numberOfString++;
	}
}

void addAll(StringList *slDestination, StringList *slSource) {

	slDestination->tail->next = slSource->head;

	slDestination->tail = slSource->tail;

	slDestination->numberOfString += slSource->numberOfString;

	slSource->head = NULL;
	slSource->tail = NULL;
	slSource->numberOfString = 0;
}

void releaseStringList(StringList *sl) {
	StringNode	*node = NULL;
	while (sl->numberOfString > 0) {
		node = sl->head;

		sl->head = node->next;
		sl->numberOfString--;

		node->next = NULL;
		memorySupport_dispose(node);
	}
}
