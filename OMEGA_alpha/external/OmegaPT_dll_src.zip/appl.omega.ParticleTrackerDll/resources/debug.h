#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
#include <math.h>

#include "tracker.h"

void DEBUG_initFile(const char *fileName, const char *fileMode);
void DEBUG_printFrameId(const char *fileName, int id);
void DEBUG_printLinkParticles(const char *fileName, PTFrame *ptFrame, int linkrange);
void DEBUG_printParticles(char const *fileName, PTFrame *ptFrame);
