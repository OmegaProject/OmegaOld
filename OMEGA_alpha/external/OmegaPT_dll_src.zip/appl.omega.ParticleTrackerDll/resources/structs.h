/*
 * structs.h
 *
 *  Created on: 11-mag-2009
 *      Author: grossi
 */

#ifndef STRUCTS_H_
#define STRUCTS_H_

#include "PlatformManager.h"
#include "MemoryManager.h"

typedef struct fileNameNode fileNameNode;

struct fileNameNode {
	fileNameNode* next;

	char* fileName;
};

typedef struct msgGateNode msgGateNode;

struct msgGateNode {
	msgGateNode* next;

	void* msgGate;
};

typedef struct msgGateQueue msgGateQueue;

struct msgGateQueue {
	msgGateNode* head;
	msgGateNode* tail;
	int nodesNum;
};

typedef struct evaluator evaluator;

struct evaluator {
	long time;
	unsigned int imgID;
};

static INLINE msgGateQueue* initMsgQueue() {
	msgGateQueue* queue = (msgGateQueue*) memorySupport_allocate(sizeof(msgGateQueue));
	queue->head = NULL;
	queue->tail = NULL;
	queue->nodesNum = 0;
	return queue;
}

static INLINE void addMsgNode(msgGateQueue* queue, void* msgGate) {
	msgGateNode* node = (msgGateNode*) memorySupport_allocate(sizeof(msgGateNode));
	node->next =  NULL;
	node->msgGate = msgGate;
	if (queue->nodesNum == 0) {
		queue->head = node;
		queue->tail = node;
		queue->nodesNum = 1;
	} else {
		queue->tail->next = node;
		queue->tail = node;
		queue->nodesNum++;
	}
}

static INLINE void releaseMsgQueue(msgGateQueue* queue) {
	msgGateNode* node = NULL;
	while (queue->nodesNum > 0) {
		node = queue->head;
		queue->head = node->next;
		queue->nodesNum--;
		node->next = NULL;
		memorySupport_dispose(node->msgGate);
		memorySupport_dispose(node);
	}
}

#endif /* STRUCTS_H_ */
