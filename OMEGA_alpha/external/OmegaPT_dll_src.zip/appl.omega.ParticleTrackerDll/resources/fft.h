#ifndef _FFT_H_
#define _FFT_H_

typedef struct FFT {
	int isInit;

	real *kernel_real;
	real *kernel_imag;

	real *image_real;
	real *image_imag;

	real *temp_real;
	real *temp_imag;

	int fft_width;
	int fft_height;
} FFT;

typedef struct FFTNode {
	FFT *fft;
	struct FFTNode *next;
} FFTNode;

typedef struct FFTQueue {
	FFTNode* head;
	FFTNode* tail;
	int fftNum;
} FFTQueue;

FFTQueue *FFT_InitQueue();
FFT *FFT_Get(FFTQueue *queue);
void FFT_Put(FFTQueue *queue, FFT *fft);
void FFT_ReleaseQueue(FFTQueue *queue);

void FFT_Reset(FFT *fft);
void FFT_Destroy(FFT *fft);

#endif //_FFT_H_
