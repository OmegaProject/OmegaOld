#ifndef _TRACKER_H_
#define _TRACKER_H_

#include <time.h>
#include <math.h>

#include "MemoryManager.h"
#include "PlatformManager.h"

#include "stringlist.h"

//#ifdef SINGLE_PRECISION
//	typedef float real;
//#else
//	typedef double real;
//#endif

typedef double real;

#define PT_FILE_TIFF		1
#define PT_FILE_MPEG		2

#define PT_PARAM_KERNELRADIUS	1
#define PT_PARAM_CUTOFF		2
#define PT_PARAM_PERCENTILE	3
#define PT_PARAM_DISPLACEMENT	4
#define PT_PARAM_LINKRANGE	5
#define PT_PARAM_VERBOSE	6

#define COORD(a, b, c)	(((a) * (c)) + (b))

#ifndef M_PI
	#define M_PI		3.14159265358979323846
#endif

#ifndef M_PI_2
	#define M_PI_2		1.57079632679489661923
#endif

typedef struct PTSequenceValues{
	int numberOfImages;
	int width, height;
	real min, max;
}PTSequenceValues;

typedef struct PTFrame{
	int id;
	int inUse;
	int isLast;

	char name[256];

	real *workingFrame;
	real *filtered;
	real *dilated;

	struct PTParticleList *pl;
} PTFrame;

typedef struct PTFiltered{
	int id;
	real *filtered;
} PTFiltered;

typedef struct PTThreshold{
	int id;
	real threshold;
} PTThreshold;

typedef struct PTParticle{
	real x, y;
	real m0, m2;
	real score;
	int special;
	int *next;
} PTParticle;

typedef struct PTParticleP{
	PTFrame *ptFrame;
	PTParticle *particle;
} PTParticleP;

typedef struct PTParticleList{
	int number_of_particles;
	PTParticle *particle;
} PTParticleList;

void PT_AddTrajectoriesInfoToStringList(StringList *sl);
void PT_AddSequenceInfoToStringList(StringList *sl, PTSequenceValues *sequenceValues);
void PT_AddConfigInfoToStringList(StringList *sl, int radius, real cutoff, real percentile, real displacement, int linkrange, int verbose);

void PT_InitPTFrame(PTFrame *ptFrame, int id);
void PT_AllocatePTFrame(PTFrame *ptFrame, int height, int width);
void PT_ResetPTFrame(PTFrame *ptFrame);
void PT_InitParticleNext(PTParticleList *pl, int linkrange);


int PT_WriteResults(StringList *sl, const char *fileName, time_t zeit);

int PT_GenerateTrajectories(StringList *sl, PTFrame **ptFrames, int numberOfFrames, int linkrange);
int PT_LinkParticles(PTParticleList *pl, PTParticleList *nextPl, int linkrange, real displacement, int linkPos);
PTParticle *PT_CreateParticles(int number_of_particles, int linkrange);
void PT_DestroyParticles(int number_of_particles, PTParticle *p);
int PT_ParticleCleanUp(int linkrange, PTParticleList *pl);
void PT_ParticleDiscrimination(real cutoff, PTParticleList *pl);
void PT_PositionRefinement(int* mask, int kernel_width, int width, int height, int radius, PTParticle *p, real *filtered);
real PT_FindThreshold(int width, int height, real percentile, real *input);
real *PT_GenerateKernel(real lambda, int radius);
int *PT_GenerateMask(int radius);
int PT_ReadNormalizedFrame(PTFrame *ptFrame, int *originalImage, int height, int width, real min, real max);

static INLINE real *PT_GenerateKernelGP(real lambda, int radius) {
	int width, i, j;
	real *kernel;
	double B, K0;

	width = (2 * radius) + 1;

	kernel = (real *) memorySupport_allocate(width * width * sizeof(real));
	if(kernel == NULL)
		return NULL;

	B = 0.0;
	for(i = -radius; i <= radius; i++)
		B += exp(-((double)(i * i)/(4.0 * lambda * lambda)));
	B *= B;

	K0 = 0.0;
	for(i = -radius; i <= radius; i++)
		K0 += exp(-((double)(i * i)/(2.0 * lambda * lambda)));
	K0 *= K0;
	K0 /= B;
	K0 -= (B / (double)(width * width));

	for(i = -radius; i <= radius; i++) {
		for(j = -radius; j <= radius; j++) {
			kernel[COORD(i + radius, j + radius, width)] = (real)((1.0 / B) * exp(-((double)(i * i + j * j) / (4.0 * lambda * lambda))) - (1.0 / (double)(width * width)));
			kernel[COORD(i + radius, j + radius, width)] /= (real)K0;
		}
	}

	return kernel;
};

#endif	// _TRACKER_H_
