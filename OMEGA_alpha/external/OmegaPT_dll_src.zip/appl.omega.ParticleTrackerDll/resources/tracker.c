#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>

#include "tracker.h"

#include "MemoryManager.h"

void PT_AddTrajectoriesInfoToStringList(StringList *sl) {
	addString(sl, "%% Trajectories:\n");
	addString(sl, "%%\t 1st column: frame number\n");
	addString(sl, "%%\t 2nd column: x coordinate top-down\n");
	addString(sl, "%%\t 3rd column: y coordinate left-right\n");
	addString(sl, "%%\t 4th column: zero-order intensity moment m0\n");
	addString(sl, "%%\t 5th column: second-order intensity moment m2\n");
	addString(sl, "%%\t 6th column: non-particle discrimination score\n");
	addString(sl, "\n");
}

void PT_AddSequenceInfoToStringList(StringList *sl, PTSequenceValues *sequenceValues) {
	addString(sl, "%% Analyzing %d frames\n", sequenceValues->numberOfImages);
	addString(sl, "%% Frame information:\n");
	addString(sl, "%% \tWidth : %d pixel\n", sequenceValues->width);
	addString(sl, "%% \tHeight: %d pixel\n", sequenceValues->height);
	addString(sl, "%% \tGlobal minimum: %f\n", sequenceValues->min);
	addString(sl, "%% \tGlobal maximum: %f\n", sequenceValues->max);
	if(sequenceValues->max - sequenceValues->min < 20.0)
		addString(sl, "%% \tWARNING: Intensity range is very small. Results maybe inaccurate\n");
	addString(sl, "\n");
}

void PT_AddConfigInfoToStringList(StringList *sl, int radius, real cutoff, real percentile, real displacement, int linkrange, int verbose) {
	addString(sl, "%% Configuration:\n");
	addString(sl, "%% \tKernel radius: %d\n", radius);
	addString(sl, "%% \tCutoff radius: %f\n", cutoff);
	addString(sl, "%% \tPercentile   : %f\n", percentile);
	addString(sl, "%% \tDisplacement : %f\n", displacement);
	addString(sl, "%% \tLinkrange    : %d\n", linkrange);
	addString(sl, "%% \tVerbose mode : ");
	if(verbose == 0)
		addString(sl, "off");
	else
		addString(sl, "on");
	addString(sl, "\n");
	addString(sl, "\n");
}

void PT_InitPTFrame(PTFrame *ptFrame, int id) {
	ptFrame->id = id;
	ptFrame->inUse = 1;
	ptFrame->isLast = 0;
	//ptFrame->counter = 0;
	ptFrame->workingFrame = NULL;
	ptFrame->filtered = NULL;
	ptFrame->dilated = NULL;
	ptFrame->pl = NULL;
}

void PT_ResetPTFrame(PTFrame *ptFrame) {
	PTParticleList *pl = NULL;

	ptFrame->id = -1;
	ptFrame->inUse = 0;
	ptFrame->isLast = 0;

	memset(ptFrame->name, 0, 256);

	if(ptFrame->workingFrame != NULL) {
		memorySupport_dispose(ptFrame->workingFrame);
		ptFrame->workingFrame = NULL;
	}

	if(ptFrame->filtered != NULL) {
		memorySupport_dispose(ptFrame->filtered);
		ptFrame->filtered = NULL;
	}

	if(ptFrame->dilated != NULL) {
		memorySupport_dispose(ptFrame->dilated);
		ptFrame->dilated = NULL;
	}

	if(ptFrame->pl != NULL) {
		pl = ptFrame->pl;
		if(pl->particle != NULL)
			PT_DestroyParticles(pl->number_of_particles, pl->particle);
		memorySupport_dispose(ptFrame->pl);
		ptFrame->pl = NULL;
	}
}

void PT_AllocatePTFrame(PTFrame *ptFrame, int height, int width) {
	if(ptFrame->workingFrame == NULL)
		ptFrame->workingFrame = (real *) memorySupport_allocate(width * height * sizeof(real));
	if(ptFrame->filtered == NULL)
		ptFrame->filtered = (real *) memorySupport_allocate(width * height * sizeof(real));
	if(ptFrame->dilated == NULL)
		ptFrame->dilated = (real *) memorySupport_allocate(width * height * sizeof(real));
	if(ptFrame->pl == NULL) {
		ptFrame->pl = (PTParticleList *) memorySupport_allocate(sizeof(PTParticleList));
		ptFrame->pl->number_of_particles = 0;
		ptFrame->pl->particle = NULL;
	}
}

void PT_InitParticleNext(PTParticleList *pl, int linkrange) {
	int nop, i, l;
	nop = pl->number_of_particles;
	for(i = 0; i < nop; i++) {
		pl->particle[i].special = 0;
		for(l = 0; l < linkrange; l++)
			pl->particle[i].next[l] = -1;
	}
}

int PT_WriteResults(StringList *sl, const char *fileName, time_t zeit) {
	FILE* f;
	StringNode* temp;
	char date[128];
	int i;

	if(sl == NULL)
		return 0;

	f = fopen(fileName, "w");

	sprintf(date, "%s", ctime(&zeit));
	fprintf(f, "%% %d\n", zeit);
	fprintf(f, "%% %s\n", date);

	temp = sl->head;
	if(temp == NULL)
		return 0;

	for(i = 0; i < sl->numberOfString; i++) {
		fputs(temp->string, f);
		temp = temp->next;
	}

	fclose(f);

	return 1;
}

//Used only by old version
int PT_GenerateTrajectories(StringList *sl, PTFrame **ptFrames, int numberOfFrames, int linkrange) {
	int i, j, k, m, n, found;
	int number_of_trajectories;

	number_of_trajectories = 0;

	for(i = 0; i < numberOfFrames; i++) {
		for(j = 0; j <	ptFrames[i]->pl->number_of_particles; j++) {
			if(ptFrames[i]->pl->particle[j].special == 0) {
				ptFrames[i]->pl->particle[j].special = 1;
				found = -1;
				for(n = 0; n < linkrange; n++) {
					// if it is NOT a dummy particle - stop looking
					if(ptFrames[i]->pl->particle[j].next[n] != -1) {
						found = n;
						break;
					}
				}
				// if this particle is not linked to any other
				// go to next particle and dont add a trajectory
				if(found == -1)
					continue;

				// Added by Guy Levy, 18.08.06 - A change form original implementation
				// if this particle is linked to a "real" particle that was already linked
				// break the trajectory and start again from the next particle. don't generate trajectory

				//Added by Alex Rigano, 12.11.2010
				if(i+n+1 > numberOfFrames)
					break;

				if(ptFrames[i+n+1]->pl->particle[ptFrames[i]->pl->particle[j].next[n]].special == 1)
					continue;

				addString(sl, "Trajectory id: %d\n", number_of_trajectories);

				// this particle is linked to another "real" particle that is not already linked
				// so we have a trajectory
				number_of_trajectories++;

				addString(sl, "%d %f %f %f %f %f\n", ptFrames[i]->id, ptFrames[i]->pl->particle[j].x, ptFrames[i]->pl->particle[j].y, ptFrames[i]->pl->particle[j].m0, ptFrames[i]->pl->particle[j].m2, ptFrames[i]->pl->particle[j].score);
				//PT_WriteResults(pts, "%d %f %f %f %f %f\n", i, pts->particlelist[i].particle[j].x, pts->particlelist[i].particle[j].y, pts->particlelist[i].particle[j].m0, pts->particlelist[i].particle[j].m2, pts->particlelist[i].particle[j].score);

				k = i;
				m = j;
				do {
					found = -1;
					for(n = 0; n < linkrange; n++) {
						if(ptFrames[k]->pl->particle[m].next[n] != -1) {
							// If this particle is linked to a "real" particle that
							// that is NOT already linked, continue with building the trajectory

							//Added by Alex Rigano, 12.11.2010
							if(k+n+1 >= numberOfFrames)
								break;

							if(ptFrames[k+n+1]->pl->particle[ptFrames[k]->pl->particle[m].next[n]].special == 0) {
								found = n;
								break;
								// Added by Guy Levy, 18.08.06 - A change form original implementation
								// If this particle is linked to a "real" particle that
								// that is already linked, stop building the trajectory
							} else {
								break;
							}
						}
					}
					if(found == -1)
						break;
					m = ptFrames[k]->pl->particle[m].next[found];
					k += (found + 1);

					//Added by Alex Rigano, 12.11.2010
					if(k > numberOfFrames)
						break;

					addString(sl, "%d %f %f %f %f %f\n", ptFrames[k]->id, ptFrames[k]->pl->particle[m].x, ptFrames[k]->pl->particle[m].y, ptFrames[k]->pl->particle[m].m0, ptFrames[k]->pl->particle[m].m2, ptFrames[k]->pl->particle[m].score);
					//PT_WriteResults(pts, "%d %f %f %f %f %f\n", k, pts->particlelist[k].particle[m].x, pts->particlelist[k].particle[m].y, pts->particlelist[k].particle[m].m0, pts->particlelist[k].particle[m].m2, pts->particlelist[k].particle[m].score);
					ptFrames[k]->pl->particle[m].special = 1;
				} while(m != -1);
				//PT_WriteResults(pts, "\n");
				addString(sl, "\n");
			}
		}
	}

	//PT_WriteResults(pts, "%% %d trajectories found\n", number_of_trajectories);

	//pts->result = 1;

	return number_of_trajectories;
}

int PT_LinkParticles(PTParticleList *pl, PTParticleList *nextPl, int linkrange, real displacement, int linkPos) {
	int i, j, k, nop, nop_next;
	int *g, ok, prev, prev_s, x, y;
	real *cost, min, z, max_cost;
	PTParticle *p1, *p2;

	if(nextPl == NULL)
		return 1;

	max_cost = displacement * displacement;

	max_cost = (real)(linkPos + 1) * displacement * (real)(linkPos + 1) * displacement;

	nop = pl->number_of_particles;
	nop_next = nextPl->number_of_particles;

	/* Set up the cost matrix */
	cost = (real *) memorySupport_allocate((nop + 1) * (nop_next + 1) * sizeof(real));

	/* Set up the relation matrix */
	g = (int *) memorySupport_allocate((nop + 1) * (nop_next + 1) * sizeof(int));
	if(cost == NULL || g == NULL) {
		return 0;
	}

	/* Set g to zero */
	memset(g, 0, (nop + 1) * (nop_next + 1) * sizeof(int));

	p1 = pl->particle;
	p2 = nextPl->particle;

	/* Fill in the costs */
	for(i = 0; i < nop; i++) {
		for(j = 0; j < nop_next; j++) {
			cost[COORD(i, j, nop_next + 1)] = (p1[i].x - p2[j].x)*(p1[i].x - p2[j].x) + (p1[i].y - p2[j].y)*(p1[i].y - p2[j].y) + (p1[i].m0 - p2[j].m0)*(p1[i].m0 - p2[j].m0) + (p1[i].m2 - p2[j].m2)*(p1[i].m2 - p2[j].m2);
		}
	}

	for(i = 0; i < nop + 1; i++)
		cost[COORD(i, nop_next, nop_next + 1)] = max_cost;
	for(j = 0; j < nop_next + 1; j++)
		cost[COORD(nop, j, nop_next + 1)] = max_cost;
	cost[COORD(nop, nop_next, nop_next + 1)] = 0.0;

	/* Initialize the relation matrix */
	for(i = 0; i < nop; i++) { // Loop over the x-axis
		min = max_cost;
		prev = 0;
		for(j = 0; j < nop_next; j++) { // Loop over the y-axis
			/* Let's see if we can use this coordinate */
			ok = 1;
			for(k = 0; k < nop + 1; k++) {
				if(g[COORD(k, j, nop_next + 1)] == 1) {
					ok = 0;
					break;
				}
			}
			if(ok == 0) // No, we can't. Try the next column
				continue;

			/* This coordinate is OK */
			if(cost[COORD(i, j, nop_next + 1)] < min) {
				min = cost[COORD(i, j, nop_next + 1)];
				g[COORD(i, prev, nop_next + 1)] = 0;
				prev = j;
				g[COORD(i, prev, nop_next + 1)] = 1;
			}
		}

		/* Check if we have a dummy particle */
		if(min == max_cost) {
			g[COORD(i, prev, nop_next + 1)] = 0;
			g[COORD(i, nop_next, nop_next + 1)] = 1;
		}
	}

	/* Look for columns that are zero */
	for(j = 0; j < nop_next; j++) {
		ok = 1;
		for(i = 0; i < nop + 1; i++) {
			if(g[COORD(i, j, nop_next + 1)] == 1)
				ok = 0;
		}

		if(ok == 1)
			g[COORD(nop, j, nop_next + 1)] = 1;
	}

	/* The relation matrix is initilized */

	/* Now the relation matrix needs to be optimized */
	min = -1.0;
	while(min < 0.0) {
		min = 0.0;
		prev = 0;
		prev_s = 0;
		for(i = 0; i < nop + 1; i++) {
			for(j = 0; j < nop_next + 1; j++) {
				if(i == nop && j == nop_next)
					continue;

				if(g[COORD(i, j, nop_next + 1)] == 0 && cost[COORD(i, j, nop_next + 1)] <= max_cost) {
					/* Calculate the reduced cost */

					// Look along the x-axis, including
					// the dummy particles
					for(k = 0; k < nop + 1; k++) {
						if(g[COORD(k, j, nop_next + 1)] == 1) {
							x = k;
							break;
						}
					}

					// Look along the y-axis, including
					// the dummy particles
					for(k = 0; k < nop_next + 1; k++) {
						if(g[COORD(i, k, nop_next + 1)] == 1) {
							y = k;
							break;
						}
					}

					/* z is the reduced cost */
					if(j == nop_next)
						x = nop;
					if(i == nop)
						y = nop_next;

					z = cost[COORD(i, j, nop_next + 1)] + cost[COORD(x, y, nop_next + 1)] - cost[COORD(i, y, nop_next + 1)] - cost[COORD(x, j, nop_next + 1)];
					if(z > -1.0e-10)
						z = 0.0;
					if(z < min) {
						min = z;
						prev = COORD(i, j, nop_next + 1);
						prev_s = COORD(x, y, nop_next + 1);
					}
				}
			}
		}

		if(min < 0.0) {
			g[prev] = 1;
			g[prev_s] = 1;
			g[COORD(prev / (nop_next + 1), prev_s % (nop_next + 1), nop_next + 1)] = 0;
			g[COORD(prev_s / (nop_next + 1), prev % (nop_next + 1), nop_next + 1)] = 0;
		}
	}

	/* After optimization, the particles needs to be linked */
	for(i = 0; i < nop; i++) {
		for(j = 0; j < nop_next; j++) {
			if(g[COORD(i, j, nop_next + 1)] == 1)
				p1[i].next[linkPos] = j;
		}
	}

	memorySupport_dispose(g);
	memorySupport_dispose(cost);

	return 1;
}

PTParticle *PT_CreateParticles(int number_of_particles, int linkrange) {
	int i, j;
	PTParticle *t;

	t = (PTParticle *) memorySupport_allocate(number_of_particles * sizeof(PTParticle));
	if(t == NULL)
		return NULL;

	for(i = 0; i < number_of_particles; i++) {
		t[i].next = (int *) memorySupport_allocate(linkrange * sizeof(int));
		if(t[i].next == NULL) {
			for(j = 0; j < i; j++)
				memorySupport_dispose(t[j].next);
			memorySupport_dispose(t);
			return NULL;
		}
	}

	return t;
}

void PT_DestroyParticles(int number_of_particles, PTParticle *p) {
	int i;

	if(p == NULL)
		return;

	for(i = 0; i < number_of_particles; i++) {
		if(p[i].next != NULL) {
			memorySupport_dispose(p[i].next);
			p[i].next = NULL;
		}
	}

	memorySupport_dispose(p);
	p = NULL;

	return;
}

int PT_ParticleCleanUp(int linkrange, PTParticleList *pl) {
	int i, p, number_of_particles;
	PTParticle *new_particle;

	if(pl->particle == NULL) {
		return 0;
	}

	/* Count how many particles are not discriminated */
	number_of_particles = 0;
	for(i = 0; i < pl->number_of_particles; i++) {
		if(pl->particle[i].special == 1)
			number_of_particles++;
	}

	new_particle = PT_CreateParticles(number_of_particles, linkrange);
	if(new_particle == NULL)
		return 0;

	/* Copy the particles to the new array */
	p = 0;
	for(i = 0; i < pl->number_of_particles; i++) {
		if(pl->particle[i].special == 1) {
			new_particle[p].x = pl->particle[i].x;
			new_particle[p].y = pl->particle[i].y;
			new_particle[p].m0 = pl->particle[i].m0;
			new_particle[p].m2 = pl->particle[i].m2;
			new_particle[p].score = pl->particle[i].score;
			new_particle[p].special = 1;
			p++;
		}
	}

	PT_DestroyParticles(pl->number_of_particles, pl->particle);

	pl->number_of_particles = number_of_particles;

	/* Release the memory of the old array */
	pl->particle = new_particle;

	return 1;
}

//FIXME rimuovere accessi multipli all'array estraendo p2 come pl->particle[k] nel secondo for loop
void PT_ParticleDiscrimination(real cutoff, PTParticleList *pl) {
	int j, k;
	real score;
	PTParticle *p;

	for(j = 0; j < pl->number_of_particles; j++) {
		p = &pl->particle[j];

		for(k = j + 1; k < pl->number_of_particles; k++) {
			score = (real)((1.0 / (2.0 * M_PI * 0.1 * 0.1)) * exp(-(p->m0 - pl->particle[k].m0)*(p->m0 - pl->particle[k].m0) / (2.0 * 0.1) - (p->m2 - pl->particle[k].m2)*(p->m2 - pl->particle[k].m2) / (2.0 * 0.1)));
			p->score += score;
			pl->particle[k].score += score;
		}

		if(p->score < cutoff)
			p->special = 0;
	}

	return;
}

void PT_PositionRefinement(int* mask, int kernel_width, int width, int height, int radius, PTParticle *p, real *filtered) {
	int j, k, l, x, y, tx, ty;
	real epsx, epsy, c;

	/* Set every value that ist smaller than 0 to 0 */
	for(j = 0; j < width * height; j++) {
		if(filtered[j] < 0.0)
			filtered[j] = 0.0;
	}

	p->special = 1;
	p->score = 0.0;
	epsx = epsy = 1.0;

	while(epsx > 0.5 || epsx < -0.5 || epsy > 0.5 || epsy < -0.5) {
		p->m0 = 0.0;
		p->m2 = 0.0;
		epsx = epsy = 0.0;
		for(k = -radius; k <= radius; k++) {
			if(((int)p->x + k) < 0 || ((int)p->x + k) >= height)
				continue;
			x = (int)p->x + k;

			for(l = -radius; l <= radius; l++) {
				if(((int)p->y + l) < 0 || ((int)p->y + l) >= width)
					continue;
				y = (int)p->y + l;

				c = filtered[COORD(x, y, width)] * (real)mask[COORD(k + radius, l + radius, kernel_width)];
				p->m0 += c;
				epsx += (real)k * c;
				epsy += (real)l * c;
				p->m2 += (real)(k * k + l * l) * c;
			}
		}

		epsx /= p->m0;
		epsy /= p->m0;
		p->m2 /= p->m0;

		// This is a little hack to avoid numerical inaccuracy
		tx = (int)(10.0 * epsx);
		ty = (int)(10.0 * epsy);

		if((real)(tx)/10.0 > 0.5) {
			if((int)p->x + 1 < height)
				p->x++;
		}
		else if((real)(tx)/10.0 < -0.5) {
			if((int)p->x - 1 >= 0)
				p->x--;
		}

		if((real)(ty)/10.0 > 0.5) {
			if((int)p->y + 1 < width)
				p->y++;
		}
		else if((real)(ty)/10.0 < -0.5) {
			if((int)p->y - 1 >= 0)
				p->y--;
		}

		if((real)(tx)/10.0 <= 0.5 && (real)(tx)/10.0 >= -0.5 && (real)(ty)/10.0 <= 0.5 && (real)(ty)/10.0 >= -0.5)
			break;
	}

	p->x += epsx;
	p->y += epsy;
}

real PT_FindThreshold(int width, int height, real percentile, real *input) {
	int i, thold;
	real min, max;
	real *hist;

	min = max = input[0];

	for(i = 1; i < width * height; i++) {
		if(input[i] < min)
			min = input[i];
		else if(input[i] > max)
			max = input[i];
	}

	if (min == max)
		// FIXME � corretto??
		// Questa condizione serve ad evitare una divisione per zero
		// alcune righe pi� sotto.
		// Min e max sono uguali quando l'immagine �, ad esempio, completamente
		// nera, bianca, grigia, ...
		return 0.0;

	hist = (real *) memorySupport_allocate(256 * sizeof(real));
	if(hist == NULL)
		return 0.0;

	memset(hist, 0, 256 * sizeof(real));

	for(i = 0; i < width * height; i++)
		hist[(int)((input[i] - min) * 255.0 / (max - min))]++;

	for(i = 254; i >= 0; i--)
		hist[i] += hist[i + 1];

	thold = 0;
	while(hist[255 - thold] / hist[0] < percentile) {
		thold++;
		if(thold > 255)
			break;
	}

	thold = 255 - thold + 1;

	memorySupport_dispose(hist);

	return ((real)(thold / 255.0) * (max - min) + min);
}

int *PT_GenerateMask(int radius) {
	int width, i, j;
	int *mask;

	width = (2 * radius) + 1;

	mask = (int *) memorySupport_allocate(width * width * sizeof(int));
	if(mask == NULL)
		return 0;

	for(i = -radius; i <= radius; i++) {
		for(j = -radius; j <= radius; j++) {
			if((i * i) + (j * j) <= radius * radius)
				mask[COORD(i + radius, j + radius, width)] = 1;
			else
				mask[COORD(i + radius, j + radius, width)] = 0;
		}
	}

	return mask;
}

real *PT_GenerateKernel(real lambda, int radius) {
	int width, i, j;
	real *kernel;
	double B, K0;

	width = (2 * radius) + 1;

	kernel = (real *) memorySupport_allocate(width * width * sizeof(real));
	if(kernel == NULL)
		return NULL;

	B = 0.0;
	for(i = -radius; i <= radius; i++)
		B += exp(-((double)(i * i)/(4.0 * lambda * lambda)));
	B *= B;

	K0 = 0.0;
	for(i = -radius; i <= radius; i++)
		K0 += exp(-((double)(i * i)/(2.0 * lambda * lambda)));
	K0 *= K0;
	K0 /= B;
	K0 -= (B / (double)(width * width));

	for(i = -radius; i <= radius; i++) {
		for(j = -radius; j <= radius; j++) {
			kernel[COORD(i + radius, j + radius, width)] = (real)((1.0 / B) * exp(-((double)(i * i + j * j) / (4.0 * lambda * lambda))) - (1.0 / (double)(width * width)));
			kernel[COORD(i + radius, j + radius, width)] /= (real)K0;
		}
	}

	return kernel;
}

int PT_ReadNormalizedFrame(PTFrame *ptFrame, int *originalImage, int height, int width, real min, real max) {
	int c, i;

	if(originalImage == NULL)
		return 0;

	if(ptFrame->workingFrame == NULL)
		return 0;

	for(i = 0; i < width * height; i++) {
		c = originalImage[i];
		ptFrame->workingFrame[i] = ((real)c - min) / (max - min);
	}
	return 1;
}
