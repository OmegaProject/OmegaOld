#ifndef _DILATE_H_
#define _DILATE_H_

real *PT_DilateGeneric(int *mask, int kernel_width, int width, int height,  int radius, real *dilated, real *input);
real *PT_Dilate1(int *mask, int width, int height, real *dilated, real *input);
real *PT_Dilate2(int *mask, int width, int height, real *dilated, real *input);
real *PT_Dilate3(int *mask, int width, int height, real *dilated, real *input);
real *PT_Dilate4(int *mask, int width, int height, real *dilated, real *input);
real *PT_Dilate5(int *mask, int width, int height, real *dilated, real *input);

#endif	// _DILATE_H_
