#ifndef SHAREDMEMORY_H_
#define SHAREDMEMORY_H_

extern __shared__ real sharedMem[];

#endif //SHAREDMEMORY_H_
