#ifndef STRUCTPTFRAME_H_
#define STRUCTPTFRAME_H_

#include "PlatformManager.h"
#include "MemoryManager.h"
#include "tracker.h"

typedef struct PTFrameNode {
	struct PTFrameNode *next;
	PTFrame *ptFrame;
}PTFrameNode;

typedef struct PTFrameQueue {
	PTFrameNode *head;
	PTFrameNode *tail;
	int nodesNum;
}PTFrameQueue;

static INLINE PTFrameQueue *initPTFrameQueue() {
	PTFrameQueue *queue = (PTFrameQueue *) memorySupport_allocate(sizeof(PTFrameQueue));
	queue->head = NULL;
	queue->tail = NULL;
	queue->nodesNum = 0;
	return queue;
}

static INLINE void addPTFrameNode(PTFrameQueue *queue, PTFrame *ptFrame) {
	PTFrameNode *node = (PTFrameNode *) memorySupport_allocate(sizeof(PTFrameNode));
	node->next =  NULL;
	node->ptFrame = ptFrame;
	if (queue->nodesNum == 0) {
		queue->head = node;
		queue->tail = node;
		queue->nodesNum = 1;
	} else {
		queue->tail->next = node;
		queue->tail = node;
		queue->nodesNum++;
	}
}

static INLINE void releasePTFrameQueue(PTFrameQueue *queue) {
	PTFrameNode *node = NULL;
	PTFrame *ptFrame = NULL;
	PTParticleList *pl = NULL;
	while (queue->nodesNum > 0) {
		node = queue->head;
		queue->head = node->next;
		queue->nodesNum--;
		node->next = NULL;
		//elimino tutti i campi aggiuntivi del ptFrame
		ptFrame = node->ptFrame;
		if(ptFrame->workingFrame != NULL)
			memorySupport_dispose(ptFrame->workingFrame);
		if(ptFrame->filtered != NULL)
			memorySupport_dispose(ptFrame->filtered);
		if(ptFrame->dilated != NULL)
			memorySupport_dispose(ptFrame->dilated);
		if(ptFrame->pl != NULL) {
			pl = ptFrame->pl;
			if(pl->particle != NULL)
				PT_DestroyParticles(pl->number_of_particles, pl->particle);
			memorySupport_dispose(ptFrame->pl);
		}
		memorySupport_dispose(ptFrame);
		memorySupport_dispose(node);
	}
}

#endif /* STRUCTPTFRAME_H_ */
