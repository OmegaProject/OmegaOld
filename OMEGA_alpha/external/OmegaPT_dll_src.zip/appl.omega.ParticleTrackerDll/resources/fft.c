#include <stdio.h>
#ifdef _WIN32	// For the Sleep(...) function
#include <windows.h>
#endif
#include "tracker.h"
#include "convolve.h"
#include "sing.h"
#include "fft.h"

#include "MemoryManager.h"

FFTQueue *FFT_InitQueue() {
	FFTQueue* queue = (FFTQueue*) memorySupport_allocate(sizeof(FFTQueue));
	queue->head = NULL;
	queue->tail = NULL;
	queue->fftNum = 0;
	return queue;
}

FFT *FFT_Get(FFTQueue *queue) {
	FFT *fft;
	FFTNode *node;
	if(queue->fftNum == 0) {
		fft = memorySupport_allocate(sizeof(FFT));
		FFT_Reset(fft);
		return fft;
	} else {
		node = queue->head;
		fft = node->fft;
		queue->head = node->next;
		queue->fftNum--;
		node->next = NULL;
		node->fft = NULL;
		memorySupport_dispose(node);
		return fft;
	}
}

void FFT_Put(FFTQueue *queue, FFT *fft) {
	FFTNode *node = (FFTNode *) memorySupport_allocate(sizeof(FFTNode));
	node->fft = fft;
	node->next = NULL;
	if(queue->fftNum == 0) {
		queue->head = node;
		queue->tail = node;
		queue->fftNum = 1;
	} else {
		queue->tail->next = node;
		queue->tail = node;
		queue->fftNum++;
	}
}

void FFT_ReleaseQueue(FFTQueue* queue) {
	FFTNode *node = NULL;
	while (queue->fftNum > 0) {
		node = queue->head;
		queue->head = node->next;
		queue->fftNum--;
		node->next = NULL;
		FFT_Destroy(node->fft);
		memorySupport_dispose(node->fft);
		memorySupport_dispose(node);
	}
}

void FFT_Reset(FFT *fft) {
	fft->isInit = 0;
	fft->kernel_real = NULL;
	fft->kernel_imag = NULL;
	fft->image_real = NULL;
	fft->image_imag = NULL;
	fft->temp_real = NULL;
	fft->temp_imag = NULL;
	fft->fft_width = 0;
	fft->fft_height = 0;
}

void FFT_Destroy(FFT *fft) {
	if(fft->kernel_real != NULL) {
		memorySupport_dispose(fft->kernel_real);
		fft->kernel_real = NULL;
	}
	if(fft->kernel_imag != NULL) {
		memorySupport_dispose(fft->kernel_imag);
		fft->kernel_imag = NULL;
	}
	if(fft->image_real != NULL) {
		memorySupport_dispose(fft->image_real);
		fft->image_real = NULL;
	}
	if(fft->image_imag != NULL) {
		memorySupport_dispose(fft->image_imag);
		fft->image_imag = NULL;
	}
	if(fft->temp_real != NULL) {
		memorySupport_dispose(fft->temp_real);
		fft->temp_real = NULL;
	}
	if(fft->temp_imag != NULL) {
		memorySupport_dispose(fft->temp_imag);
		fft->temp_imag = NULL;
	}
}
